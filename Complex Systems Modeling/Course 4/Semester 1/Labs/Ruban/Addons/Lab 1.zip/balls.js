
const w = 600
const h = 600
const d = 40
let balls = []
let overlapers = []
let BLUE;
let PURPLE;
const lifeTimeMs = 15000;
let currTime, elapsedTime, prevTime = 0
const BALL_COUNT = 10
const MAX_BALLS = 60

function dynamicColision(ballI, ballJ) {
	let xDiff = (ballI.pos.x - ballJ.pos.x) * (ballI.pos.x - ballJ.pos.x);
	let yDiff = (ballI.pos.y - ballJ.pos.y) * (ballI.pos.y - ballJ.pos.y);
	let distance = sqrt(xDiff + yDiff);

	const nx = (ballJ.pos.x - ballI.pos.x) / distance;
	const ny = (ballJ.pos.y - ballI.pos.y) / distance;

	const tgX = -ny;
	const tgY = nx;

	const dotProdTg1 = ballI.vel.x * tgX + ballI.vel.y * tgY;
	const dotProdTg2 = ballJ.vel.x * tgX + ballJ.vel.y * tgY;

	const dotProdNorm1 = ballI.vel.x * nx + ballI.vel.y * ny;
	const dotProdNorm2 = ballJ.vel.x * nx + ballJ.vel.y * ny;

	const massSum = (ballJ.mass + ballI.mass);

	const m1 = (dotProdNorm1 * (ballI.mass - ballJ.mass) + 2*ballJ.mass*dotProdNorm2) / massSum
	const m2 = (dotProdNorm2 * (ballJ.mass - ballI.mass) + 2*ballI.mass*dotProdNorm1) / massSum

	ballI.vel.x = tgX * dotProdTg1 + nx * m1;
	ballI.vel.y = tgY * dotProdTg1 + ny * m1;

	ballJ.vel.x = tgX * dotProdTg2 + nx * m2;
	ballJ.vel.y = tgY * dotProdTg2 + ny * m2;

	onLabCollision(ballI, ballJ);
}

function onCollision(ballI, ballJ) {
	let xDiff = (ballI.pos.x - ballJ.pos.x) * (ballI.pos.x - ballJ.pos.x);
	let yDiff = (ballI.pos.y - ballJ.pos.y) * (ballI.pos.y - ballJ.pos.y);
	let distance = sqrt(xDiff + yDiff);

	const overlap = 0.5*(distance - ballI.d/2 - ballJ.d/2)
	ballI.pos.x -= overlap * (ballI.pos.x - ballJ.pos.x) / distance;
	ballI.pos.y -= overlap * (ballI.pos.y - ballJ.pos.y) / distance;
	ballJ.pos.x += overlap * (ballI.pos.x - ballJ.pos.x) / distance;
	ballJ.pos.y += overlap * (ballI.pos.y - ballJ.pos.y) / distance;
}

function onLabCollision(ballI, ballJ) {
	if(ballJ.color != ballI.color) {
		const lowVel = ballI.vel.mag() < ballJ.vel.mag() ? ballI : ballJ;
		const highVel = lowVel == ballJ ? ballI : ballJ;
		const index = balls.indexOf(lowVel);
		if(index == -1)
		  return;
		balls.splice(index, 1);
		highVel.life = lifeTimeMs;
	} else {
		if (random() < 0.5) {
			createBall(ballJ.color, ballJ.vel.copy().add(ballI.vel))
		}
	}
}

function setup() {
	createCanvas(w, h);
	frameRate(60)
	BLUE = color(0, 0, 255)
  PURPLE = color(100, 0, 255)
	for(let i = 0; i < BALL_COUNT; i++) {
		createBall();
	}
}

function createBall(color, vel) {
	let pos;
	if(balls.length > MAX_BALLS) return;
	if(balls.length > MAX_BALLS / 2) {
		const cols = w / d;
		const rows = h / d;
		let flag = false
		for (let j = 1; j < rows; j++) {
			for (let i = 1; i < cols; i++) {
			pos = createVector(i * d, j * d)
			flag = balls.every(ball => {
					const xDiff = (ball.pos.x - pos.x) * (ball.pos.x - pos.x);
					const yDiff = (ball.pos.y - pos.y) * (ball.pos.y - pos.y);
					const distance = sqrt(xDiff + yDiff);
					return distance > d;
				});
			if(flag)
			break;
			};
			if(flag)
				break;
		}
		if(!flag)
			return;
	} else {
		pos = createVector(random(d, w - d), random(d, h - d));
	}
	
	
	if(!vel){
		vel = p5.Vector.random2D();
		vel.mult(5)
	}

	
	if(!color) {
		color = random() < 0.5 ? BLUE : PURPLE;
	}

	const ball = new Ball(pos, vel, d, color, lifeTimeMs)
	balls.push(ball);
}

function draw() {
	currTime = millis();
	elapsedTime = (currTime - prevTime) 
	prevTime = currTime
	background(100)
	balls.forEach(ball => {
		ball.draw()
		ball.update()
		ball.life -= elapsedTime
	});
	balls.forEach(ball => {
		if(ball.pos.x <= d/2 || ball.pos.x >= w - d/2) {
			ball.vel.x *= -1
		}

		if(ball.pos.y <= d/2 || ball.pos.y >= h - d/2) {
			ball.vel.y *=  -( 1 - ball.k)
		}
		if(ball.pos.x < d/2){
			ball.pos.x = d/2
		}
		if(ball.pos.y < d/2){
			ball.pos.y = d/2
		}

		if(ball.pos.x > w - d/2){
			ball.pos.x = w - d/2
		}
		if(ball.pos.y >  h - d/2){
			ball.pos.y =  h - d/2
		}
	});

	for (let i = 0; i < balls.length; i++) {
		const ballI = balls[i];
		for (let j = 0; j < balls.length; j++) {
			const ballJ = balls[j];
			if(i == j) continue;
			const xDiff = (ballI.pos.x - ballJ.pos.x) * (ballI.pos.x - ballJ.pos.x);
			const yDiff = (ballI.pos.y - ballJ.pos.y) * (ballI.pos.y - ballJ.pos.y);
			const rSum = (ballI.d/2 + ballJ.d/2) * (ballI.d/2 + ballJ.d/2);
			if(xDiff + yDiff <= rSum) {
				onCollision(ballI, ballJ);
				overlapers.push({ballI, ballJ});
			}
		}
	}
	overlapers.forEach(op => {
		dynamicColision(op.ballI, op.ballJ);
	})
	overlapers = []
	balls = balls.filter(ball => ball.life > 0)
}
