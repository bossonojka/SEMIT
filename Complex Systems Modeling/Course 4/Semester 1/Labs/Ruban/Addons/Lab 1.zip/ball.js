
const g = 0.2;

class Ball {
	constructor(pos, vel, d, color, life) {
		this.pos = pos;
		this.vel = vel;
		this.color = color;
		this.d = d;
		this.mass = 1;
		this.k = 0.01;
		this.a = createVector(0, g)
		this.life = life;
	}

	draw() {
		fill(this.color)
		ellipse(this.pos.x, this.pos.y, this.d, this.d);
		fill(255)
		text(Math.round(this.life / 1000), this.pos.x - 5, this.pos.y + 3)
	}

	update() {
		this.vel.add(this.a)
		this.vel.add(createVector(-this.vel.x * this.k, -this.vel.y * this.k))
		this.pos.add(this.vel)
	}
}
