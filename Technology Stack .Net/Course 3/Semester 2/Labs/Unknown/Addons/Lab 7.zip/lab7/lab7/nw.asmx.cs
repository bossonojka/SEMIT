﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using System.Data.SqlClient;

namespace lab7
{
    /// <summary>
    /// Summary description for nw
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class nw : System.Web.Services.WebService
    {

        [WebMethod]
        public DataSet GetInfo(string conn)
        {
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter("Select * from Product", conn);
            DataSet productsDataSet = new DataSet();
            sqlDataAdapter.Fill(productsDataSet, "Products");

            return productsDataSet;
        }

        [WebMethod]
        public DataSet Add(string conn, string name, string developer, decimal price)
        {
            using (SqlConnection connection = new SqlConnection(conn))
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand("insert into Product values(@name, @price, @dev)", connection))
                {
                    cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = name;
                    cmd.Parameters.Add("@dev", SqlDbType.NVarChar).Value = developer;
                    cmd.Parameters.Add("@price", SqlDbType.Decimal).Value = price;

                    cmd.ExecuteNonQuery();
                }
            }

            return GetInfo(conn);
        }

        [WebMethod]
        public DataSet Delete(string conn, int id)
        {
            using (SqlConnection connection = new SqlConnection(conn))
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand("delete from Product where id = @id", connection))
                {
                    cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;

                    cmd.ExecuteNonQuery();
                }
            }

            return GetInfo(conn);
        }
    }
}
