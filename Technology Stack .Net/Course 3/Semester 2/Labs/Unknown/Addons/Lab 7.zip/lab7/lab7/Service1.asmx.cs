﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using System.Data.SqlClient;


namespace lab7 {
    /// <summary>
    /// Summary description for Service1
    /// </summary>    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    public class FirstWebService : System.Web.Services.WebService 
    {
        [WebMethod]
        public DataSet GetInfo(string conn) {
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter("Select * from Product", conn);
            DataSet productsDataSet = new DataSet();
            sqlDataAdapter.Fill(productsDataSet, "Products");

            return productsDataSet;
        }
    }
}