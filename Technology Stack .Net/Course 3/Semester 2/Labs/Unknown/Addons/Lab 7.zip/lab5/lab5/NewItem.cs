﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace lab5
{
    /// <summary>
    /// Класс, описывающий бизнес-объект - элемент новости
    /// </summary>
    public class WorkerItem : System.Web.UI.Page
    {
        private string name;
        private string developer;
        private string position;

        public string Name { get {return name;}  set {name = value;} }
        public string Developer { get {return developer; } set {developer = value;}  }
        public string Position { get {return position;}  set { position = value;} }

        public WorkerItem(string name, string developer, string position)
        {
            this.Name = name;
            this.Developer = developer;
            this.Position = position;

        }
        public WorkerItem()
        {

        }


 


    }
}