﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services.Description;
using System.Web.UI;
using System.Web.UI.WebControls;
using lab5.itemsService;

namespace lab5
{
    public partial class Default : System.Web.UI.Page
    {
        const string conn = @"Data Source=ADMIN;Initial Catalog=lab6;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                nw items = new nw();

                GridView2.DataSource = items.GetInfo(conn);
                GridView2.DataBind();
            }
        }

        protected void GridView2_OnRowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "Delete") return;
            int id = Convert.ToInt32(e.CommandArgument) ;

            nw items = new nw();

            GridView2.DataSource = items.Delete(conn, id);
            GridView2.DataBind();
        }

        protected void Add(object sender, EventArgs e)
        {
            if (TextBox1.Text == string.Empty || TextBox2.Text == string.Empty || TextBox3.Text == string.Empty)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('please complete all the fields')", true);
                return;
            }

            nw items = new nw();

            string name = TextBox1.Text;
            string developer = TextBox2.Text;
            decimal price = decimal.Parse(TextBox3.Text);


            GridView2.DataSource = items.Add(conn, name, developer, price);
            GridView2.DataBind();

            TextBox1.Text = String.Empty;
            TextBox2.Text = String.Empty;
            TextBox3.Text = String.Empty;
        }

        protected void GridView2_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            nw items = new nw();

            GridView2.DataSource = items.GetInfo(conn);
            GridView2.DataBind();
        }
    }
}