﻿using Lab7Service.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace Lab7Service
{
    /// <summary>
    /// Сводное описание для CallerWebService
    /// </summary>
    [WebService(Namespace = "http://lab7.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Чтобы разрешить вызывать веб-службу из скрипта с помощью ASP.NET AJAX, раскомментируйте следующую строку. 
    // [System.Web.Script.Services.ScriptService]
    public class CallerWebService : System.Web.Services.WebService
    {
        ProductsEntities productsEntities;

        public CallerWebService()
        {
            productsEntities = new ProductsEntities();
        }

        [WebMethod]
        public List<CallerModel> Callers()
        {
            return productsEntities.Callers.Select(x => new CallerModel { Id = x.Id, Name = x.Name, Number = x.Number }).ToList();
        }

        [WebMethod]
        public CallerModel Caller(int id)
        {
            var prod = productsEntities.Callers.Find(id);
            if (prod == null)
                return null;

            return new CallerModel(prod);
        }
        [WebMethod]
        public void DeleteCaller(int id)
        {
            productsEntities.Callers.Remove(productsEntities.Callers.Find(id));
            productsEntities.SaveChanges();
        }

        [WebMethod]
        public void UpdateCaller(int id, CallerModel model)
        {
            var prod = productsEntities.Callers.Find(id);
            if (prod == null)
                return;

            prod.Name = model.Name;
            prod.Number = model.Number;
            productsEntities.SaveChanges();
        }

        [WebMethod]
        public void AddCaller(CallerModel model)
        {
            Caller product = new Caller();
            product.Name = model.Name;
            product.Number = model.Number;
            productsEntities.Callers.Add(product);
            productsEntities.SaveChanges();
        }

        //////////////////////////////////////////////////
       
        [WebMethod]
        public List<CallModel> Calls()
        {
            return productsEntities.Calls.Select(x => new CallModel { CallerId = x.CallerId, CalledId = x.CalledId, Duration = x.Duration, isActive = x.isActive, Date = x.Date }).ToList();
        }

        [WebMethod]
        public CallModel Call(int callerId, int calledId)
        {
            var prod = productsEntities.Calls.FirstOrDefault(x => x.CallerId == callerId && x.CalledId == calledId);
            if (prod == null)
                return null;

            return new CallModel(prod);
        }
        [WebMethod]
        public void DeleteCall(int callerId, int calledId)
        {
            productsEntities.Calls.Remove(productsEntities.Calls.FirstOrDefault(x => x.CallerId == callerId && x.CalledId == calledId));
            productsEntities.SaveChanges();
        }

        [WebMethod]
        public void UpdateCall(int callerId, int calledId, CallModel model)
        {
            var prod = productsEntities.Calls.FirstOrDefault(x => x.CallerId == callerId && x.CalledId == calledId);
            if (prod == null)
                return;

            prod.Date = model.Date;
            prod.Duration = model.Duration;
            prod.isActive = model.isActive;
            productsEntities.SaveChanges();
        }

        [WebMethod]
        public void AddCall(CallModel model)
        {
            Call product = new Call();

            product.CallerId = model.CallerId;
            product.CalledId = model.CalledId;

            product.Date = model.Date;
            product.Duration = model.Duration;
            product.isActive = model.isActive;

            productsEntities.Calls.Add(product);
            productsEntities.SaveChanges();
        }
    }
}
