﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebService.ProductService;

namespace Lab7MVC.Controllers
{
    public class CallerController : Controller
    {
        CallerWebService productSevice = new CallerWebService();

        // GET: Caller
        public ActionResult Index()
        {
            return View(productSevice.Callers());
        }

        // GET: Caller/Details/5
        public ActionResult Details(int id)
        {
            return View(productSevice.Caller(id));
        }

        // GET: Caller/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Caller/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here
                CallerModel model = new CallerModel();
                model.Name = collection["Name"];
                model.Number = int.Parse(collection["Number"]);
                productSevice.AddCaller(model);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Caller/Edit/5
        public ActionResult Edit(int id)
        {
            return View(productSevice.Caller(id));
        }

        // POST: Caller/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here
                CallerModel model = new CallerModel();
                model.Name = collection["Name"];
                model.Number = int.Parse(collection["Number"]);
                productSevice.UpdateCaller(id, model);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Caller/Delete/5
        public ActionResult Delete(int id)
        {
            return View(productSevice.Caller(id));
        }

        // POST: Caller/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                productSevice.DeleteCaller(id);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
