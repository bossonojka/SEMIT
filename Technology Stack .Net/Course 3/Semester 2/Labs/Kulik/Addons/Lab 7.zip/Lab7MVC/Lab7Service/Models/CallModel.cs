﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lab7Service.Models
{
    public class CallModel
    {
        public CallModel()
        {

        }

        public CallModel(Call call)
        {
            CallerId = call.CallerId;
            CalledId = call.CalledId;
            Duration = call.Duration;
            this.isActive = call.isActive;
            Date = call.Date;
        }


        public int CallerId { get; set; }
        public int CalledId { get; set; }
        public int Duration { get; set; }
        public int isActive { get; set; }
        public System.DateTime Date { get; set; }
    }
}