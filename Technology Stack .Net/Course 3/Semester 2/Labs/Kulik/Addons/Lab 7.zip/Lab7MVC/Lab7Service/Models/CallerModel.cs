﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lab7Service.Models
{
    public class CallerModel
    {
        public CallerModel()
        {

        }

        public CallerModel(Caller caller)
        {
            Id = caller.Id;
            Name = caller.Name;
            Number = caller.Number;
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public int Number { get; set; }
    }
}