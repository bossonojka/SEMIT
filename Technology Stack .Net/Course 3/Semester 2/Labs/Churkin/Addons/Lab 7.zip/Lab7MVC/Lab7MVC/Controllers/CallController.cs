﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebService.ProductService;

namespace Lab7MVC.Controllers
{
    public class CallModelExt
    {
        public string CallerName { get; set; }
        public string CalledName { get; set; }

        public long CallerNumber { get; set; }
        public long CalledNumber { get; set; }

        public int CallerId { get; set; }
        public int CalledId { get; set; }
        public DateTime Date { get; set; }
        public int Duration { get; set; }
        public bool isActive { get; set; }
    }
    public class CallController : Controller
    {
        CallerWebService service = new CallerWebService();

        CallModelExt FromCallModel(CallModel model)
        {
            CallModelExt res = new CallModelExt();
            res.Date = model.Date;
            res.isActive = model.isActive != 0;
            res.Duration = model.Duration;
            res.CallerId = model.CallerId;
            res.CallerName = service.Caller(model.CallerId).Name;
            res.CalledId = model.CalledId;
            var p = service.Caller(model.CalledId);
            res.CalledName = p.Name;
            res.CalledNumber = p.Number;
            res.CallerNumber = service.Caller(model.CallerId).Number;
            return res;
        }

        // GET: Call
        public ActionResult Index()
        {
            return View(service.Calls().Select(x => FromCallModel(x)));
        }

        private void FillViewBag()
        {
            ViewBag.Callers = service.Callers().Select(x => new SelectListItem { Text = x.Number.ToString() + " [" + x.Name.ToString() + "]", Value = x.Id.ToString() });
            ViewBag.Calleds = service.Callers().Select(x => new SelectListItem { Text = x.Number.ToString() + " [" + x.Name.ToString() + "]", Value = x.Id.ToString() });
        }

        // GET: Call/Details/5
        public ActionResult Details(int callerId, int calledId)
        {
            return View(FromCallModel(service.Call(callerId, calledId)));
        }

        // GET: Call/Create
        public ActionResult Create()
        {
            FillViewBag();
            return View();
        }

        // POST: Call/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here
                CallModel model = new CallModel
                {
                    CallerId = int.Parse(collection["Callers"]),
                    CalledId = int.Parse(collection["Calleds"]),
                    Duration = int.Parse(collection["Duration"]),
                    isActive = collection["isActive"] == "on" ? 1 : 0,
                    Date = DateTime.Now
                };
                service.AddCall(model);
                return RedirectToAction("Index");
            }
            catch
            {
                FillViewBag();
                return View();
            }
        }

        // GET: Call/Edit/5
        public ActionResult Edit(int callerId, int calledId)
        {
            FillViewBag();
            return View(FromCallModel(service.Call(callerId, calledId)));
        }

        // POST: Call/Edit/5
        [HttpPost]
        public ActionResult Edit(int callerId, int calledId, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here
                CallModel model = new CallModel
                {
                    CallerId = int.Parse(collection["Callers"]),
                    CalledId = int.Parse(collection["Calleds"]),
                    Duration = int.Parse(collection["Duration"]),
                    isActive = collection["isActive"] == "on" ? 1 : 0,
                    Date = DateTime.Now
                };
                service.UpdateCall(callerId, calledId, model);
                return RedirectToAction("Index");
            }
            catch
            {
                FillViewBag();
                return View();
            }
        }

        // GET: Call/Delete/5
        public ActionResult Delete(int callerId, int calledId)
        {
            return View(FromCallModel(service.Call(callerId, calledId)));
        }

        // POST: Call/Delete/5
        [HttpPost]
        public ActionResult Delete(int callerId, int calledId, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                service.DeleteCall(callerId, calledId);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}