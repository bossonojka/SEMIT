﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace EntityFrameworkDatabaseFirst.Controllers
{
    public class NotepadController : Controller
    {
        NotepadContext db = new NotepadContext();

        public ActionResult Index()
        {
            return View(db.Notepads.ToList());
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            Notepad notepad = db.Notepads.Find(id);
            if (notepad == null)
            {
                return HttpNotFound();
            }
            return View(notepad);
        }


        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Notepad notepad)
        {
            if (ModelState.IsValid)
            {
                db.Notepads.Add(notepad);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(notepad);
        }

        
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            Notepad notepad = db.Notepads.Find(id);
            if (notepad == null)
            {
                return HttpNotFound();
            }
            return View(notepad);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Notepad notepad)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    db.Entry(notepad).State = System.Data.Entity.EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                return View(notepad);
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            Notepad notepad = db.Notepads.Find(id);
            if (notepad == null)
            {
                return HttpNotFound();
            }
            return View(notepad);
        }

       
        public ActionResult DisplayImage()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int? id, Notepad note)
        {
            try
            {
                Notepad notepad = new Notepad();
              
                if (ModelState.IsValid)
                {
                    if (id == null)
                    {
                        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                    }

                    notepad = db.Notepads.Find(id);
                    if(notepad == null)
                    {
                        return HttpNotFound();
                    }
                    db.Notepads.Remove(notepad);
                    db.SaveChanges();
                    return RedirectToAction("Index");

                }
                return View(notepad);
            }
            catch
            {
                return View();
            }
        }
    }
}