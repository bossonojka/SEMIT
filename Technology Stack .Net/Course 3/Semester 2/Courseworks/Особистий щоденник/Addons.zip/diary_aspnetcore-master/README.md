# OOP Assignment BKU 2017

website: http://bkudiary.azurewebsites.net/

## Group
- 1611617 Nguyen Anh Khoa
- 1611660 Tran Dang Khoi
- 1610512 Ung Van Duy
- 1610303 Le Vinh Chi


This project uses ASP.NET Core a new framework to build .NET project

---

Coding Style

Please use omnisharp and use the omnisharp.json to modify your code before commiting

---

I don't know about licensing
