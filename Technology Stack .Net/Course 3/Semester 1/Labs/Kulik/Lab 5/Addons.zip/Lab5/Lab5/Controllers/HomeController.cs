﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Lab5.Models;

namespace Lab5.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            CallDescriptor dsr1 = new CallDescriptor(new ConnectionDevice("Dima", "3458999"), new ConnectionDevice("Igor", "3458996"), false, 240, new DateTime(2018, 12, 10, 19, 22, 05));
            CallDescriptor dsr2 = new CallDescriptor(new ConnectionDevice("Roman", "3458997"), new ConnectionDevice("Igor", "3458996"), false, 320, new DateTime(2018, 08, 10, 21, 20, 18));
            CallDescriptor dsr3 = new CallDescriptor(new ConnectionDevice("Dima", "3458999"), new ConnectionDevice("Rita", "3458995"), false, 114, new DateTime(2018, 11, 10, 19, 17, 13));
            List<CallDescriptor> con = new List<CallDescriptor>();
            con.Add(dsr1);
            con.Add(dsr2);
            con.Add(dsr3);
            return View(con);
        }
    }
}
