﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lab5.Models
{
    public class Container<T> where T : CallDescriptor
    {
        private List<T> repository = new List<T>();

        public Container(params T[] arg)
        {
            foreach (T a in arg)
            {
                if (a == null)
                {
                    continue;
                }
                repository.Add(a);
            }
        }

        public List<T> Repository
        {
            get
            {
                return repository;
            }
            set
            {
                repository[repository.Count - 1] = default(T);
            }
        }
    }
}
