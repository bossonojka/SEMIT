﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lab5.Models
{
    public class CallDescriptor
    {
        private ConnectionDevice caller;
        private ConnectionDevice called;
        private bool isActive;
        private int duration;
        private DateTime start;

        public CallDescriptor(ConnectionDevice caller, ConnectionDevice called, bool isActive, int duration, DateTime start)
        {
            this.caller = caller;
            this.called = called;
            this.isActive = isActive;
            this.duration = duration;
            this.start = start;
        }

        public ConnectionDevice Caller { get => caller; set => caller = value; }

        public ConnectionDevice Called { get => called; set => called = value; }

        public bool IsActive { get => isActive; set => isActive = value; }

        public int Duration { get => duration; set => duration = value; }

        public DateTime Start { get => start; set => start = value; }
    }
}
