﻿var field1 = document.querySelector("#field1");
var field2 = document.querySelector("#field2");
var action = document.querySelector("#action");

action.onchange = function () {
    field1.value = field2.value = "";
    option();
}

function option() {
    switch (action.value) {
        case "sqrt":
            field1.hidden = true;
            field2.placeholder = "Value";
            break;
        case "log":
            field1.required = true;
            field1.hidden = false;
            field1.placeholder = "Base";
            field2.placeholder = "Value";
            break;
        case "exp":
            field1.required = true;
            field1.hidden = false;
            field1.placeholder = "Value";
            field2.placeholder = "Degree";
    }
}

option();