﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Calc.Models;

namespace Calc.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(Fields form)
        {
            switch (form.Action)
            {
                case "sqrt":
                    form.Result = Math.Sqrt(form.Field2); 
                    return View(form);
                case "log":
                    form.Result = Math.Log(form.Field1, form.Field2);
                    return View(form);
                case "exp":
                    form.Result = Math.Pow(form.Field1, form.Field2);
                    return View(form);
                default:
                    return View(form);
            }
        }
    }
}
