﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace WebApplication3.Controllers
{
    public class HomeController : Controller
    {
        CallDescriptorContext db = new CallDescriptorContext();
        // GET: CallDesriptor
        public ActionResult Index()
        {
            return View(db.CallDescriptor.ToList());
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(CallDescriptor cd)
        {
            if (ModelState.IsValid)
            {
                db.CallDescriptor.Add(cd);
                db.SaveChanges();
                return Redirect("Index");
            }
            return View();
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            CallDescriptor cd = db.CallDescriptor.Find(id);
            if (cd == null)
                return HttpNotFound();
            return View(cd);
        }

        [HttpGet]
        public ActionResult Edit(int? id)
        {
            if (id == null)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            CallDescriptor cd = db.CallDescriptor.Find(id);
            if (cd == null)
                return HttpNotFound();
            return View(cd);
        }

        [HttpPost]
        public ActionResult Edit(CallDescriptor cd)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    db.Entry(cd).State = System.Data.Entity.EntityState.Modified;
                    db.SaveChanges();
                    return Redirect("Index");
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        [HttpGet]
        public ActionResult Delete(int? id)
        {
            if (id == null)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            CallDescriptor cd = db.CallDescriptor.Find(id);
            if (cd == null)
                return HttpNotFound();
            return View(cd);
        }

        [HttpPost]
        public ActionResult Delete(int? id, CallDescriptor cd)
        {
            try
            {
                CallDescriptor calldescriptor = new CallDescriptor();
                if (ModelState.IsValid)
                {
                    if (id == null)
                    {
                        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                    }
                    calldescriptor = db.CallDescriptor.Find(id);
                    if (calldescriptor == null)
                        return HttpNotFound();
                    db.CallDescriptor.Remove(calldescriptor);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                return View("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}