﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace lab4_empty.Models.Items
{
    public class MockItemsRepository : IItemRepository
    {
        private List<Item> _itemList;

        public MockItemsRepository()
        {
            _itemList = new List<Item>()
        {
            new Item() {Id = 1, Cost = 10, Location = 1, Maximum = 10, Name = "Мяч", Volume=100},
            new Item() {Id = 2, Cost = 10, Location = 1, Maximum = 10, Name = "Гиря", Volume=100},
            new Item() {Id = 3, Cost = 10, Location = 1, Maximum = 10, Name = "Скакалка", Volume=100},
            new Item() {Id = 4, Cost = 10, Location = 1, Maximum = 10, Name = "Груша", Volume=100},
            new Item() {Id = 5, Cost = 10, Location = 3, Maximum = 10, Name = "Канат", Volume=100},
            new Item() {Id = 6, Cost = 10, Location = 3, Maximum = 10, Name = "Мат", Volume=100},
        };
        }

        public Item GetItem(int Id)
        {
            return this._itemList.FirstOrDefault(e => e.Id == Id);
        }

        public IEnumerable GetItems()
        {
            return _itemList;
        }

        public IEnumerable Search(string searchString)
        {
            return _itemList.FindAll(e => e.Name.ToLower().Contains(searchString.ToLower()));
        }
    }
}
