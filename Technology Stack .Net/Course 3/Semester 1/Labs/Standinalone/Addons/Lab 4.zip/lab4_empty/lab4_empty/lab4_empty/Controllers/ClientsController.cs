﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using lab4_empty.Models;
using Microsoft.AspNetCore.Mvc;

using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;


namespace lab4_empty.Controllers
{
    public class ClientsController : Controller
    {
        private readonly IClientRepository _clientRepository;


        public ClientsController(IClientRepository clientRepository)
        {
            _clientRepository = clientRepository;
        }

        [Route("Clients")]
        public ViewResult Index()
        {
            return View(_clientRepository.GetClients());
        }

        [Route("Clients/Details/{id?}")]
        public ViewResult Details(int id = 1)
        {
            Client model = _clientRepository.GetClient(id);
            return View(model);
        }

        [Route("Clients/Delete/{id}")]
        public RedirectToActionResult Delete(int id)
        {
            _clientRepository.Delete(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ViewResult Create()
        {
            return View();
        }

        [HttpPost]
        public RedirectToActionResult Create(Client client)
        {
            Client newClient =_clientRepository.Add(client);
            return RedirectToAction("Details", new { id = newClient.Id });
        }
    }
}
