﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace lab4_empty.Models.Users
{
    public class MockModelsRepository : IModelsRepository
    {
        private List<Model> _modelList;

        public MockModelsRepository()
        {
            _modelList = new List<Model>()
        {
            new Model() { Id = 1, Name = "Jessy",  Password = "123", Address = "gagarina", ContactNumber = "123" },
            new Model() { Id = 2, Name = "Monica", Password = "123", Address = "pushka", ContactNumber = "456" },
        };
        }

        public Model GetModel(int Id)
        {
            return this._modelList.FirstOrDefault(e => e.Id == Id);
        }

        public IEnumerable GetModels()
        {
            return _modelList;
        }
    }
}
