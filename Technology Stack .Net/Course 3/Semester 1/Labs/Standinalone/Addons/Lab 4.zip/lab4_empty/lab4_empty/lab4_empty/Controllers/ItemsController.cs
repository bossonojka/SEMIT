﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using lab4_empty.Models;
using lab4_empty.Models.Items;
using Microsoft.AspNetCore.Mvc;

namespace lab4_empty.Controllers
{
    public class ItemsController : Controller
    {
        private readonly IItemRepository _itemRepository;

        public ItemsController(IItemRepository itemRepository)
        {
            _itemRepository = itemRepository;
        }

        [Route("Items")]
        public ViewResult Index()
        {
            return View(_itemRepository.GetItems());
        }

        [Route("Items/Details/{id?}")]
        public ViewResult Details(int id = 1)
        {
            Item model = _itemRepository.GetItem(id);
            return View(model);
        }

        public ViewResult Search(string searchString)
        {
            var items = _itemRepository.Search(searchString);
            //return RedirectToAction("Index", items);
            return View("Views/Items/index.cshtml", items);
        }
        public ViewResult Create()
        {
            return View();
        }
    }
}
