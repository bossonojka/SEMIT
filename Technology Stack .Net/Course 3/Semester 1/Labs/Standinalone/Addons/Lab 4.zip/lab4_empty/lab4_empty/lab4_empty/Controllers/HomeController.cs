﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using lab4_empty.Models;
using Microsoft.AspNetCore.Mvc;

namespace lab4_empty.Controllers
{
    public class HomeController : Controller
    {
        private readonly IClientRepository _clientRepository;

        public HomeController(IClientRepository clientRepository)
        {
            _clientRepository = clientRepository;
        }
        public ViewResult Index()
        {
            //return _clientRepository.GetClient(1).Address;
            //ViewData["Client"] = _clientRepository.GetClient(1);
            //ViewData["PageTitle"] = "Clients";
            //ViewBag.Client = _clientRepository.GetClient(1);
            //ViewBag.PageTitle = "Clients";
            //return View(_clientRepository.GetClient(1));
            return View(_clientRepository.GetClients());
        }

        public ViewResult Client (int id = 1)
        {
            Client model = _clientRepository.GetClient(id);
            return View(model);
        }

        //public ViewResult Details()
        //{
        //    Client model = _clientRepository.GetClient(1);
        //    return View(model);
        //}
    }
}
