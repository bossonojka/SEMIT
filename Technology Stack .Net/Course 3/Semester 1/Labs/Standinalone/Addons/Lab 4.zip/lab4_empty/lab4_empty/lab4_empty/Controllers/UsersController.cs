﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using lab4_empty.Models;
using lab4_empty.Models.Users;
using Microsoft.AspNetCore.Mvc;

namespace lab4_empty.Controllers
{
    public class UsersController : Controller
    {
        private readonly IModelsRepository _usersRepository;

        public UsersController(IModelsRepository modelRepository)
        {
            _usersRepository = modelRepository;
        }
        [Route("Users")]
        public ViewResult Index()
        {
            return View(_usersRepository.GetModels());
        }

        //[Route("Users/Details/{id?}")]
        //public ViewResult Details(int id = 1)
        //{
        //    Model model = _usersRepository.GetModel(id);
        //    return View(model);
        //}

        //public ViewResult Create()
        //{
        //    return View();
        //}
    }
}
