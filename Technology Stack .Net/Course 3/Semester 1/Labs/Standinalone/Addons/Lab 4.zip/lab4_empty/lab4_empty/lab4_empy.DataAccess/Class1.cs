﻿using System;

namespace lab4_empy.DataAccess
{
    public class Class1
    {
    }
}
