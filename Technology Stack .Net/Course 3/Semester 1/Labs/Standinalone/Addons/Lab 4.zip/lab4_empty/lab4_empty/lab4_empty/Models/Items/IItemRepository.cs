﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace lab4_empty.Models.Items
{
    public interface IItemRepository
    {
        Item GetItem(int Id);
        IEnumerable GetItems();
        IEnumerable Search(string searchString);
    }
}
