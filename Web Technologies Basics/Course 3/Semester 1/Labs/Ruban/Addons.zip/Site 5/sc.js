var nmb = document.getElementsByClassName("numbers")[0];
var btn = nmb.getElementsByTagName("button");
var inp = document.getElementById("expression");
for (var i = btn.length - 1; i >= 0; i--) {
	btn[i].addEventListener("click",function(){
		inp.innerHTML += this.innerHTML;
	});
}