import { Component } from '@angular/core';

@Component({
	selector:'bob-accounts-edit-form-something',
	moduleId:module.id,
	templateUrl:'accounts.edit.form.something.component.html',
	styleUrls:['accounts.edit.form.something.component.css']
})
export class AccountsEditFormSomethingComponent{
	constructor(){
	}
}