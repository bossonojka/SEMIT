import { Component } from '@angular/core';

@Component({
	selector:'bob-accounts-table-form',
	moduleId:module.id,
	templateUrl:'accounts.table.form.component.html',
	styleUrls:['accounts.table.form.component.css']
})
export class AccountsTableFormComponent{
	constructor(){
	}
}