import { Component } from '@angular/core';

@Component({
	selector:'bob-bob',
	moduleId:module.id,
	templateUrl:'bob.component.html',
	styleUrls:['bob.component.css']
})
export class BobComponent{
	constructor(){
	}
}