import { Component } from '@angular/core';

@Component({
	selector:'bob-accounts-edit-form',
	moduleId:module.id,
	templateUrl:'accounts.edit.form.component.html',
	styleUrls:['accounts.edit.form.component.css']
})
export class AccountsEditFormComponent{
	constructor(){
	}
}