import { Component } from '@angular/core';

@Component({
	selector:'app-product',
	moduleId:module.id,
	templateUrl:'product.component.html',
	styleUrls:['product.component.css']
})
export class ProductComponent{
	constructor(){
	}
}