import { Component } from '@angular/core';

@Component({
	selector:'app-test',
	moduleId:module.id,
	templateUrl:'Test.component.html',
	styleUrls:['Test.component.css']
})
export class TestComponent{
	constructor(){
	}
}