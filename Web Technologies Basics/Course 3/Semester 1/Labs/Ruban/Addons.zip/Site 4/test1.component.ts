import { Component } from '@angular/core';

@Component({
	selector:'app-test1',
	moduleId:module.id,
	templateUrl:'test1.component.html',
	styleUrls:['test1.component.css']
})
export class Test1Component{
	constructor(){
	}
}