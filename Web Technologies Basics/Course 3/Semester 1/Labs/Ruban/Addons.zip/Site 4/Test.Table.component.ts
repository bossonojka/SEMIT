import { Component } from '@angular/core';

@Component({
	selector:'app-test-table',
	moduleId:module.id,
	templateUrl:'Test.Table.component.html',
	styleUrls:['Test.Table.component.css']
})
export class TestTableComponent{
	constructor(){
	}
}