import { Component } from '@angular/core';

@Component({
	selector:'app-product-table',
	moduleId:module.id,
	templateUrl:'product.table.component.html',
	styleUrls:['product.table.component.css']
})
export class ProductTableComponent{
	constructor(){
	}
}