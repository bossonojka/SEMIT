var card = document.getElementsByClassName('wrap')[0];
var sub = document.getElementsByClassName('sub')[0];
