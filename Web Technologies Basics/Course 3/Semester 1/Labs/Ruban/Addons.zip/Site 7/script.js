
var f = function setDate(){
	let date = new Date();
	let hours = date.getHours();
	hours = hours<=9 ? '0' + hours : hours;
	let minutes = date.getMinutes();
	minutes = minutes<=9 ? '0' + minutes : minutes;

	let seconds = date.getSeconds();
	seconds = seconds<=9 ? '0' + seconds : seconds;

	let day = date.getDate();
	day = day<=9 ? '0' + day : day;

	let month = date.getMonth()+1;
	month = month<=9 ? '0' + month : month;

	let year = date.getFullYear();
	var elem = document.getElementById('time');
	var res = hours + ':'+minutes+':'+seconds+' '+day+'.'+month+'.'+year;
	elem.innerHTML = res;
}
f();
setInterval(f,1000);