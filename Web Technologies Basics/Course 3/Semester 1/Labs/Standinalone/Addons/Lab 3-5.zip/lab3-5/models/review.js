var mongoose = require('mongoose');
// var User       = require('../user');

var reviewSchema = mongoose.Schema({
    user    : {type: mongoose.Schema.Types.ObjectId, ref: 'User'},
    text    : String,
    movie   : {type: mongoose.Schema.Types.ObjectId, ref: 'Movie'},
    rate    : Number
});

module.exports = mongoose.model('Review', reviewSchema);