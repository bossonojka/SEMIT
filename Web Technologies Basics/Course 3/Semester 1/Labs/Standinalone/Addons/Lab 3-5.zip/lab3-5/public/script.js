window.onload = () => {
    let input = document.getElementById("input")
    document.getElementById("submit").addEventListener("click", () => {
        input.value = getWeeks() + ' недель'
    })
    document.getElementById("reset").addEventListener("click", () => {
        input.value = "" 
    })
    let content = document.getElementById("message")
    content.innerHTML = getDays() + ' прошло с Нового Года <br>' + content.innerHTML

    // Task 3

    
    let input2 = document.getElementById("input2")
    input2.addEventListener("focusin", () => {
        input2.value = js_event()
    })
}

function getWeeks(){
    let now = Date.now()
    let bd = new Date('03/10/1999')
    let diff = now- bd
    return (diff / 604800000).toFixed()
}

