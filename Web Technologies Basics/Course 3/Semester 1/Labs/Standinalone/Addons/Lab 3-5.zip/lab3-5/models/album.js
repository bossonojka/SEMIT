var mongoose = require('mongoose');

var albumSchema = mongoose.Schema({
    name    : String,
    movies  : [{type: mongoose.Schema.Types.ObjectId, ref: 'Movie'}],
    tags    : [String]
});

module.exports = mongoose.model('Album', albumSchema);