// ============ Libraries ===================
const express = require('express')
const path = require('path')
const morgan = require('morgan')

var mongoose = require('mongoose');
var passport = require('passport');

var cookieParser = require('cookie-parser');
var bodyParser   = require('body-parser');
var session      = require('express-session');


const app = express()

// var engine       = require('ejs-mate')
// app.engine('ejs', engine);

// router files ===============================================================
var authRoutes   = require('./routes/auth');
// var testRoutes   = require('./routes/test');

// var configDB     = require('./config/database');

// configuration ===============================================================
mongoose.connect('mongodb://localhost/lab5'); // connect to our database

require('./config/passport')(passport); // pass passport for configuration

// set up our express application
app.use(morgan('dev')); // log every request to the console
app.use(cookieParser()); // read cookies (needed for auth)
app.use(bodyParser.json()); // get information from html forms
app.use(bodyParser.urlencoded({ extended: true }));

// required for passport
app.use(session({
    secret: 'eminem', // session secret
    resave: true,
    saveUninitialized: true
}));
app.use(passport.initialize());
app.use(passport.session()); // persistent login sessions

// routes ======================================================================
app.use('/auth', authRoutes);
// app.use('/test', testRoutes);

var User = require('./models/user');
var Reviews = require('./models/review');
var Movies = require('./models/movie');

app.set('view engine', 'ejs')
app.use(express.static(__dirname + '/public'));

app.get('/', function(req, res) {
    let username = req.isAuthenticated() ? req.user.local.email : ""
    let results = Reviews.find()
    console.log(results)
    res.render('index', { loggedIn : req.isAuthenticated(), username : username});
});


app.get('/reviews', function(req, res) {
    let username = req.isAuthenticated() ? req.user.local.email : ""
    let reviews = Reviews.find().populate('user').populate('movie').exec().then((results)=>{
        res.render('reviews', { loggedIn : req.isAuthenticated(), username : username, reviews : results});
    })
});
app.get('/albums', function(req, res) {
    let username = req.isAuthenticated() ? req.user.local.email : ""
    res.render('albums', { loggedIn : req.isAuthenticated(), username : username});
});
app.get('/sitemap', function(req, res) {
    let r = Movies.find().exec().then(movies => {
        res.render('sitemap', { loggedIn : req.isAuthenticated(), username : username, movies : movies});
    })
    console.log(r)
    let username = req.isAuthenticated() ? req.user.local.email : ""
    
});
app.get('/about', function(req, res) {
    let username = req.isAuthenticated() ? req.user.local.email : ""
    res.render('about', { loggedIn : req.isAuthenticated(), username : username});
});
app.get('/javaScript', function(req, res) {
    let username = req.isAuthenticated() ? req.user.local.email : ""
    res.render('javaScript', { loggedIn : req.isAuthenticated(), username : username});
});
app.get('/signIn', function(req, res) {
    let username = req.isAuthenticated() ? req.user.local.email : ""
    res.render('signIn', { loggedIn : req.isAuthenticated(), username : username});
});
app.get('/signUp', function(req, res) {
    let username = req.isAuthenticated() ? req.user.email : ""
    res.render('signup', { loggedIn : req.isAuthenticated(), username : username});
});

app.get('/:id',(req, res) => {
    let username = req.isAuthenticated() ? req.user.email : ""
    let id = req.params.id
    console.log(id)
    let r = Movies.findOne({_id : id}).exec().then(movie => {
        res.render('movie', { loggedIn : req.isAuthenticated(), username : username, movie : movie});
    })
})

app.post('/addReview', (req, res) => {
    console.log(req.body.id)
    let query = Movies.findOne({_id : req.body.id}).exec().then(result => {
        let review = {
            user : req.user,
            text : req.body.text,
            movie : result,
            rate : req.body.rate,
        }
        console.log(review)
        let rev = new Reviews(review)
        rev.save()
        res.redirect('/')
    })



})

app.listen(8080, "0.0.0.0");
