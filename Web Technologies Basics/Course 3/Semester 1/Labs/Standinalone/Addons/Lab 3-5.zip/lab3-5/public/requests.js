async function signIn(name, password){
    let user = {
        name: name,
        surname: password
    }
    let response = await fetch('/auth/signUp', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json;charset=utf-8'
        },
        body: JSON.stringify(user)
      });
}