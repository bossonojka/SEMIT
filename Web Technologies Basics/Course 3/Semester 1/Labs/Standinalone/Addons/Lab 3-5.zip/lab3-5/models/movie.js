var mongoose = require('mongoose');

var movieSchema = mongoose.Schema({
    name        : String,
    original_name   : String,
    premiere    : Date,
    country     : String,
    genre       : String,
    poster      : String,
});

module.exports = mongoose.model('Movie', movieSchema);