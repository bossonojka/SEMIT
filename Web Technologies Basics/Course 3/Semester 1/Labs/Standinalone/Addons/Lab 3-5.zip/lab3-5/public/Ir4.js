function getDays(){
    let today = new Date();
    let ny = new Date(today.getFullYear(), 00, 01);
    let one_day=1000*60*60*24;
    return Math.ceil((today.getTime() - ny.getTime())/one_day)
}