// ============ Libraries ===================
const express = require('express')
const path = require('path')
const morgan = require('morgan')
// const engine = require('ejs-blocks')

const app = express()
// app.engine('ejs', engine);
app.set('view engine', 'ejs')
app.use(morgan('dev')) // logger
app.use(express.static(__dirname + '/public'));
app.get('/', function(req, res) {
    res.render('index');
});
app.get('/reviews', function(req, res) {
    res.render('reviews');
});
app.get('/albums', function(req, res) {
    res.render('albums');
});
app.get('/sitemap', function(req, res) {
    res.render('sitemap');
});
app.get('/about', function(req, res) {
    res.render('about');
});
// ============= Routes ==============
// app.use(express.static(__dirname));


app.listen(8080, "0.0.0.0");
