package com.company;


import org.testng.annotations.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class MainTest {
    @Test
    public void f() {
        Main main = new Main();
        boolean expected = true;
        assertEquals(false, main.soversh( 7 ));
        assertEquals(false, main.soversh( 5 ));
        assertFalse(expected==main.soversh(6));
    }
}