package com.company;

import static java.lang.Math.abs;

public class Main {

    public int temp = 0;
    public boolean result = false;

    public boolean soversh(int num) {

        if (num <= 3000 && num >= 0) {
            for(int i=1;i<=num/2;i++){
                if(num%i == 0){
                    temp += i;
                }
            }
            if (temp == num) {
                //System.out.println(num + " - простое число");
                result = true;
                return result;
            } else {
                //System.out.println(num + " - совершенное число");
                result = false;
                return result;
            }
        } else if (num > 3000) {
            result = false;
            return result;
        } else {
            result = false;
            return result;
        }
    }

    public static void main(String [] args){
        Main main = new Main();
        System.out.println(main.soversh(5));
    }

}
