﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program
{
	public class Program1

	{
        interface IProgram
        {
            double onClickMethod();
        }
        class ProgramInterface : IProgram
        {
            public double onClickMethod()
            {
                throw new NotImplementedException();
            }
        }

        public static void Main(string[] args)
		{
			Console.WriteLine("max = " + init(5));
			Console.ReadLine();
		}

		public static double init(int g) {
			double max = 0, y = 0;
			try {
				for (int i = 0; i <= g; i++) {
					y = func(i);
					if (y > max) {
						max = y;
					} else continue;
				}
			}
			catch (Exception e1) {
				Console.WriteLine("Error ");
			}
			return max;
		}

		public static double func(int x) {
			return Math.Pow(5, x) / factorial(x);
		}

		static int factorial(int x) {
			if (x == 1 || x == 0) {
				return 1;
			}
			return x * factorial(x - 1);
		}
	}
}
