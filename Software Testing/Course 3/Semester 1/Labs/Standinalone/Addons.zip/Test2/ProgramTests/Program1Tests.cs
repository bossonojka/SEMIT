﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Program;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program.Tests
{
	[TestClass()]
	public class Program1Tests
	{
        [TestMethod]
        public void Test1()
        {
            Program.Program1 program = new Program.Program1();
            double expected = Program.Program1.init(5);
           
            Assert.IsNotNull(expected, "Error");
        }

        [TestMethod]
        public void Test2()
        {
            Program.Program1 program = new Program.Program1();
            double expected = Program.Program1.init(5);
            Assert.IsNotNull(expected, "Error");
        }
    }
}