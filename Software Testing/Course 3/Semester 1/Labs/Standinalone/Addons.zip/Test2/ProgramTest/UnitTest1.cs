using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Program;

namespace Tests
{
	[TestClass]
	public class Test {
		[TestMethod]
		public void Test1()
		{
			Program.Program1 program = new Program.Program1();
			double expected = Program.Program1.init(5);
			double actual = 26.0416666666667;
			Assert.Equals(expected, actual);
		}

		[TestMethod]
		public void Test2()
		{
			Program.Program1 program = new Program.Program1();
			double expected = Program.Program1.init(5);
			Assert.AreEqual(26.0416666666667, expected, "Error");
		}

		[TestMethod]
		public void Test3()
		{
			Program.Program1 program = new Program.Program1();
			double expected = Program.Program1.init(5);
			Assert.IsNotNull( expected, "Error");
		}
	}
}