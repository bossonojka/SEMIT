package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

import java.awt.*;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        primaryStage.setTitle("Тестирование");
        primaryStage.setScene(new Scene(root,300, 275));
        primaryStage.show();
    }
    public interface IProgram {
        public  double onClickMethod();
    }
    public class ProgramInterface implements IProgram {
        @Override
        public double onClickMethod() {
            return 0;
        }
    }


    public static void main(String[] args) {
        launch(args);
    }
}
