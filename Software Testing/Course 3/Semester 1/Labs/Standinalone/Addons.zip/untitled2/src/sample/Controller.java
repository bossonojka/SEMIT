package sample;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class Controller {
    //@FXML
    //private ResourceBundle resources;
    //@FXML
    //private URL location;
    @FXML
    private TextField textField;
    @FXML
    private Button button;
    @FXML
    private TextField textFieldRes;

    private void init() {
        String text = textField.getText();
        int g = Integer.parseInt(text);
        double max = 0, y = 0, g1 = 0;
        for (int i = 0; i <= g; i++) {
            y = func(i);
            if (y > max) {
                max = y;
                g1 = i;
            } else continue;
        }
        //System.out.println("Максимум равен "+ max + " в точке " + g1);
        textFieldRes.setText("Максимум равен "+ max + " в точке " + g1);
    }

    public double func(int x) {
        return Math.pow(5, x) / factorial(x);
    }

    static int factorial(int x) {
        if (x == 1 || x == 0) {
            return 1;
        }
        return x * factorial(x - 1);
    }

    public void initialize(ActionEvent actionEvent) {
        button.setOnAction(event -> init());
    }
}