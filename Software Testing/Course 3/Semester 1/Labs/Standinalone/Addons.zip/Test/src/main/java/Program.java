public class Program {
    public void main(String[] args) {
        init(5);
    }

    public double init(int g) {

        double max = 0, y = 0;
        try {
            for (int i = 0; i <= g; i++) {
                y = func(i);
                if (y > max) {
                    max = y;

                } else continue;
            }
        }
        catch (NumberFormatException e1) {
            System.out.println("Error " );
        }

        return max;
    }

    public static double func(int x) {
        return Math.pow(5, x) / factorial(x);
    }

    static int factorial(int x) {
        if (x == 1 || x == 0) {
            return 1;
        }
        return x * factorial(x - 1);
    }
}