import junit.framework.TestCase;
import org.junit.Test;
import static org.junit.Assert.*;

public class ProgramTest {
    @Test
    public void test1() {
        Program program=new Program();
        double actual= program.init(5);
        double expected= 26.2;
        assertEquals(expected,actual,0.0001);
    }

    @Test
    public void test2() {
        Program program = new Program();
        double expectedResult = program.init(5);
        assertNotNull(expectedResult);
    }

    @Test
    public void test3() {
        Program program = new Program();
        assertTrue(program.init(5) == 26.041666666666668);
    }
}

