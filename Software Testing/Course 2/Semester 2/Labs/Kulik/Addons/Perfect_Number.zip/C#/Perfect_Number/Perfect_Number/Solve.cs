﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Perfect_Number
{
    class Solve
    {

        Boolean isPrime = true;
        int temp;
        String result;

        public String soversh(int num)
        {

            if (num <= 3000 && num >= 0)
            {
                for (int i = 1; i <= num / 2; i++)
                {
                    if (num % i == 0)
                    {
                        temp += i;
                    }
                }
                if (temp == num)
                {
                    //System.out.println(num + " - простое число");
                    result = "Perfect number";
                    return result;
                }
                else
                {
                    //System.out.println(num + " - совершенное число");
                    result = "Prime number";
                    return result;
                }
            }
            else if (num > 3000)
            {
                result = "Input is incorrect. You must enter a number not exceeding 3000!";
                return result;
            }
            else
            {
                result = "Input is incorrect. You must enter a number of at least 0!";
                return result;
            }
        }
    }
}
