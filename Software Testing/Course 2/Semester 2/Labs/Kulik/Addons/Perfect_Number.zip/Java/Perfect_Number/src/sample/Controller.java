package sample;

import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable{

    public Button pressBtn;
    public TextField txtNum;
    public TextArea txtResult;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        
    }

    public void main(javafx.event.ActionEvent actionEvent) {
        int N;
        if (txtNum.getText().matches("[0-9]+$")){
            N = Integer.parseInt(txtNum.getText());
            Solve s = new Solve();
            txtResult.setText(s.soversh(N));
        } else {
            txtResult.setText("Input is incorrect. You must enter a number!");
        }
    }
}
