package app;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;

@WebServlet(name = "ServletForDeleteTowns")
public class ServletForDeleteTowns extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Towns towns = new Towns();

        try {
            Connection connection = ConnectionHolder.getConnection();

            Statement statement = connection.createStatement();

            int townsId = Integer.parseInt(request.getParameter("townsId"));

            int i = statement.executeUpdate("DELETE FROM Towns WHERE ID="+townsId);


            RequestDispatcher dispatcher = request.getRequestDispatcher("/servletForViewTowns");
            dispatcher.forward(request, response);


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
