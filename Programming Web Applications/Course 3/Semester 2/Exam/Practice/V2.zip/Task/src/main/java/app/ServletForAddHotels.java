package app;

import app.dao.HotelsRepository;
import app.dao.TownsRepository;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;


public class ServletForAddHotels extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HotelsRepository hotelsRepository = new HotelsRepository();
        request.setAttribute("hotelsList", hotelsRepository.getAllHotels());

        TownsRepository townsRepository = new TownsRepository();
        request.setAttribute("townsList", townsRepository.getAllTowns());

        try {
            Connection connection = ConnectionHolder.getConnection();

            PreparedStatement statement = connection.prepareStatement("Insert Into Hotels (HNAME, TOWN_ID, STARS) values (?, ?, ?)");


            statement.setString(1, request.getParameter("hotelsName"));
            statement.setString(2, request.getParameter("hotelsTownsId"));
            statement.setInt(3, Integer.parseInt(request.getParameter("hotelsStars")));

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new hotel was inserted successfully!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        RequestDispatcher dispatcher = request.getRequestDispatcher("/servletForViewHotels");
        dispatcher.forward(request, response);



    }
}
