package app;

public class Hotels {
    private int hotelsId;
    private String hotelsName;
    private int hotelsTownsId;
    private int hotelsStars;

    public Hotels(int hotelsId, String hotelsName, int hotelsTownsId, int hotelsStars) {
        this.hotelsId = hotelsId;
        this.hotelsName = hotelsName;
        this.hotelsTownsId = hotelsTownsId;
        this.hotelsStars = hotelsStars;
    }

    public Hotels() {
        super();
    }

    public int getHotelsId() {
        return hotelsId;
    }

    public void setHotelsId(int hotelsId) {
        this.hotelsId = hotelsId;
    }

    public String getHotelsName() {
        return hotelsName;
    }

    public void setHotelsName(String hotelsName) {
        this.hotelsName = hotelsName;
    }

    public int getHotelsTownsId() {
        return hotelsTownsId;
    }

    public void setHotelsTownsId(int hotelsTownsId) {
        this.hotelsTownsId = hotelsTownsId;
    }

    public int getHotelsStars() {
        return hotelsStars;
    }

    public void setHotelsStars(int hotelsStars) {
        this.hotelsStars = hotelsStars;
    }

    @Override
    public String toString() {
        return "Hotels{" +
                "hotelsId=" + hotelsId +
                ", hotelsName='" + hotelsName + '\'' +
                ", hotelsTownsId=" + hotelsTownsId +
                ", hotelsStars=" + hotelsStars +
                '}';
    }
}
