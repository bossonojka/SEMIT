package app;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

@WebServlet(name = "ServletForFilterHotels")
public class ServletForFilterHotels extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        try {
            Connection connection = ConnectionHolder.getConnection();

            Statement statement = connection.createStatement();

            String sql = "SELECT *  FROM Hotels WHERE  STARS= '" + request.getParameter("hotelsStars")+"'";
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                Hotels hotels = new Hotels();

                int hotelsId = resultSet.getInt("hotelsId");
                request.setAttribute("hotelsId", hotelsId);

                String hotelsName = resultSet.getString("hotelsName");
                request.setAttribute("hotelsName", hotelsName);

                int hotelsTownsId = resultSet.getInt("hotelsTownsId");
                request.setAttribute("hotelsTownsId", hotelsTownsId);

                int hotelsStars = resultSet.getInt("hotelsStars");
                request.setAttribute("hotelsStars", hotelsStars);



                request.setAttribute("hotelsList", hotels);
                request.getRequestDispatcher("/servletForFilterHotels");


            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
