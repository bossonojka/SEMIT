package app;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet(name = "ServletForAddTowns")
public class ServletForAddTowns extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        super.doPost(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Connection connection = ConnectionHolder.getConnection();

            PreparedStatement statement = connection.prepareStatement("Insert Into Towns (TOWN, POST_INDEX) values( ?, ?)");


            statement.setString(1, request.getParameter("townsTown"));
            statement.setString(2, request.getParameter("townsIndex"));

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new town was inserted successfully!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        RequestDispatcher dispatcher = request.getRequestDispatcher("/servletForViewTowns");
        dispatcher.forward(request, response);



    }
}
