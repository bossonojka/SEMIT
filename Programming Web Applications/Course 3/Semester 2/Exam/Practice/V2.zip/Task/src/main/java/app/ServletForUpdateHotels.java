package app;

import app.dao.HotelsRepository;
import app.dao.TownsRepository;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet(name = "ServletForUpdateHotels")
public class ServletForUpdateHotels extends HttpServlet {


    private int hotelsId;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String hotelsName = request.getParameter("hotelsName");
        String hotelsTownsId = request.getParameter("hotelsTownsId");
        int hotelsStars = Integer.parseInt(request.getParameter("hotelsStars"));
        System.out.println(hotelsId);

        try {


            Connection connection = ConnectionHolder.getConnection();

            PreparedStatement statement = connection.prepareStatement("UPDATE  Hotels set HNAME=?, TOWN_ID=?, STARS=? where ID=" + hotelsId);

            statement.setString(1, hotelsName);
            statement.setString(2, hotelsTownsId);
            statement.setInt(3, hotelsStars);


            if (statement.executeUpdate() > 0) {
                RequestDispatcher dispatcher = request.getRequestDispatcher("Successful.jsp");
                dispatcher.forward(request, response);
            } else {
                RequestDispatcher dispatcher = request.getRequestDispatcher("servletForViewHotels");
                dispatcher.forward(request, response);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        TownsRepository townsRepository = new TownsRepository();
        request.setAttribute("townsList", townsRepository.getAllTowns());

        HotelsRepository hotelsRepository = new HotelsRepository();
        request.setAttribute("hotelsList", hotelsRepository.getAllHotels());

        hotelsId = Integer.parseInt(request.getParameter("hotelsId"));
        RequestDispatcher dispatcher = request.getRequestDispatcher("UpdateHotelsPage.jsp");
        dispatcher.forward(request, response);
    }
}
