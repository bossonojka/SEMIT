package app;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;

@WebServlet(name = "ServletForDeleteHotels")
public class ServletForDeleteHotels extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Connection connection = ConnectionHolder.getConnection();

            Statement statement = connection.createStatement();

            int hotelsId = Integer.parseInt(request.getParameter("hotelsId"));

            int i = statement.executeUpdate("DELETE FROM Hotels WHERE ID =" + hotelsId);


            RequestDispatcher dispatcher = request.getRequestDispatcher("/servletForViewHotels");
            dispatcher.forward(request, response);


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
