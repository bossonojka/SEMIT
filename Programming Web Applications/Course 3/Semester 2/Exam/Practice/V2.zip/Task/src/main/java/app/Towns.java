package app;

public class Towns {
    private int townsId;
    private String townsTown;
    private String townsIndex;

    public Towns(int townsId, String townsTown, String townsIndex) {
        this.townsId = townsId;
        this.townsTown = townsTown;
        this.townsIndex = townsIndex;
    }

    public Towns() {
    }

    public int getTownsId() {
        return townsId;
    }

    public void setTownsId(int townsId) {
        this.townsId = townsId;
    }

    public String getTownsTown() {
        return townsTown;
    }

    public void setTownsTown(String townsTown) {
        this.townsTown = townsTown;
    }

    public String getTownsIndex() {
        return townsIndex;
    }

    public void setTownsIndex(String townsIndex) {
        this.townsIndex = townsIndex;
    }

    @Override
    public String toString() {
        return "Towns{" +
                "townsId=" + townsId +
                ", townsTown='" + townsTown + '\'' +
                ", townsIndex='" + townsIndex + '\'' +
                '}';
    }
}
