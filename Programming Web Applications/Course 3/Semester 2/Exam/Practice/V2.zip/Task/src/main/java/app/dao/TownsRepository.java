package app.dao;

import app.ConnectionHolder;
import app.Towns;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class TownsRepository {
    private  static final String SHOW_ALL_TOWNS = "Select * From Towns";

    public List<Towns> getAllTowns(){
        List<Towns> list = null;
        try (Connection connection = ConnectionHolder.getConnection();
             PreparedStatement statement = connection.prepareStatement(SHOW_ALL_TOWNS);
             ResultSet resultSet = statement.executeQuery()){
            list = new ArrayList<>();
            while (resultSet.next()){
                Towns towns = new Towns();
                towns.setTownsId(resultSet.getInt(1));
                towns.setTownsTown(resultSet.getString(2));
                towns.setTownsIndex(resultSet.getString(3));
                list.add(towns);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }



    public static void main(String[] args) {
        TownsRepository townsRepository = new TownsRepository();
        System.out.println(townsRepository.getAllTowns());
    }
}
