package app;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionHolder {
    public static Connection getConnection() throws ClassNotFoundException, SQLException /*throws Exception*/ {
        /*try {*/
        Class.forName("org.sqlite.JDBC");
        String dbURL = "jdbc:sqlite:C:\\Users\\Dima\\Desktop\\Exam-Java-WEB-2019/Exam_JAVA_v2.db";
        Connection conn = DriverManager.getConnection(dbURL);
        if (conn != null) {
            DatabaseMetaData dm = (DatabaseMetaData) conn.getMetaData();
            return conn;
        }
       /* } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }*/
        return conn;
    }
}
