package app;

import app.dao.HotelsRepository;
import app.dao.TownsRepository;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "ServletForViewHotels")
public class ServletForViewHotels extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HotelsRepository hotelsRepository = new HotelsRepository();
        request.setAttribute("hotelsList", hotelsRepository.getAllHotels());

        TownsRepository townsRepository = new TownsRepository();
        request.setAttribute("townsList", townsRepository.getAllTowns());

        RequestDispatcher dispatcher = request.getRequestDispatcher("HotelsPage.jsp");
        dispatcher.forward(request, response);
    }
}
