package app;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet(name = "ServletForUpdateTowns")
public class ServletForUpdateTowns extends HttpServlet {

    private int townsId;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String townsTown = request.getParameter("townsTown");
        String townsIndex = request.getParameter("townsIndex");
        System.out.println(townsId);

        try {


            Connection connection = ConnectionHolder.getConnection();

            PreparedStatement statement = connection.prepareStatement("UPDATE  Towns set TOWN=?, POST_INDEX=? where ID=" + townsId);

            statement.setString(1, townsTown);
            statement.setString(2, townsIndex);


            if (statement.executeUpdate() > 0) {
                RequestDispatcher dispatcher = request.getRequestDispatcher("Successful.jsp");
                dispatcher.forward(request, response);
            } else {
                RequestDispatcher dispatcher = request.getRequestDispatcher("servletForViewTowns");
                dispatcher.forward(request, response);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        townsId = Integer.parseInt(request.getParameter("townsId"));
        RequestDispatcher dispatcher = request.getRequestDispatcher("UpdateTownsPage.jsp");
        dispatcher.forward(request, response);
    }
}
