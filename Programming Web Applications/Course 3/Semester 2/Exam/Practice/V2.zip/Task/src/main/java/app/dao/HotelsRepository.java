package app.dao;

import app.ConnectionHolder;
import app.Hotels;
import app.Towns;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class HotelsRepository {
    private  static final String SHOW_ALL_HOTELS= "Select * From Hotels";

    public List<Hotels> getAllHotels(){
        List<Hotels> list = null;
        try (Connection connection = ConnectionHolder.getConnection();
             PreparedStatement statement = connection.prepareStatement(SHOW_ALL_HOTELS);
             ResultSet resultSet = statement.executeQuery()){
            list = new ArrayList<>();
            while (resultSet.next()){
                Hotels hotels = new Hotels();
                hotels.setHotelsId(resultSet.getInt(1));
                hotels.setHotelsName(resultSet.getString(2));
                hotels.setHotelsTownsId(resultSet.getInt(3));
                hotels.setHotelsStars(resultSet.getInt(4));

                list.add(hotels);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }



    public static void main(String[] args) {
        HotelsRepository hotelsRepository = new HotelsRepository();
        System.out.println(hotelsRepository.getAllHotels());
    }
}
