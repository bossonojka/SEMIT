package com.labs.crud.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletContext;

import com.labs.crud.classes.Order;
import com.labs.crud.classes.Product;
import com.labs.crud.classes.Provider;

public class SqlRepository {
	private Connection con;
	
	private List<Product> products = new CopyOnWriteArrayList<Product>();
	private List<Provider> providers = new CopyOnWriteArrayList<Provider>();
	private List<Order> orders = new CopyOnWriteArrayList<Order>();
	
	public SqlRepository(Connection con) {
		this.con = con;
	}
	
	public List<Product> getProducts() throws SQLException {
		PreparedStatement stmt = null;
		
		String sql = "select * from products";
		stmt = this.con.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();
		
		while(rs.next()) {
			this.products.add(new Product(Integer.parseInt(rs.getString("id")), rs.getString("name"), Double.parseDouble(rs.getString("price")), rs.getString("manufacturer")));
		}
		
		rs.close();
		stmt.close();
		
		return this.products;
	}

	public List<Provider> getProviders() throws SQLException {
		PreparedStatement stmt = null;
		
		String sql = "select * from providers";
		stmt = con.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();
		
		while(rs.next()) {
			this.providers.add(new Provider(Integer.parseInt(rs.getString("id")), rs.getString("name"), rs.getString("email")));
		}
		
		rs.close();
		stmt.close();
		
		return this.providers;
	}

	public List<Order> getOrders() throws SQLException {
		PreparedStatement stmt = null;
		
		String sql = "select * from orders";
		stmt = con.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();
		
		while(rs.next()) {
			Product product = null;
			Provider provider = null;
			
			for (Product prod : this.products) {
				if (Integer.parseInt(rs.getString("productId")) == (prod.getId())) {
					product = prod;
				}
			}
			
			for (Provider prov : this.providers) {
				if (Integer.parseInt(rs.getString("providerId")) == (prov.getId())) {
					provider = prov;
				}
			}
			
			if (product != null && provider != null) {
				this.orders.add(new Order(Integer.parseInt(rs.getString("id")), product, provider, Integer.parseInt(rs.getString("quantity"))));
			}
		}
		
		rs.close();
		stmt.close();
		
		return this.orders;
	}
}
