package com.labs.crud.servlets;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.labs.crud.classes.Order;
import com.labs.crud.classes.Product;
import com.labs.crud.classes.Provider;
import com.labs.crud.util.XmlResponse;

public class XmlCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private List<Order> orders;
	private List<Product> products;
	private List<Provider> providers;
	private XmlResponse xmlr;

    public XmlCreate() {
        super();
    }
    
    public void init() {
    	final Object orders = getServletContext().getAttribute("orders");
    	final Object products = getServletContext().getAttribute("products");
    	final Object providers = getServletContext().getAttribute("providers");
    	
    	if (orders == null || !(orders instanceof CopyOnWriteArrayList)) {
    		throw new IllegalStateException();
    	} else {
    		this.orders = (CopyOnWriteArrayList<Order>) orders;
    	}
    	
    	if (products == null || !(products instanceof CopyOnWriteArrayList)) {
    		throw new IllegalStateException();
    	} else {
    		this.products = (CopyOnWriteArrayList<Product>) products;
    	}
    	
    	if (providers == null || !(providers instanceof CopyOnWriteArrayList)) {
    		throw new IllegalStateException();
    	} else {
    		this.providers = (CopyOnWriteArrayList<Provider>) providers;
    	}
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		switch(request.getParameter("type")) {
			case "products":
				new XmlResponse(response).getProducts(this.products);
				break;
			case "providers":
				new XmlResponse(response).getProviders(this.providers);
				break;
			case "orders":
				new XmlResponse(response).getOrders(this.orders);
				break;
		}
	}
}
