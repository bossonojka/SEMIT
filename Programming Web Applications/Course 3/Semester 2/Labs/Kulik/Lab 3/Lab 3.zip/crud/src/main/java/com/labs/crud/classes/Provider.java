package com.labs.crud.classes;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class Provider {
	private int id;
	private String name;
	private String email;
	public static Connection con;
	
	public Provider(int id, String name, String email) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
	}
	
	public Provider() {
		
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public boolean create(){
		String sql = "insert into providers values('"+this.getId()+"', '"+this.getName()+"', '"+this.getEmail()+"')";
		
		Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean delete(){
		String sql = "delete from providers where \"id\"='"+this.getId()+"';";
		
		Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean edit(){
		String sql = "update providers set \"name\"='"+this.getName()+"', \"price\"='"+this.getEmail()+"' where \"id\"='"+this.getId()+"';";

		Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}
