package com.labs.crud.listeners;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.labs.crud.classes.Product;
import com.labs.crud.classes.Order;
import com.labs.crud.classes.Provider;
import com.labs.crud.util.SqlRepository;

public class ContextListener implements ServletContextListener {

	public void contextInitialized(ServletContextEvent sce) {
		final ServletContext ctx = sce.getServletContext();
		
		try {
			Class.forName("org.sqlite.JDBC");
			Connection con = DriverManager.getConnection("jdbc:sqlite:e:\\Program Files\\SQLite\\shop.db");
			
			Product.con = Provider.con = Order.con = con;
			SqlRepository repo = new SqlRepository(con);
			
			ctx.setAttribute("products", repo.getProducts());
			ctx.setAttribute("providers", repo.getProviders());
			ctx.setAttribute("orders", repo.getOrders());
			
			ctx.setAttribute("con", con);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void contextDestroyed(ServletContextEvent sce) {
		try {
			((Connection) sce.getServletContext().getAttribute("con")).close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
