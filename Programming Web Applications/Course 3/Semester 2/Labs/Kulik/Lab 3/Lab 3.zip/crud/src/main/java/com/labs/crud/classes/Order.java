package com.labs.crud.classes;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.atomic.AtomicInteger;

import com.labs.crud.classes.Product;
import com.labs.crud.classes.Provider;

public class Order {
	private int id;
	private Product product;
	private Provider provider;
	private int quantity;
	public static Connection con;
	
	public Order(int id, Product product, Provider provider, int quantity) {
		super();
		this.id = id;
		this.product = product;
		this.provider = provider;
		this.quantity = quantity;
	}
	
	public Order() {
		
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Provider getProvider() {
		return provider;
	}

	public void setProvider(Provider provider) {
		this.provider = provider;
	}
	
	public boolean create(){
		String sql = "insert into orders values('"+this.getId()+"', '"+this.getProduct().getId()+"', '"+this.getProvider().getId()+"', '"+this.getQuantity()+"')";
		
		Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean delete(){
		String sql = "delete from orders where \"id\"='"+this.getId()+"';";
		
		Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean edit(){
		String sql = "update orders set \"productId\"='"+this.getProduct().getId()+"', \"providerId\"='"+this.getProvider().getId()+"', \"quantity\"='"+this.getQuantity()+"' where \"id\"='"+this.getId()+"';";

		Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}
