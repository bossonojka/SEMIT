package com.labs.crud.classes;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletContext;

public class Product{
	private int id;
	private String name;
	private double price;
	private String manufacturer;
	public static Connection con;
	
	public Product(int id, String name, double price, String manufacturer) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.manufacturer = manufacturer;
	}
	
	public Product() {
		
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public double getPrice() {
		return price;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	public String getManufacturer() {
		return manufacturer;
	}
	
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	
	public boolean create(){
		String sql = "insert into products values('"+this.getId()+"', '"+this.getName()+"', '"+this.getPrice()+"', '"+this.getManufacturer()+"')";
		
		Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean delete(){
		String sql = "delete from products where \"id\"='"+this.getId()+"';";
		
		Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean edit(){
		String sql = "update products set \"name\"='"+this.getName()+"', \"price\"='"+this.getPrice()+"', \"manufacturer\"='"+this.getManufacturer()+"' where \"id\"='"+this.getId()+"';";

		Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}
