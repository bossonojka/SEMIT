package com.labs.crud.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.labs.crud.classes.Product;
import com.labs.crud.util.SqlRepository;

public class ProductCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private List<Product> products;
	private AtomicInteger id;
	private Connection con = null;
       
    public ProductCreate() {
        super();
    }
    
    public void init() {
    	final Object products = getServletContext().getAttribute("products");
    	
    	if (products == null || !(products instanceof CopyOnWriteArrayList)) {
    		throw new IllegalStateException();
    	} else {
    		this.products = (CopyOnWriteArrayList<Product>) products;
    	}
    	if (!this.products.isEmpty()) {
    		this.id = new AtomicInteger(this.products.get(this.products.size() - 1).getId() + 1);
    	} else {
    		this.id = new AtomicInteger(1);
    	}
    	
    	con = (Connection) getServletContext().getAttribute("con");
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("./");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("name") != "" && request.getParameter("manufacturer") != "" && request.getParameter("price") != "") {
			int id = this.id.getAndIncrement();
			String manufacturer = request.getParameter("manufacturer");
			String name = request.getParameter("name");
			double price = Double.parseDouble(request.getParameter("price"));
			
			Product product = new Product(id, name, price, manufacturer);
			boolean result = product.create() ? products.add(product) : false;
		}
		response.sendRedirect("./");
	}
}
