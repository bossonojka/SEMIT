import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;

/**
 * Servlet implementation class RegistrationServlet
 */
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		if ((request.getParameter("password") == "Qwerty" && request.getParameter("username") == "Vladimir")) {
			User u = new User();
            u.setUsername(request.getParameter("username"));
            u.setPassword(request.getParameter("password"));
            
            ArrayList<User> users = new ArrayList<User>();
            for(int i = 0; i < 10; i++) {
            	users.add(new User("user" + i, "Qwerty" + i, "tempmail" + i + "@gmail.com"));
            }
            
            HttpSession session =request.getSession();
            session.setAttribute("user", u);
            session.setAttribute("users", users);

            try {
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/mylist.jsp");
                            rd.forward(request, response);
            } catch (Exception e) {
                e.printStackTrace();
            }
		} else {
			RequestDispatcher view = request.getRequestDispatcher("/index.html");
			view.forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
