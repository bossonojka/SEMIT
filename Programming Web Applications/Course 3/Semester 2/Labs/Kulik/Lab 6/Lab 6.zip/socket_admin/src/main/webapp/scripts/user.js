function start(){
    var handler = {
        onopen: function () {
            
        },
        onclose: function () {
            
        },
        onmessage: function (message) {
            let time = document.querySelector("#time");
            time.textContent = new Date();

            let content = JSON.parse(message.data);

            let table = document.querySelector("table");

            var paras = document.getElementsByClassName('content');
            while(paras[0]) {
                paras[0].parentNode.removeChild(paras[0]);
            }

            for (var i = 0; i < content.length; i++){
                let tr = document.createElement("tr");
                tr.className = "content";

                let id = document.createElement("td");
                let manufacturer = document.createElement("td");
                let name = document.createElement("td");
                let price = document.createElement("td");

                id.textContent = content[i].id;
                id.className = "id";
                manufacturer.textContent = content[i].manufacturer;
                name.textContent = content[i].name;
                price.textContent = content[i].price;

                tr.append(id);
                tr.append(manufacturer);
                tr.append(name);
                tr.append(price);

                table.append(tr);
            }
        }
    };

    shop.initialize(handler);
}

start();