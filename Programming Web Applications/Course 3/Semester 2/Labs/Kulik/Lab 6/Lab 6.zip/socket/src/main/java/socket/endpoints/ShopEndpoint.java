package socket.endpoints;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.websocket.CloseReason;
import javax.websocket.EncodeException;
import javax.websocket.EndpointConfig;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import com.google.gson.Gson;

import socket.coders.MessageDecoder;
import socket.coders.MessageEncoder;
import socket.models.Message;
import socket.models.Product;

@ServerEndpoint(value = "/websocket/shop", encoders = MessageEncoder.class, decoders = MessageDecoder.class)
public class ShopEndpoint {
	static private List<ShopEndpoint> clients = new CopyOnWriteArrayList<ShopEndpoint>();
	static Gson gson = new Gson();
	static public List<Product> products;
	
	Session session;
	
	@OnOpen
	public void onOpen(Session session, EndpointConfig endpointConfig) {
		this.session = session;
		clients.add(this);
	}
	
	@OnClose
	public void onClose(Session session, CloseReason reason) {
		System.out.println("Socket closed: " + reason.getReasonPhrase());
		clients.remove(this);
	}
	
	@OnMessage
	public void onMessage(Message msg) throws EncodeException {
		for (ShopEndpoint client : clients) {
			try {
				client.session.getBasicRemote().sendText((gson.toJson(products)));
			} catch (IOException e) {
				clients.remove(this);
				try {
					client.session.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		}
	}
}
