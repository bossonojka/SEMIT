package socket.coders;

import java.io.StringReader;

import javax.json.Json;
import javax.json.JsonException;
import javax.json.JsonObject;
import javax.websocket.DecodeException;
import javax.websocket.Decoder;
import javax.websocket.EndpointConfig;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import socket.models.Message;

public class MessageDecoder implements Decoder.Text<Message>{
	
	private static Gson gson = new Gson();
	
	@Override
	public void init(EndpointConfig config) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Message decode(String msg) throws DecodeException {
		return gson.fromJson(msg, Message.class);
	}

	@Override
	public boolean willDecode(String msg) {
		return msg != null;
	}
}
