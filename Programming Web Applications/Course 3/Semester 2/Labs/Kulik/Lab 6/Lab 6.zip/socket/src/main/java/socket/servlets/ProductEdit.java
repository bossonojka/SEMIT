package socket.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import socket.models.Product;
import socket.util.Validation;

@MultipartConfig
public class ProductEdit extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ProductEdit() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("product") != null) {
			int productId = Integer.parseInt(request.getParameter("product"));
			
			List<Product> products = (CopyOnWriteArrayList<Product>) getServletContext().getAttribute("products");
			
			for (Product p : products) {
				if (p.getId() == productId) {
					request.setAttribute("product", p);
				}
			}
			request.setAttribute("products", products);
			request.getRequestDispatcher("admin.jsp").forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("name") != "" && request.getParameter("manufacturer") != "" && Validation.isDouble(request.getParameter("price")) && (request.getParameter("product") != "")) {
			int productId = Integer.parseInt(request.getParameter("product"));
			String manufacturer = request.getParameter("manufacturer");
			String name = request.getParameter("name");
			double price = Double.parseDouble(request.getParameter("price"));
			
			List<Product> products = (CopyOnWriteArrayList<Product>) getServletContext().getAttribute("products");
			
			for (Product p : products) {
				if (p.getId() == productId) {
					p.setName(name);
					p.setPrice(price);
					p.setManufacturer(manufacturer);
					p.edit();
				}
			}
		}
		response.sendRedirect("Admin");
	}

}
