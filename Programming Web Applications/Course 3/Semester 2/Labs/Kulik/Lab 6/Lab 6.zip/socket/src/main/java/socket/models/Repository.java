package socket.models;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Repository {
	private SessionFactory factory;
	private List<Product> products;
	
	public Repository(SessionFactory factory) {
		this.factory = factory;
	}
	
	public List<Product> getProducts() {
		Session session = factory.openSession();
        session.beginTransaction();
        
        this.products = new CopyOnWriteArrayList<Product>();
        
        List<Product> products = session.createQuery("from Product", Product.class).list();
         
        for (Product p : products) {
			this.products.add(p);
		}
         
        session.getTransaction().commit();
        session.close(); 
		
		return this.products;
	}
}
