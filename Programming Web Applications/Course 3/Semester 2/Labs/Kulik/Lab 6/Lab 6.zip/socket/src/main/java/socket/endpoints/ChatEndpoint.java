//package socket.endpoints;
//
//import java.io.ByteArrayOutputStream;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.nio.ByteBuffer;
//import java.util.List;
//import java.util.concurrent.CopyOnWriteArrayList;
//
//import javax.websocket.CloseReason;
//import javax.websocket.EncodeException;
//import javax.websocket.EndpointConfig;
//import javax.websocket.OnClose;
//import javax.websocket.OnMessage;
//import javax.websocket.OnOpen;
//import javax.websocket.SendHandler;
//import javax.websocket.SendResult;
//import javax.websocket.Session;
//import javax.websocket.server.ServerEndpoint;
//
//import socket.models.Message;
//
//import socket.coders.*;
//
//@ServerEndpoint(value = "/websocket/chat", encoders = MessageEncoder.class, decoders = MessageDecoder.class)
//public class ChatEndpoint {
//	
//	static List<ChatEndpoint> clients = new CopyOnWriteArrayList<ChatEndpoint>();
//	
//	Session session;
//	
//	@OnOpen
//	public void onOpen(Session session, EndpointConfig _) {
//		this.session = session;
//		clients.add(this);
//	}
//	
//	@OnClose
//	public void onClose(Session session, CloseReason reason) {
//		System.out.println("Socket closed: " + reason.getReasonPhrase());
//		clients.remove(this);
//	}
//	
//	@OnMessage
//	public void onMessage(Message message) {
//		broadcast(message);
//	}
//	
//	ByteArrayOutputStream buffer = new ByteArrayOutputStream();
//	
//	@OnMessage
//	public void onMessage(ByteBuffer byteBuffer, boolean complete) {
//		try {
//			buffer.write(byteBuffer.array());
//			if (complete) {
//				FileOutputStream fos = null;
//				try {
//					fos = new FileOutputStream("d:\\image.jpg");
//					fos.write(buffer.toByteArray());
//				} finally {
//					if (fos != null) {
//						fos.flush();
//						fos.close();
//					}
//				}
//				for (ChatEndpoint client : clients) {
//					final ByteBuffer sendData = ByteBuffer.allocate(buffer.toByteArray().length);
//					sendData.put(buffer.toByteArray());
//					sendData.rewind();
//					client.session.getAsyncRemote().sendBinary(sendData, new SendHandler() {
//						
//						@Override
//						public void onResult(SendResult result) {
//							// TODO Auto-generated method stub
//							System.out.println(result.isOK());
//						}
//					});
//				}
//			}
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//	
//	private void broadcast(Message message) {
//		for (ChatEndpoint client : clients) {
//			try {
//				client.session.getBasicRemote().sendObject(message);
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				clients.remove(this);
//				try {
//					client.session.close();
//				} catch (IOException e1) {
//					// TODO Auto-generated catch block
//				}
//			} catch (EncodeException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//	}
//}