package socket_user.listeners;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import socket_user.models.Product;
import socket_user.util.Repository;

public class ContextListener implements ServletContextListener {
	
	private SessionFactory factory;

	public void contextInitialized(ServletContextEvent sce) {
		final ServletContext ctx = sce.getServletContext();

		StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure().build(); 
		factory = new MetadataSources(registry).buildMetadata().buildSessionFactory(); 
		
		Product.factory = factory;
		Repository repo = new Repository(factory);
		
		List<Product> products = repo.getProducts();
		
		ctx.setAttribute("products", products);
		ctx.setAttribute("repo", repo);
	}

	public void contextDestroyed(ServletContextEvent sce) {
		
	}
}
