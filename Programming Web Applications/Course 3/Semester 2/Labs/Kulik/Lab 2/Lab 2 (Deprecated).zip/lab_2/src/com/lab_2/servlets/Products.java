package com.lab_2.servlets;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lab_2.models.Product;

/**
 * Servlet implementation class Products
 */
public class Products extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Products() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ArrayList<Product> pr = (ArrayList) getServletContext().getAttribute("products");
		request.setAttribute("products", getServletContext().getAttribute("products"));
		
		if((null != request.getParameter("delete"))) {
			pr.remove(Integer.parseInt(request.getParameter("delete")));
		} else if ((null != request.getParameter("edit"))) {
			int id = Integer.parseInt(request.getParameter("edit"));
			String name = pr.get(id).getName();
			float price = pr.get(id).getPrice();
			String manufacturer = pr.get(id).getManufacturer();
			
			request.setAttribute("name", name);
			request.setAttribute("price", price);
			request.setAttribute("manufacturer", manufacturer);
			request.setAttribute("id", id);
		}
		
		RequestDispatcher rd = request.getRequestDispatcher("/products.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		float price = Float.parseFloat(request.getParameter("price"));
		String manufacturer = request.getParameter("manufacturer");
		
		ArrayList<Product> products = (ArrayList) getServletContext().getAttribute("products");
		
		if((null != request.getParameter("id"))) {
			int id = Integer.parseInt(request.getParameter("id"));
			products.get(id).setName(name);
			products.get(id).setPrice(price);
			products.get(id).setManufacturer(manufacturer);
		} else {
			products.add(new Product(name, price, manufacturer));
		}
		response.sendRedirect("/lab_2");	
	}

}
