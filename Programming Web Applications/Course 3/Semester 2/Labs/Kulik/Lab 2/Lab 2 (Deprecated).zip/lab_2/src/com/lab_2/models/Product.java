package com.lab_2.models;

import java.io.Serializable;

public class Product implements Serializable{
	private String name;
	private float price;
	private String manufacturer;
	
	public Product(String name, float price, String manufacturer) {
		super();
		this.name = name;
		this.price = price;
		this.manufacturer = manufacturer;
	}
	
	public Product() {
		
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public float getPrice() {
		return this.price;
	}

	public void setPrice(float price) {
		this.price = price;
	}
	
	public String getManufacturer() {
		return this.manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
}
