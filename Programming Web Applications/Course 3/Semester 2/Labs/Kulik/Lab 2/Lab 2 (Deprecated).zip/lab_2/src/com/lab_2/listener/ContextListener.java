package com.lab_2.listener;

import java.math.BigDecimal;
import java.util.ArrayList;

import javax.servlet.*;

import com.lab_2.models.Order;
import com.lab_2.models.Product;
import com.lab_2.models.Provider;

public class ContextListener implements ServletContextListener {
	public void contextInitialized(ServletContextEvent event) {
		ArrayList<Product> products = new ArrayList<Product>();
		
		products.add(new Product("GTX 1080Ti Gaming X+", 25999, "MSI"));
		products.add(new Product("GTX 1070 Gaming Z", 18999, "MSI"));
		products.add(new Product("GTX 1060 Gaming X", 11999, "MSI"));
		products.add(new Product("GTX 1050 Gaming", 8999, "MSI"));
		products.add(new Product("GTX 2080 Duke", 26999, "MSI"));
		
		ArrayList<Order> orders = new ArrayList<Order>();
		
		orders.add(new Order(1, new Product("GTX 1080Ti Gaming X+", 25999, "MSI"), new Provider("Amazon", "provider@amazon.com"), 2));
		orders.add(new Order(2, new Product("GTX 1080Ti Gaming X+", 25999, "MSI"), new Provider("Amazon", "provider@amazon.com"), 5));
		orders.add(new Order(3, new Product("GTX 1080 Gaming X", 20855, "MSI"), new Provider("Amazon", "provider@amazon.com"), 8));
		orders.add(new Order(4, new Product("GTX 1080 Aourus", 20100, "MSI"), new Provider("Ebay", "provider@ebay.com"), 2));
		orders.add(new Order(5, new Product("GTX 1080Ti Gaming X+", 25450, "MSI"), new Provider("Ebay", "provider@ebay.com"), 3));
		orders.add(new Order(6, new Product("GTX 1080Ti Gaming X+", 24999, "MSI"), new Provider("ComputerUniverse", "provider@compuni.de"), 1));
		orders.add(new Order(7, new Product("GTX 1080Ti Gaming X+", 24999, "MSI"), new Provider("ComputerUniverse", "provider@compuni.de"), 2));
		
		ArrayList<Provider> providers = new ArrayList<Provider>();
		
		providers.add(new Provider("Amazon", "provider@amazon.com"));
		providers.add(new Provider("Ebay", "provider@ebay.com"));
		providers.add(new Provider("ComputerUniverse", "provider@compuni.de"));
		providers.add(new Provider("Alibaba", "provider@alibaba.com"));
		
		event.getServletContext().setAttribute("products", products);
		event.getServletContext().setAttribute("orders", orders);
		event.getServletContext().setAttribute("providers", providers);
	}
	
	public void contextDestroyed(ServletContextEvent event) {
		
	}
}
