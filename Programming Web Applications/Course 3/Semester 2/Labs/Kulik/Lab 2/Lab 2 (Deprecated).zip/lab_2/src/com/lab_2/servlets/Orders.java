package com.lab_2.servlets;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lab_2.models.Order;
import com.lab_2.models.Product;
import com.lab_2.models.Provider;

/**
 * Servlet implementation class Orders
 */
public class Orders extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Orders() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ArrayList<Order> orders = (ArrayList) getServletContext().getAttribute("orders");
		request.setAttribute("orders", orders);
		
		RequestDispatcher rd = request.getRequestDispatcher("/orders.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ArrayList<Order> orders = (ArrayList) getServletContext().getAttribute("orders");
		
		if((null != request.getParameter("provider"))) {
			String key = request.getParameter("provider");	
			System.out.println(key);
			
			ArrayList<Order> result = new ArrayList<Order>();
			for (Order temp : orders) {
	            if (key.equals(temp.getProvider().getName())) {
	                result.add(temp);
	            }
	        }
			request.setAttribute("orders", result);
		}
		
		RequestDispatcher rd = request.getRequestDispatcher("/orders.jsp");
		rd.forward(request, response);
	}

}
