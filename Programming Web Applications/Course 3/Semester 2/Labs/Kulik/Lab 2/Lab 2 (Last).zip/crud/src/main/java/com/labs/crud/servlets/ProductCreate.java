package com.labs.crud.servlets;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.labs.crud.classes.Product;

/**
 * Servlet implementation class ProductCreate
 */
public class ProductCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private List<Product> products;
	private AtomicInteger id;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductCreate() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    public void init() {
    	final Object products = getServletContext().getAttribute("products");
    	
    	if (products == null || !(products instanceof CopyOnWriteArrayList)) {
    		throw new IllegalStateException();
    	} else {
    		this.products = (CopyOnWriteArrayList<Product>) products;
    	}
    	if (!this.products.isEmpty()) {
    		this.id = new AtomicInteger(this.products.get(this.products.size() - 1).getId() + 1);
    	} else {
    		this.id = new AtomicInteger(1);
    	}
    	
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("./");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("name") != "" && request.getParameter("manufacturer") != "" && request.getParameter("price") != "") {
			int id = this.id.getAndIncrement();
			String manufacturer = request.getParameter("manufacturer");
			String name = request.getParameter("name");
			double price = Double.parseDouble(request.getParameter("price"));
			
			products.add(new Product(id, name, price, manufacturer));
		}
		response.sendRedirect("./");
	}

}
