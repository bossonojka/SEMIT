package com.labs.crud.util;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletContext;

import com.labs.crud.classes.Order;
import com.labs.crud.classes.Product;
import com.labs.crud.classes.Provider;

public class CascadeDelete {
	static public void productOrder(int id, ServletContext ctx) {
		List<Product> products = (CopyOnWriteArrayList<Product>) ctx.getAttribute("products");
		List<Order> orders = (CopyOnWriteArrayList<Order>) ctx.getAttribute("orders");
		
		for (Product p : products) {
			if (p.getId() == id) {
				products.remove(p);
				for (Order o: orders) {
					if (o.getProduct().equals(p)) {
						orders.remove(o);
					}
				}
			}
		}
	}
	static public void providerOrder(int id, ServletContext ctx) {
		List<Provider> providers = (CopyOnWriteArrayList<Provider>) ctx.getAttribute("providers");
		List<Order> orders = (CopyOnWriteArrayList<Order>) ctx.getAttribute("orders");
		
		for (Provider p : providers) {
			if (p.getId() == id) {
				providers.remove(p);
				for (Order o: orders) {
					if (o.getProvider().equals(p)) {
						orders.remove(o);
					}
				}
			}
		}
	}
}
