package com.labs.crud.servlets;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.labs.crud.classes.Order;
import com.labs.crud.classes.Product;
import com.labs.crud.classes.Provider;

/**
 * Servlet implementation class OrderCreare
 */
public class OrderCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private List<Order> orders;
	private AtomicInteger id;
   
	/**
     * @see HttpServlet#HttpServlet()
     */
    public OrderCreate() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    public void init() {
    	final Object orders = getServletContext().getAttribute("orders");
    	
    	if (orders == null || !(orders instanceof CopyOnWriteArrayList)) {
    		throw new IllegalStateException();
    	} else {
    		this.orders = (CopyOnWriteArrayList<Order>) orders;
    	}
    	if (!this.orders.isEmpty()) {
    		this.id = new AtomicInteger(this.orders.get(this.orders.size() - 1).getId() + 1);
    	} else {
    		this.id = new AtomicInteger(1);
    	}
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("Orders");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("product") != null && request.getParameter("provider") != null && (request.getParameter("quantity") != null)) {
			int id = this.id.getAndIncrement();
			int productId = Integer.parseInt(request.getParameter("product"));
			int providerId = Integer.parseInt(request.getParameter("provider"));
			int quantity = Integer.parseInt(request.getParameter("quantity"));
			
			List<Product> products = (CopyOnWriteArrayList<Product>) getServletContext().getAttribute("products");
			List<Provider> providers = (CopyOnWriteArrayList<Provider>) getServletContext().getAttribute("providers");
			
			Product product = null;
			for (Product p : products) {
				if (p.getId() == productId) {
					product = p;
				}
			}
			
			Provider provider = null;
			for (Provider p : providers) {
				if (p.getId() == providerId) {
					provider = p;
				}
			}
			
			orders.add(new Order(id, product, provider, quantity));
		}
		response.sendRedirect("Orders");
	}

}
