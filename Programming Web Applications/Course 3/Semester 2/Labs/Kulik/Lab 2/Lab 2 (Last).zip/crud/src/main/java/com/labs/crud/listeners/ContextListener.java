package com.labs.crud.listeners;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.labs.crud.classes.Product;
import com.labs.crud.classes.Order;
import com.labs.crud.classes.Provider;
import com.labs.crud.util.XmlHelper;

public class ContextListener implements ServletContextListener {

	public void contextInitialized(ServletContextEvent sce) {
		final ServletContext ctx = sce.getServletContext();
		
		List<Product> products = new CopyOnWriteArrayList<Product>();
		ctx.setAttribute("products", products);
		
		List<Provider> providers = new CopyOnWriteArrayList<Provider>();
		ctx.setAttribute("providers", providers);
		
		List<Order> orders = new CopyOnWriteArrayList<Order>();
		ctx.setAttribute("orders", orders);
		
		XmlHelper.readProducts(sce.getServletContext(), products);
		XmlHelper.readOrders(sce.getServletContext(), orders);
		XmlHelper.readProviders(sce.getServletContext(), providers);
	}

	public void contextDestroyed(ServletContextEvent sce) {
		// TODO Auto-generated method stub
		
	}
	
}
