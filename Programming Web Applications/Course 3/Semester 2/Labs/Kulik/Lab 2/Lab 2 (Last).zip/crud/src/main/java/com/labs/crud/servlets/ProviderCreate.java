package com.labs.crud.servlets;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.labs.crud.classes.Provider;

/**
 * Servlet implementation class ProviderCreate
 */
public class ProviderCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private List<Provider> providers;
	private AtomicInteger id;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProviderCreate() {
        super();
        // TODO Auto-generated constructor stub
    }

    public void init() {
    	final Object providers = getServletContext().getAttribute("providers");
    	
    	if (providers == null || !(providers instanceof CopyOnWriteArrayList)) {
    		throw new IllegalStateException();
    	} else {
    		this.providers = (CopyOnWriteArrayList<Provider>) providers;
    	}
    	
    	if (!this.providers.isEmpty()) {
    		this.id = new AtomicInteger(this.providers.get(this.providers.size() - 1).getId() + 1);
    	} else {
    		this.id = new AtomicInteger(1);
    	}
    	
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("Providers");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("name") != null && request.getParameter("email") != null) {
			int id = this.id.getAndIncrement();
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			
			providers.add(new Provider(id, name, email));
		}
		response.sendRedirect("Providers");
	}

}
