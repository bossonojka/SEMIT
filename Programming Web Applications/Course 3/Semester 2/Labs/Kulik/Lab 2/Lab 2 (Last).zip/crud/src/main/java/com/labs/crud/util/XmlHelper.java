package com.labs.crud.util;

import java.beans.ExceptionListener;
import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.IntStream;

import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.labs.crud.classes.Order;
import com.labs.crud.classes.Product;
import com.labs.crud.classes.Provider;

public class XmlHelper {
	public static void exportOrders(List<Order> orders, String path) throws IOException {
		FileOutputStream fos = new FileOutputStream(path);
		
		XMLEncoder encoder = new XMLEncoder(fos);
        encoder.setExceptionListener(new ExceptionListener() {
            public void exceptionThrown(Exception e) {
                System.out.println("Exception:" + e.toString());
            }
        });
        
        for (Order o : orders) {
        	encoder.writeObject(o);
        }
        
        encoder.close();
        fos.close();
	}
	
	public static void exportProviders(List<Provider> providers, String path) throws IOException {
		FileOutputStream fos = new FileOutputStream(path);
		
		XMLEncoder encoder = new XMLEncoder(fos);
        encoder.setExceptionListener(new ExceptionListener() {
            public void exceptionThrown(Exception e) {
                System.out.println("Exception:" + e.toString());
            }
        });
        
        for (Provider p : providers) {
        	encoder.writeObject(p);
        }
        
        encoder.close();
        fos.close();
	}
	
	public static void exportProducts(List<Product> products, String path) throws IOException {
		FileOutputStream fos = new FileOutputStream(path);
		
		XMLEncoder encoder = new XMLEncoder(fos);
        encoder.setExceptionListener(new ExceptionListener() {
            public void exceptionThrown(Exception e) {
                System.out.println("Exception:" + e.toString());
            }
        });
        
        for (Product p : products) {
        	encoder.writeObject(p);
        }
        
        encoder.close();
        fos.close();
	}
	
	public static void getProductXml(List<Product> products, HttpServletResponse response) {
		try {
			ServletOutputStream sos = response.getOutputStream();
			XMLEncoder encoder = new XMLEncoder(sos);
			
			for (Product p : products) {
	        	encoder.writeObject(p);
	        }
			
			encoder.close();
	        sos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void getProviderXml(List<Provider> providers, HttpServletResponse response) {
		try {
			ServletOutputStream sos = response.getOutputStream();
			XMLEncoder encoder = new XMLEncoder(sos);
			
			for (Provider p : providers) {
	        	encoder.writeObject(p);
	        }
			
			encoder.close();
	        sos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void getOrderXml(List<Order> orders, HttpServletResponse response) {
		try {
			ServletOutputStream sos = response.getOutputStream();
			XMLEncoder encoder = new XMLEncoder(sos);
			
			for (Order o : orders) {
	        	encoder.writeObject(o);
	        }
			
			encoder.close();
	        sos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void readOrders(ServletContext sc, List<Order> orders) {
		final String path = sc.getInitParameter("xmlPath") + sc.getInitParameter("ordersPath");
	
		try {
    		Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(path);
			FileInputStream fis = new FileInputStream(path);
			XMLDecoder decoder = new XMLDecoder(fis);
			
			NodeList list = document.getDocumentElement().getChildNodes();
			IntStream.range(0, list.getLength())
			        .filter(i -> list.item(i).getNodeName().equals("object"))
			        .forEach(i -> orders.add((Order) decoder.readObject()));
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void readProviders(ServletContext sc, List<Provider> providers) {
		final String path = sc.getInitParameter("xmlPath") + sc.getInitParameter("providersPath");
	
		try {
    		Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(path);
			FileInputStream fis = new FileInputStream(path);
			XMLDecoder decoder = new XMLDecoder(fis);
			
			for (int i = 0; i < document.getElementsByTagName("object").getLength(); i++) {
				providers.add((Provider) decoder.readObject());
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void readProducts(ServletContext sc, List<Product> products) {
		final String path = sc.getInitParameter("xmlPath") + sc.getInitParameter("productsPath");
	
		try {
    		Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(path);
			FileInputStream fis = new FileInputStream(path);
			XMLDecoder decoder = new XMLDecoder(fis);
			
			for (int i = 0; i < document.getElementsByTagName("object").getLength(); i++) {
				products.add((Product) decoder.readObject());
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
