package com.labs.crud.servlets;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.labs.crud.classes.Order;
import com.labs.crud.classes.Product;
import com.labs.crud.classes.Provider;
import com.labs.crud.util.XmlHelper;

/**
 * Servlet implementation class XmlCreate
 */
public class XmlCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private List<Order> orders;
	private List<Product> products;
	private List<Provider> providers;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public XmlCreate() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    public void init() {
    	final Object orders = getServletContext().getAttribute("orders");
    	final Object products = getServletContext().getAttribute("products");
    	final Object providers = getServletContext().getAttribute("providers");
    	
    	if (orders == null || !(orders instanceof CopyOnWriteArrayList)) {
    		throw new IllegalStateException();
    	} else {
    		this.orders = (CopyOnWriteArrayList<Order>) orders;
    	}
    	
    	if (products == null || !(products instanceof CopyOnWriteArrayList)) {
    		throw new IllegalStateException();
    	} else {
    		this.products = (CopyOnWriteArrayList<Product>) products;
    	}
    	
    	if (providers == null || !(providers instanceof CopyOnWriteArrayList)) {
    		throw new IllegalStateException();
    	} else {
    		this.providers = (CopyOnWriteArrayList<Provider>) providers;
    	}
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = getServletConfig().getInitParameter("xmlPath");
		String ordersPath = path + getServletContext().getInitParameter("ordersPath");
		String productsPath = path + getServletContext().getInitParameter("productsPath");
		String providersPath = path + getServletContext().getInitParameter("providersPath");
		
		switch(request.getParameter("type")) {
			case "all":
				XmlHelper.exportOrders(this.orders, ordersPath);
				XmlHelper.exportProducts(this.products, productsPath);
				XmlHelper.exportProviders(this.providers, providersPath);
				break;
			case "products":
				XmlHelper.getProductXml(this.products, response);
				break;
			case "providers":
				XmlHelper.getProviderXml(this.providers, response);
				break;
			case "orders":
				XmlHelper.getOrderXml(this.orders, response);
				break;
		}
		response.sendRedirect("./");
	}

}
