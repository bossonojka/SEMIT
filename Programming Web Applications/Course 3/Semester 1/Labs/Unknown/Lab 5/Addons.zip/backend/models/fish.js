var mongoose = require('mongoose');

var typeDogs = new mongoose.Schema({
    typeFish: String,
    size: String
});

var dogsSchema = new mongoose.Schema({
    name: String,
    age: String,
    color: String,
    typeFish: typeFish,
});



var db =  mongoose.model('Fish', dogsSchema);

module.exports = db;
