const express = require("express");

const router = express.Router();
var FishModel = require('../models/fish');


router.post("", function (req, res, next) {

    const fish = new FishModel({
        name: req.body.name,
        age: req.body.age,
        color: req.body.color,
        typeFish: {
            typeFish: req.body.typeFish.typeFish,
            size: req.body.typeFish.size
        }
    });
    fish.save();

    res.status(201).json(fish);
    next();
});


router.get('', (req, res, next) => {
    FishModel.find({}, function (err, result) {
        if (err) {
            console.log(err);
        }

        res.status(200).json(result);

    })
})

router.get('/:id', function (req, res, next) {
    FishModel.findById(req.params.id).then(result => {
        if (result)
            res.status(200).json(result);
        else
            res.status(404).json({message: 'Fish not found'});
    })
})

router.put('/:id', function (req, res) {

    var id = req.params["id"];
    var name = req.body.name;
    var age = req.body.age;
    var color = req.body.color;
    var typeFish = req.body.typeFish;

    FishModel.findOneAndUpdate({_id: id},
        {
            name,
            age,
            color,
            typeFish
        },
        {
            returnOriginal: true
        },
        function (err, result) {
            if (err)
                console.log(err);
            console.log(result);
            res.send(result);
        });
});


router.delete('/:id', (req, res, next) => {
    FishModel.deleteOne({_id: req.params.id}).then(result => {
// res.status(200).json(result);
        console.log('delet elem' + result);
    })
});

module.exports = router;