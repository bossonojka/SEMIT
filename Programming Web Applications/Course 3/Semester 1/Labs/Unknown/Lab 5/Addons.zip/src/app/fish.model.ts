export interface Fish {
    id: string;
    name: string;
    age: string;
    color: string;
    typeFish: {
        typeFish: string,
        size: string
    };
}