import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {FishListComponent} from './fishs/fish-list/fish-list.component';
import {FishComponent} from './fishs/fish/fish.component';

const routes: Routes = [
    {path: '', component: FishListComponent},
    {path: 'create' , component : FishComponent },
    {path : 'edit/:fishId' , component: FishComponent}
    ];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule {
}
