import {Component, OnDestroy, OnInit} from '@angular/core';
import {FishService} from '../../fish.service';
import {Fish} from '../../fish.model';
import {Subscription} from 'rxjs';


@Component({
    selector: 'app-fish-list',
    templateUrl: './fish-list.component.html',
    styleUrls: ['./fish-list.component.css']
})
export class FishListComponent implements OnInit, OnDestroy {
    fishs: Fish[] = [];
    private postSub: Subscription;

    constructor(public fishService: FishService) {
    }

    ngOnInit() {
        this.fishService.getFishs();
        this.postSub = this.fishService.getFishUpdateListener().subscribe((data: Fish[]) => {
            this.fishs = data;
        });
    }

    onDelete(postID: string) {
        this.fishService.deleteFish(postID);
    }

    ngOnDestroy() {
        this.postSub.unsubscribe();
    }
}
