import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {FormsModule} from '@angular/forms';

import {HttpClientModule} from '@angular/common/http';

import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';

import {HeaderComponent} from './fishs/header/header.component';

import {
    MatToolbarModule,
    MatExpansionModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatProgressSpinnerModule
} from '@angular/material';



import {FishListComponent} from './fishs/fish-list/fish-list.component';
import {FishComponent} from './fishs/fish/fish.component';


@NgModule({
    declarations: [
        AppComponent,
        HeaderComponent,
        FishListComponent,
        FishComponent
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        FormsModule,
        BrowserAnimationsModule,
        MatToolbarModule,
        MatExpansionModule,
        MatInputModule,
        MatSelectModule,
        MatButtonModule,
        MatProgressSpinnerModule,
        HttpClientModule
    ],
    providers: [AppComponent],
    bootstrap: [AppComponent]
})
export class AppModule {
}
