import {Fish} from './fish.model';
import {Injectable} from '@angular/core';
import {Subject} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import {map} from 'rxjs/operators';
import {Router} from '@angular/router';

@Injectable({
    providedIn: 'root',

})
export class FishService {
    private fishs: Fish [] = [];
    private fishUpdates = new Subject<Fish []>();


    constructor(private http: HttpClient , private router : Router) {

    }

    getFishs() {
        this.http.get<any>('http://localhost:3000/fishs').pipe(map(function (postData) {
            return postData.map(post => {
                return {
                    id: post._id,
                    name: post.name,
                    age: post.age,
                    color: post.color,
                    typeFish: {
                        typeFish: post.typeFish.typeFish,
                        size: post.typeFish.size,
                    }
                };
            });
        })).subscribe((transFish) => {
            this.fishs = transFish;
            this.fishUpdates.next([...this.fishs]);
        });
    }

    getFish(id: string) {
        return this.http.get<Fish>('http://localhost:3000/fishs/' + id);
    }

    deleteFish(fishId: string) {
        console.log('delete Elem');
        this.http.delete('http://localhost:3000/fishs/' + fishId).subscribe(() => {
        });
        const newFishList = this.fishs.filter(fish => fish.id !== fishId);
        this.fishs = newFishList;
        this.fishUpdates.next([...this.fishs]);
    }

    getFishUpdateListener() {
        return this.fishUpdates.asObservable();
    }

    addFish(fish: Fish) {
        this.http.post<any>('http://localhost:3000/fishs', fish).pipe(map(function (addFish) {
            // return addFish.map(post => {
            return {
                id: addFish._id,
                name: addFish.name,
                age: addFish.age,
                color: addFish.color,
                typeFish: {
                    typeFish: addFish.typeFish.typeFish,
                    size: addFish.typeFish.size,
                }
            };
            // });
        })).subscribe((newFish) => {
            this.fishs.push(newFish);
            this.fishUpdates.next([...this.fishs]);
            this.router.navigate(['/']);
        });
    }

    updatePost(updateFish: Fish) {
        this.http.put<Fish>('http://localhost:3000/fishs/' + updateFish.id, updateFish).subscribe(response => {
            const updatedPosts = this.fishs;
            const oldPostIndex = updatedPosts.find(p => p.id === updateFish.id);
            // updatedPosts[oldPostIndex] = response;
            this.fishs = updatedPosts;
            this.fishUpdates.next([...this.fishs]);
            this.router.navigate(['/']);
        });
    }
}