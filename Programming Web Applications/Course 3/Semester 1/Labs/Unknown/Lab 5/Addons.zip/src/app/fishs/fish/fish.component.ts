import {Component, OnInit} from '@angular/core';
import {NgForm, NgModel} from '@angular/forms';
import {AppModule} from '../../app.module';

// Для получение параметров URL
import {ActivatedRoute, ParamMap} from '@angular/router';

import {Fish} from '../../fish.model';
import {FishService} from '../../fish.service';
import {MatProgressSpinnerModule} from '@angular/material';

@Component({
    selector: 'app-fish',
    templateUrl: './fish.component.html',
    styleUrls: ['./fish.component.css']
})
export class FishComponent implements OnInit {

    private mode = 'create';
    private fishId: string;
    isLoading = false;
    fish: Fish;

    constructor(public fishService: FishService, public route: ActivatedRoute) {
    }

    ngOnInit() {
        this.route.paramMap.subscribe((paramMap: ParamMap) => {
            if (paramMap.has('fishId')) {
                this.mode = 'edit';
                this.fishId = paramMap.get('fishId');
                this.isLoading = true;
                this.fishService.getFish(this.fishId).subscribe(result => {
                    this.isLoading = false;
                    this.fish = result;
                });
            } else {
                this.mode = 'create';
                this.fishId = null;
            }
        });
    }

    onSavePost(form: NgForm) {
        if (form.invalid) {
            return;
        }
       this.isLoading = true;
        if (this.mode === 'create') {
            const newFish = {
                id: null,
                name: form.value.name,
                age: form.value.age,
                color: form.value.color,
                typeFish: {
                    typeFish: form.value.typeFish,
                    size: form.value.size,
                }
            };
            this.fishService.addFish(newFish);
        } else {
            const upgradeFish = {
                id: this.fishId,
                name: form.value.name,
                age: form.value.age,
                color: form.value.color,
                typeFish: {
                    typeFish: form.value.typeFish,
                    size: form.value.size,
                }
            };
            this.fishService.updatePost(upgradeFish);
        }
        form.resetForm();
    }


}
