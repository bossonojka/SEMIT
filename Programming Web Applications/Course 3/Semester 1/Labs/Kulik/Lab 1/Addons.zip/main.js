var video = document.querySelector("#trailer");
var bar = document.querySelector(".bar");
var innerBar = document.querySelector(".inner-bar");

video.ontimeupdate = function(){
    if (video.currentTime == video.duration){
        video.currentTime = 0;
        video.pause();
        return;
    }
    innerBar.style.width = bar.clientWidth * (video.currentTime / video.duration) + "px";
}

bar.onclick = function(e){
    var width = e.pageX - bar.getBoundingClientRect().x;
    video.currentTime = (width * video.duration) / bar.clientWidth;
}

video.ondblclick = () => (video.paused) ? video.play() : video.pause();