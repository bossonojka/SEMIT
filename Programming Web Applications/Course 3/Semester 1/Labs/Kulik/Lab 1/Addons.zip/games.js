var divs = [];

var j = 0;
while (j < 16){
    divs.push(document.querySelector(".inner-content").appendChild(document.createElement("div")));
    j++;
}

var i  = 0;
while (i < divs.length){
    divs[i].onclick = function(e){
        randomCol(e);
    }
    i++;
}

function random(num){
    return Math.floor(Math.random() * (num + 1));
}

function randomCol(e){
    e.target.style.background = "rgb(" + random(255) + "," + random(255) + "," + random(255) + ")";
}

