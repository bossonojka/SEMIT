var worker = new Worker('worker.js');
var input = document.querySelector("#int");
var btn = document.querySelector("#convert");

btn.onclick = function(){
    console.log(input.value + " " + "to worker");
    worker.postMessage(input.value);
}

worker.onmessage = function(e){
    console.log(e.data + " " + "from worker");
    document.querySelector("#result").textContent = e.data;
}