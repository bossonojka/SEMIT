self.onmessage = function(e){
    console.log(e.data + " " + "in worker")
    postMessage(convert(e.data));
}

function convert(num){
    var bits = "";
    if (/^[0-9]+$/.test(num)){
        if (num == 1)
            bits += 1;
        else
            while(true){
                bits += num - parseInt((num / 2)) * 2;
                num = parseInt(num / 2);
                if (num == 1){
                    bits += 1;
                    break;
                }    
            }
    }
    return bits.reverse();
}

String.prototype.reverse = function(){
    var str = "";
    for (var i = this.length - 1; i >= 0; i--){
        str += this[i];
    };
    return str;
}