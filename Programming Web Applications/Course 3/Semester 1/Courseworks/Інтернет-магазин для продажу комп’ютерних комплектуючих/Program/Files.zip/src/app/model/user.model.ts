export class User {
    public id: number;
    public email: string;
    public name: string;
    public surname: string;
    public adress: string;
    public city: string;
    public password: string;
    public role: string;
}