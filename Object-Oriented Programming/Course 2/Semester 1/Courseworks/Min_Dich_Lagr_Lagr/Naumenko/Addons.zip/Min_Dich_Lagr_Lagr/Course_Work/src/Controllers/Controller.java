package Controllers;

import Exceptions.FileReadException;
import Exceptions.SamePointsException;
import Source.XMLFunction;
import generated.FuncData;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import generated.FuncData.FuncPoints.Point;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.WritableImage;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Pair;
import javafx.util.converter.NumberStringConverter;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Controller {

    private static final Pair<String, String> FILTER_XML = new Pair<String, String>("XML-files (*.xml)", "*.xml");
    private static final Pair<String, String> FILTER_HTML = new Pair<String, String>("Html-files (*.html)", "*.html");

    @FXML
    private LineChart<Number, Number> chart;
    @FXML
    private TableView<Point> tableFFunc;
    @FXML
    private TableView<Point> tableGFunc;

    @FXML
    private TableColumn<Point, Number> columnFx;
    @FXML
    private TableColumn<Point, Number> columnFy;
    @FXML
    private TableColumn<Point, Number> columnGx;
    @FXML
    private TableColumn<Point, Number> columnGy;
    @FXML
    private Label labelMinReuslt;
    @FXML
    private Label labelStrMin;
    @FXML
    private TextField from;
    @FXML
    private TextField to;

    private ContextMenu contextMenu;
    private ObservableList<Point> obsF;
    private ObservableList<Point> obsG;

    private XMLFunction xmlFunc;

    public void doNew(ActionEvent actionEvent) {
        clearData();
    }

    public void doOpen(ActionEvent actionEvent) {
        FileChooser fileChooser = getFileChooser("Открыть XML-файл", FILTER_XML);
        File file;
        try {
            if ((file = fileChooser.showOpenDialog(null)) != null) {
                clearData();
                xmlFunc.readFromXML(file.getCanonicalPath());
                updateTables();
            }
        } catch (SamePointsException e) {
            clearData();
            showError("check input data same points");
        } catch (Exception e) {
            clearData();
            e.printStackTrace();
        }
    }

    public void doSave(ActionEvent actionEvent) {

    }

    public void doExit(ActionEvent actionEvent) {
        Platform.exit();
    }

    public void doClear(ActionEvent actionEvent) {
        clearData();
    }

    private void clearData() {
        chart.getData().clear();
        obsG = null;
        obsF = null;
        updateSourceData();
        from.clear();
        to.clear();
        tableGFunc.setItems(null);
        tableFFunc.setItems(null);
        labelMinReuslt.setVisible(false);
        labelStrMin.setVisible(false);
    }

    public void doBuild(ActionEvent actionEvent) {
        try {
            checkPoints();
        } catch (Exception e) {
            showError("check input data same points");
            return;
        }

        chart.getData().clear();
        if (!checkInterval()) {
            showMessage("check interval");
            return;
        }

        if (obsF == null || obsG == null) {
            labelStrMin.setVisible(false);
            labelStrMin.setVisible(false);
            showMessage("fill tables");

            return;
        }
        if(obsF.toString().equals(obsG.toString())){
            showMessage("f(x) = g(x)");

        }

        XYChart.Series<Number, Number> fSeries = new XYChart.Series<>();
        XYChart.Series<Number, Number> gSeries = new XYChart.Series<>();
        XYChart.Series<Number, Number> fgSeries = new XYChart.Series<>();
        ObservableList<Point> observableList = FXCollections.observableArrayList();
        fSeries.setName("f(x)");
        gSeries.setName("g(x)");
        fgSeries.setName("f(x)-g(x)");

        Double f = Double.parseDouble(from.getText());
        Double u = Double.parseDouble(to.getText());
        for (double i = f; i <= u; i += 0.1) {
            double fy = xmlFunc.getF().y(i);
            double gy = xmlFunc.getG().y(i);

            fSeries.getData().add(new XYChart.Data<>(i, fy));
            gSeries.getData().add(new XYChart.Data<>(i, gy));
            fgSeries.getData().add(new XYChart.Data<>(i, fy - gy));

            observableList.add(new Point(i, fy - gy));
        }

        XYChart.Series<Number, Number> res = new XYChart.Series<>();

        labelStrMin.setVisible(true);
        labelMinReuslt.setVisible(true);
        double minx = xmlFunc.findMax(f, u, 0.001);
        double miny = xmlFunc.getF().y(minx) - xmlFunc.getG().y(minx);
        res.getData().add(new XYChart.Data<>(minx, miny));
        res.setName("min");

        chart.getData().add(fSeries);
        chart.getData().add(gSeries);
        chart.getData().add(fgSeries);
        chart.getData().add(res);

        labelMinReuslt.setText(
                "X = " + DecimalFormat.getInstance().format(minx) + " Y = " + DecimalFormat.getInstance().format(miny));

    }

    private void checkPoints() throws SamePointsException {

        Map<Double, Integer> map = new HashMap<>();
        Map<Double, Integer> map2 = new HashMap<>();

        for (Point points : obsF) {
            if (map.get(points.getX()) == null) {
                map.put(points.getX(), 0);
            } else {
                map.put(points.getX(), (map.get(points.getX()) + 1));
            }
        }
        for (Point points : obsG) {
            if (map2.get(points.getX()) == null) {
                map2.put(points.getX(), 0);
            } else {
                map2.put(points.getX(), (map2.get(points.getX()) + 1));
            }
        }

        for (Map.Entry<Double, Integer> pEntry : map.entrySet()) {
            if (pEntry.getValue() > 0) {
                throw new SamePointsException(new Point(pEntry.getKey(), 0.));
            }
        }
        for (Map.Entry<Double, Integer> pEntry : map2.entrySet()) {
            if (pEntry.getValue() > 0) {
                throw new SamePointsException(new Point(pEntry.getKey(), 0.));
            }
        }
    }

    private boolean checkInterval() {
        if (from.getText().length() > 0 && to.getText().length() > 0) {
            try {
                return Double.parseDouble(from.getText()) < Double.parseDouble(to.getText()) ? true : false;
            } catch (Exception e) {
            }
        }
        return false;
    }

    public void doHelp(ActionEvent actionEvent) {
        File file = new File("help.html");
        WebView webView = new WebView();
        webView.getEngine().load(file.toURI().toString());
        Scene scene = new Scene(webView);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }

    public void doReport(ActionEvent actionEvent) {

        if (!xmlFunc.equals(null) && !from.getText().equals("") && !to.getText().equals("")) {
            final WebView webView = new WebView();
            final WebEngine engine = webView.getEngine();

            String imagePath = engine.hashCode() + "Chart.png";
            File imageFullPath = new File(imagePath);
            saveAsPng(imagePath);
            String html = xmlFunc.buildReport(Double.parseDouble(from.getText()), Double.parseDouble(to.getText()),
                    imageFullPath.getPath());
            xmlFunc.saveReport("null.html", html);
            File file = new File("null.html");
            //System.out.println(html);
            engine.load(file.toURI().toString());
            Button button = new Button("Save report");
            button.setOnAction(new EventHandler<ActionEvent>() {

                @Override
                public void handle(ActionEvent event) {
                    // TODO Auto-generated method stub
                    FileChooser fileChooser = getFileChooser("Save report", FILTER_HTML);
                    File file;
                    if ((file = fileChooser.showSaveDialog(null)) != null) {
                        try {
                            String name = file.getAbsolutePath().replaceAll(".html", "");
                            saveAsPng(name + "S.png");
                            String string = xmlFunc.buildReport(Double.parseDouble(from.getText()),
                                    Double.parseDouble(to.getText()),
                                    file.getName().replaceAll(".html", "") + "S.png");
                            xmlFunc.saveReport(file.getPath(), string);
                            showMessage("The report successfully saved");
                        } catch (Exception e) {
                            e.printStackTrace();
                            showError("Error with file saving");
                        }
                    }

                }
            });
            VBox root = new VBox();
            root.getChildren().addAll(webView, button);

            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();

            stage.setOnCloseRequest(e -> {
                new File(imagePath).delete();
                new File("null.html").delete();
            });
        } else

            showMessage("Fill in all the data");

    }

    public void doAbout(ActionEvent actionEvent) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("About ...");
        alert.setHeaderText("Find maximum f(x)-g(x) using method dichotomy");
        alert.setContentText("version 1");
        alert.showAndWait();
    }

    public void doAddFRow(ActionEvent actionEvent) {
        if (obsF == null) {
            updateTables();
        }
        obsF.add(new Point(0., 0.));
        updateSourceData();
    }

    public void doRemoveFRow(ActionEvent actionEvent) {
        if (obsF == null) {
            return;
        }
        if (obsF.size() > 0) {
            obsF.remove(obsF.size() - 1);

        }
        if (obsF.size() <= 0) {
            obsF = null;
        }
        updateSourceData();
    }

    public void doAddGRow(ActionEvent actionEvent) {
        if (obsG == null) {
            updateTables();
        }
        obsG.add(new Point(0., 0.));
        updateSourceData();
    }

    public void doRemoveGRow(ActionEvent actionEvent) {
        if (obsG == null) {
            return;
        }
        if (obsG.size() > 0) {
            obsG.remove(obsG.size() - 1);
        }
        if (obsG.size() <= 0) {
            obsG = null;
        }
        updateSourceData();
    }

    private void updateSourceData() {
        xmlFunc.getData().clearData();
        if (obsF != null)
            for (Point point : obsF) {
                xmlFunc.getData().getFFuncPoints().getPoint().add(point);
            }
        System.out.println();
        if (obsG != null)
            for (Point point : obsG) {
                xmlFunc.getData().getGFuncPoints().getPoint().add(point);
            }
        xmlFunc.updateFunc();
    }

    private void updateTables() {
        List<Point> fList = new ArrayList<>();
        List<Point> gList = new ArrayList<>();

        obsF = FXCollections.observableList(fList);
        obsG = FXCollections.observableList(gList);

        for (Point point : xmlFunc.getData().getFFuncPoints().getPoint()) {
            fList.add(point);
        }

        for (Point point : xmlFunc.getData().getGFuncPoints().getPoint()) {
            gList.add(point);
        }
        tableFFunc.setItems(obsF);
        tableGFunc.setItems(obsG);

        columnFx.setCellValueFactory(new PropertyValueFactory<>("x"));
        columnFx.setCellFactory(TextFieldTableCell.<Point, Number>forTableColumn(new NumberStringConverter()));
        columnFx.setOnEditCommit(t -> ((Point) t.getTableView().getItems().get(t.getTablePosition().getRow()))
                .setX(t.getNewValue().doubleValue()));

        columnFy.setCellValueFactory(new PropertyValueFactory<>("y"));
        columnFy.setCellFactory(TextFieldTableCell.<Point, Number>forTableColumn(new NumberStringConverter()));
        columnFy.setOnEditCommit(t -> ((Point) t.getTableView().getItems().get(t.getTablePosition().getRow()))
                .setY(t.getNewValue().doubleValue()));

        columnGx.setCellValueFactory(new PropertyValueFactory<>("x"));
        columnGx.setCellFactory(TextFieldTableCell.<Point, Number>forTableColumn(new NumberStringConverter()));
        columnGx.setOnEditCommit(t -> ((Point) t.getTableView().getItems().get(t.getTablePosition().getRow()))
                .setX(t.getNewValue().doubleValue()));

        columnGy.setCellValueFactory(new PropertyValueFactory<>("y"));
        columnGy.setCellFactory(TextFieldTableCell.<Point, Number>forTableColumn(new NumberStringConverter()));
        columnGy.setOnEditCommit(t -> ((Point) t.getTableView().getItems().get(t.getTablePosition().getRow()))
                .setY(t.getNewValue().doubleValue()));


    }

    public FileChooser getFileChooser(String title, Pair<String, String> filters) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setInitialDirectory(new File("."));
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter(filters.getKey(), filters.getValue()));
        fileChooser.setTitle(title);
        return fileChooser;
    }

    public void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(message);
        alert.showAndWait();
    }

    public void showMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("");
        alert.setHeaderText(message);
        alert.showAndWait();
    }

    public void saveAsPng(String path) {
        WritableImage image = chart.snapshot(new SnapshotParameters(), null);
        File file = new File(path);
        try {
            ImageIO.write(SwingFXUtils.fromFXImage(image, null), "png", file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void initialize() {
        xmlFunc = new XMLFunction();
        //  chart.setCreateSymbols(false);
        tableFFunc.setEditable(true);
        tableGFunc.setEditable(true);
        columnFx.setSortable(false);
        columnFy.setSortable(false);
        columnGx.setSortable(false);
        columnGy.setSortable(false);


        tableFFunc.setContextMenu(createMenu(0));
        tableGFunc.setContextMenu(createMenu(1));

        from.textProperty().addListener(new FieldListener(from));
        to.textProperty().addListener(new FieldListener(to));
    }

    private ContextMenu createMenu(final int i) {
        ContextMenu contextMenu = new ContextMenu();

        String s = i == 0 ? "FFunc" : "GFunc";

        MenuItem item1 = new MenuItem("Add " + s + " row");
        item1.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                if (i == 0)
                    doAddFRow(null);
                else doAddGRow(null);
            }
        });
        MenuItem item2 = new MenuItem("Remove " + s + " row");
        item2.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                if (i == 0)
                    doRemoveFRow(null);
                else doRemoveGRow(null);
            }
        });

        // Add MenuItem to ContextMenu
        contextMenu.getItems().addAll(item1, item2);
        return contextMenu;
    }

    public void doOpenReport(ActionEvent actionEvent) {
        FileChooser fileChooser = getFileChooser("Open report", FILTER_HTML);
        File file;
        file = fileChooser.showOpenDialog(null);
        WebView webView = new WebView();
        webView.getEngine().load(file.toURI().toString());
        Scene scene = new Scene(webView);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();

    }

    class FieldListener implements ChangeListener<String> {
        private TextField field;

        public FieldListener(TextField field) {
            this.field = field;
        }

        @Override
        public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
            //  if (!isNumber(newValue) || newValue.isEmpty()) {
            //  field.setText(newValue.length() > 1 ? newValue.substring(0, newValue.length() - 1) : "");
            //  }
        }
    }

}
