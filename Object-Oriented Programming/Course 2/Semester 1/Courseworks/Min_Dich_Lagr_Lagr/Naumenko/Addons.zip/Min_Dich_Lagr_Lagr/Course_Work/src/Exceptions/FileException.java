package Exceptions;

public class FileException extends Exception {
	private String fileName;

	public FileException(String fileName) {
		this.fileName = fileName;
	}

	public String getFileName() {
		return fileName;
	}
}

