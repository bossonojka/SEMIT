package Exceptions;

public class FileReadException extends FileException {
	public FileReadException(String fileName) {
		super(fileName);
	}
}
