
package generated;

import Source.ExtendedFunction;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "funcPoints"
})
@XmlRootElement(name = "FuncData")
public class FuncData {

    @XmlElement(name = "FuncPoints")
    protected List<FuncData.FuncPoints> funcPoints;


    public List<FuncData.FuncPoints> getFuncPoints() {
        if (funcPoints == null) {
            funcPoints = new ArrayList<FuncData.FuncPoints>();
        }
        return this.funcPoints;
    }

    public void clearData() {
        if (funcPoints != null)
            funcPoints.clear();

    }

    public FuncPoints getFFuncPoints() {
        if (funcPoints == null || funcPoints.size() == 0) {
            funcPoints = new ArrayList<FuncPoints>();
            funcPoints.add(new FuncPoints());
            funcPoints.add(new FuncPoints());
        }
        return funcPoints.get(0);
    }

    public FuncPoints getGFuncPoints() {
        if (funcPoints == null || funcPoints.size() == 0) {
            funcPoints = new ArrayList<FuncPoints>();
            funcPoints.add(new FuncPoints());
            funcPoints.add(new FuncPoints());
        }
        return funcPoints.get(1);
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
            "point"
    })
    public static class FuncPoints implements ExtendedFunction {

        @XmlElement(name = "Point")
        protected List<FuncData.FuncPoints.Point> point;


        public List<FuncData.FuncPoints.Point> getPoint() {
            if (point == null) {
                point = new ArrayList<FuncData.FuncPoints.Point>();
            }
            return this.point;
        }

        private int size() {
            return point.size();
        }

        @Override
        public double y(double x) {
            double lagrangePol = 0;
            for (int i = 0; i < size(); i++) {
                double basicsPol = 1;
                for (int j = 0; j < size(); j++) {
                    if (j != i) {
                        basicsPol *= (x - point.get(j).getX()) / (point.get(i).getX() - point.get(j).getX());
                    }
                }
                lagrangePol += basicsPol * point.get(i).getY();
            }
            return lagrangePol;
        }

        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
                "value"
        })
        public static class Point {

            @XmlValue
            protected String value;
            @XmlAttribute(name = "X")
            protected Double x;
            @XmlAttribute(name = "Y")
            protected Double y;

            public Point(Double x, Double y) {
                this.x = x;
                this.y = y;
            }

            public Point() {
            }

            public String getValue() {
                return value;
            }

            public void setValue(String value) {
                this.value = value;
            }

            public Double getX() {
                return x;
            }

            public void setX(Double value) {
                this.x = value;
            }

            public Double getY() {
                return y;
            }

            public void setY(Double value) {
                this.y = value;
            }

            @Override
            public String toString() {
                return "X = " + x + " Y = " + y;
            }
        }

    }

}
