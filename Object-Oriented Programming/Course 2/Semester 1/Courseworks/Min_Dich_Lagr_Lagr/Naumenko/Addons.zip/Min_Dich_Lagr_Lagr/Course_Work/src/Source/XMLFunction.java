package Source;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;

import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import Exceptions.FileReadException;
import Exceptions.SamePointsException;
import generated.FuncData;
import generated.FuncData.FuncPoints;
import generated.FuncData.FuncPoints.Point;

public class XMLFunction extends FGFunctions {

	private FuncData data = new FuncData();

	public XMLFunction() {
	}

	public XMLFunction(String fileName) throws SamePointsException {
		try {
			readFromXML(fileName);
		} catch (FileReadException e) {
			e.printStackTrace();
		}
	}

	public FuncData getData() {
		return data;
	}

	public FuncPoints getFFunc() {
		return (FuncData.FuncPoints) getF();
	}

	public FuncPoints getGFunc() {
		return (FuncData.FuncPoints) getG();
	}

	public XMLFunction readFromXML(String fileName) throws FileReadException, SamePointsException {
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance("generated");
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			data = (FuncData) unmarshaller.unmarshal(new FileInputStream(fileName));
			checkPoints();
			setF(data.getFFuncPoints());
			setG(data.getGFuncPoints());
			return this;
		} catch (JAXBException | FileNotFoundException e) {
			throw new FileReadException(fileName);
		}
	}

	public void updateFunc(){
		setF(data.getFFuncPoints());
		setG(data.getGFuncPoints());
	}

	public boolean toXml(String name) throws Exception {
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance("generated");
			Marshaller marshaller = jaxbContext.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			marshaller.marshal(data, new FileWriter(name));
			return true;
		} catch (Exception e) {
			throw e;
		}
	}

	private void checkPoints() throws SamePointsException {
		for (int i = 0; i < 2; i++) {

			Map<Double, Integer> map = new HashMap<>();
			for (Point points : data.getFuncPoints().get(i).getPoint()) {
				if (map.get(points.getX()) == null) {
					map.put(points.getX(), 0);
				} else {
					map.put(points.getX(), (map.get(points.getX()) + 1));
				}
			}

			for (Map.Entry<Double, Integer> pEntry : map.entrySet()) {
				if (pEntry.getValue() > 0) {
					throw new SamePointsException(new Point(pEntry.getKey(), 0.));
				}
			}

		}
	}

	public String buildReport(Double from, Double to, String chart) {
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append("<html>");

		sBuilder.append("<head>");
		sBuilder.append("<meta http-equiv='Content-Type' content='text/html; " + "charset=UTF-8'>");
		sBuilder.append("</head>");
		sBuilder.append("<body>");
		sBuilder.append("<h2>Report</h2>");
		sBuilder.append("</table>");
		sBuilder.append(
				"<h4><span style='font-family:Times, Serif;'>" + "<em>f(t)</em></span></h4>");
		sBuilder.append("<table border = '1' cellpadding=4 cellspacing=0>");
		sBuilder.append("<tr>");
		sBuilder.append("<th>x</th>");
		sBuilder.append("<th>y</th>");
		sBuilder.append("</tr>");

		for (int i = 0; i < getFFunc().getPoint().size(); i++) {
			sBuilder.append("<tr>");
			sBuilder.append(String.format("<td>%8.1f</td>%n", data.getFFuncPoints().getPoint().get(i).getX()));
			sBuilder.append(String.format("<td>%8.1f</td>%n", data.getFFuncPoints().getPoint().get(i).getY()));
			sBuilder.append("</tr>");
		}

		sBuilder.append("</table>");
		sBuilder.append(
				"<h4><span style='font-family:Times, Serif;'>" + "<em>g(t)</em></span></h4>");
		sBuilder.append("<table border = '1' cellpadding=4 cellspacing=0>");
		sBuilder.append("<tr>");
		sBuilder.append("<th>x</th>");
		sBuilder.append("<th>y</th>");
		sBuilder.append("</tr>");

		for (int i = 0; i < getGFunc().getPoint().size(); i++) {
			sBuilder.append("<tr>");
			sBuilder.append(String.format("<td>%8.1f</td>%n", data.getGFuncPoints().getPoint().get(i).getX()));
			sBuilder.append(String.format("<td>%8.1f</td>%n", data.getGFuncPoints().getPoint().get(i).getY()));
			sBuilder.append("</tr>");
		}

		sBuilder.append("</table>");
		sBuilder.append("<img src=" + chart + " />");
		sBuilder.append("</body>");
		sBuilder.append("</html>");
		return sBuilder.toString();
	}

	public void saveReport(String path, String html) {

		try (PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(path), "UTF-8"))) {
			out.write(html);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
