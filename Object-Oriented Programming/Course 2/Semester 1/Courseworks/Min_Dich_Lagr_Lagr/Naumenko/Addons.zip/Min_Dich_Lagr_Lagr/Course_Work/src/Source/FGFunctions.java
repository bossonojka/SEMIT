package Source;

public class FGFunctions {
	private ExtendedFunction f;
	private ExtendedFunction g;

	public FGFunctions() {
		// TODO Auto-generated constructor stub
	}

	public FGFunctions(ExtendedFunction f, ExtendedFunction g) {
		this.f = f;
		this.g = g;
	}

	public ExtendedFunction getF() {
		return f;
	}

	public ExtendedFunction getG() {
		return g;
	}

	public void setF(ExtendedFunction f) {
		this.f = f;
	}

	public void setG(ExtendedFunction g) {
		this.g = g;
	}

/*	public double findMin(double a, double b, double eps) {
		final double PHI = (1 + Math.sqrt(5)) / 2;
		double x1, x2;
		while (true) {
			x1 = b - (b - a) / PHI;
			x2 = a + (b - a) / PHI;
			if (f.y(x1) - g.y(x1) > f.y(x2) - g.y(x2))
				a = x1;
			else
				b = x2;
			if (Math.abs(b - a) < eps)
				break;
		}
		return (a + b) / 2;
	}

	public double findMax(double a, double b, double e){
		final double PHI = (1 + Math.sqrt(5)) / 2;
		double x1, x2;
		while (true){
			x1 = b - (b - a) / PHI;
			x2 = a + (b - a) / PHI;
			if (f.y(x1) - g.y(x1) <= f.y(x2) - g.y(x2))
				a = x1;
			else
				b = x2;
			if (Math.abs(b - a) < e)
				break;
		}
		return (a + b) / 2;
	}*/

public double findMin(double a, double b, double eps) {
		double X;
		int C = 1;
		while (Math.abs(b - a) > eps) {
			X = (a + b) / 2;
			if (C * f.y(X - eps) < C * f.y(X + eps))
				b = X;
			else {
				a = X;
			}
		}
		X = (a + b) / 2;
		return X;
	}

public double findMax(double a, double b, double eps) {
//	double x1,x2;
//	while (Math.abs(a-b)>eps) {
//		x1 = (b-a)/2-eps;
//		x2 = (b-a)/2+eps;
//		if (f.y(x1)-g.y(x1)>f.y(x2)-g.y(x2))
//			a=x1; else b = x2;
//	}
//	return (a+b)/2;


		double X;
		int C = 1;
		while ((b - a) > eps) {
			X = (a + b) / 2;
			if (C * (f.y(X - eps)-g.y(X-eps)) < C * (f.y(X + eps)-g.y(X+eps)))
				b = X;
			else {
				a = X;
			}
		}
		X = (a + b) / 2;
		return X;
	}
}
