package Exceptions;

import generated.FuncData.FuncPoints.Point;

public class SamePointsException extends Exception {

	private Point point;

	public SamePointsException(Point point) {
		this.point = point;
	}

	public Point getPoint() {
		return point;
	}
}
