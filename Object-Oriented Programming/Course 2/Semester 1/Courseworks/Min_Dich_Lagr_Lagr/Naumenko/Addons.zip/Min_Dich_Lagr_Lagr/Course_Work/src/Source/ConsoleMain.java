package Source;

import Exceptions.SamePointsException;

public class ConsoleMain {
    public static void main(String[] args) throws SamePointsException {
        XMLFunction xFunction = new XMLFunction("correctData.xml");
        System.out.println(xFunction.findMax(-5, 5, 0.005));
    }
}
