from tkinter import *

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2TkAgg
from matplotlib.figure import Figure

from Lagr1 import *
from nxml import *
import easygui
from tkinter import messagebox, colorchooser
from copy import deepcopy
from web2 import *


class Window():
    def __init__(self, parent):
        self.parent = parent
        frame = Frame(self.parent)
        frame.grid()
        self.parent1 = Entry(frame)
        self.initUI()

    def add_fun_f(self, x, y, i):
        FuncF().SetXInd(x, i)
        FuncF().SetYInd(y, i)
        text = "Точки x: %s \nТочки y: %s" % (FuncF().x, FuncF().y)
        return text

    def add_fun_g(self, x, y, i):
        FuncG().SetXInd(x, i)
        FuncG().SetYInd(y, i)
        text = "Точки x: %s \nТочки y: %s" % (FuncG().x, FuncG().y)
        return text

    def inserter(self, value):
        self.output.delete("0.0", "end")
        self.output.insert("0.0", value)

    def handler1(self):
        try:
            a_val = float(self.x.get())
            b_val = float(self.y.get())
            if (FuncF().x.count(a_val) != 0):
                index = FuncF().x.index(a_val)
                self.inserter(self.add_fun_f(a_val, b_val, index))
            else:
                self.inserter(self.add_fun_f(a_val, b_val, FuncF().SizeF()))
        except ValueError:
            self.onError("Вы не ввели 2 точки")

    def handler2(self):
        key = {"Дихотомия": Dich, "Хорды": Hords, "Интерполяция Лагранжа": Lagr, "Линейная интерполяция": Liner}
        try:
            if float(self.ot.get()) > float(self.do.get()):
                return self.onError("Начало диапазона не должно превышать его конец")
            p = Solve(key[self.var1.get()], key[self.var2.get()]).solve(float(self.ot.get()), float(self.do.get()))
            text = "Корень уравнения: %s" % (p.print())
            i = key[self.var2.get()]
            fig = Figure(figsize=(5, 5), dpi=100)
            fn = fig.add_subplot(111)
            fn.plot(InterpoolFun(i).xnew3, InterpoolFun(i).temp1, InterpoolFun(i).xnew3, InterpoolFun(i).temp2,
                     InterpoolFun(i).xnew3,
                     InterpoolFun(i).ynew3)
            fn.grid(True)
            fn.legend(("Interpol F(x)", "Interpol G(x)", "F(x) - G(x)"))
            frame = Frame(self.parent)
            frame.grid(row=1, column=20)
            canvas = FigureCanvasTkAgg(fig, frame)
            canvas.show()
            toolbar = NavigationToolbar2TkAgg(canvas, frame)
            toolbar.update()
            canvas.get_tk_widget().pack()
            canvas._tkcanvas.pack()
            return self.inserter(text)
        except ValueError:
            if FuncF().SizeF() < 2:
                return self.onError("Мало точек функции f(x)")
            elif FuncG().SizeG() < 2:
                return self.onError("Мало точек функции g(x)")
            else:
                return self.onError("Вы неправильно ввели диапазон")


    def handler3(self):
        try:
            a_val = float(self.x_g.get())
            b_val = float(self.y_g.get())
            if (FuncG().x.count(a_val) != 0):
                index = FuncG().x.index(a_val)
                self.inserter(self.add_fun_g(a_val, b_val, index))
            else:
                self.inserter(self.add_fun_g(a_val, b_val, FuncG().SizeG()))
        except ValueError:
            self.onError("Вы не ввели 2 точки")

    def handler4(self):
        file = easygui.fileopenbox()
        if file == None:
            return
        Xml.readxml(file)
        text = "f(x)\nТочки x: %s \nТочки y: %s\ng(x)\nТочки x: %s \nТочки y: %s" % (
            FuncF().x, FuncF().y, FuncG().x, FuncG().y)
        self.inserter(text)

    def handler5(self):
        file = easygui.filesavebox(default=('~/Users/Tukva/PycharmProjects/kursach/') + 'new.xml', filetypes=['*.xml'])
        Xml.createxml(file)
        return

    def handler6(self):
        key = {"Дихотомия": Dich, "Хорды": Hords, "Интерполяция Лагранжа": Lagr, "Линейная интерполяция": Liner}
        WebReport(key[self.var2.get()], self.handler7()).report()
        return

    def handler7(self):
        key = {"Дихотомия": Dich, "Хорды": Hords, "Интерполяция Лагранжа": Lagr, "Линейная интерполяция": Liner}
        try:
            if float(self.ot.get()) > float(self.do.get()):
                return self.onError("Начало диапазона не должно превышать его конец")
            p = Solve(key[self.var1.get()], key[self.var2.get()]).solve(float(self.ot.get()), float(self.do.get()))
            text = p.print()
            i = key[self.var2.get()]
            return text
        except ValueError:
            if FuncF().SizeF() < 2:
                return "Мало точек функции f(x)"
            elif FuncG().SizeG() < 2:
                return "Мало точек функции g(x)"
            else:
                return "Вы неправильно ввели диапазон"

    def dialog(self):
        root = Tk()
        root.title("Справка")
        text2 = Text(root, height=35, width=70)
        scroll = Scrollbar(root, command=text2.yview)
        text2.configure(yscrollcommand=scroll.set)
        text2.tag_configure('big', font=('Verdana', 20, 'bold'))
        text2.tag_configure('color', foreground='#476042',
                            font=('Tempus Sans ITC', 12, 'bold'))
        text2.tag_bind('follow', '<1>', lambda e, t=text2: t.insert(END, "Not now, maybe later!"))
        text2.insert(END, '\nВвод данных\n', 'big')
        quote = """
        Для ввода данных нужно ввести значения x и y в поля для нужной вам функции, а затем нажать кнопку "Добавить".
        """
        text2.insert(END, quote, 'color')
        text2.insert(END, '\nЗагрузка\n', 'big')
        quote = """
        Для загрузки данных с файла xml нужно выбрать Файл=>Загрузка. Затем в открытом диалоговом меню выбираем нужный вам файл и жмем "Ок". 
                """
        text2.insert(END, quote, 'color')
        text2.insert(END, '\nСохранение\n', 'big')
        quote = """
        Для сохранения данных в файл xml нужно выбрать Файл=>Сохранить. Затем в открытом диалоговом меню вводим имя файла и жмем "Ок". 
                """
        text2.insert(END, quote, 'color')
        text2.insert(END, '\nСоздать отчет\n', 'big')
        quote = """
        Для создания отчета нужно выбрать Файл=>Создать отчет. Отчет откроется в вашем браузере по умолчанию.
                """
        text2.insert(END, quote, 'color')
        text2.pack(side=LEFT)
        scroll.pack(side=RIGHT, fill=Y)
        root.mainloop()

    def clear(self, event):
        """ Clears entry form """
        caller = event.widget
        caller.delete("0", "end")

    def onError(self, n):
        messagebox.showerror("Error", n)

    def author(self):
        root = Tk()
        root.title("Автор")
        text = Text(root, height=5, width=50)
        scroll = Scrollbar(root, command=text.yview)
        text.configure(yscrollcommand=scroll.set)
        text.tag_configure('bold_italics', font=('Arial', 12, 'bold', 'italic'))
        text.tag_bind('follow', '<1>', lambda e, t=text: t.insert(END, "Not now, maybe later!"))
        text.insert(END, '\nСделал студент группы КН 36А Антоненко В.В.\n', 'bold_italics')
        text.pack(side=LEFT)
        scroll.pack(side=RIGHT, fill=Y)
        root.mainloop()


    def initUI(self):
        self.parent.title("Курсач")
        self.parent.minsize(550, 530)
        self.parent.resizable(width=False, height=False)
        frame = Frame(self.parent)
        frame.grid()
        f = Label(frame, text="f(x)").grid(row=0, column=0)
        self.x = Entry(frame, width=3)
        self.x.grid(row=0, column=3, padx=(10, 0))
        self.x.bind("<FocusIn>", self.clear)
        x_lab = Label(frame, text="точка x:").grid(row=0, column=2)

        self.y = Entry(frame, width=3)
        self.y.bind("<FocusIn>", self.clear)
        self.y.grid(row=0, column=5)
        y_lab = Label(frame, text="точка y:").grid(row=0, column=4)

        g = Label(frame, text="g(x)").grid(row=1, column=0)
        self.x_g = Entry(frame, width=3)
        self.x_g.grid(row=1, column=3, padx=(10, 0))
        self.x_g.bind("<FocusIn>", self.clear)
        x_g_lab = Label(frame, text="точка x:").grid(row=1, column=2)

        self.y_g = Entry(frame, width=3)
        self.y_g.bind("<FocusIn>", self.clear)
        self.y_g.grid(row=1, column=5)
        y_g_lab = Label(frame, text="точка y:").grid(row=1, column=4)

        range_lab_ot = Label(frame, text="Диапазон от").grid(row=0, column=9)
        self.ot = Entry(frame, width=2)
        self.ot.bind("<FocusIn>", self.clear)
        self.ot.grid(row=0, column=10)
        range_lab_do = Label(frame, text="до").grid(row=0, column=11)
        self.do = Entry(frame, width=+2)
        self.do.bind("<FocusIn>", self.clear)
        self.do.grid(row=0, column=12)

        but1 = Button(frame, text="Добавить", command=self.handler1).grid(row=0, column=7, padx=(10, 0))
        but2 = Button(frame, text="Найти корень уравнения", command=self.handler2).grid(row=0, column=8, padx=(10, 20))
        but3 = Button(frame, text="Добавить", command=self.handler3).grid(row=1, column=7, padx=(10, 0))
        self.var1 = StringVar()
        self.var1.set("Дихотомия")
        option_menu_1 = OptionMenu(frame, self.var1, *["Дихотомия", "Хорды"]).grid(row=1, column=8, padx=(10, 0))

        self.var2 = StringVar()
        self.var2.set("Интерполяция Лагранжа")
        option_menu_2 = OptionMenu(frame, self.var2, *["Интерполяция Лагранжа", "Линейная интерполяция"]).grid(row=2,
                                                                                                               column=8,
                                                                                                               padx=(
                                                                                                               10, 0))

        self.output = Text(frame, bg="light sea green", font="Arial 12", width=65, height=25)
        self.output.grid(row=3, columnspan=30)
        menubar = Menu(self.parent)
        self.parent.config(menu=menubar)
        fileMenu1 = Menu(menubar, tearoff=0)
        fileMenu1.add_command(label="Загрузить", command=self.handler4)
        fileMenu1.add_command(label="Сохранить", command=self.handler5)
        fileMenu1.add_command(label="Создать отчет", command=self.handler6)
        fileMenu1.add_separator()
        fileMenu1.add_command(label="Выход", command=self.onExit)
        menubar.add_cascade(label="Файл", menu=fileMenu1)
        menubar.add_cascade(label="Справка", command=self.dialog)
        menubar.add_cascade(label="Автор", command=self.author)

    def onExit(self):
        self.parent.quit()


if __name__ == '__main__':
    root = Tk()
    app = Window(root)
    root.mainloop()

