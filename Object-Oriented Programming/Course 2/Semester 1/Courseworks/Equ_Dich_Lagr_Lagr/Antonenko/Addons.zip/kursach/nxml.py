import xml.etree.ElementTree as ET
from Lagr1 import FuncF, FuncG


class Xml:

    def readxml(file):
        tree = ET.parse(file)

        function = tree.findall('.//function')

        for p in function:
            for k in p:
                for dat in k:
                    if k.tag == "f":
                        if dat.tag == "x":
                            FuncF().SetX(float(dat.text))
                        elif dat.tag == "y":
                            FuncF().SetY(float(dat.text))
                    if k.tag == "g":
                        if dat.tag == "x":
                            FuncG().SetX(float(dat.text))
                        elif dat.tag == "y":
                            FuncG().SetY(float(dat.text))


    def createxml(file):
        root = ET.Element("function")
        func1 = ET.Element("function")
        func2 = ET.Element("function")
        root.append(func1)
        root.append(func2)
        f = ET.Element("f")
        g = ET.Element("g")
        func1.append(f)
        func2.append(g)
        for i in range(FuncF().SizeF()):
            x = ET.SubElement(f, "x")
            x.text = str(FuncF().GetX(i))
            y = ET.SubElement(f, "y")
            y.text = str(FuncF().GetY(i))
        for i in range(FuncG().SizeG()):
            x = ET.SubElement(g, "x")
            x.text = str(FuncG().GetX(i))
            y = ET.SubElement(g, "y")
            y.text = str(FuncG().GetY(i))
        tree = ET.ElementTree(root)
        tree.write(str(file))
