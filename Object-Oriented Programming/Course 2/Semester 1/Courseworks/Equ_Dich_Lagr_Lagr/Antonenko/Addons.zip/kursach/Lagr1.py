import numpy as np
import matplotlib.pyplot as plt


class Lagr():
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def interpool(self, t):
        z = 0
        for j in range(len(self.y)):
            p1 = 1
            p2 = 1
            for i in range(len(self.x)):
                if i == j:
                    p1 = p1 * 1
                    p2 = p2 * 1
                else:
                    p1 = p1 * (t - self.x[i])
                    p2 = p2 * (self.x[j] - self.x[i])
            try:
                z = z + self.y[j] * p1 / p2
            except ZeroDivisionError:
                return ("Нахождение ")
        return z


class Liner():
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def intrepool(self, t):
        min, max, c, max_i, min_i = 0, 0, 0, 0, 0
        for i in range(len(self.x)):
            if self.x[i] == t:
                return self.y[i]
            elif self.x[i] > t:
                max = self.x[i]
                max_i = i
                break
            elif self.x[i] < t:
                min = self.x[i]
                min_i = i
                break
            c = (self.y[max_i] - self.y[min_i]) * (t - min) / (max - min) + self.y[min_i]
        return c


class Dich():
    def __init__(self, f, a, b, e=0.001):
        self.a = a
        self.b = b
        self.e = e
        self.f = f

    def print(self):
        y1 = self.f.interpool(self.a)
        y2 = self.f.interpool(self.b)
        if y1 * y2 >= 0:
            return "Нет корней"
        else:
            c = (self.a + self.b) / 2
            y3 = self.f.interpool(c)
            while abs(y3) > self.e:
                c = (self.a + self.b) / 2
                y3 = self.f.interpool(c)
                if y1 * y3 < 0:
                    self.b = c
                else:
                    self.a = c
            return c


class Hords():
    def __init__(self, f, a, b, e=0.001):
        self.a = a
        self.b = b
        self.e = e
        self.f = f

    def print(self):
        y1 = self.f.interpool(self.a)
        y2 = self.f.interpool(self.b)
        if y1 * y2 >= 0:
            return 2
        else:
            c = (y2 * self.a - y1 * self.b) / (y2 - y1)
            y3 = self.f.interpool(c)
            while abs(y3) > self.e:
                c = (y2 * self.a - y1 * self.b) / (y2 - y1)
                y3 = self.f.interpool(c)
                if y1 * y3 < 0:
                    self.b = c
                else:
                    self.a = c
            return c


class FuncF():
    # solve(2x-4)
    x = []
    y = []

    def GetX(self, i):
        return self.x[i]

    def GetY(self, i):
        return self.y[i]

    def SetX(self, newx):
        self.x.append(newx)

    def SetXInd(self, newx, index):
        if (index == self.x.__len__()):
            self.x.append(newx)
        else:
            self.x.insert(index, newx)
            self.x.pop(index + 1)

    def SetY(self, newy):
        self.y.append(newy)

    def SetYInd(self, newy, index):
        if (index == self.y.__len__()):
            self.y.append(newy)
        else:
            self.y.insert(index, newy)
            self.y.pop(index + 1)

    def SizeF(self):
        return self.x.__len__()


class FuncG():
    # solve(x^2-4)
    x = []
    y = []

    def GetX(self, i):
        return self.x[i]

    def GetY(self, i):
        return self.y[i]

    def SetX(self, newx):
        self.x.append(newx)

    def SetXInd(self, newx, index):
        if (index == self.x.__len__()):
            self.x.append(newx)
        else:
            self.x.insert(index, newx)
            self.x.pop(index + 1)

    def SetY(self, newy):
        self.y.append(newy)

    def SetYInd(self, newy, index):
        if (index == self.y.__len__()):
            self.y.append(newy)
        else:
            self.y.insert(index, newy)
            self.y.pop(index + 1)

    def SizeG(self):
        return self.x.__len__()


class InterpoolFun():
    def __init__(self, f):
        self.xnew3 = np.linspace(np.min(FuncF().x + FuncG.x), np.max(FuncF().x + FuncG.x),
                                 1 + abs(np.min(FuncF().x + FuncG.x)) + abs(np.max(FuncF().x + FuncG.x)))
        self.xnew3 = self.xnew3.tolist()
        self.temp1 = [f(FuncF().x, FuncF().y).interpool(i) for i in self.xnew3]
        self.temp2 = [f(FuncG().x, FuncG().y).interpool(i) for i in self.xnew3]
        self.ynew3 = []
        for i in range(len(self.xnew3)):
            self.ynew3.append(self.temp1[i] - self.temp2[i])

    def GetInterF(self):
        print("X: ", self.xnew3)
        print("Y: ", self.temp1)

    def GetInterG(self):
        print("X: ", self.xnew3)
        print("Y: ", self.temp2)

    def GetInterFG(self):
        print("X: ", self.xnew3)
        print("Y: ", self.ynew3)

    def SizeFG(self):
        return self.ynew3.__len__()


class Solve:
    def __init__(self, f, g):
        self.f = f
        self.g = g

    def solve(self, a, b):
        return self.f(self.g(InterpoolFun(self.g).xnew3, InterpoolFun(self.g).ynew3), a, b)




"""x = [-1.0, 7.0, 4.0, -6.0, 3.0]
#y = [-6.0, 10.0, 4.0, -16.0, 2.0]

#x = [5.0, -2.0, 4, 1.0, 3.0, -5.0]
#y = [21.0, 0.0, 12, -3.0, 5.0, 21.0]"""
