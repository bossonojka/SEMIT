from Lagr1 import *
from yattag import Doc
import webbrowser
from interface import *


class WebReport:
    def __init__(self, i, root):
        self.i = i
        self.root = root

    def report(self):
        doc, tag, text = Doc().tagtext()
        doc.asis('<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE html>')
        with tag('html'):
            with tag('h2', align='center', style='background:#008080; color: Black'):
                text('Отчет')
            with tag('h3', style='color:#A52A2A'):
                text('Задача:')
            with tag('body'):
                text(
                    'Отчет программы графического пользовательского интерфейса для численного нахождения корня уравнения f(x) - g(x)=0 методом дихотомии. '
                    'Значение функции f(x) и g(x) задаются набором точек. '
                    'Для промежуточных значений функций, необходимых для выполнения используется интерполяция Лагранжа.')
                with tag('br'):
                    with tag('br'):
                        with tag('h3', style='color:#A52A2A'):
                            text('Исходные данные данные:')
                        text("f(x):")
                with tag('table', border="1", width="40%", cellpadding="5"):
                    with tag('tr'):
                        with tag('th'):
                            text('x')
                        with tag('th'):
                            text('y')
                    for i in range(FuncF().SizeF()):
                        with tag('tr'):
                            with tag('td'):
                                text(FuncF().x[i])
                            with tag('td'):
                                text(FuncF().y[i])
                with tag('br'):
                    with tag('br'):
                        with tag('br'):
                            text("g(x):")
                with tag('table', border="1", width="40%", cellpadding="5"):
                    with tag('tr'):
                        with tag('th'):
                            text('x')
                        with tag('th'):
                            text('y')
                    for i in range(FuncG().SizeG()):
                        with tag('tr'):
                            with tag('td'):
                                text(FuncG().x[i])
                            with tag('td'):
                                text(FuncG().y[i])
                with tag('h3', style='color:#A52A2A'):
                    text('Выходные данные:')
                with tag('table', border="1", width="40%", cellpadding="5"):
                    with tag('tr'):
                        with tag('th'):
                            text('x')
                        with tag('th'):
                            text('y')
                    for i in range(InterpoolFun(Lagr).SizeFG()):
                        with tag('tr'):
                            with tag('td'):
                                text(InterpoolFun(self.i).xnew3[i])
                            with tag('td'):
                                text(InterpoolFun(self.i).ynew3[i])
                with tag('br'):
                    with tag('br'):
                        text("Рисунок функции:")
                i = self.i
                plt.plot(InterpoolFun(i).xnew3, InterpoolFun(i).temp1, InterpoolFun(i).xnew3, InterpoolFun(i).temp2,
                         InterpoolFun(i).xnew3,
                         InterpoolFun(i).ynew3)
                plt.grid(True)
                plt.legend(("Interpol F(x)", "Interpol G(x)", "F(x) - G(x)"))
                plt.savefig('graphic.png')
                with tag('img', src="graphic.png", alt="graphic"):
                    text('')
                with tag('br'):
                    text("Корень функции: ", self.root)
        print(doc.getvalue())
        f = open("report.html", 'w', encoding="utf-8")
        f.write(doc.getvalue())
        webbrowser.open_new('report.html')
