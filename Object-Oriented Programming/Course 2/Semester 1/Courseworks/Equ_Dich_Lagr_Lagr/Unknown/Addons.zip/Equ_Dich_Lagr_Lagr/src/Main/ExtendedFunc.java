package Main;

/**
 * Created by 1111 on 14.12.2017.
 */
public interface ExtendedFunc {
    double extend(double x);
}
