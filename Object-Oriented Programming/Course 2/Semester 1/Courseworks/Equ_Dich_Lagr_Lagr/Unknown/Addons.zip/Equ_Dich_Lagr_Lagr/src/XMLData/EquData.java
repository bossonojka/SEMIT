
package XMLData;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.*;

import Main.ExtendedFunc;
import XMLData.EquData.Points.Point;

/**
 * <p>Java class for EquDataType complex type.
 * <p>
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="EquDataType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Points" type="{}PointsType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EquDataType", propOrder = {"points"})
@XmlRootElement(name = "EquData")
public class EquData {

    @XmlElement(name = "Points")
    protected List<EquData.Points> points;

    public List<EquData.Points> getPoints() {
        if (points == null) {
            points = new ArrayList<EquData.Points>();
        }
        return this.points;
    }

    public Points getFPoints() {
        if (points == null) {
            points = new ArrayList<Points>();
            points.add(new Points());
            points.add(new Points());
        }
        return points.get(0);
    }

    public Points getGPoints() {
        if (points == null) {
            points = new ArrayList<Points>();
            points.add(new Points());
            points.add(new Points());
        }
        return points.get(1);
    }

    public void clearData() {
        for (Points points2 : points) {
            points2.getPoint().clear();
            points2.getPoint().clear();
        }
    }

    public void setFPoints(List<Point> list) {
        if (points == null) {
            points = new ArrayList<Points>();
            points.add(new Points());
            points.add(new Points());
        } else {
            points.get(0).setPoint(list);
        }
    }

    public void setGPoints(List<Point> list) {
        if (points == null) {
            points = new ArrayList<Points>();
            points.add(new Points());
            points.add(new Points());
        } else {
            points.get(1).setPoint(list);

        }
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {"point"})

    public static class Points implements ExtendedFunc {
        @XmlElement(name = "Point")
        protected List<EquData.Points.Point> point;

        public void setPoint(List<EquData.Points.Point> point) {
            this.point = point;
        }

        public List<EquData.Points.Point> getPoint() {
            if (point == null) {
                point = new ArrayList<EquData.Points.Point>();
            }
            return this.point;
        }

        private int size() {
            return point.size();
        }

        public void remove(int i) {
            if (point != null) {
                point.remove(i);
            }
        }

        public void add(Point p) {
            if (point != null) {
                point.add(p);
            } else {
                point = new ArrayList<>();
                point.add(p);
            }
        }

        @Override
        public double extend(double x) {
            double result = 0;
            for (int i = 0; i < size(); i++) {
                double k = 1;
                for (int j = 0; j < size(); j++) {
                    if (j != i) {
                        k *= (x - point.get(j).getX()) / (point.get(i).getX() - point.get(j).getX());
                    }
                }
                result += k * point.get(i).getY();
            }
            return result;
        }


        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {"value"})
        public static class Point {

            @XmlValue
            protected String value;
            @XmlAttribute(name = "X")
            protected Double x;
            @XmlAttribute(name = "Y")
            protected Double y;

            public Point() {
            }

            public Point(Double x, Double y) {
                this.x = x;
                this.y = y;
            }

            public String getValue() {
                return value;
            }

            public void setValue(String value) {
                this.value = value;
            }

            public Double getX() {
                return x;
            }

            public void setX(Double value) {
                this.x = value;
            }

            public Double getY() {
                return y;
            }

            public void setY(Double value) {
                this.y = value;
            }

            @Override
            public String toString() {
                return "x = " + x + "\ty = " + y;
            }

        }
    }
}
