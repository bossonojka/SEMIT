package Main;

/**
 * Created by 1111 on 15.12.2017.
 */
public class AbstractFunctionFG {

    private ExtendedFunc F;
    private ExtendedFunc G;
    private double root;

    public AbstractFunctionFG() {}

    public AbstractFunctionFG(ExtendedFunc f, ExtendedFunc g) {
        this.F = f;
        this.G = g;
    }

    public double getRoot() {
        return root;
    }

    public void setRoot(double root) {
        this.root = root;
    }

    public ExtendedFunc getF() {
        return F;
    }

    public ExtendedFunc getG() {
        return G;
    }

    public void setF(ExtendedFunc f) {
        this.F = f;
    }

    public void setG(ExtendedFunc g) {
        this.G = g;
    }

    public class EqualBordersException extends Exception {}

    public double EquDichotomy(double left, double right, double eps) throws EqualBordersException {
        if (left == right)
            throw new EqualBordersException();

        double x;
        do
        {
            x = (left + right) / 2;
            if (F_G(F, G, left) * F_G(F, G, x) > 0)
            {
                left = x;
            }
            else
            {
                right = x;
            }
        }
        while (right - left > eps);
        root = x;
        return root;
    }

    public static double F_G(ExtendedFunc F, ExtendedFunc G, double x){
        double result;
        result = F.extend(x) - G.extend(x);
        return result;
    }
}
