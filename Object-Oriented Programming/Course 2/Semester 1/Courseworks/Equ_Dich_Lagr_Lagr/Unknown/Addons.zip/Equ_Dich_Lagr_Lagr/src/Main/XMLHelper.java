package Main;

import javax.imageio.ImageIO;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.*;
import java.util.HashMap;
import java.util.Map;

import XMLData.EquData;
import XMLData.EquData.Points;
import XMLData.EquData.Points.Point;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.image.WritableImage;


/**
 * Created by 1111 on 15.12.2017.
 */

class FileReadException extends Exception {}

public class XMLHelper extends AbstractFunctionFG {

    public static class SamePointsException extends Exception {

        private Point point;

        public SamePointsException(Point point) {
            this.point = point;
        }

        public Point getPoint() {
            return point;
        }
    }

    private EquData data = new EquData();

    public XMLHelper() {
    }

    public XMLHelper(String fileName) throws SamePointsException {
        try {
            readFromXMLFile(fileName);
        } catch (FileReadException e) {
            e.printStackTrace();
        }
    }

    public EquData getData() {
        return data;
    }

    public Points getFFunc() {
        return (EquData.Points) getF();
    }

    public Points getGFunc() {
        return (EquData.Points) getG();
    }


    public XMLHelper readFromXMLFile(String fileName) throws FileReadException, SamePointsException {
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance("XMLData");
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            data = (EquData) unmarshaller.unmarshal(new FileInputStream(fileName));
            checkPoints();
            setF(data.getPoints().get(0));
            setG(data.getPoints().get(1));
            return this;
        } catch (JAXBException | FileNotFoundException e) {
            throw new FileReadException();
        }
    }

    public boolean writeToXMLFile(String name) throws Exception {
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance("generated");
            Marshaller marshaller = jaxbContext.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            marshaller.marshal(data, new FileWriter(name));
            return true;
        } catch (Exception e) {
            throw e;
        }
    }

    private void checkPoints() throws SamePointsException {
        for (int i = 0; i < 2; i++) {

            Map<Double, Integer> map = new HashMap<>();
            for (Point points : data.getPoints().get(i).getPoint()) {
                if (map.get(points.getX()) == null) {
                    map.put(points.getX(), 0);
                } else {
                    map.put(points.getX(), (map.get(points.getX()) + 1));
                }
            }

            for (Map.Entry<Double, Integer> pEntry : map.entrySet()) {
                if (pEntry.getValue() > 0) {
                    throw new SamePointsException(new Point(pEntry.getKey(), 0.));
                }
            }

        }
    }

    public void saveReport() {
        try (PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream("Report.html"), "UTF-8"))) {
            out.printf("<html>%n");

            out.printf("<head>%n");
            out.printf("<meta http-equiv='Content-Type' content='text/html; " + "charset=UTF-8'>%n");
            out.printf("</head>%n");
            out.printf("<body>%n");
            out.printf("<h2>Report</h2>%n");
            out.printf("<h1>Chart</h1>%n");
//            out.printf("<center><img src=\\\"screenshots/screen1\" + \".png\\\" alt=\\\"picture\\\"></center>\");
            out.printf("<p>As a result of solving the two functions " + "with such initial data:</p>%n");
            out.printf("</table>%n");
            out.printf("<h4>Functions data <span style='font-family:Times, Serif;'>" + "<em>f(x)</em></span></h4>%n");
            out.printf("<table border = '1' cellpadding=4 cellspacing=0>%n");
            out.printf("<tr>%n");
            out.printf("<th>Index</th>%n");
            out.printf("<th>x</th>%n");
            out.printf("<th>extend</th>%n");
            out.printf("</tr>%n");
            out.printf("<td>%n");

            for (int i = 0; i < getFFunc().getPoint().size(); i++) {
                out.printf("<tr>%n");
                out.printf("<td>%d</td>", i);
                out.printf("<td>%8.1f</td>%n", data.getPoints().get(0).getPoint().get(i).getX());
                out.printf("<td>%8.1f</td>%n", data.getPoints().get(0).getPoint().get(i).getY());
                out.printf("</tr>%n");
            }

            out.printf("</table>%n");
            out.printf("<h4>Functions data <span style='font-family:Times, Serif;'>" + "<em>g(x)</em></span></h4>%n");
            out.printf("<table border = '1' cellpadding=4 cellspacing=0>%n");
            out.printf("<tr>%n");
            out.printf("<th>Index</th>%n");
            out.printf("<th>x</th>%n");
            out.printf("<th>extend</th>%n");
            out.printf("</tr>%n");
            out.printf("<td>%n");

            for (int i = 0; i < getGFunc().getPoint().size(); i++) {
                out.printf("<tr>%n");
                out.printf("<td>%d</td>", i);
                out.printf("<td>%8.1f</td>%n", data.getPoints().get(1).getPoint().get(i).getX());
                out.printf("<td>%8.1f</td>%n", data.getPoints().get(1).getPoint().get(i).getY());
                out.printf("</tr>%n");
            }

            out.printf("</table>%n");

            out.printf("<p>Equataton <em>x</em>: %8.3f</p>%n", getRoot());

            out.printf("</body>%n");
            out.printf("</html>%n");


        } catch (IOException e) {

        }
    }

    public static void main(String[] args) throws SamePointsException, FileReadException, EqualBordersException {
        XMLHelper xmlHelper = new XMLHelper();
        xmlHelper.readFromXMLFile("EquData.xml").EquDichotomy(-2,7,0.001);
        xmlHelper.saveReport();
    }
}
