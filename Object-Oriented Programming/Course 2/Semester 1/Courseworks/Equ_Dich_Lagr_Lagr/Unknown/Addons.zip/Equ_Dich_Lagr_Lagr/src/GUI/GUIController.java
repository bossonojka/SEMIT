package GUI;

import Main.AbstractFunctionFG;
import Main.XMLHelper;
import Main.XMLHelper.SamePointsException;
import XMLData.EquData.Points.Point;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.WritableImage;
import javafx.stage.FileChooser;
import javafx.util.converter.NumberStringConverter;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GUIController {

	private final String PROJECT_PATH = System.getProperty("user.dir");

	@FXML
	private LineChart<Number, Number> chart;
	@FXML
	private TableView<Point> tableFfunc;
	@FXML
	private TableView<Point> tableGfunc;
	@FXML
	private TableColumn<Point, Number> columnFx;
	@FXML
	private TableColumn<Point, Number> columnFy;
	@FXML
	private TableColumn<Point, Number> columnGx;
	@FXML
	private TableColumn<Point, Number> columnGy;
	@FXML
	private Label textEquatation;
	@FXML
	private Label resultEquatation;
	@FXML
	private TextField from;
	@FXML
	private TextField to;

	private ObservableList<Point> obsF;
	private ObservableList<Point> obsG;

	private XMLHelper xmlHelper;

	@FXML
	private void initialize() {
		xmlHelper = new XMLHelper();

		tableFfunc.setEditable(true);
		tableGfunc.setEditable(true);

		columnFx.setSortable(false);
		columnFy.setSortable(false);
		columnGx.setSortable(false);
		columnGy.setSortable(false);

		from.textProperty().addListener(new FieldListener(from));
		to.textProperty().addListener(new FieldListener(to));
	}

	@FXML
	private void doNew() {
		doClear();
	}

	@FXML
	private void doOpen() {
		FileChooser fileChooser = getFileChooser("Open XML file");
		File file;
		try {
			if ((file = fileChooser.showOpenDialog(null)) != null) {
				xmlHelper.readFromXMLFile(file.getCanonicalPath());
				clearData();
				updateTables();
			}
		} catch (SamePointsException e) {
			clearData();
			showError("Your data have the same points!");
		} catch (Exception e) {
			clearData();
			e.printStackTrace();
		}

	}

	@FXML
	private void doSaveReport() {
		FileChooser fileChooser = getFileChooser("Save as HTML file");
		File file;
		if ((file = fileChooser.showSaveDialog(null)) != null) {
			try {
				xmlHelper.saveReport();
				showMessage("Repo rt successfully saved");
			} catch (Exception e) {
				showError("Error during saving report");
			}
		}

	}

	@FXML
	private void doHelp() {
		showMessage("Short guide for the program:" + "\n" + "1. Open your XML file in File menu" + "\n"
				+ "2. You can add or change your points in tables in menu Action with points" + "\n"
				+ "3. Enter from and to values on the pane" + "\n"
				+ "4. Press 'Build' button on pane to build a chart"  + "\n"
				+ "5. You can save your report in Help menu or save your points data as XML-file in File menu");
	}
	
	private void clearData() {
		chart.getData().clear();
		textEquatation.setVisible(false);
		resultEquatation.setVisible(false);
	}

	@FXML
	private void doSave() {
		FileChooser fileChooser = getFileChooser("Save as XML file");
		File file;
		if ((file = fileChooser.showSaveDialog(null)) != null) {
			try {
				updateSourceData();
				xmlHelper.writeToXMLFile(file.getCanonicalPath());
				showMessage("Your data has been saves to XML file");
			} catch (Exception e) {
				showError("Error during saving XML");
			}
		}
	}

	@FXML
	private void doClear() {
		chart.getData().clear();
		obsF.clear();
		obsG.clear();
		updateSourceData();
		from.clear();
		to.clear();
		textEquatation.setVisible(false);
		resultEquatation.setVisible(false);
	}

	@FXML
	private void doBuild() throws AbstractFunctionFG.EqualBordersException {
		try {
			checkPoints();
		} catch (Exception e) {
			showError("Please, check your points in tables!");
			return;
		}

		chart.getData().clear();
		if (!checkInterval()) {
			showMessage("Please, enter from and to fields!");
			return;
		}

		if (obsF == null || obsG == null) {
			textEquatation.setVisible(false);
			resultEquatation.setVisible(false);
			showMessage("Please, enter your points in tables!");
			return;
		}

		XYChart.Series<Number, Number> fSeries = new XYChart.Series<>();
		XYChart.Series<Number, Number> gSeries = new XYChart.Series<>();
		XYChart.Series<Number, Number> fgSeries = new XYChart.Series<>();
		ObservableList<Point> observableList = FXCollections.observableArrayList();

		fSeries.setName("f(x)");
		gSeries.setName("g(x)");
		fgSeries.setName("f(x) - g(x)");

		Double from = Double.parseDouble(this.from.getText());
		Double to = Double.parseDouble(this.to.getText());
		for (double i = from; i <= to; i += 0.1) {
			double fy = xmlHelper.getF().extend(i);
			double gy = xmlHelper.getG().extend(i);

			fSeries.getData().add(new Data<>(i, fy));
			gSeries.getData().add(new Data<>(i, gy));
			fgSeries.getData().add(new Data<>(i, fy - gy));

			observableList.add(new Point(i, fy - gy));
		}

		chart.getData().add(fSeries);
		chart.getData().add(gSeries);
		chart.getData().add(fgSeries);

		showResults(observableList);
		double x = xmlHelper.EquDichotomy(from, to, 0.001);

		resultEquatation.setText("     X = " + DecimalFormat.getInstance().format(x));
	}

	private void showResults(ObservableList<Point> list) {
		resultEquatation.setVisible(true);
		textEquatation.setVisible(true);
	}

	@FXML
	private void doExit() {
		Platform.exit();
	}

	@FXML
	private void doAddF() {
		if (obsF == null) {
			updateTables();
		}
		obsF.add(new Point(0., 0.));
		updateSourceData();
	}

	@FXML
	private void doRemoveF() {
		if (obsF == null) {
			return;
		}
		if (obsF.size() > 0) {
			obsF.remove(obsF.size() - 1);

		}
		if (obsF.size() <= 0) {
			obsF = null;
		}
		updateSourceData();
	}

	@FXML
	private void doAddG() {
		if (obsG == null) {
			updateTables();
		}
		obsG.add(new Point(0., 0.));
		updateSourceData();
	}

	@FXML
	private void doRemoveG() {
		if (obsG == null) {
			return;
		}
		if (obsG.size() > 0) {
			obsG.remove(obsG.size() - 1);
		}
		if (obsG.size() <= 0) {
			obsG = null;
		}
		updateSourceData();
	}

	@FXML
	private void doAbout() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("About program");
		alert.setHeaderText("Graphic equatation of functions");
		alert.setContentText("Version 1.1");
		alert.showAndWait();
	}

	public FileChooser getFileChooser(String title) {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setInitialDirectory(new File("."));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("XML-files (*.xml)", "*.xml"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("HTMl-files (*.html)", "*.html"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("All files (*.*)", "*.*"));
		fileChooser.setTitle(title);
		return fileChooser;
	}

	public void showError(String message) {
		Alert alert = new Alert(AlertType.ERROR);
		alert.setTitle("Error");
		alert.setHeaderText(message);
		alert.showAndWait();
	}

	public void showMessage(String message) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("");
		alert.setHeaderText(message);
		alert.showAndWait();
	}

	private void updateTables() {
		List<Point> fList = new ArrayList<>();
		List<Point> gList = new ArrayList<>();

		obsF = FXCollections.observableList(fList);
		obsG = FXCollections.observableList(gList);

		for (Point point : xmlHelper.getData().getFPoints().getPoint()) {
			fList.add(point);
		}

		for (Point point : xmlHelper.getData().getGPoints().getPoint()) {
			gList.add(point);
		}
		tableFfunc.setItems(obsF);
		tableGfunc.setItems(obsG);

		columnFx.setCellValueFactory(new PropertyValueFactory<>("x"));
		columnFx.setCellFactory(TextFieldTableCell.<Point, Number>forTableColumn(new NumberStringConverter()));
		columnFx.setOnEditCommit(t -> ((Point) t.getTableView().getItems().get(t.getTablePosition().getRow()))
				.setX(t.getNewValue().doubleValue()));

		columnFy.setCellValueFactory(new PropertyValueFactory<>("y"));
		columnFy.setCellFactory(TextFieldTableCell.<Point, Number>forTableColumn(new NumberStringConverter()));
		columnFy.setOnEditCommit(t -> ((Point) t.getTableView().getItems().get(t.getTablePosition().getRow()))
				.setY(t.getNewValue().doubleValue()));

		columnGx.setCellValueFactory(new PropertyValueFactory<>("x"));
		columnGx.setCellFactory(TextFieldTableCell.<Point, Number>forTableColumn(new NumberStringConverter()));
		columnGx.setOnEditCommit(t -> ((Point) t.getTableView().getItems().get(t.getTablePosition().getRow()))
				.setX(t.getNewValue().doubleValue()));

		columnGy.setCellValueFactory(new PropertyValueFactory<>("y"));
		columnGy.setCellFactory(TextFieldTableCell.<Point, Number>forTableColumn(new NumberStringConverter()));
		columnGy.setOnEditCommit(t -> ((Point) t.getTableView().getItems().get(t.getTablePosition().getRow()))
				.setY(t.getNewValue().doubleValue()));

	}

	private void updateSourceData() {
		xmlHelper.getData().clearData();
		if (obsF != null)
			for (Point point : obsF) {
				xmlHelper.getData().getPoints().get(0).getPoint().add(point);
			}
		if (obsG != null)
			for (Point point : obsG) {
				xmlHelper.getData().getPoints().get(1).getPoint().add(point);
			}
	}

	private boolean isNumber(String str) {
		if (str == null || str.isEmpty())
			return false;
		if (str.contains(",")) {
			return false;
		}

		int count = 0;

		for (int i = 0; i < str.length(); i++) {
			if (Character.compare(str.charAt(i), '.') == 0) {
				count++;
			}
		}
		if (count > 1) {
			return false;
		}

		for (int i = 0; i < str.length(); i++) {
			if (!Character.isDigit(str.charAt(i)) && !(i == 0 && str.charAt(i) == '-') && str.charAt(i) != '.')
				return false;
		}
		return true;
	}

	private boolean checkInterval() {
		if (from.getText().length() > 0 && to.getText().length() > 0) {
			try {
				return Double.parseDouble(from.getText()) < Double.parseDouble(to.getText()) ? true : false;
			} catch (Exception e) {
				showError("Enter interval");
			}
		}
		return false;
	}

	class FieldListener implements ChangeListener<String> {
		private TextField field;

		public FieldListener(TextField field) {
			this.field = field;
		}

		@Override
		public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
			if (!isNumber(newValue) || newValue.isEmpty()) {
				field.setText(newValue.length() > 1 ? newValue.substring(0, newValue.length() - 1) : "");
			}
		}
	}

	private void checkPoints() throws SamePointsException {

		Map<Double, Integer> map = new HashMap<>();
		Map<Double, Integer> map2 = new HashMap<>();

		for (Point points : obsF) {
			if (map.get(points.getX()) == null) {
				map.put(points.getX(), 0);
			} else {
				map.put(points.getX(), (map.get(points.getX()) + 1));
			}
		}
		for (Point points : obsG) {
			if (map2.get(points.getX()) == null) {
				map2.put(points.getX(), 0);
			} else {
				map2.put(points.getX(), (map2.get(points.getX()) + 1));
			}
		}

		for (Map.Entry<Double, Integer> pEntry : map.entrySet()) {
			if (pEntry.getValue() > 0) {
				throw new SamePointsException(new Point(pEntry.getKey(), 0.));
			}
		}
		for (Map.Entry<Double, Integer> pEntry : map2.entrySet()) {
			if (pEntry.getValue() > 0) {
				throw new SamePointsException(new Point(pEntry.getKey(), 0.));
			}
		}
	}

}
