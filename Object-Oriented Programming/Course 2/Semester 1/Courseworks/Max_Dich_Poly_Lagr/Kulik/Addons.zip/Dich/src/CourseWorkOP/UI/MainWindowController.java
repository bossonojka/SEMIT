package CourseWorkOP.UI;

import CourseWorkOP.Backend.GraphicShow;
import CourseWorkOP.Backend.ReadWriteXML;
import CourseWorkOP.Backend.Report;
import CourseWorkOP.Backend.TableBack;
import CourseWorkOP.Solution.Function;
import CourseWorkOP.Solution.Lagrange;
import CourseWorkOP.Solution.Solution;
import CourseWorkOP.Solution.StringFunction;
import javafx.embed.swing.SwingFXUtils;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;


public class MainWindowController {
    @FXML
    private GridPane pane;
    @FXML
    private Canvas canvas;
    private GraphicShow gs;
    @FXML
    private TextField fromTextField;
    @FXML
    private TextField toTextField;
    @FXML
    private TextField epsTextField;
    @FXML
    private Label max;
    @FXML
    private Label pointOnCanvas;
    private TableView results;
    private TableView firstFunctionTableView;

    private TextField secondFunctionTextField;
    private double from;
    private double to;
    private double eps;
    private Solution solution;
    private Function firstFunction;
    private Function secondFunction;
    private ReadWriteXML readWriteXML;
    private boolean correctedValue;

    public MainWindowController() {
        readWriteXML = new ReadWriteXML();
        secondFunctionTextField = new TextField();
        epsTextField = new TextField();
        eps = 0.01;
        gs = new GraphicShow();
        firstFunction = new Lagrange();
        secondFunction = new StringFunction();
    }

    @FXML
    public void initialize() {
        firstFunctionTableView = TableBack.initTheTable(firstFunctionTableView);
        pane.add(firstFunctionTableView, 0, 0);
        secondFunction = new StringFunction();
        secondFunctionTextField = new TextField();
        pane.add(secondFunctionTextField, 2, 0);
        if (secondFunction instanceof StringFunction) {
            secondFunctionTextField.textProperty().addListener((observable, oldValue, newValue) ->
                    ((StringFunction) secondFunction).setPolynomialFunction(newValue));

        }
    }


    @FXML
    public void help() {
        try {
            new ProcessBuilder("cmd", "/c", "start", "help\\help.pdf").start();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    @FXML
    public void solve() {
        initData();
        if (correctedValue) {
            GraphicsContext gc = canvas.getGraphicsContext2D();
            gc.setFill(Color.WHITE);
            gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
            gs.setCanvas(canvas);
            gs.setPointOnCanvas(pointOnCanvas);
            pointOnCanvas.setVisible(true);
            gs.setFunctions(firstFunction, secondFunction);
            gs.setFromTo(from, to);
            gs.initYMaxYMin();
            gs.setScales();
            gs.initCenterPoint();
            gs.drawNet();
            gs.drawFunction(firstFunction);
            gs.drawFunction(secondFunction);
            gs.drawFunction(gs.getDiff());
            gs.drawPoints();
        }
    }

    public void saveFunctions() {
        FileChooser fileChooser = new FileChooser();
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter(
                "XML files (*.xml)", "*.xml");
        fileChooser.getExtensionFilters().add(extFilter);
        File file = fileChooser.showSaveDialog(new Stage());
        if (file != null) {
            if (!file.getPath().endsWith(".xml")) {
                file = new File(file.getPath() + ".xml");
            }
            readWriteXML.setFirstFunction(firstFunction);
            readWriteXML.setSecondFunction(secondFunction);
            readWriteXML.writeXML(file);
        }
    }

    public void openFunctions() {
        FileChooser fileChooser = new FileChooser();
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter(
                "XML files (*.xml)", "*.xml");
        fileChooser.getExtensionFilters().add(extFilter);
        File file = fileChooser.showOpenDialog(new Stage());

        if (file != null) {
            readWriteXML = ReadWriteXML.readXML(file);
            assert readWriteXML != null;
            firstFunction = readWriteXML.getFirstFunction();
            secondFunction = readWriteXML.getSecondFunction();
            deleteNode(secondFunctionTextField);
            deleteNode(firstFunctionTableView);
            if (firstFunction instanceof Lagrange) {
                firstFunctionTableView = TableBack.initTheTable(firstFunctionTableView);
                firstFunctionTableView.getItems().clear();
                pane.add(firstFunctionTableView, 0, 0);
                firstFunctionTableView.getItems().addAll(((Lagrange) firstFunction).getPoints());
            }

            if (secondFunction instanceof StringFunction) {
                pane.add(secondFunctionTextField, 2, 0);
                secondFunctionTextField.setText(((StringFunction) secondFunction).getPolynomialFunction());
                secondFunctionTextField.textProperty().addListener((observable, oldValue, newValue) ->
                        ((StringFunction) secondFunction).setPolynomialFunction(newValue));
            }
        }
    }

    private void setFromTo() {
        Alert alert;

        try {
            from = Double.parseDouble(fromTextField.getText());
            correctedValue = true;
        } catch (NumberFormatException e) {
            alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Ошибка");
            alert.setContentText("Некорректный ввод");
            alert.showAndWait();
        }
        double[] froms = new double[]{firstFunction.getXMin(), secondFunction.getXMin()};
        for (int i = 0; i < 2; i++) {
            if (froms[i] > from)
                from = froms[i];
        }
        correctedValue = false;
        try {
            to = Double.parseDouble(toTextField.getText());
            correctedValue = true;
        } catch (NumberFormatException e) {
            alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Ошибка");
            alert.setContentText("Некорректный ввод");
            alert.showAndWait();
        }
        double[] toArray = new double[]{firstFunction.getXMax(), secondFunction.getXMax()};
        for (int i = 0; i < 2; i++)
            if (toArray[i] < to)
                to = toArray[i];
    }

    private void initData() {
        if (firstFunction instanceof Lagrange) {
            ((Lagrange) firstFunction).setPoints(firstFunctionTableView.getItems());
        }

        firstFunction.initXMinXMax();
        secondFunction.initXMinXMax();
        setFromTo();
        try {
            eps = Double.valueOf(epsTextField.getText());
        } catch (NumberFormatException e) {
            eps = 0.01;
        }
        solution = new Solution(firstFunction, secondFunction);
        solution.setEps(eps);
        solution.setFrom(from);
        solution.setTo(to);
        correctedValue = false;
        try {
            solution.findMax();
            correctedValue = true;
        } catch (IllegalArgumentException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Ошибка");
            alert.setContentText("Неккоректная функция лагранджа");
            alert.showAndWait();
        } catch (RuntimeException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Ошибка");
            alert.setContentText("Некорректированная полиномиальная функция");
            alert.showAndWait();
        }
        max.setVisible(true);
        max.setText(solution.getResult().getY()+"");//БЫЛО X
        gs.setPoints(solution.getResult());
    }

    private void deleteNode(Node node) {
        if (pane.getChildren().contains(node))
            pane.getChildren().remove(node);
    }

    public void saveResults() {
        if (solution != null) {
            FileChooser fileChooser = new FileChooser();
            FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter(
                    "XML files (*.xml)", "*.xml");
            fileChooser.getExtensionFilters().add(extFilter);
            File file = fileChooser.showSaveDialog(new Stage());

            if (file != null) {
                if (!file.getPath().endsWith(".xml")) {
                    file = new File(file.getPath() + ".xml");
                }
                solution.writeXml(file);
            }
        }
    }

    @FXML
    public void saveReport() {
        saveImage();
        if (solution != null) {
            FileChooser fileChooser = new FileChooser();
            FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter(
                    "PDF files (*.pdf)", "*.pdf");
            fileChooser.getExtensionFilters().add(extFilter);
            File file = fileChooser.showSaveDialog(new Stage());
            new Report(file, solution.toString());

        }
    }

    private void saveImage() {
        WritableImage image = canvas.snapshot(new SnapshotParameters(), null);
        File file = new File("graphic.png");
        try {
            ImageIO.write(SwingFXUtils.fromFXImage(image, null), "png", file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

