package CourseWorkOP.Solution;

public abstract class Function {
    public final transient double eps = 0.001D;
    protected double yMax;
    protected double yMin;
    protected double xMax;
    protected double xMin;

    public Function() {
    }

    public abstract double getY(double var1);

    public abstract void initXMinXMax();

    public void initYMax(double a, double b) {
        this.yMax = this.getY(a);

        for(double step = (Math.abs(a) + Math.abs(b)) / 100.0D; a < b && Math.abs(this.getY(a) - this.getY(a + step)) <= 100.0D; a += step) {
            if(this.getY(a) > this.yMax) {
                this.yMax = this.getY(a);
            }
        }

    }

    public void initYMin(double a, double b) {
        this.yMin = this.getY(a);

        for(double step = (Math.abs(a) + Math.abs(b)) / 100.0D; a < b && Math.abs(this.getY(a) - this.getY(a + step)) <= 100.0D; a += step) {
            if(this.getY(a) < this.yMin) {
                this.yMin = this.getY(a);
            }
        }

    }

    public double getYMax() {
        return this.yMax;
    }

    public double getYMin() {
        return this.yMin;
    }

    public double getXMax() {
        return this.xMax;
    }

    public double getXMin() {
        return this.xMin;
    }
}
