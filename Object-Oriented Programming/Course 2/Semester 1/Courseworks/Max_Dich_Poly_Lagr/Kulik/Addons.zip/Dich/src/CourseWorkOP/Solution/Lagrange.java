package CourseWorkOP.Solution;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@XmlRootElement
public class Lagrange extends Function implements Serializable {
    private ArrayList<Point> points = new ArrayList<>();

    public Lagrange() {
    }

    @XmlElementWrapper(
            name = "Points"
    )
    @XmlElement(
            name = "Point"
    )
    public void setPoints(List<Point> points) {
        this.points = new ArrayList(points);
        this.sortList();
    }

    public List<Point> getPoints() {
        return this.points;
    }

    public void addPoint(double x, double y) {
        if (!this.points.contains(new Point(x, y))) {
            this.points.add(new Point(x, y));
        }

        this.sortList();
    }

    private void sortList() {
        this.points.sort((o1, o2) -> {
            return o1.getX() > o2.getX() ? 1 : (o1.getX() == o2.getX() ? 0 : -1);
        });
    }

    private int findPoint(double x) {
        Iterator var3 = this.points.iterator();

        Point a;
        do {
            if (!var3.hasNext()) {
                return -1;
            }

            a = (Point) var3.next();
        } while (a.getX() != x);

        return this.points.indexOf(a);
    }

    public void initXMinXMax() {
        this.xMin = this.points.get(0).getX();
        this.xMax = this.points.get(this.points.size() - 1).getX();
    }

    public double getY(double x) throws IllegalArgumentException {
        if (this.points.size() == 1) {
            throw new IllegalArgumentException();
        } else if (this.findPoint(x) != -1) {
            return this.points.get(this.findPoint(x)).getY();
        } else {
            double result = 0.0D;

            for (int i = 0; i < this.points.size(); ++i) {
                double k = 1.0D;

                for (int j = 0; j < this.points.size(); ++j) {
                    if (j != i) {
                        k *= (x - ((Point) this.points.get(j)).getX()) / (((Point) this.points.get(i)).getX() - ((Point) this.points.get(j)).getX());
                    }
                }

                result += k * ((Point) this.points.get(i)).getY();
            }

            return result;
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Lagrange function").append('\n');

        for (Object a : this.points) {
            sb.append(a.toString()).append('\n');
        }
        return sb.toString();
    }

}
