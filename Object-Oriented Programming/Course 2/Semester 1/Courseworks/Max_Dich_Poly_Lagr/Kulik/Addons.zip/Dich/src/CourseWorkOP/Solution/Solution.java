//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package CourseWorkOP.Solution;


import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

@XmlRootElement
public class Solution implements Serializable {
    private Function firstFunction;
    private Function secondFunction;
    private Point result;
    private double from;
    private double to;
    private double eps;
    private Double root[];


    public Solution() {
    }

    public Solution(Function firstFunction, Function secondFunction) {
        this.firstFunction = firstFunction;
        this.secondFunction = secondFunction;
    }

    @XmlElementWrapper(
            name = "Points"
    )
    @XmlElement(
            name = "Point"
    )
    public Point getResult() {
        return this.result;
    }

    public Function getFirstFunction() {
        return this.firstFunction;
    }

    @XmlElement
    public void setFirstFunction(Lagrange firstFunction) {
        this.firstFunction = firstFunction;
    }

    public Function getSecondFunction() {
        return this.secondFunction;
    }

    @XmlElement
    public void setSecondFunction(Function secondFunction) {
        this.secondFunction = secondFunction;
    }

    @XmlAttribute
    public void setFrom(double from) {
        this.from = from;
    }

    @XmlAttribute
    public void setTo(double to) {
        this.to = to;
    }

    @XmlAttribute
    public void setEps(double eps) {
        this.eps = eps;
    }

    //НАЧАЛО
    public Double[] getRoot() {
        return root;
    }

    public void findRoot() {
        List <Double[]> roots = new LinkedList<Double[]>();

        double n = (to-from)/eps;
        for (double i = from; i <= to; i+=eps){
            if (getFunction(i)*getFunction(i+eps)<0){
                roots.add(new Double[] {i,i+eps});
            }
        }

        root = new Double[roots.size()];

        for (int i = 0; i < roots.size();i++){

            double x = roots.get(i)[0];
            double x1 = x;

            do {
                x1 = x;
                x = x - getFunction(x) / der(x);
            } while (Math.abs(x-x1)<eps);

            root[i] = x;

        }
    }//НАХОЖДЕНИЕ КОРНЕЙ

    public double der(double x){
        double df=(getFunction(x+eps)-getFunction(x))/eps;
        return df;
    }//ПРОИЗВОДНАЯ
    //КОНЕЦ

    public void findMax() {
        double x = 0, x1, x2;
        while(Math.abs(to - from) > eps) {
            x = (from + to) / 2;
            x1 = getFunction(x - eps);
            x2 = getFunction(x + eps);
            if ((-1) * x1 < (-1) * x2)
                to = x;
            else
                from = x;
        }
        result = new Point(x, getFunction(x));
    }//МАКСИМУМ

    private double getFunction(double x) {
        return this.firstFunction.getY(x) - this.secondFunction.getY(x);
    }


    public void writeXml(File file) {
        try {
            JAXBContext e = JAXBContext.newInstance(Solution.class, StringFunction.class, Lagrange.class);
            Marshaller jaxbMarshaller = e.createMarshaller();
            jaxbMarshaller.setProperty("jaxb.formatted.output", Boolean.TRUE);
            jaxbMarshaller.marshal(this, file);
        } catch (JAXBException var4) {
            var4.printStackTrace();
        }

    }

    public static Solution readXML(File file) {
        try {
            JAXBContext e = JAXBContext.newInstance(Solution.class, StringFunction.class, Lagrange.class);
            Unmarshaller jaxbUnmarshaller = e.createUnmarshaller();
            return (Solution) jaxbUnmarshaller.unmarshal(file);
        } catch (Exception var3) {
            var3.printStackTrace();
            return null;
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("First function: ").append('\n');
        sb.append(this.firstFunction.toString()).append('\n');
        sb.append("Second function:").append('\n');
        sb.append(this.secondFunction.toString()).append('\n');
        sb.append("Results:").append('\n');
        sb.append(result.toString()).append('\n');
        return sb.toString();
    }
}
