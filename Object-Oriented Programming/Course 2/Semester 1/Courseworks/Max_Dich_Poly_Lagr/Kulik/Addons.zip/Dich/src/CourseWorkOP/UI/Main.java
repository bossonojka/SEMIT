package CourseWorkOP.UI;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("../MainWindow.fxml"));
        primaryStage.setTitle("Graphic Builder");
        primaryStage.setScene(new Scene(root, 900, 570));
        /*primaryStage.getStylesheets().add
                (HelloWorld.class.getResource("HelloWorld.css").toExternalForm());*/
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
