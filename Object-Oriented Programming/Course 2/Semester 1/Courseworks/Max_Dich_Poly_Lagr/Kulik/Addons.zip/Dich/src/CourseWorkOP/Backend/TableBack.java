package CourseWorkOP.Backend;

import CourseWorkOP.Solution.Point;
import com.sun.istack.internal.NotNull;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;



public class TableBack {

    public static TableView initTheTable(@NotNull TableView a) {
        a = new TableView();
        a.setEditable(true);

        ObservableList<Point> data = FXCollections.observableArrayList(new Point(0, 0));
        a.setItems(data);
        TableColumn<Point, Double> tableX = new TableColumn<>("X");
        TableColumn<Point, Double> tableY = new TableColumn<>("Y");

        tableX.setCellValueFactory(new PropertyValueFactory<>("x"));
        tableY.setCellValueFactory(new PropertyValueFactory<>("y"));
        //Cell X Factory
        tableX.setCellFactory(param -> new EditingCell());
        tableY.setCellFactory(param -> new EditingCell());
        //Save changed
        tableX.setOnEditCommit(event -> event.getTableView().getItems().get(
                event.getTablePosition().getRow()
        ).setX(event.getNewValue()));
        //
        tableY.setOnEditCommit(event -> event.getTableView().getItems().get(
                event.getTablePosition().getRow()
        ).setY(event.getNewValue()));

        a.getColumns().addAll(tableX, tableY);
        a.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        addContextMenu(a, data);
        return a;
    }

    private static void addContextMenu(final TableView a, final ObservableList data) {
        final ContextMenu contextMenu = new ContextMenu();
        MenuItem add = new MenuItem("Add");
        add.setOnAction(event -> {
            data.add(new Point(0, 0));
            a.setItems(data);
        });

        MenuItem rem = new MenuItem("Remove");
        rem.setOnAction(event -> {
            Point point = (Point) a.getSelectionModel().getSelectedItem();
            data.remove(point);
            a.setItems(data);
        });
        contextMenu.getItems().addAll(add, rem);
        a.setContextMenu(contextMenu);

    }

    private static class EditingCell extends TableCell<Point, Double> {

        private TextField textField;

        public EditingCell() {
        }

        @Override
        public void startEdit() {
            if (!isEmpty()) {
                super.startEdit();
                createTextField();
                setText(null);
                setGraphic(textField);
                textField.selectAll();
            }
        }

        @Override
        public void cancelEdit() {
            super.cancelEdit();
            setText(getItem() + "");
            setGraphic(null);
        }

        @Override
        public void updateItem(Double item, boolean empty) {
            super.updateItem(item, empty);

            if (empty) {
                setText(null);
                setGraphic(null);
            } else {
                if (isEditing()) {
                    if (textField != null) {
                        textField.setText(getString());
                    }
                    setText(getItem() + "");
                    setGraphic(textField);
                } else {
                    setText(getString());
                    setGraphic(null);
                }
            }
        }

        private void createTextField() {
            textField = new TextField(getString());
            textField.setMinWidth(this.getWidth() - this.getGraphicTextGap() * 2);
            textField.focusedProperty()
                    .addListener(
                            (ObservableValue<? extends Boolean> arg0, Boolean arg1,
                             Boolean arg2) -> {
                                if (!arg2) {
                                    try {
                                        commitEdit(Double.parseDouble(textField.getText()));
                                    } catch (Exception e) {
                                        commitEdit(0.0);
                                    }
                                }
                            });
        }

        private String getString() {
            return getItem() == null ? "" : getItem().toString();
        }

    }
}
