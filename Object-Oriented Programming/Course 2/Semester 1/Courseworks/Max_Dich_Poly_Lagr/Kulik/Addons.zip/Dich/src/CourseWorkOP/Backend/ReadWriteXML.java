package CourseWorkOP.Backend;

import CourseWorkOP.Solution.Function;
import CourseWorkOP.Solution.Lagrange;
import CourseWorkOP.Solution.StringFunction;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.File;


@XmlRootElement
public class ReadWriteXML {
    public ReadWriteXML() {
    }

    private Function firstFunction;
    private Function secondFunction;

    public Function getFirstFunction() {
        return firstFunction;
    }

    public Function getSecondFunction() {
        return secondFunction;
    }

    @XmlElement
    public void setFirstFunction(Function firstFunction) {
        this.firstFunction = firstFunction;
    }
    @XmlElement
    public void setSecondFunction(Function secondFunction) {
        this.secondFunction = secondFunction;
    }

    public void writeXML(File file) {
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(ReadWriteXML.class, StringFunction.class, Lagrange.class);
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

            // output pretty printed
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

            jaxbMarshaller.marshal(this, file);
            //jaxbMarshaller.marshal(this, System.out);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static ReadWriteXML readXML(File file) {
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(ReadWriteXML.class, StringFunction.class, Lagrange.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            return (ReadWriteXML) jaxbUnmarshaller.unmarshal(file);
        } catch (JAXBException e) {
            e.printStackTrace();
        }
        return null;
    }
}
