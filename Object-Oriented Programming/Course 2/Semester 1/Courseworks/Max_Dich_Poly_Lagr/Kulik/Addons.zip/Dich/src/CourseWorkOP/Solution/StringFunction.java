package CourseWorkOP.Solution;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@XmlRootElement
public class StringFunction extends Function implements Serializable {
    private String polynomialFunction;
    private ScriptEngine engine;
    private Object result;
    private List<Character> BasicMathOperations = new ArrayList<>();


    public StringFunction() {
        BasicMathOperations.add('+');
        BasicMathOperations.add('-');
        BasicMathOperations.add('/');
        BasicMathOperations.add('*');
    }

    public void setPolynomialFunction(String function) {
        if (function.contains("sin(") && !function.contains("Math.sin(")) {
            function = function.replace("sin(", "Math.sin(");
        }
        if (function.contains("cos(") && !function.contains("Math.cos(")) {
            function = function.replace("cos(", "Math.cos(");
        }
        if (function.contains("tan(") && !function.contains("Math.tan(")) {
            function = function.replace("tan(", "Math.tan(");
        }
        if (function.contains("ctg(") && !function.contains("1/Math.tan(")) {
            function = function.replace("ctg(", "1/Math.tan(");
        }
        if (function.contains("sqrt(") && !function.contains("Math.sqrt(")) {
            function = function.replace("sqrt(", "Math.sqrt(");
        }
        function = function.replace(" ", "");
        while (function.indexOf('^') != -1 && function.indexOf('^') + 1 != function.length()) {
            int i = 2;
            StringBuilder s = new StringBuilder("x^" + function.charAt(function.indexOf('^') + 1));
            StringBuilder power = new StringBuilder(String.valueOf(function.charAt(function.indexOf('^') + 1)));
            if (function.indexOf('^') + i < function.length()) {
                char c = function.charAt(function.indexOf('^') + i);
                while (!BasicMathOperations.contains(c)) {
                    s.append(function.charAt(function.indexOf('^') + i));
                    power.append(function.charAt(function.indexOf('^') + i));
                    i++;
                    if (function.indexOf('^') + i != function.length())
                        c = function.charAt(function.indexOf('^') + i);
                    else
                        break;
                }
            }
            function = function.replace(s, "Math.pow(x," + power + ")");
        }
        this.polynomialFunction = function;
        setEngine();
    }

    @XmlElement
    public String getPolynomialFunction() {
        return polynomialFunction;
    }

    private void setEngine() {
        ScriptEngineManager factory = new ScriptEngineManager();
        engine = factory.getEngineByName("JavaScript");
    }

    public double getY(double x) {
        engine.put("x", x);
        try {
            result = engine.eval(polynomialFunction);
        } catch (ScriptException e) {
          e.printStackTrace();
        }
        return Double.valueOf(result.toString());
    }

    public void initXMinXMax() {
        xMin = -Double.MAX_VALUE;
        xMax = Double.MAX_VALUE;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Polynomial function: ").append(polynomialFunction).append('\n');
        return sb.toString();
    }

}
