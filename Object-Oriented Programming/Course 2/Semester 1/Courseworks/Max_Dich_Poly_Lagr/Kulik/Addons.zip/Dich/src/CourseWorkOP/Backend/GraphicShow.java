package CourseWorkOP.Backend;

import CourseWorkOP.Solution.Function;
import CourseWorkOP.Solution.Point;
import com.sun.istack.internal.NotNull;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.List;

public class GraphicShow {
    private double width;
    private double height;
    private double from;
    private double to;
    private double yMax;
    private double yMin;
    private double xScale;
    private double yScale;
    private double step;
    private int rightLeft;
    private int upDown;
    private double xMouse;
    private double yMouse;
    private double x1;
    private double y1;
    private double xDelta;
    private double yDelta;
    private Label pointOnCanvas;
    private Point centerPoint;
    private Function fx;
    private Function gx;
    private Function diff;
    private Canvas canvas;
    private GraphicsContext gc;
    private Point point;
    private Color color = Color.BLACK;


    public GraphicShow() {
        rightLeft = -30;
        upDown = 15;
    }

    public void setCanvas(Canvas canvas) {
        this.canvas = canvas;
        this.width = canvas.getWidth();
        this.height = canvas.getHeight();
        gc = canvas.getGraphicsContext2D();
        canvas.addEventHandler(MouseEvent.MOUSE_MOVED, event -> {
            xMouse = event.getX();
            yMouse = event.getY();
            DecimalFormat df = new DecimalFormat("#.##");
            df.setRoundingMode(RoundingMode.CEILING);
            pointOnCanvas.setText("x = " + df.format((xMouse - centerPoint.getX()) / xScale) + " y = " + df.format((centerPoint.getY() - yMouse) / yScale));

        });
        canvas.addEventHandler(MouseEvent.MOUSE_DRAGGED, event -> {

            xDelta = x1 - event.getX();
            yDelta = y1 - event.getY();
            x1 = event.getX();
            y1 = event.getY();
            centerPoint = new Point(centerPoint.getX() - xDelta, centerPoint.getY() - yDelta);
            gc.clearRect(0, 0, width, height);
            drawNet();
            drawFunction(fx);
            drawFunction(gx);
            drawFunction(diff);

            drawPoints();

        });
        canvas.addEventHandler(MouseEvent.MOUSE_PRESSED, event -> {

            x1 = event.getX();
            y1 = event.getY();
        });

    }

    public void setFromTo(double from, double to) {
        this.from = from;
        this.to = to;
        step = 0.01;
    }

    public void setScales() {
        yMin -= 0.1;
        yMax += 0.1;
        from -= 0.1;
        to += 0.1;
        if (from <= 0 && to >= 0)
            xScale = width / (Math.abs(from) + Math.abs(to));
        if (from < 0 && to < 0)
            xScale = width / Math.abs(from - to);
        if (to > 0 && from > 0)
            xScale = width / (to - from);
        if (yMax > 0 && yMin >= 0)
            yScale = height / (yMax - yMin);
        if (yMax <= 0 && yMin < 0)
            yScale = height / Math.abs(yMin - yMax);
        if (yMax > 0 && yMin < 0)
            yScale = height / (yMax - yMin);

    }

    public void initYMaxYMin() {
        fx.initYMax(from, to);
        fx.initYMin(from, to);
        gx.initYMax(from, to);
        gx.initYMin(from, to);
        diff.initYMax(from, to);
        diff.initYMin(from, to);
        yMax = fx.getYMax() > gx.getYMax() ? fx.getYMax() : gx.getYMax();
        if (diff.getYMax() > yMax)
            yMax = diff.getYMax();
        yMin = fx.getYMin() < gx.getYMin() ? fx.getYMin() : gx.getYMin();
        if (diff.getYMin() < yMin)
            yMin = diff.getYMin();
    }

    public void initCenterPoint() {
        double xCenter = from > 0 && to > 0 ? 0 - from : from < 0 && to < 0 ? -from : Math.abs(from);
        double yCenter = yMax > 0 && yMin >= 0 ? yMax + yMin : yMax < 0 && yMin < 0 ? 0 : yMax;
        this.centerPoint = new Point(xCenter * xScale, yCenter * yScale);
    }

    public void setFunctions(@NotNull Function fx, @NotNull Function gx) {
        this.fx = fx;
        this.gx = gx;
        diff = new Function() {
            @Override
            public double getY(double var1) {
                return fx.getY(var1) - gx.getY(var1);
            }

            @Override
            public void initXMinXMax() {
                xMin = fx.getXMin();
                xMax = fx.getXMax();
            }
        };
    }

    public void setPoints(Point point) {
        this.point = point;
    }


    public void drawNet() {
        gc.setFill(Color.WHITE);
        gc.setLineWidth(2);
        gc.setFill(Color.BLACK);
        gc.setStroke(Color.BLACK);
        gc.strokeLine(centerPoint.getX(), 0, centerPoint.getX(), height);
        gc.strokeLine(0, centerPoint.getY(), width, centerPoint.getY());
        gc.setLineWidth(0.5);
        for (double i = centerPoint.getX(), xi = 0; i < width; i += width / 15, xi += (width / 15) / xScale) {
            gc.strokeLine(i, 0, i, height);
            gc.fillText((Math.round((xi) * 100.0) / 100.0) + "", i, centerPoint.getY() + upDown);
        }
        for (double i = centerPoint.getX(), xi = 0; i > 0; i -= width / 15, xi -= (width / 15) / xScale) {
            gc.fillText((Math.round((xi) * 100.0) / 100.0) + "", i - 15, centerPoint.getY() + upDown);
            gc.strokeLine(i, 0, i, height);
        }
        for (double i = centerPoint.getY(), yi = 0; i < height; i += height / 10, yi -= (height / 10) / yScale) {
            gc.strokeLine(0, i, width, i);
            if (i == centerPoint.getY())
                continue;
            gc.fillText((Math.round((yi) * 100.0) / 100.0) + "", centerPoint.getX() + rightLeft, i);
        }
        for (double i = centerPoint.getY(), yi = 0; i > 0; i -= height / 10, yi += (height / 10) / yScale) {
            gc.strokeLine(0, i, width, i);
            if (i == centerPoint.getY())
                continue;
            gc.fillText((Math.round((yi) * 100.0) / 100.0) + "", centerPoint.getX() + rightLeft, i);
        }
        gc.setLineWidth(2);
        gc.strokeLine(centerPoint.getX() - 3, 10, centerPoint.getX(), 0);
        gc.strokeLine(centerPoint.getX() + 3, 10, centerPoint.getX(), 0);
        gc.fillText("y", centerPoint.getX() - 10, 7);
        gc.strokeLine(width - 10, centerPoint.getY() - 3, width, centerPoint.getY());
        gc.strokeLine(width - 10, centerPoint.getY() + 3, width, centerPoint.getY());
        gc.fillText("x", width - 10, centerPoint.getY() - 7);
    }

    public void drawFunction(Function f) {
        gc.setFill(Color.WHITE);
        if (f.equals(diff))
            gc.setStroke(Color.RED);
        else
            gc.setStroke(color);
        gc.setLineWidth(2);

        for (double i = centerPoint.getX(), xi = 0; i < width; i += step * xScale, xi += step) {
            try {
                gc.strokeLine(i, centerPoint.getY() - f.getY(xi) * yScale,
                        i + step * xScale, centerPoint.getY() - f.getY(xi + step) * yScale);

            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            }
        }
        for (double i = centerPoint.getX(), xi = 0; i > 0; i -= step * xScale, xi -= step) {
            try {
                gc.strokeLine(i, centerPoint.getY() - f.getY(xi) * yScale,
                        i + step * xScale, centerPoint.getY() - f.getY(xi + step) * yScale);

            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            }
        }
    }


    public void drawPoints() {
        gc.setFill(Color.RED);
            gc.fillOval(centerPoint.getX() + point.getX() * xScale - 5, centerPoint.getY() - point.getY() * yScale - 5, 10, 10);
    }

    public void setPointOnCanvas(Label pointOnCanvas) {
        this.pointOnCanvas = pointOnCanvas;
    }

    public Function getDiff() {
        return diff;
    }
}
