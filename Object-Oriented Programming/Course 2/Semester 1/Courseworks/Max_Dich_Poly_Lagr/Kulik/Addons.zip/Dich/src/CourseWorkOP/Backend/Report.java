package CourseWorkOP.Backend;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.File;
import java.io.FileOutputStream;

public class Report {

    private Document document;
    private PdfWriter writer;
    private Font font;
    private Font fontBold;

    public Report(File file, String report) {
        document = new Document(PageSize.A4, 50, 50, 50, 50);
        try {
            writer = PdfWriter.getInstance(document, new FileOutputStream(file));
            BaseFont helvetica =
                    BaseFont.createFont("C:\\Windows\\Fonts\\ARIAL.TTF", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
            font = new Font(helvetica, 14);
            BaseFont bold = BaseFont.createFont("C:\\Windows\\Fonts\\ARIBLK.TTF", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
            fontBold = new Font(bold, 14);
            document.open();
            setTextToPDF("Условия задачи:", 2);
            setTextToPDF("Даны 2 функции,f(x) и g(x), где f(x) задана точками, а g(x) является полиномом." +
                    " Необходимо найти максимум функции f(x) - g(x)", 1);
            setTextToPDF("Решение: ", 2);
            setTextToPDF(report, 1);
            Image image = Image.getInstance("graphic.png");
            document.add(image);


        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            document.close();
        }
    }

    private void setTextToPDF(String text, int bold) {
        try {
            switch (bold) {
                case 1:
                    document.add(new Paragraph(text, font));
                    break;
                case 2:
                    document.add(new Paragraph(text, fontBold));
            }
        } catch (DocumentException e) {
            e.printStackTrace();
        }

    }
}
