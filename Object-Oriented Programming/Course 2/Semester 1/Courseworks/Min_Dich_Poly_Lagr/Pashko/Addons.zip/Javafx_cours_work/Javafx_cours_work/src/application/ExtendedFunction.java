package application;

public interface ExtendedFunction {
	double y(double x);
}