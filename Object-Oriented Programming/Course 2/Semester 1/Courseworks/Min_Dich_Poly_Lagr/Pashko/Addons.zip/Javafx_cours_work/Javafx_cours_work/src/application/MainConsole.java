package application;

import Exceptions.SamePointsException;

public class MainConsole {

	public static void main(String[] args) throws SamePointsException {
		XMLFunction xFunction = new XMLFunction("correctData.xml");
		System.out.println(xFunction.findMin(-5, 5, 0.005));

	}
	
}
