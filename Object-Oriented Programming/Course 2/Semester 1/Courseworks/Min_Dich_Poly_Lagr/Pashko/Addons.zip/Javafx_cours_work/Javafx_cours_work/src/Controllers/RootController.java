package Controllers;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;

import Exceptions.SamePointsException;
import application.XMLFunction;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.effect.Shadow;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Pair;
import javafx.util.converter.NumberStringConverter;
import generated.FuncData;
import generated.FuncData.Points.Point;

public class RootController {

	private static final Pair<String, String> FILTER_XML = new Pair<String, String>("XML-files (*.xml)", "*.xml");
	private static final Pair<String, String> FILTER_HTML = new Pair<String, String>("Html-files (*.html)", "*.html");

	@FXML
	private LineChart<Number, Number> chart;
	@FXML
	private TableView<Point> tableFfunc;
	@FXML
	private TableView<Point> tableGfunc;
	@FXML
	private TableView<Point> resultData;
	@FXML
	private TableColumn<Point, Number> columnRx;
	@FXML
	private TableColumn<Point, Number> columnRy;
	@FXML
	private TableColumn<Point, Number> columnFx;
	@FXML
	private TableColumn<Point, Number> columnFy;
	@FXML
	private TableColumn<Point, Number> columnGx;
	@FXML
	private TableColumn<Point, Number> columnGy;
	@FXML
	private Label labelMin;
	@FXML
	private Label labelStrMin;
	@FXML
	private TextField from;
	@FXML
	private TextField until;

	private ObservableList<Point> obsF;
	private ObservableList<Point> obsG;

	private XMLFunction xmlFunc;

	public void saveAsPng(String path) {
		WritableImage image = chart.snapshot(new SnapshotParameters(), null);
		File file = new File(path);
		try {
			ImageIO.write(SwingFXUtils.fromFXImage(image, null), "png", file);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	private void doHelp(){
		WebView webView=new WebView();
		File file =new File("contexHelp/intex.html");
		webView.getEngine().load(file.toURI().toString());
		Scene scene = new Scene(webView);
		Stage stage = new Stage();
		stage.setScene(scene);
		stage.show();
	}

	@FXML
	private void doReport() {
		if (!xmlFunc.equals(null) && !from.getText().equals("") && !until.getText().equals("")) {
			final WebView webView = new WebView();
			final WebEngine engine = webView.getEngine();

			String imagePath = engine.hashCode() + "Chart.png";
			File imageFullPath = new File(imagePath);
			saveAsPng(imagePath);
			String html = xmlFunc.buildReport(Double.parseDouble(from.getText()), Double.parseDouble(until.getText()),
					imageFullPath.getPath());
			xmlFunc.saveReport("null.html", html);
			File file = new File("null.html");
			engine.load(file.toURI().toString());
			Button button = new Button("Save report");
			button.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent event) {
					// TODO Auto-generated method stub
					FileChooser fileChooser = getFileChooser("Save report", FILTER_HTML);
					File file;
					if ((file = fileChooser.showSaveDialog(null)) != null) {
						try {
							String name = file.getAbsolutePath().replaceAll(".html", "");
							saveAsPng(name + "S.png");
							String string = xmlFunc.buildReport(Double.parseDouble(from.getText()),
									Double.parseDouble(until.getText()),
									file.getName().replaceAll(".html", "") + "S.png");
							xmlFunc.saveReport(file.getPath(), string);
							showMessage("The report successfully saved");
						} catch (Exception e) {
							e.printStackTrace();
							showError("Error with file saving");
						}
					}

				}
			});
			VBox root = new VBox();
			root.getChildren().addAll(webView, button);

			Scene scene = new Scene(root);
			Stage stage = new Stage();
			stage.setScene(scene);
			stage.show();

			stage.setOnCloseRequest(e -> {
				new File(imagePath).delete();
				new File("null.html").delete();
			});
		} else

			showMessage("Fill in all the data");
	}

	@FXML
	private void initialize() {
		xmlFunc = new XMLFunction();
		chart.setCreateSymbols(false);
		tableFfunc.setEditable(true);
		tableGfunc.setEditable(true);

		columnFx.setSortable(false);
		columnFy.setSortable(false);
		columnGx.setSortable(false);
		columnGy.setSortable(false);
		columnRx.setSortable(false);
		columnRy.setSortable(false);

		from.textProperty().addListener(new FieldListener(from));
		until.textProperty().addListener(new FieldListener(until));
	}

	@FXML
	private void doNew() {
		doClear();
	}

	@FXML
	private void doOpen() {
		FileChooser fileChooser = getFileChooser("������� XML-����", FILTER_XML);
		File file;
		try {
			if ((file = fileChooser.showOpenDialog(null)) != null) {
				xmlFunc.readFromXML(file.getCanonicalPath());
				clearData();
				updateTables();
			}
		} catch (SamePointsException e) {
			clearData();
			showError("check input data same points");
		} catch (Exception e) {
			clearData();
			e.printStackTrace();
		}

	}

	private void clearData() {
		chart.getData().clear();
		resultData.setVisible(false);
		labelMin.setVisible(false);
		labelStrMin.setVisible(false);
	}

	@FXML
	private void doSave() {
		FileChooser fileChooser = getFileChooser("Save as XML", FILTER_XML);
		File file;
		if ((file = fileChooser.showSaveDialog(null)) != null) {
			try {
				updateSourceData();
				xmlFunc.toXml(file.getCanonicalPath());
				showMessage("Succes");
			} catch (Exception e) {
				showError("Error write to Xml");
			}
		}
	}

	@FXML
	private void doClear() {
		chart.getData().clear();
		obsF.clear();
		obsG.clear();
		updateSourceData();
		resultData.setVisible(false);
		from.clear();
		until.clear();
		labelMin.setVisible(false);
		labelStrMin.setVisible(false);
	}

	@FXML
	private void doBuild() {

		try {
			checkPoints();
		} catch (Exception e) {
			showError("check inpud data same points");
			return;
		}

		chart.getData().clear();
		if (!checkInterval()) {
			showMessage("Fill all fields");
			return;
		}

		if (obsF == null || obsG == null) {
			labelMin.setVisible(false);
			labelStrMin.setVisible(false);
			resultData.setVisible(false);
			showMessage("fill tables");

			return;
		}

		XYChart.Series<Number, Number> fSeries = new XYChart.Series<>();
		XYChart.Series<Number, Number> gSeries = new XYChart.Series<>();
		XYChart.Series<Number, Number> fgSeries = new XYChart.Series<>();
		ObservableList<Point> observableList = FXCollections.observableArrayList();

		fSeries.setName("f(x)");
		gSeries.setName("g(x)");
		fgSeries.setName("f(x)-g(x)");

		Double f = Double.parseDouble(from.getText());
		Double u = Double.parseDouble(until.getText());
		for (double i = f; i <= u; i += 0.1) {
			double fy = xmlFunc.getF().y(i);
			double gy = xmlFunc.getG().y(i);

			fSeries.getData().add(new Data<>(i, fy));
			gSeries.getData().add(new Data<>(i, gy));
			fgSeries.getData().add(new Data<>(i, fy - gy));

			observableList.add(new Point(i, fy - gy));
		}

		chart.getData().add(fSeries);
		chart.getData().add(gSeries);
		chart.getData().add(fgSeries);

		showResults(observableList);
		double minx = xmlFunc.findMin(f, u, 0.001);
		double miny = xmlFunc.getF().y(minx) - xmlFunc.getG().y(minx);

		labelMin.setText(
				"X = " + DecimalFormat.getInstance().format(minx) + " Y = " + DecimalFormat.getInstance().format(miny));

	}

	private void showResults(ObservableList<Point> list) {
		resultData.setVisible(true);
		labelStrMin.setVisible(true);
		labelMin.setVisible(true);
		resultData.setItems(list);

		columnRx.setCellValueFactory(new PropertyValueFactory<>("x"));
		columnRx.setCellFactory(TextFieldTableCell.<Point, Number>forTableColumn(new NumberStringConverter()));
		columnRy.setCellValueFactory(new PropertyValueFactory<>("y"));
		columnRy.setCellFactory(TextFieldTableCell.<Point, Number>forTableColumn(new NumberStringConverter()));
	}

	@FXML
	private void doExit() {
		Platform.exit();
	}

	@FXML
	private void doAddF() {
		if (obsF == null) {
			updateTables();
		}
		obsF.add(new Point(0., 0.));
		updateSourceData();
	}

	@FXML
	private void doRemoveF() {
		if (obsF == null) {
			return;
		}
		if (obsF.size() > 0) {
			obsF.remove(obsF.size() - 1);

		}
		if (obsF.size() <= 0) {
			obsF = null;
		}
		updateSourceData();
	}

	@FXML
	private void doAddG() {
		if (obsG == null) {
			updateTables();
		}
		obsG.add(new Point(0., 0.));
		updateSourceData();
	}

	@FXML
	private void doRemoveG() {
		if (obsG == null) {
			return;
		}
		if (obsG.size() > 0) {
			obsG.remove(obsG.size() - 1);
		}
		if (obsG.size() <= 0) {
			obsG = null;
		}
		updateSourceData();
	}

	@FXML
	private void doAbout() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("About ...");
		alert.setHeaderText("Find min zol method");
		alert.setContentText("version 1.1");
		alert.showAndWait();
	}

	public FileChooser getFileChooser(String title, Pair<String, String> filters) {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setInitialDirectory(new File("."));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter(filters.getKey(), filters.getValue()));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("All files (*.*)", "*.*"));
		fileChooser.setTitle(title);
		return fileChooser;
	}

	public void showError(String message) {
		Alert alert = new Alert(AlertType.ERROR);
		alert.setTitle("Error");
		alert.setHeaderText(message);
		alert.showAndWait();
	}

	public void showMessage(String message) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("");
		alert.setHeaderText(message);
		alert.showAndWait();
	}

	private void updateTables() {
		List<Point> fList = new ArrayList<>();
		List<Point> gList = new ArrayList<>();

		obsF = FXCollections.observableList(fList);
		obsG = FXCollections.observableList(gList);

		for (Point point : xmlFunc.getData().getFPoints().getPoint()) {
			fList.add(point);
		}

		for (Point point : xmlFunc.getData().getGPoints().getPoint()) {
			gList.add(point);
		}
		tableFfunc.setItems(obsF);
		tableGfunc.setItems(obsG);

		columnFx.setCellValueFactory(new PropertyValueFactory<>("x"));
		columnFx.setCellFactory(TextFieldTableCell.<Point, Number>forTableColumn(new NumberStringConverter()));
		columnFx.setOnEditCommit(t -> ((Point) t.getTableView().getItems().get(t.getTablePosition().getRow()))
				.setX(t.getNewValue().doubleValue()));

		columnFy.setCellValueFactory(new PropertyValueFactory<>("y"));
		columnFy.setCellFactory(TextFieldTableCell.<Point, Number>forTableColumn(new NumberStringConverter()));
		columnFy.setOnEditCommit(t -> ((Point) t.getTableView().getItems().get(t.getTablePosition().getRow()))
				.setY(t.getNewValue().doubleValue()));

		columnGx.setCellValueFactory(new PropertyValueFactory<>("x"));
		columnGx.setCellFactory(TextFieldTableCell.<Point, Number>forTableColumn(new NumberStringConverter()));
		columnGx.setOnEditCommit(t -> ((Point) t.getTableView().getItems().get(t.getTablePosition().getRow()))
				.setX(t.getNewValue().doubleValue()));

		columnGy.setCellValueFactory(new PropertyValueFactory<>("y"));
		columnGy.setCellFactory(TextFieldTableCell.<Point, Number>forTableColumn(new NumberStringConverter()));
		columnGy.setOnEditCommit(t -> ((Point) t.getTableView().getItems().get(t.getTablePosition().getRow()))
				.setY(t.getNewValue().doubleValue()));

	}

	private void updateSourceData() {
		xmlFunc.getData().clearData();
		if (obsF != null)
			for (Point point : obsF) {
				xmlFunc.getData().getPoints().get(0).getPoint().add(point);
			}
		if (obsG != null)
			for (Point point : obsG) {
				xmlFunc.getData().getPoints().get(1).getPoint().add(point);
			}
		xmlFunc.updateFunc();
	}

	private boolean isNumber(String str) {
		if (str == null || str.isEmpty())
			return false;
		if (str.contains(",")) {
			return false;
		}

		int count = 0;

		for (int i = 0; i < str.length(); i++) {
			if (Character.compare(str.charAt(i), '.') == 0) {
				count++;
			}
		}
		if (count > 1) {
			return false;
		}

		for (int i = 0; i < str.length(); i++) {
			if (!Character.isDigit(str.charAt(i)) && !(i == 0 && str.charAt(i) == '-') && str.charAt(i) != '.')
				return false;
		}
		return true;
	}

	private boolean checkInterval() {
		if (from.getText().length() > 0 && until.getText().length() > 0) {
			try {
				return Double.parseDouble(from.getText()) < Double.parseDouble(until.getText()) ? true : false;
			} catch (Exception e) {
				showError("Fill interval");
			}
		}
		return false;
	}

	class FieldListener implements ChangeListener<String> {
		private TextField field;

		public FieldListener(TextField field) {
			this.field = field;
		}

		@Override
		public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
			if (!isNumber(newValue) || newValue.isEmpty()) {
				field.setText(newValue.length() > 1 ? newValue.substring(0, newValue.length() - 1) : "");
			}
		}
	}

	private void checkPoints() throws SamePointsException {

		Map<Double, Integer> map = new HashMap<>();
		Map<Double, Integer> map2 = new HashMap<>();

		for (Point points : obsF) {
			if (map.get(points.getX()) == null) {
				map.put(points.getX(), 0);
			} else {
				map.put(points.getX(), (map.get(points.getX()) + 1));
			}
		}
		for (Point points : obsG) {
			if (map2.get(points.getX()) == null) {
				map2.put(points.getX(), 0);
			} else {
				map2.put(points.getX(), (map2.get(points.getX()) + 1));
			}
		}

		for (Map.Entry<Double, Integer> pEntry : map.entrySet()) {
			if (pEntry.getValue() > 0) {
				throw new SamePointsException(new Point(pEntry.getKey(), 0.));
			}
		}
		for (Map.Entry<Double, Integer> pEntry : map2.entrySet()) {
			if (pEntry.getValue() > 0) {
				throw new SamePointsException(new Point(pEntry.getKey(), 0.));
			}
		}
	}

}
