package application;

public class FGFunctions {
	private ExtendedFunction f;
	private ExtendedFunction g;

	public FGFunctions() {
		// TODO Auto-generated constructor stub
	}

	public FGFunctions(ExtendedFunction f, ExtendedFunction g) {
		this.f = f;
		this.g = g;
	}

	public ExtendedFunction getF() {
		return f;
	}

	public ExtendedFunction getG() {
		return g;
	}

	public void setF(ExtendedFunction f) {
		this.f = f;
	}

	public void setG(ExtendedFunction g) {
		this.g = g;
	}

	public double findMin(double a, double b, double eps) {
		double sigma = eps / 2 - eps / 4;
		double x = 0;
		do {
			x = (a + b) / 2.;
			double l = x - sigma;
			double r = x + sigma;

			if ((f.y(l) - g.y(l)) <= (f.y(r) - g.y(r))) {
				b = r;
			} else {
				a = l;
			}
		} while (Math.abs(a - b) > eps);
		return x;
	}
}
