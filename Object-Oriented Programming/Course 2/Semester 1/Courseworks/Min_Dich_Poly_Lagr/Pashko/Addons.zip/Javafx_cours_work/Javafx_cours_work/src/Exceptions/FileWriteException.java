package Exceptions;

public class FileWriteException extends FileException {
	public FileWriteException(String fileName) {
		super(fileName);
	}
}
