import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.layout.StackPane;
import javafx.scene.control.TextField;

import java.util.function.Function;

public class Controller {
    Main main;
    @FXML
    private TextField a;
    @FXML
    private TextField b;
    @FXML
    private TextField f;
    @FXML
    private TextField g;
    @FXML
    private TextField start;
    @FXML
    private TextField end;
    @FXML
    private LineChart<Number, Number> chart;

    public Controller() {
    }

    public void setMain(Main main) {
        this.main = main;
    }


    @FXML
    private void calc(){
        Function<Double, Double> fx = new Polynom(f.getText());
        Function<Double, Double> gx = new Polynom(g.getText());
        chart.getData().clear();
        double ae = Double.parseDouble(a.getText());
        double be = Double.parseDouble(b.getText());
        //double exp1 = ae * fx.apply(0.0);
        // double exp2 = gx.apply(be* 0.0);
        XYChart.Series series = new XYChart.Series();

        Function<Double, Double> h = (Double x) -> {
            return ae * fx.apply(x) - gx.apply(be* x);
        };


        for(double i = Double.parseDouble(start.getText()); i <= Double.parseDouble(end.getText()); i+=0.1){
            series.getData().add(new XYChart.Data<Number, Number>(i, h.apply(i)));
        }

        chart.getData().add(series);
        for (XYChart.Data<Number, Number> data : chart.getData().get(0).getData()) {
            StackPane stackPane = (StackPane) data.getNode();
            stackPane.setDisable(true);
            stackPane.setVisible(false);
        }

    }
}
