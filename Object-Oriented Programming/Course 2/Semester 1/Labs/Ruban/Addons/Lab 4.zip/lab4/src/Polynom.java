import org.mariuszgromada.math.mxparser.Argument;
import org.mariuszgromada.math.mxparser.Expression;

import java.util.function.Function;

public class Polynom implements Function<Double, Double> {
    Expression f;
    Argument argX = new Argument("x");

    public Polynom(String func) {
        func = func.replaceAll(" ", "");
        f = new Expression(func, argX);
    }

    @Override
    public Double apply(Double x) {
        argX.setArgumentValue(x);
        return f.calculate();
    }
}
