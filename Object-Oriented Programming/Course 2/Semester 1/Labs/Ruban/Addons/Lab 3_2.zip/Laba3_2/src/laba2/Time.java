package laba2;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javax.xml.bind.annotation.XmlElement;

public class Time {
    private IntegerProperty passengers;
    private StringProperty time;
    private StringProperty comment;

    public IntegerProperty passengersProperty() {
        return passengers;
    }
    public StringProperty timeProperty() {
        return time;
    }
    public StringProperty commentProperty() {
        return comment;
    }

    @XmlElement(name = "time")
    public String getTime() {
        return time.get();
    }
    @XmlElement(name = "comment")
    public String getComment() {
        return comment.get();
    }
    @XmlElement(name = "passengers")
    public int getPassengers() {
        return passengers.get();
    }

    public void setTime(String time) {
        this.time.set(time);
    }
    public void setComment(String comment) {
        this.comment.set(comment);
    }
    public void setPassengers(int passengers) {
        this.passengers.setValue(passengers);
    }

    public Time() {
        this(0, null, null);
    }

    public Time(int passengers) {
        this.passengers.set(passengers);
        this.time.set(null);
        this.comment.set(null);
    }

    @Override
    public String toString() {
        return "\nPassengers = " + passengers.get()
                + " Time = " + time.get() + " Comment = "+ comment.get();
    }

    @Override
    public boolean equals(Object obj) {
        Time s = (Time) obj;
        return this.passengers == s.passengers;
    }

    public Time(int passengers, String time, String comment) {
        this.passengers = new SimpleIntegerProperty(passengers);
        this.time = new SimpleStringProperty(time);
        this.comment = new SimpleStringProperty(comment);
    }
}
