package laba2;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name="TramStations")
public class TramStations {
    private List<TramStation> tramStations;

    public TramStations() { }

    @XmlElement(name = "TramStation")
    public List<TramStation> getList() {
        return tramStations;
    }

    @Override
    public String toString() {
        String res = "";
        for (TramStation ts:
                tramStations) {
            res+= "\nName: " + ts.getName()
                    + "\nNumber: " + ts.getNumberList() + "\n"+ ts.getTimes();
        }
        return res;
    }

    public void setList(List<TramStation> ws) {
        this.tramStations = ws;
    }
}