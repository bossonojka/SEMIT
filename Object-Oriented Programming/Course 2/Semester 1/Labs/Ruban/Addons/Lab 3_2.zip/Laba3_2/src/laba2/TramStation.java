package laba2;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import javax.xml.bind.annotation.XmlElement;
import java.util.ArrayList;


public class TramStation {
    private StringProperty name;//name
    private StringProperty numberList;//address

    private ArrayList<Time> times = new ArrayList<>();//shifts
    @Override
    public String toString() {
        return "TramStation{" +
                "name='" + name.get() + '\'' +
                ", numberList='" + numberList.get() + '\'' + times.toString() + '}';
    }

    @XmlElement(name = "numberList")
    public String getNumberList() {
        return numberList.get();
    }
    @XmlElement(name = "name")
    public String getName() {
        return name.get();
    }
    @XmlElement(name = "times")
    public ArrayList<Time> getTimes() {
        return times;
    }

    public StringProperty getPropertyNumberList() {
        return numberList;
    }
    public StringProperty getPropertyName() {
        return name;
    }
    public void setName(String name) {
        this.name.set(name);
    }

    public void setNumberList(String numberList) {
        this.numberList.set(numberList);
    }

    public void setTimes(ArrayList<Time> times) {
        this.times = times;
    }

    public void add(Time ws) {
        boolean exist = false;
        for (Time s:
             times) {
            if(s.getPassengers() == ws.getPassengers()) {
                exist = true;
                break;
            }
        }
        if(!exist) times.add(ws);
    }

    public String search(Time ws) {
        for (Time time: times) {
            if(time.equals(ws)){
                return ws.toString();
            }
        }
        System.out.println("This passengers ("+ ws.getPassengers() +") not exist!");
        return null;
    }

    public int total() {
        return times.size();
    }
    public void hourWithMinPassengers() {
        int minIndex = 0;
        for (int i = 1; i < total(); i++) {
            if(times.get(minIndex).getPassengers() > times.get(i).getPassengers()){
                minIndex = i;
            }
        }
        System.out.println("Hour With Min Number Of Passengers " + times.get(minIndex).getTime()
                + " passengers (" + times.get(minIndex).getPassengers() + ").");
    }
    public Time getPassengers(int i) {
        return times.get(i);
    }
    public TramStation() {
        this(null, null);
    }

    public TramStation(String name, String numberList) {
        this.name = new SimpleStringProperty(name);
        this.numberList = new SimpleStringProperty(numberList);
    }
}
