﻿package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.FileChooser;
import javafx.util.converter.NumberStringConverter;
import laba2.Time;
import laba2.TramStation;
import sample.Main;

import java.io.File;

public class MainController {
    Main main;
    @FXML
    private TextField addName;
    @FXML
    private TextField addNumber;
    @FXML
    private TextField addTime;
    @FXML
    private TextField addPassengers;
    @FXML
    private TextField addComment;
    @FXML
    private TextField Summ;
    @FXML
    private TableView<TramStation> TramStationTableView;
    @FXML
    private TableView<Time> TimeTableView;
    @FXML
    private TableColumn<TramStation, String> nameTS;
    @FXML
    private TableColumn<TramStation, String> numberTS;
    @FXML
    private TableColumn<Time, Number> passengersNum;
    @FXML
    private TableColumn<Time, String> timesNum;
    @FXML
    private TableColumn<Time, String> commentN;

    public void initialize() {
        nameTS.setCellFactory(TextFieldTableCell.forTableColumn());
        nameTS.setOnEditCommit(
                event -> (event.getTableView().getItems().get(
                        event.getTablePosition().getRow())
                ).setName(event.getNewValue())
        );
        nameTS.setCellValueFactory(cellBack -> cellBack.getValue().getPropertyName());
        numberTS.setCellValueFactory(cellBack -> cellBack.getValue().getPropertyNumberList());
        numberTS.setCellFactory(TextFieldTableCell.forTableColumn());
        numberTS.setOnEditCommit(
                event -> (event.getTableView().getItems().get(
                        event.getTablePosition().getRow())
                ).setNumberList(event.getNewValue())
        );

        showDetails(null);

        passengersNum.setCellFactory(TextFieldTableCell.forTableColumn(new NumberStringConverter()));
        passengersNum.setOnEditCommit(
                event -> (event.getTableView().getItems().get(
                        event.getTablePosition().getRow())
                ).setPassengers(event.getNewValue().intValue())
        );

        timesNum.setCellFactory(TextFieldTableCell.forTableColumn());
        timesNum.setOnEditCommit(
                event -> (event.getTableView().getItems().get(
                        event.getTablePosition().getRow())
                ).setTime(event.getNewValue())
        );
        commentN.setCellFactory(TextFieldTableCell.forTableColumn());
        commentN.setOnEditCommit(
                event -> (event.getTableView().getItems().get(
                        event.getTablePosition().getRow())
                ).setComment(event.getNewValue())
        );

        TramStationTableView.getSelectionModel().selectedItemProperty().addListener(
                (observable, old, selected) -> showDetails(selected));
    }


    private void showDetails(TramStation tramStation) {
        if (tramStation != null) {
            passengersNum.setCellValueFactory(cellBack -> cellBack.getValue().passengersProperty());
            timesNum.setCellValueFactory(cellBack -> cellBack.getValue().timeProperty());
            commentN.setCellValueFactory(cellBack -> cellBack.getValue().commentProperty());
            ObservableList<Time> temp = FXCollections.observableArrayList();
            temp.addAll(tramStation.getTimes());
            TimeTableView.setItems(temp);
        }
    }

    public void setMain(Main main) {
        this.main = main;
        ObservableList<TramStation> temp = FXCollections.observableArrayList();
        temp.addAll(main.getList());
        TramStationTableView.setItems(temp);
    }

    @FXML
    private void handleSaveAs() {
        main.saveToXML(main.getStage());
    }

    @FXML
    private void handleAddTS() {
        if(addName.getText().length() > 1 && addNumber.getText().length() > 1) {
            main.getList().add(new TramStation(
                    addName.getText(),
                    addNumber.getText()));

            ObservableList<TramStation> temp = FXCollections.observableArrayList();
            temp.addAll(main.getList());
            TramStationTableView.setItems(temp);

            addName.clear();
            addNumber.clear();
        }
    }
    @FXML
    private void handleAbout() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("NewApp");
        alert.setHeaderText("About: version 14.04");
        alert.setContentText("Author: Bodnia Yevhen\n");
        alert.showAndWait();
    }
    @FXML
    private void handleAddTSTime() {
        if(addTime.getText().length() > 1 && addPassengers.getText().length() > 1 && addComment.getText().length() > 1&&
                Integer.parseInt(addPassengers.getText())>0) {
               // pass();
                TramStation selected = TramStationTableView.getSelectionModel().selectedItemProperty().get();
                //if(Integer.parseInt(addPassengers.getText())>0)
                selected.add(new Time(Integer.parseInt(addPassengers.getText()),
                        String.valueOf(addTime.getText()),
                        String.valueOf(addComment.getText())));
                ObservableList<Time> temp = FXCollections.observableArrayList();
                temp.addAll(selected.getTimes());
                TimeTableView.setItems(temp);
                int sum = 0;
                for (int i = 0; i < selected.total(); i++) {
                    sum += selected.getTimes().get(i).getPassengers();
                }
                Summ.setText(String.valueOf(sum));
                addTime.clear();
                addPassengers.clear();
                addComment.clear();
                showDetails(selected);

            }

    }
    @FXML
    private void handleOpen() {
        FileChooser fileChooser = new FileChooser();
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter(
                "XML files (*.xml)", "*.xml");
        fileChooser.getExtensionFilters().add(extFilter);

        File file = fileChooser.showOpenDialog(main.getStage());

        if (file != null) {
            main.loadDataFromFile(file);
            ObservableList<TramStation> temp = FXCollections.observableArrayList();
            temp.addAll(main.getList());
            TramStationTableView.setItems(temp);
        }

    }

    @FXML
    public void handleDelete(){
        TramStation workShop = TramStationTableView.getSelectionModel().selectedItemProperty().get();
        Time workingShift = TimeTableView.getSelectionModel().selectedItemProperty().get();
        if(workingShift == null){
            main.getList().remove(workShop);
            ObservableList<TramStation> temp = FXCollections.observableArrayList();
            temp.addAll(main.getList());
            TimeTableView.setItems(null);
            TramStationTableView.setItems(temp);
        }else{
            workShop.getTimes().remove(workingShift);
            ObservableList<Time> temp = FXCollections.observableArrayList();
            temp.addAll(workShop.getTimes());
            TimeTableView.setItems(temp);
        }
    }

}
