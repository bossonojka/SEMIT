import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.LinkedList;
import java.util.List;

import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.chart.Axis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.collections.FXCollections;

public class RootController {

	@FXML
	private TextField aValue;
	@FXML
	private TextField bValue;
	@FXML
	private TextField fFunc;
	@FXML
	private TextField gFunc;
	@FXML
	private TextField from;
	@FXML
	private TextField to;
	@FXML
	private LineChart<Number, Number> lineChart;

	private final String PATH = "D:/Eclipse/4.1/bin/FGFunc.java";
	private final String BUILD = "build";

	@FXML
	private void onBuild() {
		lineChart.getData().clear();
		if (checkFields().equals(BUILD)) {
			genSource();
			XYChart.Series<Number, Number> series = solve();
			lineChart.getData().add(series);
		} else {
			showError(checkFields());
		}
	}

	private XYChart.Series<Number, Number> solve() {
		double f = Double.parseDouble(aValue.getText());
		double u = Double.parseDouble(bValue.getText());
		Double from1=Double.parseDouble(from.getText());
		Double to1=Double.parseDouble(to.getText());
		XYChart.Series<Number, Number> series = new XYChart.Series<>();
		try {
			if (compile()) {
				MyLoader test = new MyLoader();
				Class<?> fClass = test.loadFG();
				Method fMethod = fClass.getMethod("getFY", double.class);
				Method gMethod = fClass.getMethod("getGY", double.class);

				for (double i = from1; i <= to1; i += 0.1) {
					double fy = (double) fMethod.invoke(null, new Object[] { (f / i) });
					double gy = (double) gMethod.invoke(null, new Object[] { (u / i) });
					double y = fy + gy;
					if (Math.abs(y) > 50 && series.getData().size() > 0) {
						y = (double) series.getData().get(series.getData().size() - 1).getYValue() +5;
					}
					series.getData().add(new Data<>(i, y));
				}
			}else {
				throw new Exception();
			}
		} catch (Exception e) {
			showError("invalid function");
			e.printStackTrace();
		}

		return series;
	}

	private boolean compile() {
		JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
		return compiler.run(null, null, null, PATH) == 0;
	}

	private void genSource() {
		try (PrintWriter out = new PrintWriter(PATH)) {
			out.println("");
			out.println("import java.lang.Math;\n");
			out.println("public class FGFunc {");
			out.println("   public static double getFY(double x) {");
			out.println("        return " + fFunc.getText().toString() + ";");
			out.println("    }");
			out.println("   public static double getGY(double x) {");
			out.println("        return " + gFunc.getText().toString() + ";");
			out.println("    }");
			out.println("}");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private String checkFields() {
		if (aValue.getText().length() == 0 || bValue.getText().length() == 0 || fFunc.getText().length() == 0
				|| gFunc.getText().length() == 0) {
			return "Fill all fields";
		}

		Double i1 = Double.parseDouble(from.getText());
		Double i2 = Double.parseDouble(to.getText());

		return i1 < i2 ? BUILD : "Check interval";
	}

	private void showError(String message) {
		Alert alert = new Alert(AlertType.ERROR);
		alert.titleProperty().set("ERROR");
		alert.setHeaderText(message);
		alert.show();
	}

	@FXML
	private void initialize() {
		setListeners();
		lineChart.setTitle("f(a / x) + g(b/x)");
		lineChart.setCreateSymbols(false);
	}

	private void setListeners() {
		aValue.textProperty().addListener(new FieldListener(aValue));
		bValue.textProperty().addListener(new FieldListener(bValue));
		from.textProperty().addListener(new FieldListener(from));
		to.textProperty().addListener(new FieldListener(to));
		
	}

	@FXML
	private void onClear() {
		aValue.clear();
		bValue.clear();
		fFunc.clear();
		gFunc.clear();
		lineChart.getData().clear();
	}

	private boolean isNumber(String str) {
		if (str == null || str.isEmpty())
			return false;
		if (str.contains(",")) {
			return false;
		}

		int count = 0;

		for (int i = 0; i < str.length(); i++) {
			if (Character.compare(str.charAt(i), '.') == 0) {
				count++;
			}
		}
		if (count > 1) {
			return false;
		}

		for (int i = 0; i < str.length(); i++) {
			if (!Character.isDigit(str.charAt(i)) && !(i == 0 && str.charAt(i) == '-') && str.charAt(i) != '.')
				return false;
		}
		return true;
	}

	class FieldListener implements ChangeListener<String> {
		private TextField field;

		public FieldListener(TextField field) {
			this.field = field;
		}

		@Override
		public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
			if (!isNumber(newValue) || newValue.isEmpty()) {
				field.setText(newValue.length() > 1 ? newValue.substring(0, newValue.length() - 1) : "");
			}
		}
	}

}
