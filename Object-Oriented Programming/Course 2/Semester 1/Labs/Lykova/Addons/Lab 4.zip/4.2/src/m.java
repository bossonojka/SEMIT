import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Scanner;

public class m {
	public static void main(String[] args) {
		try {
			System.out.println("������� ��� ������:");
			String string = new Scanner(System.in).next();
			Class<?> class1 = Class.forName(string);
			System.out.println("\n���� ����� ������:");
			for (Method method : class1.getDeclaredMethods()) {
				System.out.println(method.toString());
			}
			System.out.println("\n");
			for (Field field : class1.getDeclaredFields()) {
				System.out.println(field.toString());
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
