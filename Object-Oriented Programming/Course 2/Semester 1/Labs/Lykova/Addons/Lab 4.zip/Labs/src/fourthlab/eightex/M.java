package fourthlab.eightex;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class M implements Runnable {

	private int value;

	public M(int i) {
		value = i;
	}

	public static void main(String[] args) {
		int i = 0;
		System.out.println("������� �����:");
		while (i <= 0)
			i = new Scanner(System.in).nextInt();
		Thread thread = new Thread(new M(i));
		thread.setDaemon(true);
		thread.start();
		new Scanner(System.in).next();		
		
	}

	@Override
	public void run() {
		String string;

		for (int i = 1;; i++) {
			string = i + "";
			int temp = 0;
			for (int k = 0; k < string.length(); k++) {
				temp += Integer.parseInt(string.charAt(k) + "");
			}
			if (temp == value) {
				System.out.println(string);
				try {
					Thread.sleep(400);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

}
