package fourthlab.fourtex;

import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Numbers {
	public static void main(String[] args) throws InterruptedException {
		BlockingQueue<Integer> integers = new ArrayBlockingQueue<>(10);

		Thread aThread = new Thread(new Adder(integers,5));
		aThread.start();
		Thread thread = new Thread(new Averager(integers,5));
		thread.start();
		Thread.sleep(100);
		aThread.interrupt();
	}
}

class Adder implements Runnable {

	private BlockingQueue<Integer> integers;
	private Random random = new Random();
	int countToTake;

	public Adder(BlockingQueue<Integer> integers,int countToTake) {
		this.integers = integers;
		this.countToTake=countToTake;
	}

	@Override
	public void run() {
		while (true) {
			try {
				for (int i = 1; i <= countToTake; i++) {
				integers.put(random.nextInt(10));
				Thread.sleep(100);}
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

}

class Averager implements Runnable {

	private BlockingQueue<Integer> integers;
	private Random random = new Random();
	int countTo;

	public Averager(BlockingQueue<Integer> integers,int countTo) {
		this.integers = integers;
		this.countTo=countTo;
	}

	@Override
	public void run() {
		try {
			for (int i = 1; i <= countTo; i++) {
			while (true) {
				int count = 0;
				int value = 0;
				String string = "";
				while (integers.size() != 0 || count == 0) {
					int temp = integers.take();
					value += temp;
					string += temp + " + ";
					count++;
					Thread.sleep(10);
				}

				string += " = " + (double) value / (double) count;
				System.out.println(string);

				Thread.sleep(random.nextInt(5) * 100);

			}}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
}