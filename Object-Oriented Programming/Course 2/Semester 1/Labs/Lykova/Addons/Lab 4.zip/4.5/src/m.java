import java.lang.reflect.Method;

public class m {

	public static void main(String[] args) throws Exception {
		System.out.println("��� ������ A: ");
		Class<?> class1 = Class.forName("A");
		Method m1 = class1.getMethod("getStr", String.class, int.class);
		System.out.println(m1.invoke(null, new Object[] { "Nine", 9 }));
		m1 = class1.getDeclaredMethod("isEven", int.class);
		m1.setAccessible(true);
		System.out.println(m1.invoke(class1.newInstance(), new Object[] { 3 }));
		m1 = class1.getMethod("print");
		m1.invoke(class1.newInstance());
	}

}

class A {
	public static String getStr(String s, int i) {
		return s + " is " + i;
	}

	private boolean isEven(int i) {
		return i % 2 == 0 ? true : false;
	}

	public void print() {
		System.out.println("Good job, sir");
	}
}
