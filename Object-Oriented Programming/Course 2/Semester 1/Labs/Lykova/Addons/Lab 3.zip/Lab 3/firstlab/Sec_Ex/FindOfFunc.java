package Sec_Ex;

public interface FindOfFunc {
	double function(double x);

}
