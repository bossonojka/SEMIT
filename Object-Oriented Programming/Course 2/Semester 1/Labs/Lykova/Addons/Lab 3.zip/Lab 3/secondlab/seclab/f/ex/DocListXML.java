package seclab.f.ex;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

public class DocListXML extends DocList{
	private generated.Doc doc;
	public DocListXML() {
	}

	public DocListXML(String name, String spec, List<Recept> list) {
		super(name, spec, list);
	}

	public DocListXML fromXml(String filename) {
		try {
			JAXBContext jaxbContext=JAXBContext.newInstance(generated.Doc.class);
			Unmarshaller unmarshaller=jaxbContext.createUnmarshaller();
			doc =(generated.Doc) unmarshaller.unmarshal(new File("Doctor.xml"));
			
			List<Recept> lis=new ArrayList<>();
			for (generated.Doc.Recept recept : doc.getRecept()) {
				lis.add(new Recept(recept.getDay(),recept.getNumOfVisit(),recept.getShift()));
			}
			
			
			this.setList(lis);
			this.setName(doc.getName());
			this.setSpec(doc.getSpec());
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return null;
	}

	public void toXml(String name) {

		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(generated.Doc.class);
			Marshaller marshaller = jaxbContext.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			
			doc.setName(getName());
			doc.setSpec(getSpec());
			List<generated.Doc.Recept> list=new ArrayList<>();
			for (Recept recept : getList()) {
				list.add(new generated.Doc.Recept(recept.getNumOfVisit(),recept.getDay(),recept.getShift()));
			}
			
			marshaller.marshal(doc, new FileWriter(name));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
