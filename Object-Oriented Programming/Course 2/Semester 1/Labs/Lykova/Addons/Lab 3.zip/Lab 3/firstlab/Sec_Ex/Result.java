package Sec_Ex;

import java.util.Scanner;

public class Result {
	public static void main(String[] args) {
		System.out.print("Enter the start of interval: ");String st=new Scanner(System.in).nextLine();
		if(st.matches("\\D")){
			do{
			System.out.println("Not correct value. Try again: ");st=new Scanner(System.in).nextLine();}while(st.matches("\\D"));
		}
		double st1 = Double.parseDouble(st);
		System.out.print("Enter the end of interval: ");String en=new Scanner(System.in).nextLine();
		if(en.matches("\\D")){
			do{
			System.out.println("Not correct value. Try again: ");en=new Scanner(System.in).nextLine();}while(en.matches("\\D"));
		}
		double en1 = Double.parseDouble(en);
		System.out.print("Enter the step: ");String step=new Scanner(System.in).nextLine();
		if(step.matches("\\D")){
			do{
			System.out.println("Not correct value. Try again: ");step=new Scanner(System.in).nextLine();}while(step.matches("\\D"));
		}
		double step1 = Double.parseDouble(step);
		if(en1<st1){
			System.out.println("The start of interval under the end, they'll be swapped");
			double temp = st1;
		    st1 = en1;
		    en1 = temp;
		}
		if(st==en){
			System.out.println("It's no interval here,because start and end are same. There will be just a solution of equation.");
			
		}
		if(step1==0){
			do{
				System.out.println("Ridiculous!");
				System.out.print("Enter the step of interval again: ");step1=new Scanner(System.in).nextDouble();
			}while(step1<=0);
		}
		 System.out.println("The minimum of our function on this interval is: "+minOfFunc.solve(st1, en1, step1, new F()));
		 System.out.println("The minimum of our function on this interval is: "+interFunc.solve(st1, en1, step1, x -> x*x*x - 2*x + 15));
	}

}
