package Four_ex;
import java.util.*;
public class Myarray<T> {
	private Object[] arr;
	public Myarray(T[] arr)
	{
		this.arr = arr;
	}
	
	public  <T> void PomenyatSosednie(T[] arr) {
		if (arr.length % 2 == 0)
			for (int i = 0; i < arr.length; i += 2) {
				T elem = arr[i];
				arr[i] = arr[i + 1];
				arr[i + 1] = elem;
			}
		else
			for (int i = 0; i < arr.length - 1; i += 2) {
				T elem = arr[i];
				arr[i] = arr[i + 1];
				arr[i + 1] = elem;
			}
		
	}
	public void My_swap(int index)
	{
		Object[] temp = new Object[arr.length];
		for (int i=index-1, j=arr.length-1; i>=0; i--, j--)
			temp[j] = arr[i];
		for (int i=index, j=0; i<arr.length; i++, j++)
			temp[j] = arr[i];
		arr = temp;
	}
	public void print()
	{
		for (int i=0; i<arr.length; i++)
			System.out.print(arr[i] + "  ");
	}
	public  <T> void swap( int i,int j) {
		
		Object t = arr[i];
		arr[i] = arr[j];
		arr[j] = t;
	}
	public  void ArrToArr(T[] first, T[] second) {
		Object[] res = new Object[first.length + second.length];

		System.arraycopy(first, 0, res, 0, first.length);
		System.arraycopy(second, 0, res, first.length, second.length);
		System.out.println(Arrays.toString(res));
	}
}
