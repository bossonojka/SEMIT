package thirdlab.f_ex;

import java.awt.Checkbox;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.FileChooser;
import javafx.util.converter.IntegerStringConverter;
import seclab.f.ex.DocListXML;
import seclab.f.ex.Recept;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;

public class ReceptionsController {
	
	 @FXML TextField TextFieldDoctor;
	 @FXML TextField TextFieldSpec;
	 @FXML TextField TextFieldSearch;
	 @FXML TextArea TextAreaResults;@FXML TextArea textAreaAll;
	 @FXML CheckBox CheckBoxch;
	 @FXML TableView<Recept> tableViewReceptions;
	 @FXML TableColumn<Recept, Integer> TableColumnVisitors;
	 @FXML TableColumn<Recept, String> TableColumnShift;
	 @FXML TableColumn<Recept, String> TableColumnDate;
	 
	 private DocListXML doctor = new DocListXML();	 
	 private ObservableList<Recept> observableList;
	 
	 @FXML
		public void initialize() {
			tableViewReceptions.setPlaceholder(new Label(""));
		}
	 
	 @FXML
		public void doNew(ActionEvent event) {
			doctor = new DocListXML();
			observableList = null;
			TextFieldDoctor.setText("");
			TextFieldSpec.setText("");
			TextFieldSearch.setText("");
			TextAreaResults.setText("");
			tableViewReceptions.setItems(null);
			tableViewReceptions.setPlaceholder(new Label(""));
		}

		@FXML
		public void doOpen(ActionEvent event) {
			FileChooser fileChooser = getFileChooser("������� XML-����");
			File file;
			try {
				if ((file = fileChooser.showOpenDialog(null)) != null) {
					doctor.fromXml(file.getCanonicalPath());
					TextFieldDoctor.setText(doctor.getName());
					TextFieldSpec.setText(doctor.getSpec());
					TextAreaResults.setText("");
					tableViewReceptions.setItems(null);
					updateTable();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		@FXML
		public void doSave(ActionEvent event) {
			FileChooser fileChooser = getFileChooser("��������� XML-����");
			File file;
			if ((file = fileChooser.showSaveDialog(null)) != null) {
				try {
					updateSourceData();
					doctor.toXml(file.getCanonicalPath());
					showMessage("���������� ������� ���������");
				}
				catch (Exception e) {
					showError("������ ������ � ����");
				}

			}
		}

		@FXML
		public void doExit(ActionEvent event) {
			Platform.exit();
		}

		@FXML
		public void doAdd(ActionEvent event) {
			if (observableList == null) {
				updateTable();
			}
			observableList.add(new Recept(null,0, null));
		}

		@FXML
		public void doRemove(ActionEvent event) {
			if (observableList == null) {
				return;
			}
			if (observableList.size() > 0) {
				observableList.remove(observableList.size() - 1);
			}
			if (observableList.size() <= 0) {
				observableList = null;
			}
		}

		@FXML
		public void doSortByDay(ActionEvent event) {
			updateSourceData();
			doctor.sortByDay();
			updateTable();
		}

		@FXML
		public void doSortByVisitors(ActionEvent event) {
			updateSourceData();
			doctor.sortByVisitors();
			updateTable();
		}

		@FXML
		public void doAbout(ActionEvent event) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("��� ��������");
			alert.setHeaderText("������ 1.0");
			alert.showAndWait();
		}

		@FXML
		public void nameChanged(ActionEvent event) {
			doctor.setName(TextFieldDoctor.getText());
		}

		@FXML
		public void specChanged(ActionEvent event) {
			doctor.setSpec(TextFieldSpec.getText());
		}

		@FXML
		public void doSearchByWord(ActionEvent event) {

			updateSourceData();
			TextAreaResults.clear();
			showResults(doctor.minOfVisitors());
		}
		
		@FXML
		public void doSearchByAll(ActionEvent event) {

			updateSourceData();
			textAreaAll.clear();
			if(CheckBoxch.isSelected()) {
			showResult();}
		}

		@FXML
		public void doSearchBySubstring(ActionEvent event) {

			updateSourceData();
			TextAreaResults.clear();
			for (int i = 0; i < doctor.getList().size(); i++) {
				Recept h = doctor.getList().get(i);
				if (h.getShift().contains(TextFieldSearch.getText())||h.getDay().contains(TextFieldSearch.getText())||Integer.toString(h.getNumOfVisit()).contains(TextFieldSearch.getText())) {
					showResults(h);
				}
			}

		}

		private void showResults(Recept recep) {
			TextAreaResults.appendText("����: " + recep.getDay() + "\n");
			TextAreaResults.appendText("���-�� ����������� :" + recep.getNumOfVisit() + "\n");
			TextAreaResults.appendText("����� :" + recep.getShift() + "\n");
			TextAreaResults.appendText("\n");
		}
		
		private void showResult() {
			textAreaAll.appendText(""+doctor.sumOfVisitors());
		}
		
		private void updateSourceData() {
			doctor.getList().clear();
			for (Recept h : observableList) {
				doctor.getList().add(h);
			}
		}

		private void updateVisitors(CellEditEvent<Recept, Integer> t) {

			Recept h = (Recept) t.getTableView().getItems().get(t.getTablePosition().getRow());
			h.setNumOfVisit(t.getNewValue());

		}

		private void updateShift(CellEditEvent<Recept, String> t) {

			Recept h = (Recept) t.getTableView().getItems().get(t.getTablePosition().getRow());
			h.setShift(t.getNewValue());

		}

		private void updateTable() {
			List<seclab.f.ex.Recept> sList = new ArrayList<>();
			observableList = FXCollections.observableList(sList);
			for (Recept rec : doctor.getList()) {
				sList.add(rec);
			}

			tableViewReceptions.setItems(observableList);
			TableColumnVisitors.setCellValueFactory(new PropertyValueFactory<>("numOfVisit"));
			TableColumnVisitors
					.setCellFactory(TextFieldTableCell.<Recept, Integer>forTableColumn(new IntegerStringConverter()));
			TableColumnVisitors.setOnEditCommit(t -> updateVisitors(t));
			TableColumnDate.setCellValueFactory(new PropertyValueFactory<>("day"));
			TableColumnDate.setCellFactory(TextFieldTableCell.forTableColumn());
			TableColumnDate.setOnEditCommit(t -> updateSourceData());
			TableColumnShift.setCellValueFactory(new PropertyValueFactory<>("shift"));
			TableColumnShift.setCellFactory(TextFieldTableCell.forTableColumn());
			TableColumnShift.setOnEditCommit(t -> updateShift(t));

		}

		public static void showMessage(String message) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("");
			alert.setHeaderText(message);
			alert.showAndWait();
		}

		public static void showError(String message) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("������");
			alert.setHeaderText(message);
			alert.showAndWait();
		}

		public static FileChooser getFileChooser(String title) {
			FileChooser fileChooser = new FileChooser();
			fileChooser.setInitialDirectory(new File("."));
			fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("XML-����� (*.xml)", "*.xml"));
			fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("��� ����� (*.*)", "*.*"));
			fileChooser.setTitle(title);
			return fileChooser;
		}

		private boolean isNumber(String str) {
			if (str == null || str.isEmpty())
				return false;

			for (int i = 0; i < str.length(); i++) {
				if (!Character.isDigit(str.charAt(i)))
					return false;
			}
			return true;
		}
}
