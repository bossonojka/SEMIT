package firstlab;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RealizationByList extends Doctor {
	List<Reception> b = new ArrayList<>();
	@Override
	public Reception getReception(int i) {
		return b.get(i);
	}

	@Override
	public void setReception(int i, Reception recep) {
		b.set(i, recep);
	}

	@Override
	public int recepCount() {
		return b.size();
	}

	@Override
	public void addReception(Reception recep) {
		b.add(recep);
	}

	@Override
	public void sortByDay() {
		Collections.sort(b, (a, b) -> a.getDay().compareTo(b.getDay()));
	}

	@Override
	public void sortByVisit() {
		Collections.sort(b, (b, a) -> Integer.compare(a.getNumOfVisit(), b.getNumOfVisit()));
	}

	public static void main(String[] args) {
		new RealizationByList().testing();
	}

	@Override
	public void clearRecep() {
		// TODO Auto-generated method stub
		
	}

}
