package firstlab;

public abstract class Doctor {
	private String name;
	private String spec;
	
	abstract public Reception getReception(int i);
	abstract public void setReception(int i,Reception recep);
	abstract public int recepCount();
	abstract public void addReception(Reception recep);
	abstract public void clearRecep();
	abstract public void sortByDay();
	abstract public void sortByVisit();
	
	public Doctor() {
		this.name = name;
		this.spec = spec;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;}

	public String getSpec() {
		return spec;
	}

	public void setSpec(String spec) {
		this.spec = spec;
	}

	public int allVisitors(){
		int s=0;
		for(int i=0;i<recepCount();i++){
			s+=getReception(i).getNumOfVisit();
		}
		return s;
	}
    public int minVisitors() {
        Reception recep=getReception(0);
        for (int i = 1; i < recepCount(); i++) {
            if (recep.getNumOfVisit() > getReception(i).getNumOfVisit()) {
                recep = getReception(i);
            }
        }
        
       return recep.getNumOfVisit();
    }
      
    public void showData(String title) {
		System.out.println(title);
		System.out.println(" Name : " + getName() + ", Spec : " + getSpec());
		for (int i = 0; i < recepCount(); i++) {
			System.out.println(" Visitors : " + getReception(i).getNumOfVisit() + ", Day : "
					+ getReception(i).getDay() + ", Shift : " + getReception(i).getShift());
		}
		System.out.println();
	}
    public void testing() {
		setName("Alex Prego");
		setSpec("Family doctor");
		addReception(new Reception(15, "12.10.17", "Morning"));
		addReception(new Reception(20, "23.10.17", "Night"));
		addReception(new Reception(13, "16.10.17", "Afternoon"));
		showData("Entered data: ");
		// System.out.println("");
		sortByDay();
		showData("Sort by days: ");
		// System.out.println("");
		sortByVisit();
		showData("Sort by visitors: ");
		System.out.println("Min number of visitors per shifts : " + minVisitors());
		System.out.println("All visitors" + " " + allVisitors());

	}
	/*public static void main(String[] args) {
		Doctor [] doctor={new Doctor("Ivanoff","Family doctor",new Reception[]{
				new Reception(29,"30.03.17","Morning"),
				new Reception(15,"31.03.17","Afternoon"),
				new Reception(21,"01.04.17","Morning")}),
		 new Doctor("Kromp","terepevte",new Reception[]{
					new Reception(30,"30.03.17","Morning"),
					new Reception(12,"31.03.17","Afternoon"),
					new Reception(21,"01.04.17","Morning")}) };
		Integer s=0;
		for(Doctor d : doctor ){
		s+=d.allVisitors();
		}
		if (doctor[0].minVisitors()<doctor[1].minVisitors()) {
			System.out.println("The minimum of all visitors from two doctors: "+doctor[0].minVisitors()+"\nThe lenght of last name of this doctor is: "+doctor[0].SurnameLength());
					}
		else{
			System.out.println("The minimum of all visitors from two doctors: "+doctor[1].minVisitors()+"\nThe lenght of last name of this doctor is: "+doctor[1].SurnameLength());
		}
	System.out.println("All visitors: "+s+"\n");	
	}*/


}
