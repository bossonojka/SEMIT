package thirdlab.sec_ex;

public class Test {
	public static void main(String[] args) {
		Month f=Month.APRIL.previous();
		System.out.println("Previous month for April:");
		System.out.println(f);
		System.out.println();
		System.out.println("Next month for April: ");
		f=Month.APRIL.next();
		System.out.println(f);
		System.out.println();
		Month.printAll();
    }
}
