package seclab.f.ex;

public class Test {
	public static void main(String[] Args) {

		DocArrTXT sArr = new DocArrTXT();
		sArr = sArr.fromTxt();
		sArr.sortByDay();
		sArr.toTxt("sortbyDay.txt");
		sArr.sortByVisitors();
		sArr.toTxt("sortbyVisitors.txt");

		DocListXML list = new DocListXML();
		list.fromXml("Doctor.xml");
		System.out.println(list);
		list.sortByDay();
		list.toXml("sortbyDay.xml");
		list.sortByVisitors();
		list.toXml("sortbyVisitors.xml");
	}
}
