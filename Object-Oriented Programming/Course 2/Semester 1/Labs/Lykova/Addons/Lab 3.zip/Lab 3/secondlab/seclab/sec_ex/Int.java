package seclab.sec_ex;

import static java.lang.Math.abs;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class Int {
	public static Comparator<Integer> comareByAbsValues() {
        class LocalComparator implements Comparator<Integer> {
            @Override
            public int compare(Integer d1, Integer d2) {
                return -Integer.compare(abs(d1), abs(d2));
            }
        }
        return new LocalComparator();
    }
	public static Comparator<Integer> comareByNorValues() {
        class LocalComparator implements Comparator<Integer> {
            @Override
            public int compare(Integer d1, Integer d2) {
                return Integer.compare(abs(d1), abs(d2));
            }
        }
        return new LocalComparator();
    }
	
	void readWrite() {
       try (BufferedReader reader = new BufferedReader(new FileReader("in.txt"))) {
            	String line;ArrayList<Integer> numbers = new ArrayList<>();Integer[] arr = {};
            	while ((line = reader.readLine()) != null){
            		@SuppressWarnings("resource")
					Scanner scanner = new Scanner(line);
            		while (scanner.hasNextInt()){ 
            			numbers.add(scanner.nextInt());
            			}
            		int i=numbers.size()-1;
            		while(i>=0){
            		    if(numbers.get(i)<0){
            		       numbers.remove(i);
            		    }
            		    i--;
            		}
            		}
            		arr = numbers.toArray(new Integer[numbers.size()]);
            		PrintWriter firstWriter = new PrintWriter(new FileWriter("out1.txt"));
            	    PrintWriter secondWriter = new PrintWriter(new FileWriter("out2.txt"));
            	        try {
            	            Arrays.sort(arr,comareByNorValues());
            	            for (int x : arr)
            	                firstWriter.print(x + " ");
            	            Arrays.sort(arr, comareByAbsValues());
            	            for (int x : arr)
            	                secondWriter.print(x + " ");
            	        }
            	        finally {
            	            firstWriter.close();
            	            secondWriter.close();}
    	            }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Int().readWrite();
    }

}    
