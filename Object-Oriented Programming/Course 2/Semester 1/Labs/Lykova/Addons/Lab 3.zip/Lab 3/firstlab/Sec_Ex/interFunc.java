package Sec_Ex;

public interface interFunc {
	double f(double x);
	
	static double solve(double a, double b,  double step, FindOfFunc func) {
		double  x = 0;
		double temp = 0;
		 for( ; a<=b;a+=step){
			 temp = func.function(a);
		  x = temp;
		 if (temp<x)x=temp;
		}
	       return x;
	}
}
