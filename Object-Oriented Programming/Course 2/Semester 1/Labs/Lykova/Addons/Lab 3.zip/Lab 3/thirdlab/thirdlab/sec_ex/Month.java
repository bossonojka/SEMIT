package thirdlab.sec_ex;

enum Month {
	JANUARY(31),
	FEBRUARY(28),
	MARCH(31),
	APRIL(30),
	MAY(31),
	JUNE(30),
	JULY(31),
	AUGUST(31),
	SEPTEMBER(30),
	OCTOBER(31),
	NOVEMBER(30),
	DECEMBER(31);
	
	private int daysCount;
	
	private Month(int daysCount){
		this.daysCount=daysCount;
	}
	
	double getMonth() {
        return daysCount;
    }

    @Override
    public String toString() {
        return "Month: "+name()+"\nDays in month: " + daysCount;
    }
    
    Month next() {
    	Month month = values()[(ordinal() + 1) % values().length];
        return month;
    }
    
    Month previous() {
    	Month month = values()[(ordinal()-1) % values().length];
        return month;
    }
    
    public String toStr() {
        switch (this) {
            case JANUARY:
                return "Январь"+"\nДней в месяце: " + daysCount;
            case FEBRUARY:
                return "Февраль"+"\nДней в месяце: " + daysCount;
            case MARCH:
                return "Март"+"\nДней в месяце: " + daysCount;
            case APRIL:
                return "Апрель"+"\nДней в месяце: " + daysCount;
            case MAY:
                return "Май"+"\nДней в месяце: " + daysCount;
            case JUNE:
                return "Июнь"+"\nДней в месяце: " + daysCount; 
            case JULY:
                return "Июль"+"\nДней в месяце: " + daysCount;
            case AUGUST:
                return "Август"+"\nДней в месяце: " + daysCount;
            case SEPTEMBER:
                return "Сентябрь"+"\nДней в месяце: " + daysCount;
            case OCTOBER:
                return "Октябрь"+"\nДней в месяце: " + daysCount;
            case NOVEMBER:
                return "Ноябрь"+"\nДней в месяце: " + daysCount;
            case DECEMBER:
                return "Декабрь"+"\nДней в месяце: " + daysCount;
        }
        return "Месяцы закончились!";
    }
    @SuppressWarnings("incomplete-switch")
	String Season(){
    	String s="";
    	switch (this) {
        case DECEMBER:
        case JANUARY:
        case FEBRUARY:
            return s="Winter";}
    	switch(this){
    	case MARCH:
    	case MAY:
    	case APRIL:
    		return s="Spring";
    	}
    	switch(this){
    	case JUNE:
    	case JULY:
    	case AUGUST:
    		return s="Summer";
    	}
    	switch(this){
    	case SEPTEMBER:
    	case NOVEMBER:
    	case OCTOBER:
    		return s="Autumn";
    	}
    	return s;
    }
    @SuppressWarnings("incomplete-switch")
	String SeasonRus(){
    	String s="";
    	switch (this) {
        case DECEMBER:
        case JANUARY:
        case FEBRUARY:
            return s="Зима";}
    	switch(this){
    	case MARCH:
    	case MAY:
    	case APRIL:
    		return s="Весна";
    	}
    	switch(this){
    	case JUNE:
    	case JULY:
    	case AUGUST:
    		return s="Лето";
    	}
    	switch(this){
    	case SEPTEMBER:
    	case NOVEMBER:
    	case OCTOBER:
    		return s="Осень";
    	}
    	return s;
    }
    
    static void printAll() {
        for (Month d : values()) {
          System.out.println("--English--\n"+d + "\nSeason: "+d.Season());
          System.out.println("--Russian--\nМесяц: "+d.toStr()+ "\nСезон: "+d.SeasonRus());
          System.out.println();
        }
    }
}
