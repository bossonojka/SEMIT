package firstlab;

import java.util.Arrays;

public class Circle implements Comparable<Circle> {
	double rad;

	Circle(double rad) {
		this.rad = rad;
	}

	public int compareTo(Circle r) {

		if (rad == r.rad)
			return 0;
		else if (rad > r.rad)
			return 1;
		else
			return -1;
	}

	public double getRad() {
		return rad;
	}

	public void setRad(double rad) {
		this.rad = rad;
	}

	@Override
	public String toString() {
		String s = "" + getRad();
		return s;
	}


}
