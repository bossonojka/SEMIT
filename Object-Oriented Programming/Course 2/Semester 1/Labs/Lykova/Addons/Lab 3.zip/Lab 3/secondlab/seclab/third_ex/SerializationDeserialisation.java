package seclab.third_ex;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;

public class SerializationDeserialisation {
	public static void main(String[] args) {
		Student[] students = { new Student("Rita","Lykova",18), new Student("Kolya","Garbozyuk",19), new Student("Maks","Kozachenko",18) };
		Group group = new Group(students,"KN-36b");
		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("temp.dat"))) {
			out.writeObject(group);
		} catch (IOException e) {
			e.printStackTrace();
		}
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("temp.dat"))) {
			Group group2 = (Group) in.readObject();
			System.out.println(Arrays.asList(group2.students));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try (XMLEncoder xmlEncoder = new XMLEncoder(new FileOutputStream("group.xml"))) {
            xmlEncoder.writeObject(group);
            xmlEncoder.flush();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
		
		try (XMLDecoder xmlDecoder = new XMLDecoder(new FileInputStream("group.xml"))) {
            Group group2 = (Group)xmlDecoder.readObject();
            System.out.println(Arrays.asList(group2.students));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
		
		
	}
}
