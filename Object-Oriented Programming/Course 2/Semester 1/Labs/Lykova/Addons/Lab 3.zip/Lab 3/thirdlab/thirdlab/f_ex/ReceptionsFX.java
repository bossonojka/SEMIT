package thirdlab.f_ex;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class ReceptionsFX extends Application{	
	private BorderPane recep;

	public void start(Stage primaryStage) {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(ReceptionsFX.class.getResource("Recep.fxml"));
			recep = (BorderPane) loader.load();
			Scene scene = new Scene(recep);
            scene.setRoot(recep);
			primaryStage.setScene(scene);
			primaryStage.setTitle("���������� � �������");
			//primaryStage.getIcons().add(new Image("file:resources/images//3semestr/resouces/image/if_christmas-icon-candy-cane_820695.png"));
			primaryStage.show();
        } 
        catch(Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
