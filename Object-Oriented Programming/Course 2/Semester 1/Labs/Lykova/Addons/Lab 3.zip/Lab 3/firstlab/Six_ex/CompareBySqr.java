package Six_ex;

import java.util.Comparator;

public class CompareBySqr implements Comparator<Triangle> {
	public int compare(Triangle s1, Triangle s2) {
		 return Double.compare(s1.squareT(), s2.squareT()); 
	}

}
