package firstlab;

import java.util.Arrays;

public class RealizByArr extends Doctor {
	Reception []h = null;
	@Override
	public Reception getReception(int i) {
		return h[i];
	}

	@Override
	public void setReception(int i, Reception recep) {
		h[i] = recep;

	}

	@Override
	public int recepCount() {
		return h == null ? 0 : h.length;
	}

	@Override
	public void addReception(Reception recep) {
		Reception[] temp = new Reception[recepCount() + 1];
        if (h != null)
            System.arraycopy(h, 0, temp, 0, h.length);
        temp[recepCount()] = recep ;
        h = temp;


	}

	@Override
	public void sortByDay() {
		Arrays.sort(h, (a, b) -> a.getDay().compareTo(b.getDay()));

	}

	@Override
	public void sortByVisit() {
		 Arrays.sort(h, (a, b) -> Integer.compare(a.getNumOfVisit(), b.getNumOfVisit()));
		 }
	public static void main(String[] args) {
		new RealizByArr().testing();
	}

	@Override
	public void clearRecep() {
		// TODO Auto-generated method stub
		
	}

}
