package seclab.third_ex;

import java.io.Serializable;

public class Student implements Serializable {

	private static final long serialVersionUID = -8744549235976038849L;
	public String name;
	public String lastname;
	public int yearsold;

	public Student(String name,String lastname,int yearsold) {
		this.name = name;
		this.lastname=lastname;
		this.yearsold=yearsold;
	}

	public Student() {
		
	}
	
	@Override
	public String toString() {
		String s=name+" "+lastname+" "+yearsold;
		return s;
	}
}

