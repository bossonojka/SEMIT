package Sec_Ex;

public class F implements FindOfFunc{
	public double function(double x) {
		 return x*x*x - 2*x + 15 ; }
}
