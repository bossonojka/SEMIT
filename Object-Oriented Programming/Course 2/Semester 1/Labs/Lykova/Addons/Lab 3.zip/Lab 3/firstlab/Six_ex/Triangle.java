package Six_ex;

import java.util.*;

public class Triangle {
	private double a;
	private double b;
	private double c;
	public double getA() {
	      return a;
	}
	public double getB() {
	      return b;
	}
	public double getC(){
		return c;
	}
	public void setA(double a) {
		this.a = a;
	}
	public void setB(double b) {
		this.b = b;
	}
	public void setC(double c) {
		this.c = c;
	}
	public Triangle(double a, double b, double c) {
		super();
		this.a = a;
		this.b = b;
		this.c = c;
	}
	public double squareT() {
        double s = 0.25*Math.sqrt((a+b+c)*(a+b-c)*(a+c-b)*(b+c-a));
        return s;
    }
	@Override 
    public String toString() { 
       String s=""+(0.25)*Math.sqrt(( getA()+getB()+getC())*( getB()+getC()-getA())*(getA()+getC()-getB())*( getA()+getB()-getC()));
       return s;
    }
	 public static void main(String args[]) {
		 ArrayList<Triangle> list = new ArrayList<Triangle>();

		  list.add(new Triangle(20, 15, 25));
		  list.add(new Triangle(6, 8, 10));
	      list.add(new Triangle(15, 9, 12));
	      
	      Collections.sort(list, new CompareBySqr());
	      System.out.println("��������������� ������� �������������: ");
	      for(Triangle lists:list){
	    	  System.out.println(lists+" ");
	      }
	        
	 }

}
