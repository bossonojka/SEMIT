package seclab.f.ex;

import java.util.Arrays;

public class DocArr extends Doc {
	private Recept[] recepts;

	public DocArr() {
		// TODO Auto-generated constructor stub
	}

	public DocArr(String name,String spec, Recept[] recepts) {
		super(name, spec);
		this.recepts = recepts;
	}

	public void setRecepts(Recept[] recepts) {
		this.recepts = recepts;
	}

	public Recept[] getRecepts() {
		return recepts;
	}

	@Override
	public Recept minOfVisitors() {
		Recept min = recepts[0];
		for (Recept h : recepts) {
			if (h.getNumOfVisit() < min.getNumOfVisit())
				min = h;
		}
		return min;
	}

	@Override
	public int sumOfVisitors() {
		int sum = 0;
		for (Recept rec : recepts) {
			sum += rec.getNumOfVisit();
		}
		return sum;
	}

	@Override
	public void sortByVisitors() {
		Arrays.sort(recepts, (a, b) -> Integer.compare(a.getNumOfVisit(), b.getNumOfVisit()));
	}

	@Override
	public void sortByDay() {
		Arrays.sort(recepts, (a, b) -> a.getDay().compareTo(b.getDay()));
	}

	@Override
	public String toString() {
		return "Doctor " + getName() + " " + getSpec() + "\n" + Arrays.asList(recepts);
	}

	@Override
	public int receptCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Recept getRecept(int i) {
		return recepts[i];
	}

	@Override
	public void addRecept(Recept recept) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void clearRecept() {
		// TODO Auto-generated method stub
		
	}
}
