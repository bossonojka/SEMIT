package Sec_Ex;
import java.util.*;
public class minOfFunc {
	
	static double solve(double a, double b,  double step, FindOfFunc func) {
		double  x = 0;
		double temp = 0;
		 for( ; a<=b;a+=step){
			 x = func.function(a);
		  temp = x;
		 if (x<temp)temp=x;
		}
	       return temp;
	       		
	}

}
