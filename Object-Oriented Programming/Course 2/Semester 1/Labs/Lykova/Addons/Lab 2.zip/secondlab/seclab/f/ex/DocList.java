package seclab.f.ex;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class DocList extends Doc{
	private List<Recept> list;

	public DocList() {
	}


	public DocList(String name, String spec, List<Recept> list) {
		super(name, spec);
		this.list = list;
	}

	public List<Recept> getList() {
		return list;
	}

	public void setList(List<Recept> list) {
		this.list = list;
	}


	@Override
	public Recept minOfVisitors() {
		Recept h = list.get(0);
		for (Recept spec : list) {
			if (h.getNumOfVisit() > spec.getNumOfVisit())
				h = spec;
		}
		return h;
	}

	@Override
	public int sumOfVisitors() {
		int sum = 0;
		for (Recept spec : list) {
			sum += spec.getNumOfVisit();
		}
		return sum;
	}

	@Override
	public void sortByVisitors() {
		Collections.sort(list, (a, b) -> Integer.compare(a.getNumOfVisit(), b.getNumOfVisit()));
	}

	@Override
	public void sortByDay() {
		Collections.sort(list, (a, b) -> b.getDay().compareTo(a.getDay()));
	}

	@Override
	public String toString() {
		return "Doctor " + getName() + " " + getSpec() + "\n" + Arrays.asList(list.toArray());
	}

	@Override
	public int receptCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Recept getRecept(int i) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addRecept(Recept recept) {
		
	}

	@Override
	public void clearRecept() {
		
	}

}
