package seclab.third_ex;

import java.io.Serializable;

public class Group implements Serializable {

	private static final long serialVersionUID = -5942871511728120386L;
	public Student[] students;
	public String groupName;
	
	public Group() {
		// TODO Auto-generated constructor stub
	}

	public Group(Student[] students,String groupName) {
		this.students = students;
		this.groupName=groupName;
	}
}
