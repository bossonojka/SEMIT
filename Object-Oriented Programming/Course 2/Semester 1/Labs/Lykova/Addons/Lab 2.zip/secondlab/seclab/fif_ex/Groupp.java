package seclab.fif_ex;

import java.util.Arrays;

public class Groupp {
	public StudentInf[] students;
	
	public Groupp(StudentInf[] students) {
		super();
		this.students = students;
	}
	public StudentInf[] getStudents() {
		return students;
	}
	public void setStudents(StudentInf[] students) {
		this.students = students;
	}
	@Override
	public String toString() {
		return "Group members:\n" + Arrays.toString(students);
	
	}
}
