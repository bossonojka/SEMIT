package Lab3_1;

import java.util.*;
public class Trips implements Comparable<Trips> {
private int year, amountOfconserts;
private String town;
Scanner s =new Scanner(System.in);
 /*Trips() {
	System.out.println("enter year of the trip\n");
	year=s.nextInt();
	System.out.println("enter amount of conserts\n");
	amountOfconserts=s.nextInt();
	System.out.println("enter town\n");
	town=s.next();
}*/
 Trips(){}
 Trips(Trips a){
	this. year=a.year;
	this.town=a.town;
	this.amountOfconserts=a.amountOfconserts; 
 }

public Trips(int i, int j, String string) {
	this. year=i;
	this.town=string;
	this.amountOfconserts=j; 
}
public int getAmountOfconserts() {
	return amountOfconserts;
}
public String getTown() {
	return town;
}
public int getYear() {
	return year;
}
@Override
public int compareTo(Trips arg0) {
	return Integer.compare(amountOfconserts,arg0.getAmountOfconserts());
}
public void setYear(int year) {
	this.year = year;
}
public void setAmountOfconserts(int amountOfconserts) {
	this.amountOfconserts = amountOfconserts;
}
public void setTown(String town) {
	this.town = town;
}
@Override
public boolean equals(Object obj) {
	 if (this == obj) {
         return true;
     }
     if (obj == null || !(obj instanceof Trips)) {
         return false;
     }
     Trips c = (Trips) obj;
     return c.getYear() == getYear() && 
            c.getAmountOfconserts() == getAmountOfconserts() && 
            c.getTown().equals(getTown());
}
@Override
public String toString() {
    return "[year= " + getYear() + ",   amount of conserts=" + getAmountOfconserts() + 
           ",   town=" + getTown()+"]";
}

}
