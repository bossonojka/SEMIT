import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;

public class Lists extends AbstractWrite {
		public List array;
	
}
