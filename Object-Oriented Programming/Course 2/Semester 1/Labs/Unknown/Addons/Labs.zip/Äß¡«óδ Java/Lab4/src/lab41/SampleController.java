package lab41;

import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.canvas.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.paint.*;

import java.net.URL;
import java.util.ResourceBundle;

public class SampleController implements Initializable{
	@FXML TextField TextA, TextB, TextBeg, TextEnd;
	@FXML Slider Scale;
	@FXML ScrollBar LineWidth;
	@FXML ColorPicker LineColor;
	@FXML Canvas canvas;
	double x0, y0;
	GraphicsContext gc;
	
	public void initialize(URL arg0, ResourceBundle arg1) {
		LineColor.setValue(Color.BLACK);
		x0=canvas.getHeight()/2;
		y0=canvas.getWidth()/2;
		gc = canvas.getGraphicsContext2D();
		DrawCoordGrid();
	}
	private void DrawCoordGrid()
	{
		gc.setFill(Color.BLACK);
		gc.setStroke(Color.BLACK);
		gc.setLineWidth(2);
		gc.strokeLine(y0, 0, y0, canvas.getHeight());
		gc.strokeLine(0, x0, canvas.getWidth(), x0);
		gc.setLineWidth(1);
		double scale = Scale.getValue()/2, x, y;
		for(int i = -20; i < 20; i++)
		{
			x = y0 + i * scale;
			y = x0 + i * scale;
			if(i != 0)
			{
				for(double yj=0; yj < canvas.getHeight(); yj+=10)
					gc.strokeLine(x, yj, x, yj+5);
				for(double xj=0; xj < canvas.getWidth(); xj+=10)
					gc.strokeLine(xj, y, xj+5, y);
			}
			gc.fillText(""+i, x - 10, x0 + 10);
			gc.fillText(""+(-i), y0 - 10, y + 10);
		}
		gc.fillText("x", canvas.getWidth() - 10, x0 - 10);
		gc.fillText("y", y0 + 10, 0 + 10);
	}
	@FXML public void OnDraw(ActionEvent action)
	{
		try {
			Double a,b,beg,end;
			a = Double.parseDouble(TextA.getText());
			b = Double.parseDouble(TextB.getText());
			beg = Double.parseDouble(TextBeg.getText());
			end = Double.parseDouble(TextEnd.getText());
			if(end<=beg)
				throw new MyException("Invalid Interaval!","End of the interval <= beginning.");
			
			
			gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
			DrawCoordGrid();
			gc.setFill(LineColor.getValue());
			double h=0.001, xi, yi, x, y, scale, line;
			scale = Scale.getValue()/2;
			line = LineWidth.getValue();
			for(xi = beg; xi<=end+h;xi+=h)
			{
				if((a*Math.cos(xi) + b) == xi)
					continue;
				yi = (a*Math.sin(xi) + b*xi);
				y = x0 - yi * scale;
				x = y0 + xi * scale;
				gc.fillOval(x - line, y - line, line, line);
			}
		}
		catch(MyException ex)
		{
			Alert alert = new Alert(AlertType.ERROR);
	        alert.setTitle("Error");
	        alert.setHeaderText(ex.getHeaderTxt());
	        alert.setContentText(ex.getContentTxt());
	        alert.showAndWait();
		}
		catch(NumberFormatException e1) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Incorrect data!");
            alert.showAndWait();
		}
	}
}

/**
 *
 */
@SuppressWarnings("serial")
class MyException extends Exception{
	private String headerTxt,contentTxt;
	public MyException(String headerTxt,String contentTxt) {
		this.headerTxt = headerTxt;
		this.contentTxt = contentTxt;
	}
	String getHeaderTxt()
	{
		return headerTxt;
	}
	String getContentTxt()
	{
		return contentTxt;
	}
}