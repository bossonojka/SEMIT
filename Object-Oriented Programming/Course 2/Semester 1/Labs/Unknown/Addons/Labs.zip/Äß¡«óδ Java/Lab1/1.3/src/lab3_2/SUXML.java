package lab3_2;

import java.beans.XMLEncoder;
import java.io.FileOutputStream;
import java.io.IOException;

public class SUXML {
	 public static void main(String[] args) {
		 Student [] array = { new Student(12,5), new Student(25,69)};
			Group ag = new Group(array) ;
	        try (XMLEncoder xmlEncoder = new XMLEncoder(new FileOutputStream("Line.xml"))) {
	            xmlEncoder.writeObject(ag);
	            xmlEncoder.flush();
	        }
	        catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
}
