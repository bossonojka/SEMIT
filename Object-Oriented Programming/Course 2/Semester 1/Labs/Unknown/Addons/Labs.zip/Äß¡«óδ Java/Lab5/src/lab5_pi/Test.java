package lab5_pi;

import java.util.Scanner;

public class Test implements Runnable{

    @Override
    public void run() {
        double eps;
        Scanner in = new Scanner(System.in);
        System.out.println("Enter epsilon: ");
        eps = in.nextDouble();
        double p=0;
        double a=4;
        double b=4/3;
        int check;
        int count=2;
        for (double i=5;a-b>eps;i+=2){
            p+=a-b;
            a=4/i;
            i+=2;
            b=4/i;
            count+=2;
            System.out.println("Do you want to know about step? If Yes 0 ");
            check = in.nextInt();
            if(check == 0){
                System.out.println(count);
            }
        }
            System.out.println(p);
    }

    public static void main(String[] args) {
        Thread a = new Thread(new Test());
        a.start();
    }
}
