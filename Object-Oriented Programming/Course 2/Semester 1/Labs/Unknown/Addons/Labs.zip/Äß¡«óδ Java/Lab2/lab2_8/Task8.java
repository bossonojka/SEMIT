import java.util.Scanner;

public class Task8 {
    public static void main(String[] args) {
        BSTree<Integer,String> test = new BSTree<>();
        Scanner in = new Scanner(System.in);
        int num;
        System.out.println("Write number elements ");
        num = in.nextInt();
        for (int i=1;i<=num;i++){
            test.add(in.nextInt(),in.nextLine());
        }
        test.traverseTree();
        test.remove(in.nextInt());
        test.traverseTree();
    }
}
