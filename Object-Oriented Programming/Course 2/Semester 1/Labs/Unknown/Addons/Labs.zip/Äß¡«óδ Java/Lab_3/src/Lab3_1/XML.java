package Lab3_1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

import javax.xml.bind.*;

public class XML {
	public static void writeToXml(String nameOfFile, XMLStructure m){
	    try{  JAXBContext   jaxbContext = JAXBContext.newInstance(XMLStructure.class);

	        Marshaller marshaller = jaxbContext.createMarshaller();
	        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	        marshaller.marshal(m, new FileWriter(nameOfFile));

	    }
	    catch (JAXBException | IOException e){e.printStackTrace();}

	}
	public static XMLStructure readFromXml(String nameOfFile){
	    try{JAXBContext  jaxbContext = JAXBContext.newInstance(XMLStructure.class);
	        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
	        XMLStructure us= (XMLStructure) unmarshaller.unmarshal(new FileInputStream(nameOfFile));
	        return us;}
	    catch (JAXBException | FileNotFoundException e){e.printStackTrace();}
	    return null;
	}

	 
	
}