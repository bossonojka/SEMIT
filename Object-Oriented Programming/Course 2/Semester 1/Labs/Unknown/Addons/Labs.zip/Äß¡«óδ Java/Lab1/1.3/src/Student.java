import java.io.Serializable;

public class Student implements Serializable {
	
	@Override
	public String toString() {
		return "Student [StudentPIN=" + StudentPIN + ", course=" + course + "]";
	}
	private static final long serialVersionUID = 1L;
		private int StudentPIN;
		private int course;
		public Student(int StudentPIN, int course) {
			this.setStudentPIN(StudentPIN);
			this.setCourse(course);
		}
		public int getCourse() {
			return course;
		}
		public void setCourse(int course) {
			this.course = course;
		}
		public int getStudentPIN() {
			return StudentPIN;
		}
		public void setStudentPIN(int studentPIN) {
			StudentPIN = studentPIN;
		}
		
		
}
