import java.util.*;

public  class Mass<T> extends AbstractList<T> {
    private int from;
    private int to;
    private T[] arr;

    public Mass(int from, int to) {
        this.from = from;
        this.to = to;
        Object a[] = new Object[Math.abs(from - to) + 1];
        this.arr = (T[]) a;
    }

    @Override
    public void add(int index, T element) {
        this.arr[Math.abs(index - from)] = element;
    }

    public void setArr(T[] arr) {
        this.arr = arr;
    }

    @Override
    public int size() {
        return Math.abs(to - from+1);
    }

    @Override
    public T get(int index) {
        try {
            return arr[Math.abs(index - from)];
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Index is wrong " + e);

        }
        return null;
    }

    @Override
    public String toString() {
        return "Mass{" +
                "arr=" + Arrays.toString(arr) +
                '}';
    }
}
