package lab5_4;

import java.util.Scanner;

public class Test implements Runnable {
    @Override
    public void run() {
        int i ;
        System.out.println("Enter the value: ");
        Scanner in = new Scanner(System.in);
        try {
            i = in.nextInt();

            for (int j = 2; i / j != 1; j++) {
                for (; ; ) {
                    if (i > 0 && i % j == 0) {
                        i -= j;
                        System.out.println(j + " ");
                    } else {
                        break;
                    }

                }
                if(j==0)
                    break;
            }
        }catch(NumberFormatException e){
            System.out.println("Incorrect data");
        }
    }

    public static void main(String[] args) {
        Thread t = new Thread(new Test());
        t.start();
    }
}
