package lab4_4;

import javafx.event.ActionEvent;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.transform.Scale;


public class Controler {

    public LineChart<Number,Number> chart;
    public Button bt;
    public TextField begin;
    public TextField and;
    public TextField a;
    public TextField b;
    public ScrollBar LineWight;
    public Slider scroll;
    public Button clear;
    XYChart.Series<Number,Number> series=new XYChart.Series() ;

    public void OnDraw(ActionEvent event){
        chart.getData().clear();
        int l=0;
        series=new XYChart.Series();
        series.setName("F(x)");
        try {
            if(Double.parseDouble(and.getText())<= Double.parseDouble(begin.getText()))
                throw new MyException("Invalid Interaval!","End of the interval <= beginning.");
            for (double i = Double.parseDouble(begin.getText())/( scroll.getValue()/100.0); i <=Double.parseDouble(and.getText())/( scroll.getValue()/100.0); i+=0.5,l++)
                series.getData().add(new XYChart.Data(i,(Double.parseDouble(a.getText())*((Math.sin(i))+i*Double.parseDouble(b.getText())))));
            chart.setCreateSymbols(false);
            chart.getData().add(series);
            for (XYChart.Series<Number, Number> s : chart.getData())
                s.getNode().setStyle("-fx-stroke-width: "+LineWight.getValue()+"px; ");

        }
        catch(MyException ex)
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(ex.getHeaderTxt());
            alert.setContentText(ex.getContentTxt());
            alert.showAndWait();
        }
        catch(NumberFormatException e1) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Incorrect data!");
            alert.showAndWait();
        }
    }

    public void Clear (ActionEvent event){
        begin.clear();
        and.clear();
        a.clear();
        b.clear();
        chart.getData().clear();
    }
}
@SuppressWarnings("serial")
class MyException extends Exception{
    private String headerTxt,contentTxt;
    public MyException(String headerTxt,String contentTxt) {
        this.headerTxt = headerTxt;
        this.contentTxt = contentTxt;
    }
    String getHeaderTxt()
    {
        return headerTxt;
    }
    String getContentTxt()
    {
        return contentTxt;
    }
}