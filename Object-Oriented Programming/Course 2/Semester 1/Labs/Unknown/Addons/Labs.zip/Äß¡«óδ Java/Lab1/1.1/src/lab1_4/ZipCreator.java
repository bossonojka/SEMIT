package lab1_4;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;



public class ZipCreator {
	 
		public static void main(String []args ) {
			try (ZipOutputStream zOut = new ZipOutputStream(new FileOutputStream("Source.zip"))) {
	            ZipEntry zipEntry = new ZipEntry("src/lab1_4/ZipCreator.java");
	            zOut.putNextEntry(zipEntry);
	            try (FileInputStream in = new FileInputStream("src/lab1_4/ZipCreator.java")) {
	                byte[] bytes = new byte[1024];
	                int length;
	                while ((length = in.read(bytes)) >= 0) {
	                    zOut.write(bytes, 0, length);
	                }
	            } 
	            zOut.closeEntry();
	        }
	        catch (IOException e) {
	            e.printStackTrace();
	        }
		}
	
}
