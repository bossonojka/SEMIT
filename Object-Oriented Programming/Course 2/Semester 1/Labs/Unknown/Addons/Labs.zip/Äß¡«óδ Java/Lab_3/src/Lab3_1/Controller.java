package Lab3_1;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.FileChooser;
import javafx.util.converter.IntegerStringConverter;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;

public class Controller implements Initializable {

	private MusicBand group = new MusicBand();
	private ObservableList<Trips> observableList;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// Записуємо порожній рядок замість "No content in table":
		tableViewBand.setPlaceholder(new Label(""));

	}

	public static void showMessage(String message) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("");
		alert.setHeaderText(message);
		alert.showAndWait();
	}


	public static void showError(String message) {
		Alert alert = new Alert(AlertType.ERROR);
		alert.setTitle("Помилка");
		alert.setHeaderText(message);
		alert.showAndWait();
	}



	public static FileChooser getFileChooser(String title) {
		FileChooser fileChooser = new FileChooser();
		// Починаємо шукати з поточної теки:
		fileChooser.setInitialDirectory(new File("."));
		// Встановлюємо фільтри для пошуку файлів:
		fileChooser.getExtensionFilters().add(
				new FileChooser.ExtensionFilter("XML-файли (*.xml)", "*.xml"));
		fileChooser.getExtensionFilters().add(
				new FileChooser.ExtensionFilter("Усі файли (*.*)", "*.*"));
		// Вказуемо заголовк вікна:
		fileChooser.setTitle(title);
		return fileChooser;
	}

	@FXML
	TextField textFieldBand;
	@FXML
	TextField textFieldSurname;
	@FXML
	TextField textFieldTown;
	@FXML
	TextArea textResult;
	@FXML
	TableView<Trips> tableViewBand;
	@FXML
	TableColumn<Trips, Integer> tableColumnYear;
	// @FXML TableColumn<Trips, Integer> tableColumnA;
	@FXML
	TableColumn<Trips, String> tableColumnTown;
	@FXML
	TableColumn<Trips, Integer> tableColumnConcerts;
	@FXML
	TableColumn<Trips, Integer> tableColumnConcerts2;

	@FXML
	public void doNew(ActionEvent event) {
		group = new MusicBand();
		observableList = null;
		textFieldBand.setText("");
		textFieldSurname.setText("");
		textFieldTown.setText("");
		textResult.setText("");
		tableViewBand.setItems(null);
		tableViewBand.setPlaceholder(new Label(""));
	}

	@FXML
	public void doOpen(ActionEvent event) {
		FileChooser fileChooser = getFileChooser("Відкрити XML-файл");
		File file;
		if ((file = fileChooser.showOpenDialog(null)) != null) {
			try {
				XMLStructure str = new XMLStructure();
				str = XML.readFromXml(file.getCanonicalPath());

				group = new MusicBand();
				group.setName(str.getName());
				group.setSurname(str.getSurname());
				group.setTrips(str.getTrips());


				textFieldBand.setText(str.getName());
				textFieldSurname.setText(str.getSurname());
				textResult.setText("");
				// Очищаємо та оновлюємо таблицю:
				tableViewBand.setItems(null);
				updateTable();
			} catch (IOException e) {
				showError("Файл не знайдено");
			}
		}
	}

	@FXML
	public void doSave(ActionEvent event) {
		FileChooser fileChooser = getFileChooser("Зберегти XML-файл");
		File file;
		if ((file = fileChooser.showSaveDialog(null)) != null) {
			try {
				updateSourceData(); // оновлюємо дані в моделі
				XMLStructure str = new XMLStructure();
				str.setName(group.getName());
				str.setSurname(group.getSurname());
				str.setTrips(group.getTrips());
				XML.writeToXml(file.getCanonicalPath(), str);
				showMessage("Результати успішно збережені");
			} catch (Exception e) {
				showError("Помилка запису в файл");
			}
		}
	}

	@FXML
	public void doExit(ActionEvent event) {
		Platform.exit(); // коректне завершення застосунку JavaFX
	}

	@FXML
	public void doAdd(ActionEvent event) {
		if (observableList == null) {
			group.trips = new Trips[]{};
			updateTable(); // створюємо нові дані
		}
		observableList.add(new Trips(0, 0, ""));
	}

	@FXML
	public void doRemove(ActionEvent event) {
		// Не можемо видалити рядок, якщо немає даних:
		if (observableList == null) {
			return;
		}
		// Якщо є рядки, видаляємо останній:
		if (observableList.size() > 0) {
			observableList.remove(observableList.size() - 1);
		}
		// Якщо немає рядків, вказуємо, що дані відсутні:
		if (observableList.size() <= 0) {
			observableList = null;
		}
	}

	@FXML
	public void doSortByABC(ActionEvent event) {
		updateSourceData();
		group.SortByLetter();
		updateTable();
	}

	@FXML
	public void doSortByAmount(ActionEvent event) {
		updateSourceData();
		group.SortByAmount();
		updateTable();
	}

	@FXML
	public void doAbout(ActionEvent event) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Про програму...");
		alert.setHeaderText("Дані про музичну групу");
		alert.setContentText("Версія 3.0. Виконав Я");
		alert.showAndWait();
	}

	@FXML
	public void BandChanged(ActionEvent event) {
		// Коли користувач змінив дані в textFieldCountry,
		// автоматично оновлюємо назву:
		group.setName(textFieldBand.getText());
	}

	@FXML
	public void SurnameChanged(ActionEvent event) {
		// Коли користувач змінив дані в textFieldArea, автоматично
		// оновлюємо значення території і щільності населення:
		group.setSurname(textFieldSurname.getText());
	}

	@FXML
	public void doFind(ActionEvent event) {
		// Оновлюємо дані:
		updateSourceData();
		textResult.setText("");
		Trips tmp = group.SomeTown(textFieldTown.getText());
		if(observableList.setAll(tmp))
			showError("Проверьте правильность ввода");
		showResults(tmp);

	}

	private void showResults(Trips census) {
		textResult.appendText("year " + census.getYear() + "\n");
		textResult.appendText("Amount of conserts" + census.getAmountOfconserts() + "\n");
		textResult.appendText("town" + census.getTown());
	}

	private void updateSourceData() {//wride a lot og date!!!!
		// Переписуємо дані в модель з observableList
		group.ClearTpirs(observableList.size());
		for (int i = 0; i < observableList.size(); i++) {
			group.setTrips(observableList.get(i), i);
		}
	}


	private void updateYear(CellEditEvent<Trips, Integer> t) {

		Trips c = (Trips) t.getTableView().getItems().get(t.getTablePosition().getRow());
		c.setYear(t.getNewValue());
		System.out.println("a" + c.getYear());

	}

	   /* private void updateAmount(CellEditEvent<Trips, Integer> k) {

	    	Trips c = (Trips) k.getTableView().getItems().get(k.getTablePosition().getRow());
	        c.setAmountOfconserts(k.getNewValue());

	    }*/

	private void updateTown(CellEditEvent<Trips, String> t) {

		Trips c = (Trips) t.getTableView().getItems().get(t.getTablePosition().getRow());
		c.setTown(t.getNewValue());
	}

	private void updateTable() {
		// Заповнюємо observableList:
		List<Trips> list = new ArrayList<Trips>();
		observableList = FXCollections.observableList(list);
		if (group.getTrips().length == 0) {
			list.add(new Trips(0, 0, ""));
		} else {
			for (int i = 0; i < group.getTrips().length; i++) {
				list.add(group.getTrips(i));
			}
		}
		tableViewBand.setItems(observableList);


		tableColumnYear.setCellValueFactory(new PropertyValueFactory<>("Year"));
		tableColumnYear.setCellFactory(
				TextFieldTableCell.<Trips, Integer>forTableColumn(new IntegerStringConverter()));
		tableColumnYear.setOnEditCommit(t -> updateYear(t));

	        /*tableColumnA.setCellValueFactory(new PropertyValueFactory<>("Amount"));
	        tableColumnA.setCellFactory(
	            TextFieldTableCell.<Trips, Integer>forTableColumn(new IntegerStringConverter()));
	        tableColumnA.setOnEditCommit(k -> updateAmount(k));*/

		tableColumnTown.setCellValueFactory(new PropertyValueFactory<>("Town"));
		tableColumnTown.setCellFactory(TextFieldTableCell.forTableColumn());
		tableColumnTown.setOnEditCommit(t -> updateTown(t));


		tableColumnConcerts.setCellValueFactory(new PropertyValueFactory<>("amountOfconserts"));
		tableColumnConcerts.setCellFactory(
				TextFieldTableCell.<Trips, Integer>forTableColumn(new IntegerStringConverter()));
		tableColumnConcerts.setOnEditCommit(t -> updateColumn(t));


	}

	private void updateColumn(CellEditEvent<Trips, Integer> t) {
		Trips c = (Trips) t.getTableView().getItems().get(t.getTablePosition().getRow());
		if(c.getAmountOfconserts()<0) {
			showError("МИНУС");
			c.setAmountOfconserts(0);
		}
		c.setAmountOfconserts(t.getNewValue());
//		        System.out.println("b"+c.getAmountOfconserts());
	}
}