import java.util.*;

public class Task2 {

    public static void main(String[] args) {
        TreeSet<String> test = new TreeSet<>((aStr, bStr) -> aStr.compareToIgnoreCase(bStr));
        Scanner in = new Scanner(System.in);
        String[] t;
        String tmp;
        System.out.println("Write some sentence: ");
        tmp=in.nextLine();
        t=tmp.split(" |,|\\.|!");
        Collections.addAll(test, t);
        test.remove("");
        System.out.println("Result of this programm: ");
        System.out.println(test.toString());

    }
}
