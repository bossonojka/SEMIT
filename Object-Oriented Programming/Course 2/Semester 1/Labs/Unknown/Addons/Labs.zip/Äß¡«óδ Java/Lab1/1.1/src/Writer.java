import javax.xml.bind.annotation.*;

import java.util.Vector;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Writer")
public class Writer {
	@XmlElement(name = "Surname", required = true)
	private String Surname;
	@XmlElement(name = "Languager", required = true)
	private String Languager;
	@XmlElement(name = "Books", required = true)
	private int Books;
	@XmlElementWrapper(name = "Speech")
	private Vector<Speech> array = new Vector<Speech>() ;
	Writer(String Surname, String Languager, int Books,Speech array[]){
		this.Surname=Surname;
		this.Languager=Languager;
		this.Books=Books;	
		this.array.copyInto(array);
	}
	public Writer() {
		
	}

	public String getSurname() {
		return Surname;
	}

	public void setSurname(String surname) {
		Surname = surname;
	}
	
	public String getLanguager() {
		return Languager;
	}
	public void setLanguager(String languager) {
		Languager = languager;
	}
	public int getBooks() {
		return Books;
	}
	public void setBooks(int books) {
		Books = books;
	}
	public int AllListeners() {
		int count=0;
		for(int i=0;i<array.size();i++)
			count+=((Speech) array.elementAt(i)).getListeners();
		return count;
	}
	public Vector<Speech> getArray() {
		return array;
	}

	public void setArray(Vector<Speech> array) {
		this.array = array;
	}

	public int DayLowListeners() {
		int min=((Speech) array.elementAt(0)).getData();
		for(int i=0;i<array.size();i++)
			if(min>((Speech)array.elementAt(i)).getData()) {min=((Speech) array.elementAt(i)).getData();}
		return min;
	}
	public void sortListenrs() {
		Speech tmp= new Speech();
		for(int i=0;i<array.size();i++) {
			for(int j=1;j<array.size();j++){
				if(array.elementAt(i).getListeners()>array.elementAt(j).getListeners()) {
					tmp=array.elementAt(i);
					array.set(i,array.elementAt(j));
					array.set(j, tmp);
				}
			}
				
		}
	}
	public int LengthSurname() {
		return getSurname().length();
	}
	public static void main(String[] args) {
		
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Books;
		result = prime * result + ((Languager == null) ? 0 : Languager.hashCode());
		result = prime * result + ((Surname == null) ? 0 : Surname.hashCode());
		result = prime * result + ((array == null) ? 0 : array.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Writer other = (Writer) obj;
		if (Books != other.Books)
			return false;
		if (Languager == null) {
			if (other.Languager != null)
				return false;
		} else if (!Languager.equals(other.Languager))
			return false;
		if (Surname == null) {
			if (other.Surname != null)
				return false;
		} else if (!Surname.equals(other.Surname))
			return false;
		if (array == null) {
			if (other.array != null)
				return false;
		} else if (!array.equals(other.array))
			return false;
		return true;
	}

}
