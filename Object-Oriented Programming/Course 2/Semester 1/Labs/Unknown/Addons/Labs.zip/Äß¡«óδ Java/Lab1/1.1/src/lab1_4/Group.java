package lab1_4;

import java.util.Arrays;


public class Group {

	@Override
	public String toString() {
		return "Group [student=" + Arrays.toString(student) + "]";
	}
		public Group() {
			
		}
		private Student[] student;

		public Group(Student [] student) {
			this.setStudent(student);
		}

		public Student[] getStudent() {
			return student;
		}

		public void setStudent(Student[] student) {
			this.student = student;
		}

		
			 public static void main(String[] args) {
				 Student [] array = { new Student(12,5), new Student(25,69)};
					Group ag = new Group(array) ;
					
			 }	
}
