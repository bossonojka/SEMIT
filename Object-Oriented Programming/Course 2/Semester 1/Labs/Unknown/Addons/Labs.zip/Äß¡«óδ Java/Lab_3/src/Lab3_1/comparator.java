package Lab3_1;
import java.util.Comparator;

public class comparator implements Comparator<Trips> {

	@Override
	public int compare(Trips o1, Trips o2) {
		
		return o1.getTown().compareToIgnoreCase(o2.getTown());
	}

	
}
