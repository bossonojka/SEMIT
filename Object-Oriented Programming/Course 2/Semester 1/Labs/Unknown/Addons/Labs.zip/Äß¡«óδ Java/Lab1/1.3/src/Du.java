import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class Du {
	public static void main(String[] args) throws ClassNotFoundException {
		 try (ObjectInputStream in = new ObjectInputStream(
	                new FileInputStream("temp.dat"))) {
	            Group g = (Group) in.readObject();
	            System.out.println(g.toString());
	        }
	        catch (IOException e) {
	            e.printStackTrace();
	        }
	}
}
