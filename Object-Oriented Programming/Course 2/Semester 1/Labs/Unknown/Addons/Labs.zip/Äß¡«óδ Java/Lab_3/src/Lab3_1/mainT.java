package Lab3_1;
import java.util.*;
public class mainT {

	public static void main(String[] args) {
		/*MusicBand group = new MusicBand();
		group.maxConsert();
		group.SomeTown();
		group.LastLetter();
		group.SortByAmount();
		group.SortByLetter();*/
		/*System.out.println("if you want to create new trips ernter 1");
		Scanner s = new Scanner(System.in);
		int tmp =s.nextInt();
		if(tmp==1) { //��������� ������ ������ ������
			group.Addtrips();
		}
		group.maxConsert();
		group.SomeTown();
		group.LastLetter();
		group.SortByAmount();
		group.SortByLetter();*/
		
		//XML
		
       //XMLStructure str =new XMLStructure();
       //str.setName(group.getName());
       //str.setSurname(group.getSurname());
       //str.setTrips(group.getTrips());
      // XML.writeToXml("Band", str);
		
		XMLStructure str =new XMLStructure();
	    str=XML.readFromXml("Band.xml");
	    System.out.println(str);
	    MusicBand group = new MusicBand();
	    group.setName(str.getName());
	    group.setSurname(str.getSurname());
	    group.setTrips(str.getTrips());
	    group.maxConsert();
		group.SomeTown();
		group.LastLetter();
		group.SortByAmount();
		group.SortByLetter();
		Trips tr=new Trips(1934,6,"Fall");
		group.addTrips(tr);
		System.out.println(group);
	}

}
