import java.util.*;

public class Task4 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        ArrayList<String> keys = new ArrayList<>();
        ArrayList<String> keys1 = new ArrayList<>();
        String data ;
        int num;
        System.out.println("Write some number of accounts ");
        num = in.nextInt();
        HashMap<ArrayList<String>,String> test = new HashMap<ArrayList<String>,String>();
        for(int i=1;i<=num;i++){
            System.out.println("Write login ");
            keys.add(in.nextLine());
            if(i==1) {
                keys.remove("");
                keys.add(in.nextLine());
            }
            System.out.println("Write password ");
            keys.add(in.nextLine());
            keys1.addAll(keys);
            System.out.println("Write sex ");
            data = in.nextLine();
            test.put(keys,data);
            keys.remove(0);
            keys.remove(0);
        }
        System.out.println(keys1.size());
        for(int i=0;i<keys1.size()-1;i++){
            if(keys1.get(i+1).length()>=6){
                keys.add(keys1.get(i));
                keys.add(keys1.get(i + 1));
                System.out.println(keys1.get(i));
                System.out.println(test.get(keys));
                keys.remove(1);
                keys.remove(0);
                i++;
            }
        }

    }
}
