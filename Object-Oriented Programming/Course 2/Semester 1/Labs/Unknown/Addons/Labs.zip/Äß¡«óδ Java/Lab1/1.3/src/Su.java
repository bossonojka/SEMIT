import java.io.*;


public class Su {

	public static void main(String[] args) {
		Student [] array = { new Student(12,5), new Student(25,69)};
		Group ag = new Group(array) ;		
		 try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("temp.dat"))) {
	            out.writeObject(ag);
	        }
	        catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
}
