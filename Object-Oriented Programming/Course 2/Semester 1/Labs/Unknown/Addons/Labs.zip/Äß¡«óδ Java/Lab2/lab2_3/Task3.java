import java.util.*;
public class Task3 {
     static class Tcom implements Comparator<Double>{
         @Override
        public int compare(Double o1, Double o2) {
            if(o1<0){
                o1*=-1;
            }
            if(o2<0){
                o2*=-1;
            }
            return o1.compareTo(o2);
        }
    }
    public static void main(String[] args) {
        PriorityQueue<Double> test = new PriorityQueue<>(new Tcom());
        Scanner in = new Scanner(System.in);
        System.out.println("Write a value of set numbers ");
        int num;
        num=in.nextInt();

        for(int i=1;i<=num;i++) {
            System.out.println("Write a number");
            test.offer(in.nextDouble());
        }
        double sum=0.0;
        for(Double arr:test)
            sum+=arr.doubleValue();
        System.out.println("Averange of set numbers are " + sum);
        while (!test.isEmpty())
            System.out.println(test.poll());
    }
}
