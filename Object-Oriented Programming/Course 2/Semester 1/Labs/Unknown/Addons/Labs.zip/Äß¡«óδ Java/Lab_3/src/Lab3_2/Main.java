package Lab3_2;

import javafx.application.Application;
import javafx.event.Event;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Alert.AlertType;

public class Main extends Application {
    TextField text1 ;
    TextField text2 ;
    TextField text3;
    Label label;
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Calculator");
        VBox rootNode = new VBox();
        Scene scene = new Scene(rootNode, 300, 300);
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        ToggleGroup radioGroup = new ToggleGroup();
        RadioButton button1 = new RadioButton("-");
        button1.setToggleGroup(radioGroup);
        button1.setOnAction(this::buttonClick1);
        RadioButton button2 = new RadioButton("+");
        button2.setToggleGroup(radioGroup);
        button2.setOnAction(this::buttonClick2);
        RadioButton button3 = new RadioButton("/");
        button3.setToggleGroup(radioGroup);
        RadioButton button4 = new RadioButton("*");
        button4.setToggleGroup(radioGroup);
        button3.setOnAction(this::buttonClick3);
        button4.setOnAction(this::buttonClick4);
        text1 = new TextField();
        text2 = new TextField();
        text3 = new TextField();
        text3.setEditable(false);
        text3.setMouseTransparent(true);
        text3.setFocusTraversable(false);
        label = new Label();
        rootNode.setSpacing(10);
        rootNode.setPadding(new Insets(10, 10, 10, 10));
        rootNode.getChildren().addAll(button1,button3,button2,button4,text1,text2,text3,label);

        primaryStage.show();
    }

    private void buttonClick2(Event event) {
        try {
            double i = Double.parseDouble(text1.getText());
            double j = Double.parseDouble(text2.getText());
            double k = i + j;
            text3.setText(k + "");
            label.setText(((RadioButton)event.getSource()).getText());
        }
        catch (NumberFormatException e1) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Помилка");
            alert.setHeaderText("Хибні дані!");
            alert.showAndWait();
        }
    }

    private void buttonClick1(Event event) {
        try {
            double i = Double.parseDouble(text1.getText());
            double j = Double.parseDouble(text2.getText());
            double k = i - j;
            text3.setText(k + "");
            label.setText(((RadioButton)event.getSource()).getText());
        }
        catch (NumberFormatException e1) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Помилка");
            alert.setHeaderText("Хибні дані!");
            alert.showAndWait();
        }
    }
    private void buttonClick4(Event event) {
        try {
            double i = Double.parseDouble(text1.getText());
            double j = Double.parseDouble(text2.getText());
            double k = i * j;
            text3.setText(k + "");
            label.setText(((RadioButton)event.getSource()).getText());
        }
        catch (NumberFormatException e1) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Помилка");
            alert.setHeaderText("Хибні дані!");
            alert.showAndWait();
        }
    }
    private void buttonClick3(Event event) {
        try {
            double i = Double.parseDouble(text1.getText());
            double j = Double.parseDouble(text2.getText());
            double k = i / j;
            text3.setText(k + "");
            label.setText(((RadioButton)event.getSource()).getText());
        }
        catch (NumberFormatException e1) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Помилка");
            alert.setHeaderText("Хибні дані!");
            alert.showAndWait();
        }
    }
}
