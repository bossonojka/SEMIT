package Lab3_1;
import javax.xml.bind.annotation.XmlElement;

public class XMLtrip {
	 @XmlElement(name = "year", required = true)
	private int year1;
	 @XmlElement(name = "amountOfconserts1", required = true)
	private int amountOfconserts1;
	 @XmlElement(name = "town1", required = true)
	private String town1;
	 
	 
	public XMLtrip() {}
	
	public XMLtrip(int year,int amountOfconsert,String town) {
		this.year1=year;
		this.amountOfconserts1=amountOfconsert;
		this.town1=town;
	}
	
	public Trips getTrip() {
		Trips tr=new Trips();
		tr.setAmountOfconserts(amountOfconserts1);
		tr.setTown(town1);
		tr.setYear(year1);
		return tr;
		
	}
	@Override
	public String toString() {
		return  "\ntrip [year=" + year1 + ", amount of conserts=" + amountOfconserts1 + ", town=" + town1 + "]";
	}
	
	
	public int getYear() {
		return year1;
	}
	public int getAmountOfconserts() {
		return amountOfconserts1;
	}
	public String getTown() {
		return town1;
	}
	
	 
	 
}
