package Lab3_1;

import java.util.*;
public class MusicBand {
	private
		String name, surname;
	public Trips[] trips;
	Scanner c =new Scanner(System.in);
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSurname() {
		return surname;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}
	public Trips[] getTrips() {
		return trips;
	}
	public void setTrips(Trips[] trips) {
		this.trips = trips;
	}
	/*public MusicBand() {
		System.out.println("enter name of group\n");
		name = c.next();
		System.out.println("enter surnsme of boss\n");
		surname =c.next();
		System.out.println("enter amount of trips\n");
		int tmpAmount=c.nextInt();
		trips=new Trips[tmpAmount];
		for(int i=0;i<tmpAmount;i++) {
			trips[i]= new Trips();
		}
		
	}*/
	public MusicBand() {
		
	}
	
	
	
	public MusicBand(String name, String surname, Trips[] trips) {
		
		this.name = name;
		this.surname = surname;
		this.trips = trips;
	}
	public void maxConsert() {
		int tmp=0;
		int tmpI=0;
		for(int i=0;i<this.trips.length;i++) {
		if(this.trips[i].getAmountOfconserts()>tmp) {
			tmp=this.trips[i].getAmountOfconserts();
			tmpI=i;
		}
		}
		System.out.println(trips[tmpI].toString());
		
	}
	
	public Trips maxConsert1() {
		int tmp=0;
		int tmpI=0;
		for(int i=0;i<this.trips.length;i++) {
		if(this.trips[i].getAmountOfconserts()>tmp) {
			tmp=this.trips[i].getAmountOfconserts();
			tmpI=i;
		}
		}
		return this.trips[tmpI];	
	}
public void SomeTown() {
	System.out.println("enter the town to serch\n");
	String townSerch = c.next();
	for(int i=0;i<this.trips.length;i++){
		if(this.trips[i].getTown().equalsIgnoreCase(townSerch)) {
			System.out.println(trips[i].toString());
		}
			
	}
}
public Trips SomeTown(String townSerch) {
	
	for(int i=0;i<this.trips.length;i++){
		if(this.trips[i].getTown().equalsIgnoreCase(townSerch)) {
			return trips[i];
		}	
	}
	return null;
	 
}
	
public void LastLetter() {
	System.out.println("last letter in surname boss");
	System.out.println(this.surname.substring(this.surname.length()-1,this.surname.length() ));
	
}
public void SortByAmount() {
	Arrays.sort(trips);
	System.out.println("sort by amount of concerts");
	for (int i=0;i<trips.length;i++) {
        System.out.println(trips[i].toString());}
}
public void SortByLetter() {
	Arrays.sort(trips, new comparator());
	System.out.println("sort by letter");
	for (int i=0;i<trips.length;i++) {
        System.out.println(trips[i].toString());}
} 
public void Addtrips() {
	Trips tmp = new Trips();
	for(int i=0;i<trips.length;i++) {
		if(tmp.equals(trips[i])) {
			System.out.println("this element is in the list already, try again");
			Addtrips();
		}
	}
	int amount =trips.length+1;
 trips = Arrays.copyOf(trips, amount);
 trips[trips.length-1]= new Trips(tmp);
 System.out.println(trips[trips.length-1].toString());
}


public void ClearTpirs(int i) {
	this.trips=new Trips[i];
	}


public void addTrips(Trips c2) {
	
	Trips t[]=Arrays.copyOf(trips, trips.length+1);
	t[trips.length]=c2;
	trips=t;
	
}

@Override
public String toString() {
	return "MusicBand [name=" + name + ", surname=" + surname + ", trips=" + Arrays.toString(trips) + "]";
}
public Trips getTrips(int i) {
	return trips[i];
}
public void setTrips(Trips trips2, int i) {
	this.trips[i]=trips2;
	
}

}
