package Lab3_1;
import java.util.Arrays;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Band")
public class XMLStructure {
	
	 @XmlElement(name = "name", required = true)
	private String name;
	 @XmlElement(name = "surname", required = true)
	private String surname;
	 @XmlElementWrapper(name = "trips")
	    XMLtrip [] trips;
	 
	 public void setTrips(Trips[] trips1) {
	       this.trips=new XMLtrip[trips1.length];
	        for (int i=0;i<trips1.length;i++)
	       {
	           trips[i]=new XMLtrip(trips1[i].getYear(),trips1[i].getAmountOfconserts(),trips1[i].getTown());
	       }

	    }
	
	@Override
	public String toString() {
		return "BAnd [name=" + name + ", surname=" + surname + "]"+"\n"+ "trips=\n" + Arrays.toString(trips);
	}

	XMLStructure(){}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSurname() {
		return surname;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}
	public Trips[] getTrips() {
		Trips[] tr=new Trips[trips.length];
		for(int i=0;i<trips.length;i++) {
			tr[i]=trips[i].getTrip();
		}
		return tr;
	}
	 
	 
	 
	
}
