package lad4_3;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.RadioButton;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Rectangle;


public class Controller {

    public Circle circle1;
    public Rectangle square;
    public Rectangle rectangle;
    public Ellipse ellipse;
    public RadioButton ellipse1;
    public ColorPicker color;


    @FXML
    public void Ellipse (ActionEvent event){
        ellipse.setFill(color.getValue());
        square.setOpacity(0);
        rectangle.setOpacity(0);
        circle1.setOpacity(0);
        ellipse.setOpacity(1);
    }

    @FXML
    public void Square (ActionEvent event){
        square.setFill(color.getValue());
        rectangle.setOpacity(0);
        ellipse.setOpacity(0);
        circle1.setOpacity(0); 
        square.setOpacity(1);
    }

    @FXML
    public void Rectangle (ActionEvent event){
        rectangle.setFill(color.getValue());
        square.setOpacity(0);
        ellipse.setOpacity(0);
        circle1.setOpacity(0);
        rectangle.setOpacity(1);
    }

    @FXML
    public void Cercle(ActionEvent event) {
        circle1.setFill(color.getValue());
        square.setOpacity(0);
        rectangle.setOpacity(0);
        ellipse.setOpacity(0);
        circle1.setOpacity(1);
    }

}
