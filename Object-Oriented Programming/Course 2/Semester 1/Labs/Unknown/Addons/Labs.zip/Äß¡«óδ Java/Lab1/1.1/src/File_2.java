import java.io.*;
import java.util.Arrays;
import java.util.*;

import javax.xml.bind.*;

import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils.Collections;

import sun.text.CompactByteArray;
public class File_2 extends Writer{
	 File_2(){
		 
	 }

	/**
	 * 
	 */
	@SuppressWarnings("unused")
	private static final long serialVersionUID = 1L;
	public void Read() {
		try {
			 	JAXBContext jaxbContext = JAXBContext.newInstance(Writer.class);
	            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
	            Writer Alex = (Writer) unmarshaller.unmarshal(new FileInputStream("Data.xml"));
	            Marshaller marshaller = jaxbContext.createMarshaller();
	            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	            System.out.println(Alex);
	            marshaller.marshal(Alex, new FileWriter("Result.xml"));
	            marshaller.marshal(Alex, System.out);
		}
		catch (JAXBException | IOException e) {
            e.printStackTrace();
        }
		
	}
	public static void main(String [] args) {
		File_2 file = new File_2();
		file.Read();
	}
}
