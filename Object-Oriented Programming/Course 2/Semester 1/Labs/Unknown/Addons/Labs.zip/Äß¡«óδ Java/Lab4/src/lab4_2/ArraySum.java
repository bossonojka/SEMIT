package lab4_2;

public class ArraySum{

    public static double sum(Double[] array ){
        double counter = 0;
        for(Double a:array)
            counter+=a.doubleValue();
        return counter;
    }


}
