import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Speech")
public class Speech {
	@XmlElement(name = "Data", required = true)
	private int Data;
	@XmlElement(name = "Place", required = true)
	private String Place;
	@XmlElement(name = "Listeners", required = true)
	private int Listeners;
	Speech(int Data,String Place,int Listeners){
		this.Data=Data;
		this.Place=Place;
		this.Listeners=Listeners;
	}
	@Override
	public String toString() {
		return Data + " " + Place + " " + Listeners ;
	}
	public Speech() {
	
	}
	public int getData() {
		return Data;
	}
	public void setData(int data) {
		Data = data;
	}
	public String getPlace() {
		return Place;
	}
	public void setPlace(String place) {
		Place = place;
	}
	public int getListeners() {
		return Listeners;
	}
	public void setListeners(int listeners) {
		Listeners = listeners;
	}
	public int compareTo(Speech o) {
		return Integer.compare(o.getListeners(),getListeners());
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Data;
		result = prime * result + Listeners;
		result = prime * result + ((Place == null) ? 0 : Place.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Speech other = (Speech) obj;
		if (Data != other.Data)
			return false;
		if (Listeners != other.Listeners)
			return false;
		if (Place == null) {
			if (other.Place != null)
				return false;
		} else if (!Place.equals(other.Place))
			return false;
		return true;
	}

	
}
