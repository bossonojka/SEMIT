package Lab3_1;
	
import java.io.FileInputStream;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.IOException;



public class Main extends Application {
	@Override
	public void start(Stage primaryStage) throws IOException {
		 try {
	            BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("FX.fxml"));
	            Scene scene = new Scene(root, 700, 500);
	            primaryStage.setScene(scene);
	            primaryStage.setTitle("Levadny");
	            primaryStage.show();
	        } 
	        catch(Exception e) {
	            e.printStackTrace();
	        }
	}
	
	public static void main(String[] args) {
		Application.launch(args);
	}
}
