package lab4_4;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class Controller {
    public TextField begin;
    public LineChart chart;
    public TextField and;
    public TextField eps;
    public Button buttonSuspend;
    public Button buttonStart;
    public Button buttonResuem;
    public Button buttonStop;
    private PrimeNumbers primeNumbers = new PrimeNumbers(this::addToTextArea,this::finish);
    XYChart.Series<Number,Number> series=new XYChart.Series() ;

    private void addToTextArea() {
        series.getData().add(new XYChart.Data(primeNumbers.getX(),primeNumbers.getY()));

    }

    @FXML
    private void startClick(ActionEvent actionEvent) {
       try {
           chart.getData().clear();
           series = new XYChart.Series();
           series.setName("F(x)");
           if (Double.parseDouble(begin.getText())>Double.parseDouble(and.getText())||Double.parseDouble(eps.getText())<=0)
               throw new NumberFormatException() ;
           primeNumbers.setA(Double.parseDouble(begin.getText()));
           primeNumbers.setB(Double.parseDouble(and.getText()));
           primeNumbers.setEps(Double.parseDouble(eps.getText()));
           buttonStart.setDisable(true);
           buttonSuspend.setDisable(false);
           buttonResuem.setDisable(true);
           buttonStop.setDisable(false);
           primeNumbers.start();
           chart.getData().add(series);
       }catch(NumberFormatException e){
           Alert alert = new Alert(Alert.AlertType.ERROR);
           alert.setTitle("Помилка");
           alert.setHeaderText("Хибний діапазон!");
           alert.showAndWait();
       }
    }

    @FXML private void suspendClick(ActionEvent actionEvent) {
        primeNumbers.suspend();
        buttonStart.setDisable(true);
        buttonSuspend.setDisable(true);
        buttonResuem.setDisable(false);
        buttonStop.setDisable(false);
    }

    @FXML private void resumeClick(ActionEvent actionEvent) {
        primeNumbers.resume();
        buttonStart.setDisable(true);
        buttonSuspend.setDisable(false);
        buttonResuem.setDisable(true);
        buttonStop.setDisable(false);
    }

    @FXML private void stopClick(ActionEvent actionEvent) {
        primeNumbers.stop();
    }
    private void finish() {

        buttonStart.setDisable(false);
        buttonSuspend.setDisable(true);
        buttonResuem.setDisable(true);
        buttonStop.setDisable(true);
    }


}
