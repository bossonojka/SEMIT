package lab1_5;

import java.io.File;
import java.util.Scanner;

public class Tag {
	public static void recur(String list) {
		 	File dir = new File(list);
	        if (!dir.isDirectory()) {
	            System.out.println("����� ��\'� ����!");
	            return;
	        }
	        String[] list1 = dir.list();
	        for(String name:list1)
	        	 System.out.println(name);
	        for(String name : list1) {
	            System.out.println(list+"\\"+name+"\\");
	            recur(list+"\\"+name+"\\");
	        }
	}

	        

	public static void main(String[] args) {
		  @SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
	        System.out.print("������ ��\'� ����:");
	        String dirName = scanner.next();
	        recur(dirName);
	}

}
