package Lab3_4;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.Random;

public class Main extends Application {
    ArrayList<ArrayList<String>> a = new ArrayList<>();
    int r;
    Button b3,b1,b2;
    Label label,label2;
    public static void main(String[] args) {
        launch(args);
    }

    public void init()  {
        a.add(new ArrayList<String>());
        a.add(new ArrayList<String>());
        a.add(new ArrayList<String>());
        a.add(new ArrayList<String>());
        a.add(new ArrayList<String>());
        a.add(new ArrayList<String>());
        a.get(0).add("to fight");
        a.get(0).add("биться");
        a.get(1).add("gown");
        a.get(1).add("платье");
        a.get(2).add("conceited");
        a.get(2).add("зазнавшийся");
        a.get(3).add("concerned");
        a.get(3).add("обеспакоенный");
        a.get(4).add("short-tempered");
        a.get(4).add("вспыльчивый");
        a.get(5).add("strict");
        a.get(5).add("строгий");

    }

    @Override
    public void start(Stage primaryStage) {
        VBox box = new VBox();
        b1 = new Button();
        b2 = new Button();
        b3 = new Button("Start");
        b3.setOnAction(this::Actiom);
        label = new Label();
        label2 = new Label();
        primaryStage.setScene(new Scene(box,200,200));
        box.getChildren().addAll(label,b1,b2,label2,b3);
        b1.setOnAction(this::CheckTrue);
        b2.setOnAction(this::CheckTrue);
        primaryStage.setResizable(false);
        box.setSpacing(10);
        box.setPadding(new Insets(10, 10, 10, 95));
        primaryStage.show();
    }

    private void Actiom (Event event){
        Random random = new Random();
        r = random.nextInt(a.size());
        int l =  random.nextInt(a.size());
        int i = random.nextInt(2);
        label.setText(a.get(r).get(1));
        ((Button)event.getSource()).setText("Next");
       if(i==0) {
                b1.setText(a.get(r).get(0));
                while(r==l)
                    l =  random.nextInt(a.size());
                b2.setText(a.get(l).get(0));
       }else {
                b2.setText(a.get(r).get(0));
                while(r==l)
                    l =  random.nextInt(a.size());
                b1.setText(a.get(l).get(0));
       }
    }

    private void CheckTrue(Event event){
        if( ((Button)event.getSource()).getText()==a.get(r).get(0)){
            label2.setText("Correct");
            Random random = new Random();
            r = random.nextInt(a.size());
            int l =  random.nextInt(a.size());
            int i = random.nextInt(2);
            label.setText(a.get(r).get(1));
            if(i==0) {
                b1.setText(a.get(r).get(0));
                while(r==l)
                    l =  random.nextInt(a.size());
                b2.setText(a.get(l).get(0));
            }else {
                b2.setText(a.get(r).get(0));
                while(r==l)
                    l =  random.nextInt(a.size());
                b1.setText(a.get(l).get(0));
            }
        }else{
            label2.setText("Incorrect");
        }
    }

}
