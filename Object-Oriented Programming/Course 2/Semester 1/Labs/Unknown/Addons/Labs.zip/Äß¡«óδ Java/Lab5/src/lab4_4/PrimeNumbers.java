package lab4_4;

import javafx.application.Platform;

public class PrimeNumbers implements Runnable {
    private Thread primesThread;
    private double a;
    private double b;
    private double eps;
    private double y;
    private double x;
    private Runnable finishFunc;
    public double getEps() {
        return eps;
    }

    public void setEps(double eps) {
        this.eps = eps;
    }

    public synchronized double getY() {
        return y;
    }

    public synchronized void setY(double y) {
        this.y = y;
    }

    public synchronized double getX() {
        return x;
    }

    public synchronized void setX(double x) {
        this.x = x;
    }

    private Runnable displayFunc;
    private boolean suspended;
    private boolean stopped;

    public PrimeNumbers(Runnable addFunc, Runnable finishFunc ) {
        this.displayFunc = addFunc;
        this.finishFunc = finishFunc;
    }

    public double getA() {
        return a;
    }

    public void setA(double a) {
        this.a = a;
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        this.b = b;
    }

    public synchronized boolean isSuspended() {
        return suspended;
    }

    private synchronized void setSuspended(boolean suspended) {
        this.suspended = suspended;
    }

    public synchronized boolean isStopped() {
        return stopped;
    }

    private synchronized void setStopped(boolean stopped) {
        this.stopped = stopped;
    }

    @Override
    public void run() {
        for (double i = a; i <= b; i += eps) {
            try {
                setX(i);
                setY(i*i);
                Thread.sleep(20);
                Platform.runLater(displayFunc);
            } catch (InterruptedException e) {
                // залежно від стану об'єкта чекаємо на продовження або завершуємо пошук:
                while (isSuspended()) {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e1) {
                        // Перервали у стані очікування:
                        if (isStopped()) {
                            break;
                        }
                    }
                }
                if (isStopped()) {
                    break;
                }
            }
        }

        if (finishFunc != null) {
            Platform.runLater(finishFunc);
        }

    }

    public void start() {
        primesThread = new Thread(this);
        setSuspended(false);
        setStopped(false);
        primesThread.start();
    }


    public void suspend() {
        setSuspended(true);
        primesThread.interrupt();
    }

    public void resume() {
        setSuspended(false);
        primesThread.interrupt();
    }

    public void stop() {
        setStopped(true);
        primesThread.interrupt();
    }
}
