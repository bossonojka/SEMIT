import java.io.*;

import java.util.Vector;



public class File extends Writer{
	
	public File() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return  getSurname() + " " + getLanguager() + " "
				+ getBooks() ;
	}
	

	void readWrite() {
		Vector<Speech> array = new Vector<Speech>();
		Speech tmp;
		try { 
			FileReader fr = new FileReader("data.txt");
			BufferedReader br = new BufferedReader(fr);
			String s_t =new String();
			String s=br.readLine();
			s_t+=s;
			for(;(s=br.readLine())!=null;) {
				s_t+=s;
			}
			String s1[] =s_t.split(" ");
			try {
	                for(int i=0;i<3;i++)
	                {
	                setSurname(s1[i]);
	                i++;
	                setLanguager(s1[i]);
	                i++;
	                setBooks(Integer.parseInt(s1[i]));
	                i++;
	                }
	                for(int i=3;i<s1.length;i++) {
	                	tmp=new Speech();
	               		tmp.setData(Integer.parseInt(s1[i]));
	               		i++;
	            		tmp.setPlace(s1[i]);
	            		i++;	            		
	              		tmp.setListeners(Integer.parseInt(s1[i]));
	            		array.addElement(tmp);
	            	}
	                setArray(array);
			 		}
	            	finally {
	                     br.close();
	                 }
				sortListenrs();
				System.out.println(toString()+" \n"+array.toString());
			 	FileWriter fw = new FileWriter("results1.txt");
	            PrintWriter pw = new PrintWriter(fw);
	            pw.println(toString());
	            for(int i=0;i<array.size();i++)
	            pw.println((Speech)array.elementAt(i));
	            pw.close();
			 }	catch (IOException ex) {
		            ex.printStackTrace();
			 }
 }
	 
	public static void main(String [] args) {
		File file = new File();
		file.readWrite();
	}
	
}
