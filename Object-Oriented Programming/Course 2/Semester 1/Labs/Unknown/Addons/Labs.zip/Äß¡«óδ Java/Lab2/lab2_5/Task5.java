import java.util.Scanner;

public class Task5 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int from,to;
        System.out.println("Please, write value of TO ");
        to=in.nextInt();
        System.out.println("Please, write value of FROM ");
        from = in.nextInt();
        Mass<String> test = new Mass<>(to,from);
        for(int i=to;i<=from;i++){
            System.out.println("Write a value ");
            test.add(i,in.nextLine());
            if(i==to)
                test.add(i,in.nextLine());
        }
        System.out.println(test.toString());

    }
}
