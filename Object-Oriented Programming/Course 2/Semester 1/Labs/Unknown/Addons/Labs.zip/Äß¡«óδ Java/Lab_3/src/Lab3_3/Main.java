package Lab3_3;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import java.util.*;

public class Main extends Application {
    TextField text1,text2,text3,text4;
    Label label1,label2, label3;
    TreeMap<String, String> states = new TreeMap<String, String>();

    public static void main(String[] args) {
        launch(args);
    }

    public void init(){
        states.put("to fight", "биться");
        states.put("to bring","приносить");
        states.put("ash", "пепел");
    }

    @Override
    public void start(Stage primaryStage) {
        VBox box = new VBox();
        Scene scene = new Scene(box,200,300);
        text1 = new TextField();
        text3 = new TextField();
        text4 = new TextField();
        text1.setOnAction(this::Translate);
        text2 = new TextField();
        text2.setEditable(false);
        text2.setMouseTransparent(true);
        text2.setFocusTraversable(false);
        label1 = new Label("Enter a word below what you \nwant to find a translation ");
        label2 = new Label("It is a translation your word");
        label3 = new Label("Enter a word and translation below\nif you want to add");
        Button button1 = new Button("Add");
        button1.setOnAction(event -> states.put(text3.getText(),text4.getText()));
        box.setSpacing(10);
        box.setPadding(new Insets(5,10,10,10));
        box.getChildren().addAll(label1,text1,label2,text2,label3,text3,text4,button1);
        primaryStage.setResizable(false);
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    private void Translate(ActionEvent event) {
        try {
            String s;
            s = text1.getText();
            if(!s.matches("([a-z]+)|([a-z]+\\s+[a-z]+)"))
                throw new NumberFormatException();
            text2.setText(states.get(s));
        }
        catch (NumberFormatException e ){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("Wrong data!");
            alert.showAndWait();
        }
    }

}
