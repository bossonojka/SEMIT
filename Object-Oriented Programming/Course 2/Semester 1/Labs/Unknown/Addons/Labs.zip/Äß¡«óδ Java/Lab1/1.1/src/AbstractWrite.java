
public abstract class AbstractWrite extends Writer{
	public void readWrite() {};
	
}
