import java.util.Scanner;

public class DoublyLinkedList<E> {

    private class Node {
        E data;
        Node next;
        Node prev;

        Node(E data, Node next, Node prev) {
            this.data = data;
            this.next = next;
            this.prev = prev;
        }
    }

        private Node first = null;
        private Node last = null;
        private int count = 0;

        public void add(E elem) {
            Node newNode = new Node(elem, null, null);
            if (last == null) {
                first = newNode;
            } else {
                last.next = newNode;
                newNode.prev = last;
            }
            last = newNode;
            count++;
        }

        public void removeFirstOccurrence(E value) {

            if (first != null && first.data.equals(value)) {
                first = first.next;
                first.prev=null;
                count--;
            } else {
                Node link = first;
                while (link.next != null) {
                    if (link.next.data.equals(value)) {
                        link.next = link.next.next;
                        link.next.prev=link;
                        count--;
                    }
                    if (link.next == null) {
                        last = link;
                        break; // видалили останній елемент
                    }
                    link = link.next;
                }
            }
        }

        public final int size() {
            return count;
        }

        @Override
        public String toString() {
            String s = "size = " + size() + "\n[";
            Node link = first;
            while (link != null) {
                s += link.data;
                link = link.next;
                if (link != null) {
                    s += ", ";
                }
            }
            s += "]\n";
            return s;
        }

    public static void main(String[] args) {
        DoublyLinkedList<Integer> list = new DoublyLinkedList<>();
        Scanner in = new Scanner(System.in);
        int num;
        System.out.println("Write number elements ");
        num = in.nextInt();
        for(int i=1;i<=num;i++) {
            System.out.println("Write an element ");
            list.add(in.nextInt());
        }
        System.out.println(list);
        System.out.println("Write an element which you want delete ");
        list.removeFirstOccurrence(in.nextInt());
        System.out.println(list);

    }
}
