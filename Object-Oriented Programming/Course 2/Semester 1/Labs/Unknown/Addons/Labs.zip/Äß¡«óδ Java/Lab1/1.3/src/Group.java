import java.io.Serializable;
import java.util.Arrays;

public class Group implements Serializable {

	@Override
	public String toString() {
		return "Group [student=" + Arrays.toString(student) + "]";
	}

	private static final long serialVersionUID = 1L;
		private Student[] student;

		public Group(Student [] student) {
			this.setStudent(student);
		}

		public Student[] getStudent() {
			return student;
		}

		public void setStudent(Student[] student) {
			this.student = student;
		}


	
}
