package lab4_2;

import junit.framework.TestCase;

public class ArraySumTest extends TestCase {
    @org.junit.jupiter.api.Test
    void sum() {
        ArraySum sum = new ArraySum();
        sum.sum(null);
    }

}
