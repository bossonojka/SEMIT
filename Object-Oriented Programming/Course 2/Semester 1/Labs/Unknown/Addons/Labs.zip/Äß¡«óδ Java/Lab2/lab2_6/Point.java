import java.util.*;
public class Point extends AbstractArrayOfPoints {
    private LinkedList<Double> a = new LinkedList<>() ;
    @Override
    public void setPoint(int i, double x, double y) {
        a.set(i*2,x);
        a.set(i*2+1,y);
    }

    @Override
    public double getX(int i) {
        double x = a.get(i*2);
        return x;
    }

    @Override
    public double getY(int i) {
        double y = a.get(i*2+1);
        return y;
    }

    @Override
    public int count() {
        int size = a.size()/2;
        return size;
    }

    @Override
    public void addPoint(double x, double y) {
        a.add(x);
        a.add(y);
    }

    @Override
    public void removeLast() {
        a.removeLast();
        a.removeLast();
    }


    public static void main(String[] args) {
        Point test = new Point();
        int num;
        Scanner in = new Scanner(System.in);
        System.out.println("Write some number of points ");
        num = in.nextInt();
        for(int i = 0;i<num;i++){
            System.out.println("Write value x and y ");
            test.addPoint(in.nextDouble(),in.nextDouble());
        }
        System.out.println(test.toString());
        test.sortByX();
        System.out.println(test.toString());

    }
}
