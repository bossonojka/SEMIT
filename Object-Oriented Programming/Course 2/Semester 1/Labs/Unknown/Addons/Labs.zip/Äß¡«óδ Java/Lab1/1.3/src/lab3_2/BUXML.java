package lab3_2;

import java.beans.XMLDecoder;
import java.io.FileInputStream;
import java.io.IOException;

public class BUXML {

    public static void main(String[] args) {
        try (XMLDecoder xmlDecoder = new XMLDecoder(new FileInputStream("Line.xml"))) {
            Group ag = (Group)xmlDecoder.readObject();
            System.out.println(ag.toString());
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
