import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Vector;

public class Array extends AbstractWrite {
    public  Vector<Speech> array = new Vector<Speech>();  
	public void readWrite() {
  		Speech tmp;
  		try { 
  			FileReader fr = new FileReader("data.txt");
  			BufferedReader br = new BufferedReader(fr);
  			String s_t =new String();
  			String s=br.readLine();
  			s_t+=s;
  			for(;(s=br.readLine())!=null;) {
  				s_t+=s;
  			}
  			String s1[] =s_t.split(" ");
  			try {
  	                for(int i=0;i<3;i++)
  	                {
  	                setSurname(s1[i]);
  	                i++;
  	                setLanguager(s1[i]);
  	                i++;
  	                setBooks(Integer.parseInt(s1[i]));
  	                i++;
  	                }
  	                for(int i=3;i<s1.length;i++) {
  	                	tmp=new Speech();
  	               		tmp.setData(Integer.parseInt(s1[i]));
  	               		i++;
  	            		tmp.setPlace(s1[i]);
  	            		i++;	            		
  	              		tmp.setListeners(Integer.parseInt(s1[i]));
  	            		array.addElement(tmp);
  	            	}
  	                setArray(array);
  			 		}
  	            	finally {
  	                     br.close();
  	                 }
  				sortListenrs();
  				System.out.println(getSurname() + " " + getLanguager() + " "
  						+ getBooks()+" \n"+array.toString());
  			 	FileWriter fw = new FileWriter("results1.txt");
  	            PrintWriter pw = new PrintWriter(fw);
  	            pw.println(toString());
  	            for(int i=0;i<array.size();i++)
  	            pw.println((Speech)array.elementAt(i));
  	            pw.close();
  			 }	catch (IOException ex) {
  		            ex.printStackTrace();
  			 }
      }
	
	public static void main(String [] args) {
		Array file = new Array();
		file.readWrite();
	}
}
