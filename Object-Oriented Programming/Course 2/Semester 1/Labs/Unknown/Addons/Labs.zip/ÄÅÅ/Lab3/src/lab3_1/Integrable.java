package lab3_1;

public interface Integrable {
    double fun(double x);
    default double integral(Integrable integral, double a, double b, double eps){
        double S=0;
        double h=(b-a)/eps;
        for(double x=a;x<=b;x+=h){
            S+=fun(x);
        }
        return S*h;
    }
}
