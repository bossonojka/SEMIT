package lab3_1;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;


public class Main extends Application {
    TextField text1,text2,text3,text4,text5,text6;
    Label label1,label2,label3,label4,label5,label6;
    LineChart linechart;
    private static String[] func1Names = new String[] {"abs", "acos", "asin", "atan", "ceil", "cos", "exp", "floor", "log", "random",
            "round", "sin", "sqrt", "tan"};
    private static String[] func2Names = new String[] {"atan2", "max", "min", "pow"};
    ScriptEngineManager factory;
    ScriptEngine engine;
    Pane root;
    NumberAxis xAxis;
    NumberAxis yAxis;
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void init() throws ScriptException {
        factory = new ScriptEngineManager();
        engine = factory.getEngineByName("JavaScript");
        engine.put("pi", Math.PI);
        engine.put("e", Math.E);
        for( String func : func1Names )
            engine.eval(String.format("function %1$s(x){return Math.%1$s(x);}", func));
        for( String func : func2Names )
            engine.eval(String.format("function %1$s(x,y){return Math.%1$s(x,y);}", func));
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Lab3_1");
        root = new Pane();
        Scene scene = new Scene(root,700,600);
        text1 = new TextField ();
        text1.setPrefSize(710,40);
        text1.setLayoutY(scene.getWidth()-300);
        text2 = new TextField ();
        text2.setPrefSize(710,40);
        text2.setLayoutY(scene.getWidth()-230);
        text3 = new TextField ();
        text3.setPrefSize(50,40);
        text3.setLayoutY(scene.getWidth()-180);
        text3.setLayoutX(270);
        text4 = new TextField ();
        text4.setPrefSize(50,40);
        text4.setLayoutY(scene.getWidth()-140);
        text4.setLayoutX(270);
        text5 = new TextField ();
        text5.setPrefSize(50,40);
        text5.setLayoutY(scene.getWidth()-180);
        text5.setLayoutX(570);
        text6 = new TextField ();
        text6.setPrefSize(50,40);
        text6.setLayoutY(scene.getWidth()-140);
        text6.setLayoutX(570);
        label1=new Label("Enter a function f()");
        label1.setPrefSize(500,20);
        label1.setFont(Font.font("TimesNewRoman", FontWeight.BOLD, FontPosture.ITALIC, 15));
        label1.setLayoutY(scene.getWidth()-325);
        label2=new Label("Enter a function g()");
        label2.setPrefSize(500,20);
        label2.setFont(Font.font("TimesNewRoman", FontWeight.BOLD, FontPosture.ITALIC, 15));
        label2.setLayoutY(scene.getWidth()-255);
        label3=new Label("Enter a value of \"a\"");
        label3.setPrefSize(150,20);
        label3.setFont(Font.font("TimesNewRoman", FontWeight.BOLD, FontPosture.ITALIC, 15));
        label3.setLayoutY(scene.getWidth()-170);
        label3.setLayoutX(100);
        label4=new Label("Enter a value of \"b\"");
        label4.setPrefSize(150,20);
        label4.setFont(Font.font("TimesNewRoman", FontWeight.BOLD, FontPosture.ITALIC, 15));
        label4.setLayoutY(scene.getWidth()-130);
        label4.setLayoutX(100);
        label5=new Label("Enter a value of right");
        label5.setPrefSize(150,20);
        label5.setFont(Font.font("TimesNewRoman", FontWeight.BOLD, FontPosture.ITALIC, 15));
        label5.setLayoutY(scene.getWidth()-170);
        label5.setLayoutX(400);
        label6=new Label("Enter a value of left");
        label6.setPrefSize(150,20);
        label6.setFont(Font.font("TimesNewRoman", FontWeight.BOLD, FontPosture.ITALIC, 15));
        label6.setLayoutY(scene.getWidth()-130);
        label6.setLayoutX(400);
        Button btn1 = new Button("Create Chart");
        btn1.setLayoutY(scene.getWidth()-170);
        btn1.setOnAction(this::AddChart);
        Button btn2 = new Button("Clean Chart");
        btn2.setLayoutY(scene.getWidth()-130);
        btn2.setOnAction((event)->{
            linechart.getData().clear();
            xAxis.setTickLabelsVisible(false);
            yAxis.setTickLabelsVisible(false);
        });
        xAxis = new NumberAxis() ;
        xAxis.setLabel("X") ;
        xAxis.setForceZeroInRange(false);
        xAxis.setTickLabelsVisible(false);
        yAxis = new NumberAxis() ;
        yAxis.setLabel("Y");
        yAxis.setForceZeroInRange(false);
        yAxis.setTickLabelsVisible(false);
        linechart = new LineChart(xAxis,yAxis) ;
        linechart.setLayoutX(0);
        linechart.setPrefHeight(375);
        linechart.setPrefWidth(700);
        linechart.setLayoutX(0);
        linechart.setLayoutY(0);
        root.getChildren().addAll(linechart);
        root.getChildren().addAll(text1,text2,label1,label2,label3,text3,label4,text4,label5,label6,text5,text6,btn1,btn2);
        primaryStage.setResizable(false);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void AddChart(ActionEvent event)  {
        try {
            if(Double.parseDouble(text5.getText())>=Double.parseDouble(text6.getText())){
                showMessage("THE RIGHT SIDE IS BIG THEN THE SECOND");
                return;
            }
            XYChart.Series series = new XYChart.Series() ;
            double t1;
            double t2;
            for (double d = Double.parseDouble(text5.getText()); d <= Double.parseDouble(text6.getText()); d += 10) {
                try {
                    engine.put("x", d - Double.parseDouble(text3.getText()));
                    t1 = (double) engine.eval(text1.getText());
                    engine.put("x", d + Double.parseDouble(text4.getText()));
                    t2 = (double) engine.eval(text2.getText());
                    series.getData().add(new XYChart.Data(d, t1 * t2));
                } catch (ScriptException e) {
                    e.printStackTrace();
                }
            }
            series.setName("h(x)");
            xAxis.setTickLabelsVisible(true);
            yAxis.setTickLabelsVisible(true);
            linechart.getData().addAll(series);
        }catch (NumberFormatException e){
            showMessage("PLEASE, FULL IN ALL FIELDS CORRECT");
        }

    }

    public static void showMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Error");
        alert.setHeaderText(message);
        alert.showAndWait();
    }

}
