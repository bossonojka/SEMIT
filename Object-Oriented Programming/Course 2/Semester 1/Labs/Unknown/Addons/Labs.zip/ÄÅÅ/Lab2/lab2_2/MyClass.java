import java.util.Arrays;
abstract public class MyClass {
    abstract public Speech[] getArray();
    abstract public void setArray(Speech[] array);
    abstract  public void Sort() ;
    abstract public void Sort1() ;


}
