import java.util.ArrayList;
import java.util.List;

public class ArrayOfPoints_1 extends AbstractArrayOfPoints {
   List<Double> Ar1;

    public ArrayOfPoints_1() {
        Ar1 = new ArrayList<>();
    }

    
    @Override
    public void setPoint(int i, double x, double y) {
        Ar1.set(i, x);
        Ar1.set(i+1, y);
    }

    @Override
    public double getX(int i) {
       return Ar1.get(i);
    }

    @Override
    public double getY(int i) {
       return Ar1.get(i);
    }

    @Override
	public String toString() {
		return "ArrayOfPoints_1 [Ar1=" + Ar1 + "]";
	}


	@Override
    public int count() {
        return Ar1.size();
    }

    @Override
    public void addPoint(double x, double y) {
        Ar1.add(x);
        Ar1.add(y);
    }

    @Override
    public void removeLast() {
    Ar1.remove(Ar1.size()-1);
        Ar1.remove(Ar1.size()-2);
    }

    public static void main(String[] args) {
        ArrayOfPoints_1 Ar2=new ArrayOfPoints_1();
        Ar2.test();
        System.out.print(Ar2.toString());
    }
}