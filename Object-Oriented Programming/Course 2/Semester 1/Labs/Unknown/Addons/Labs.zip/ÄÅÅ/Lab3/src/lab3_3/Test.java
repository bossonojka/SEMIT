package lab3_3;

import java.util.Scanner;

public class Test {
    static public double fun(double x){
        return x*x;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double a, b;
        System.out.println("Enter some double value of a = ");
        a = in.nextDouble();
        System.out.println("Enter some double value of b = ");
        b = in.nextDouble();
        System.out.println("Check of first way:  ");
        System.out.println(FunMin.fun(a,b,x->x*x));
        System.out.println("Check of second way:  ");
        System.out.println(FunMin.fun(a,b,Test::fun));
    }
}
