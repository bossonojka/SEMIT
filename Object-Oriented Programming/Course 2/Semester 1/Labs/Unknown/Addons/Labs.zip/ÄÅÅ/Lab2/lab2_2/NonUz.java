import java.util.Arrays;

public class NonUz extends MyClass {
    private String Surname;
    private String Languager;
    private int Books;

   private Speech[] array;
   NonUz(String Surname, String Languager, int Books, Speech... array) {
        this.Surname=Surname;
        this.Books=Books;
        this.Languager=Languager;
        this.array=array;
    }
    public String getSurname() {
        return Surname;
    }

    public void setSurname(String surname) {
        Surname = surname;
    }

    public String getLanguager() {
        return Languager;
    }

    public void setLanguager(String languager) {
        Languager = languager;
    }

    public void setBooks(int books) {
        Books = books;
    }

    public Speech[] getArray() {
        return array;
    }
    @Override
    public void setArray(Speech[] array) {
        this.array=array;
    }

    public void Sort() {
        Arrays.sort(array,new CompareByArray());
        System.out.println("The sort of Comparator ");
        for (Speech c : array)
            System.out.println(c.toString());
    }

    public void Sort1() {
        Arrays.sort(array);
        System.out.println("The sort of Comparable ");
        for (Speech c : array)
            System.out.println(c.toString());
    }

}
