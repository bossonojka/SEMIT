
public class Citizen extends People {
	
	private String country;
	
	Citizen(String Surname, int age,String country) {
		super(Surname, age);
		this.setCountry(country);
		// TODO Auto-generated constructor stub
	}

	public String getCountry() {
		return country;
	}

	@Override
	public String toString() {
		return "Citizen [Surname=" + getSurname() + ", age=" + getAge() + " country= " + country + "]";
	}

	public void setCountry(String country) {
		this.country = country;
	}
}
