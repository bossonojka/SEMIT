package lab3_5;

import java.lang.annotation.Annotation;
import java.util.Scanner;

public class ShowAllAnnotations {
    public static void main(String[] args) {
        System.out.println("Please, enter a name of class: ");
        String nameOfClass = new Scanner(System.in).next();
        System.out.println("Please, enter a name of method: ");
        String nameOfMethod = new Scanner(System.in).next();
        try {
            Class<?> cls = Class.forName(nameOfClass);
            if (cls.getMethod(nameOfMethod).getAnnotations().length!=0) {
                for(Annotation an:cls.getMethod(nameOfMethod).getAnnotations())
                    System.out.println(an.annotationType());
            }
            else {
                System.out.println("No annotation before " + cls.getMethod(nameOfMethod).getName());
            }
        } catch(ClassNotFoundException e){
            System.err.println("Wrong the name of class");
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
    }
}
