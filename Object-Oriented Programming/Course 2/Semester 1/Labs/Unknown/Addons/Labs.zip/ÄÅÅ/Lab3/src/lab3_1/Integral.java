package lab3_1;

import java.util.Scanner;

public class Integral implements Integrable{

    @Override
    public double fun(double x) {
        return x*x;
    }

    @Override
    public double integral(Integrable integral,double a, double b, double eps) {
        double S=0;
        double h=(b-a)/eps;
        for(double x=0;x<100;x++){
            S+=integral.fun(a+x*h);
        }
        return h*(integral.fun(a)+integral.fun(b))/2+S;
    }

    public static void main(String[] args) {
        Integral integral = new Integral();
        Scanner in = new Scanner(System.in);
        int h=in.nextInt();
        double a = in.nextDouble();
        double b = in.nextDouble();
        System.out.println(integral.integral(x->x*x,a,b,h));
        System.out.println(integral.integral(Math::sin,a,b,h));
    }
}
