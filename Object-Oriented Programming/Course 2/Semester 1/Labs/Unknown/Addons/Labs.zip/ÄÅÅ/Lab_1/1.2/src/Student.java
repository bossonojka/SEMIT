
public class Student extends Citizen {
	private String University;
	
	private int PIN;
	
	Student(String Surname, int age, String country,String University,int PIN) {
		super(Surname, age, country);
		this.PIN=PIN;
		this.University = University;
	}

	@Override
	public String toString() {
		return "Student [Surname=" + getSurname() + ", age=" + getAge() + " country=" + getCountry() + ", PIN=" + PIN + "]";
	}

	public String getUniversity() {
		return University;
	}

	public void setUniversity(String university) {
		University = university;
	}

	public int getPIN() {
		return PIN;
	}

	public void setPIN(int pIN) {
		PIN = pIN;
	}
	
	
}
