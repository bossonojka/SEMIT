
public class Employe extends Citizen {
	
	private String Work;
	
	Employe(String Surname, int age, String country,String Work) {
		super(Surname, age, country);
		this.setWork(Work);
	}

	@Override
	public String toString() {
		return "Employe [Surname= " + getSurname() + ", age=" + getAge() + " country=" + getCountry() + " Work=" + Work + "]";
	}

	public String getWork() {
		return Work;
	}

	public void setWork(String work) {
		Work = work;
	}


}
