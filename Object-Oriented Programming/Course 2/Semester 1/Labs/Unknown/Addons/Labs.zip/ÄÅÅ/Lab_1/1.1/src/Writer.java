import java.util.Arrays;

public class Writer {
	private String Surname;
	private String Languager;
	private int Books;
	private Speech[] array ;
	Writer(String Surname, String Languager, int Books,Speech array[]){
		this.Surname=Surname;
		this.Languager=Languager;
		this.Books=Books;	
		this.array=array;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Books;
		result = prime * result + ((Languager == null) ? 0 : Languager.hashCode());
		result = prime * result + ((Surname == null) ? 0 : Surname.hashCode());
		result = prime * result + Arrays.hashCode(array);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Writer other = (Writer) obj;
		if (Books != other.Books)
			return false;
		if (Languager == null) {
			if (other.Languager != null)
				return false;
		} else if (!Languager.equals(other.Languager))
			return false;
		if (Surname == null) {
			if (other.Surname != null)
				return false;
		} else if (!Surname.equals(other.Surname))
			return false;
		if (!Arrays.equals(array, other.array))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Writer [Surname=" + Surname + ", Languager=" + Languager + ", Books=" + Books + ", \n array="
				+ Arrays.toString(array) + "]";
	}

	public String getSurname() {
		return Surname;
	}

	public void setSurname(String surname) {
		Surname = surname;
	}
	
	public String getLanguager() {
		return Languager;
	}
	public void setLanguager(String languager) {
		Languager = languager;
	}
	public int getBooks() {
		return Books;
	}
	public void setBooks(int books) {
		Books = books;
	}
	public int AllListeners() {
		int count=0;
		for(Speech c:array) 
			count+=c.getListeners();
		return count;
	}
	
	public int DayLowListeners() {
		int min= array[0].getListeners();
		int minDay= array[0].getData();
		for(int i=0;i<array.length;i++)
			if(min>array[i].getListeners()) {
				min=array[i].getListeners();
				minDay=array[i].getData();
			}
		return minDay;
	}
	
	public Speech[] getArray() {
		return array;
	}
	public void setArray(Speech[] array) {
		this.array = array;
	}
	public int LengthSurname() {
		return getSurname().length();
	}
	public void AddElement(Speech el) {
		for(int i=0;i<array.length;i++)	{
			if(array[i].equals(el)) {
				System.out.println("This element is there");
				return;
			}
		}
		Speech[] Arry=Arrays.copyOf(array, array.length+1);
		setArray(Arry);
		array[array.length-1]=el;
	}
	public void Sort() {
		Arrays.sort(array, new CompareByArray());
		System.out.println("The sort of Comparator ");
		for(Speech c:array)
		System.out.println(c.toString());
	}
	public void Sort1() {
		Arrays.sort(array);
		System.out.println("The sort of Comparable ");
		for(Speech c:array)
		System.out.println(c.toString());
		
	}

}