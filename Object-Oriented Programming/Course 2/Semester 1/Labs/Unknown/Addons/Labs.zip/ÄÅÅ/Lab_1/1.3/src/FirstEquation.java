class FirstEquation implements Leftsize {
    public double f(double x) {
        return x * x - 2;
    }
}
