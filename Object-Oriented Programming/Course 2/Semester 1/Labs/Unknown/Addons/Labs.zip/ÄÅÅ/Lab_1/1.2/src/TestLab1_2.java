
public class TestLab1_2 {
	public static void main(String[] ards) {
		People[] people = {
				new Citizen("Slavik",18,"UK"),
				new Student("Inna",18,"UK","KHPI",15869),
				new Employe("Pash",19,"UK","XTZ")
		};
		System.out.println(people[0].toString());
		System.out.println(people[1].toString());
		System.out.println(people[2].toString());
	}
}
