import java.util.Arrays;
import java.util.Scanner;

public class Propertis {
    public static <T> void swap(T[] arr,int i_1,int i_2,int j_1,int j_2){
        Object temp = new Object[arr.length];
        if(i_1!=0) {
            System.arraycopy(arr, 0, temp, 0, i_1);
            System.arraycopy(arr,j_1,temp,i_1,(j_2-j_1)+1);
        } else System.arraycopy(arr,j_1,temp,0,j_2-j_1+1);
        if(j_1-i_2!=1){
            if(i_1!=0){
                System.arraycopy(arr,i_2+1,temp,i_1+(j_2-j_1)+1,j_1-i_2-1);
                System.arraycopy(arr,i_1,temp,i_1+j_1-i_2-1+(j_2-j_1)+1,i_2-i_1+1);
            } else {
                System.arraycopy(arr, i_2 + 1, temp, j_2 - j_1 + 1, j_1 - i_2 - 1);
                System.arraycopy(arr,i_1,temp,j_2 - j_1 + 1+j_1 - i_2 - 1,i_2-i_1+1);
            }
        }else{
            if(i_1!=0)
                System.arraycopy(arr,i_1,temp,i_1+(j_2-j_1)+1,i_2-i_1+1);
            else System.arraycopy(arr,i_1,temp,j_2-j_1+1,i_2-i_1+1);
        }
        if(arr.length-1!=j_2){
            if(j_1-i_2!=1) {
                if (i_1 != 0)
                    System.arraycopy(arr, j_2 + 1, temp, i_1 + (j_2 - j_1) + 1 + j_1 - i_2 - 1 + i_2 - i_1 + 1, arr.length - 1 - j_2);
                else System.arraycopy(arr,j_2+1,temp,j_2+1,arr.length-1-j_2);
            }else{
                if (i_1 != 0)
                    System.arraycopy(arr,j_2+1,temp,j_2+1,arr.length-1-j_2);
                else System.arraycopy(arr,j_2+1,temp,j_2+1,arr.length-1-j_2);
            }
        }
        System.arraycopy(temp,0,arr,0,arr.length);
    }
    public static <T> void Change(T[] arr) {
        Object tmp;
        Number tmp1;
        Number tmp2;
        for(int i=0;i<arr.length-1;i++){
            tmp1= (Number) arr[i];
            tmp2 =  (Number) arr[i+1];
            if(tmp1.doubleValue()%2==0&&tmp2.doubleValue()%2!=0) {
                if ((i + 1) != arr.length) {
                    tmp = arr[i];
                    arr[i] = arr[i + 1];
                    arr[i + 1] = (T) tmp;
                    i += 1;
                } else {
                    break;
                }
            }else i+=1;
        }
    }
    public static <T> void swapArray(T[] arr, T[] a,int i){
        if((i+a.length)<=arr.length)
        System.arraycopy(a,0,arr,i,a.length);
        else System.out.println("Incorect voluem");
    }
    public static <T> void addArray(T[] arr, T[] a,T[] temp,int i){

        if(i!=0) {
            System.arraycopy(arr,0,temp,0,i);
            System.arraycopy(a,0,temp,i,a.length);
            System.arraycopy(arr,i,temp,i+a.length,arr.length-i);

        }else{
            System.arraycopy(a,0,temp,0,a.length);
            System.arraycopy(arr,0,temp,a.length,arr.length);
        }

    }
    public static <T> void cwrcl(T[] arr,int i){
        Object[] temp = new Object[arr.length];
        for(int j=0;j<i;j++){
                System.arraycopy(arr,arr.length-1,temp,0,1);
                System.arraycopy(arr,0,temp,1,arr.length-1);
            System.arraycopy(temp,0,arr,0,arr.length);
        }

    }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int l;
        l=in.nextInt();
        Integer[] a = {1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15};
        Integer[] a1={2,5,7};
        cwrcl(a,l);
        for(Integer k:a)
            System.out.print(k+" ");
        Integer[] temp = new Integer[a.length+a1.length];
        Double[] b = {1.1, 2.2, 3.3, 4.4, 5.5, 6.6, 7.7, 8.8, 9.9,10.10,11.11,12.12,13.13,14.14,15.15};
        Double[] b1={2.2,5.5,7.7};
        Double[] temp_b = new Double[b.length+b1.length];
        String[] c={"q","w","e","r","t","y","u","i","o","p","a","s","d","f","g"};
        String[] c1={"a","b","c"};
        String[] temp_c = new String[c.length+c1.length];
        System.out.println("Test Intenger: ");
        System.out.println("Task 1: ");
        System.out.println(" ");
             Change(a);
        for(Integer k:a)
            System.out.print(k+" ");
    }
}
