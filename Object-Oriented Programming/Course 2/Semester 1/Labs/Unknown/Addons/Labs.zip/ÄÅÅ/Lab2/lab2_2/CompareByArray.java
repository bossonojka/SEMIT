import java.util.Comparator;

public class CompareByArray implements Comparator<Speech>{

    @Override
    public int compare(Speech arg0, Speech arg1) {
        return Integer.compare(arg1.getData(), arg0.getData());
    }

}
