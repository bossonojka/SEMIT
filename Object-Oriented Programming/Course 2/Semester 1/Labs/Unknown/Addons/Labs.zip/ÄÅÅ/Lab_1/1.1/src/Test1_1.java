
public class Test1_1 {

	public static void main(String[] args) {
		Speech[] test= {
				 new Speech(25,"EN",89),
				 new Speech(30,"FR",45),
				 new Speech(1,"UA",100)
		};
		Speech test1 = new Speech(2,"RU",58);
		Speech test2 = new Speech(30,"FR",45);
		Writer writer = new Writer("Pushkin","Russian",250,test);
		System.out.println(writer.toString());
		writer.AddElement(test1);
		writer.AddElement(test2);
		System.out.println("The number of all Listeners "+writer.AllListeners());
		System.out.println("The day whth a short number of Listeners "+ writer.DayLowListeners());
		System.out.println("The length of Surname "+writer.LengthSurname());
		writer.Sort();
		writer.Sort1();
	}

}
