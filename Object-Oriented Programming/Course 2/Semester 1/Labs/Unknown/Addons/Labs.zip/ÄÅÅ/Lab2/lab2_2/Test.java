public class Test {
    public static void main(String[] args) {
        Speech[] a ={
                 new Speech(2,"UA",14),
                new Speech(6,"RU",58),
                new Speech(3,"AM",145),
        };
        Uz a1 = new Uz("Ova","UA",25,a);
        NonUz a2 = new NonUz("Loa","SD",5,a);
        a1.Sort1();
        a2.Sort1();
    }
}
