
public interface Leftsize {
	double f(double x) throws Exception;
}
