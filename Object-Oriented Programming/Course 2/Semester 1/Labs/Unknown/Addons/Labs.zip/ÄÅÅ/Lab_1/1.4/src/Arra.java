
public class Arra extends AbstractArrayOfPoints{
	private double [] [] poin= {};
	@Override
	public void setPoint(int i, double x, double y) {
		 if (i < count()) {
	            poin[i][0]=x;
	            poin[i][1]=y;
	        }
	}

	@Override
	public double getX(int i) {
		return poin[i][0];
	}

	@Override
	public double getY(int i) {
		return poin[i][1];
	}

	@Override
	public int count() {
		return poin.length;
	}

	@Override
	public void addPoint(double x, double y) {
		double [][] p = new double[count()][2];
		p[count()-1][0]=x;
		p[count()-1][1]=y;
		for(int i=0;i<p.length-1;i++) {
			p[i][0]=poin[i][0];
			p[i][1]=poin[i][1];
		}
		poin=p;
	}

	@Override
	public void removeLast() {
		double [][]p = new double[count()-1][2];
		for(int i=0;i<p.length;i++) {
			p[i][0]=poin[i][0];
			p[i][1]=poin[i][1];
		}
		poin=p;
	}

	public double[][] getPoin() {
		return poin;
	}

	public void setPoin(double[][] poin) {
		this.poin = poin;
	}
	public static void main(String[] args) {
		double[][] p = new double[4][2];
		p[0][0]=39;
		p[0][1]=12;
		p[1][0]=-9;
		p[1][1]=3;
		p[2][0]=5;
		p[2][1]=7;
		p[3][0]=25;
		p[3][1]=4;
		Arra a = new Arra();
		a.setPoin(p);
		a.sortByX();
		System.out.println(a);
		a.removeLast();
		System.out.println(a);
		a.addPoint(1, 5);
		System.out.println(a);
	}

	
}
