
public abstract class MethodDihotomy {
	public abstract double f(double x) throws Exception;
	  
    public double solve(double a, double b, double eps) throws EquationException, Exception {
        if (f(a) * f(b) > 0) {
            throw new EquationException();
        }
        double x = (a + b) / 2;
        while (Math.abs(b - a) > eps) {
            if (f(a) * f(x) > 0) {
                a = x;
            }
            else {
                b = x;
            }
            x = (a + b) / 2;
        }
        return x;
    }
}
