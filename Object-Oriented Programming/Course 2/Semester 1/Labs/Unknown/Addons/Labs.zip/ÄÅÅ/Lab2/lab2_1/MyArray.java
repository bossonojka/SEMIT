import java.util.Arrays;

public class MyArray<T> {
    private Object[] arr = {};

    public MyArray(int size) {
        arr = new Object[size];
    }

    public MyArray(T... arr) {
        this.arr = arr;
    }
    public int size() {
        return arr.length;
    }

    public T get(int i) {
        return (T)arr[i];
    }
    public T[] get2() {
        return (T[])arr;
    }
    public void set(int i, T t) {
        arr[i] = t;
    }
    public void set2( T[] t) {
        arr =  t;
    }

    public void add(T t) {
        Object[] temp = new Object[arr.length + 1];
        System.arraycopy(arr, 0, temp, 0, arr.length);
        arr = temp;
        arr[arr.length - 1] = t;
    }

    public void Del(int i){
        Object[] temp = new Object[arr.length-1];
        System.arraycopy(arr,0,temp,0,i);
        if(i!=arr.length-1)
        System.arraycopy(arr,i+1,temp,i,arr.length-1-i);
        arr = temp;
    }
    public void addArray(T[] ars){
        Object[] temp=new Object[ars.length+arr.length];
        System.arraycopy(arr,0,temp,0,arr.length);
        System.arraycopy(ars,0,temp,arr.length,ars.length);
        arr=temp;
    }

    @Override
    public String toString() {
        return Arrays.toString(arr);
    }

    public static void main(String[] args) {
        MyArray<Integer> a =new MyArray<Integer>(1,4);
        a.add(5);
        a.add(68);
        System.out.println(a.toString());
        Integer[] b={1,68,45,5};
        a.addArray(b);
        System.out.println(a.toString());
    }
}
