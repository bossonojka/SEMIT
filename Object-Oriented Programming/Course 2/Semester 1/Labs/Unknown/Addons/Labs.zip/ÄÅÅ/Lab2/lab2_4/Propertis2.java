
public class Propertis2 {
    static <T extends Number> int Index_min(T[] arr){
        for(int j=0;j<arr.length;j++){
            if(arr[j].intValue()==0)
                return j;
        }
        return -1;
    }

    static  <T extends Number> int Number(T[] arr){
        int i=0;
        for(int j=0;j<arr.length;j++){
            if(arr[j].intValue()<0)
                i++;
        }
        return i;
    }

    static  <T extends Number> Number Last(T[] arr){
        Number i=0;
        for(int j=0;j<arr.length;j++){
            if(arr[j].intValue()<0)
                i=arr[j];
        }
        return i;
    }

    public static void main(String[] args) {
        Integer[] a={1,25,-4,45,5,-145,45};
        Double[] b={45.0,0.0,-47.45,89.147,-5.145,43.358};
        System.out.println("Test Integer: ");
        System.out.println(Index_min(a));
        System.out.println(Number(a));
        System.out.println(Last(a));
        System.out.println("Test Double: ");
        System.out.println(Index_min(b));
        System.out.println(Number(b));
        System.out.println(Last(b));
    }
}
