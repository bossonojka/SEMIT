
public class People {
		private String Surname;
		private int age;
		People(String Surname, int age){
			this.age=age;
			this.Surname=Surname;
		}
		@Override
		public String toString() {
			return "People [Surname=" + Surname + ", age=" + age + "]";
		}
		public String getSurname() {
			return Surname;
		}
		public void setSurname(String surname) {
			Surname = surname;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
}
