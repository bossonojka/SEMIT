import java.util.Arrays;
public class Uz extends MyClass {
    private String Surname;
    private String Languager;

    @Override
    public String toString() {
        return "Uz{" +
                "Surname='" + Surname + '\'' +
                ", Languager='" + Languager + '\'' +
                ", Books=" + Books +
                ", array=" + array +
                '}';
    }

    private int Books;
    private MyArray<Speech> array=new MyArray<>();
    Uz() {
        this.Surname=Surname;
        this.Books=Books;
        this.Languager=Languager;
        this.array=array;
    }
    Uz(String Surname, String Languager, int Books, Speech... array) {
        this.Surname=Surname;
        this.Books=Books;
        this.Languager=Languager;
        this.array.set2(array);
    }

    public String getSurname() {
        return Surname;
    }

    public void setSurname(String surname) {
        Surname = surname;
    }

    public String getLanguager() {
        return Languager;
    }

    public void setLanguager(String languager) {
        Languager = languager;
    }

    public int getBooks() {
        return Books;
    }

    public void setBooks(int books) {
        Books = books;
    }
    @Override
    public Speech[] getArray() {
        return array.get2();
    }
    @Override
    public void setArray(Speech[] array) {
        this.array.set2(array);
    }

    public void Sort() {
        Arrays.sort(array.get2(),new CompareByArray());
        System.out.println("The sort of Comparator ");
        for (Speech c : array.get2())
            System.out.println(c.toString());
    }

    public void Sort1() {
        Arrays.sort(array.get2());
        System.out.println("The sort of Comparable ");
        for (Speech c : array.get2())
            System.out.println(c.toString());
    }

}
