package lab3_3;

public interface FunMin {
    double min(double a);
    static double fun(double a,double b,FunMin f){
        double min = a;
        for(double i=a;i<b;i+=0.001){
            if(f.min(i)<f.min(min))
                min=i;
        }
        return min;
    }

}
