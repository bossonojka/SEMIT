public class Solver {
    static double solve(double a, double b, double eps, Leftsize ls) throws Exception {
        if (ls.f(a) * ls.f(b) > 0) {
            throw new EquationException();
        }
        double x = (a + b) / 2;
        while (Math.abs(b - a) > eps) {
          if (ls.f(a) * ls.f(x) > 0) {
                a = x;
            }
            else {
                b = x;
            }
            x = (a + b) / 2;
        }
        return x;
    }
}