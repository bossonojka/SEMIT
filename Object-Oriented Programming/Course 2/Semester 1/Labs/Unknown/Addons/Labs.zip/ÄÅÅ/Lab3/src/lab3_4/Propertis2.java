package lab3_4;

import java.util.Scanner;

public class Propertis2 {
    static <T extends Number> int Index_min(T[] arr){
        for(int j=0;j<arr.length;j++){
            if(arr[j].intValue()==0)
                return j;
        }
        return -1;
    }

    static  <T extends Number> int Number(T[] arr){
        int i=0;
        for(int j=0;j<arr.length;j++){
            if(arr[j].intValue()<0)
                i++;
        }
        return i;
    }

    static  <T extends Number> Number Last(T[] arr){
        Number i=0;
        for(int j=0;j<arr.length;j++){
            if(arr[j].intValue()<0)
                i=arr[j];
        }
        return i;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int num;
        System.out.println("Enter a value of elements arrays: ");
        num = in.nextInt();
        Integer[] a=new Integer[num];
        for(int i=0;i<num;i++)
            a[i]=in.nextInt();
        System.out.println(Index_min(a));
        System.out.println(Number(a));
        System.out.println(Last(a));

    }
}
