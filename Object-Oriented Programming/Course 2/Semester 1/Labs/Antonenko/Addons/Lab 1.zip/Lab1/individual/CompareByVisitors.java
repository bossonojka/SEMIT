package F_ex;

import java.util.Comparator;

import Additions.Reception;

public class CompareByVisitors implements Comparator<Reception> {

	public int compare(Reception c1, Reception c2) {
        return Double.compare(c1.getNumOfVisit(), c2.getNumOfVisit());
    }

}
