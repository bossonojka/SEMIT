package F_ex;
import Additions.Reception;
public abstract  class BaseAbstract {
	private String name;
	private String spec;
	
	abstract public Reception getReception(int i);
    abstract public void setReception(int i, Reception recep);
    abstract public int receptionsCount();
    abstract public void addReception(Reception recep);
    abstract public void clearReception();
	abstract public void sortByVisitors();
	abstract public void sortByDate();
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;}

	public String getSpec() {
		return spec;
	}

	public void setSpec(String spec) {
		this.spec = spec;
	}
	public int allVisitors(){
		int s=0;
		for(int i=0;i<receptionsCount();i++){
			s+=getReception(i).getNumOfVisit();
		}
		return s;
	}
    public int minVisitors() {
        Reception visit=getReception(0);
        for (int i = 1; i < receptionsCount(); i++) {
            if (visit.getNumOfVisit() > getReception(i).getNumOfVisit()) {
                visit = getReception(i);
            }
        }
        
       return visit.getNumOfVisit();
    }
    public int SurnameLength(){
    	return name.length();
    }   
    public void showData(String title) {
        System.out.println(title);
        System.out.println(getName() + " " + getSpec());
        for (int i = 0; i < receptionsCount(); i++) {
            System.out.println(getReception(i).getDay() + " " + getReception(i).getShift() + " "
                            + getReception(i).getNumOfVisit());
        }
        System.out.println();
    }
    protected void test(){
    	setName("Vladimir Nikolaychuk");
    	setSpec("Terapist");
    	addReception(new Reception(30,"15.03.17","Morning"));
    	addReception(new Reception(12,"31.03.17","Afternoon"));
    	addReception(new Reception(21,"01.03.17","Night"));
    	showData("Output data:");
    	System.out.println("The minimum of visitors: " + minVisitors());
    	System.out.println("The doctor's last name length is: " + SurnameLength());
    	sortByVisitors();
    	showData("Sort by visitors:");
        sortByDate();
        showData("Sort by date:");
    	
    }

}

