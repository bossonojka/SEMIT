package seclab.third_ex;

import java.beans.XMLDecoder;
import java.io.*;

public class XMLDeserialization {

    public static void main(String[] args) {
        try (XMLDecoder xmlDecoder = new XMLDecoder(new FileInputStream("AcademGroup.xml"))) {
            Student a = (Student)  xmlDecoder.readObject();
            Student b = (Student)  xmlDecoder.readObject();
            AcademGroup c = (AcademGroup) xmlDecoder.readObject();
            System.out.println(c.getName());
            for (Student j : c.getStudents()) {
                System.out.println(j.getName() + " " + j.getAge());
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

}

