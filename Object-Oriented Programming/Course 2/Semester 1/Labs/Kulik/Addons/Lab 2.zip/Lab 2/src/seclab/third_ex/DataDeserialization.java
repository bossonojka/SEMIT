package seclab.third_ex;

import java.io.*;

public class DataDeserialization {

    public static void main(String[] args) throws ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("AcademGroups.dat"))) {
            AcademGroup academgroup = (AcademGroup) in.readObject();
            System.out.println(academgroup.getName());
            for (Student c : academgroup.getStudents()) {
                System.out.println(c.getName() + " " + c.getAge());
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        };
    }

}
