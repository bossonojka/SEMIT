package seclab.f_ex;

public class Recept {
	private int numOfVisit;
	private String day;
	private String shift;
	
	public Recept() {}
		
	public Recept(int numOfVisit, String day,String shift) {
		this.numOfVisit = numOfVisit;
		this.day = day;
		this.shift = shift;
	}
	
	public void setDay(String day) {
		this.day = day;
	}
		
	public void setNumOfVisit(int numOfVisit) {
		this.numOfVisit = numOfVisit;
	}
	
	public void setShift(String shift) {
		this.shift = shift;
	}
		
	public String getDay() {
		return day;
	}
	
	public int getNumOfVisit() {
		return numOfVisit;
	}
	
	public String getShift() {
		return shift;
	}
	
	@Override
	public String toString() {
		return day + " , " + shift+","+numOfVisit;
	}
}
