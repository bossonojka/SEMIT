package seclab.third_ex;

import java.io.*;

public class DataSerialization {
    public static void main(String[] args) {
        AcademGroup c = new AcademGroup("36A",
                new Student("Gosha", 18),
                new Student("Valera", 20),
                new Student("Lesha", 19)
        );
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("AcademGroups.dat"))) {
            out.writeObject(c);
        }
        catch (IOException e) {
            e.printStackTrace();
        };
    }
}
