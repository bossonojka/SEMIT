
package seclab.sec_ex;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.InputMismatchException;
import java.util.Scanner;

public final class IntNumbers {
	public static class IntValueException extends Exception {
		private int wrongValue;
		
		IntValueException(int wrongValue){
			this.wrongValue = wrongValue;
		}
		
		public double getWrongValue() {
			return wrongValue;
		}
	}
	
	public static Comparator<Integer> compareBySumOfDigits() {
        class LocalComparator implements Comparator<Integer> {
            @Override
            public int compare(Integer i1, Integer i2) {
                return Integer.compare(sumOfDigits(i1), sumOfDigits(i2));
            }
        }
        return new LocalComparator();
    }
	
	public static int sumOfDigits(int number){
		int res = 0;
		String asString = Integer.toString(number);
		String[] digits = asString.split("");
		for (int i = 0; i < digits.length; i++){
			res += Integer.parseInt(digits[i]); 
		}
		return res;
	}
	
	public static void sortIntegers(String inFileName, String firstOutFileName,
            String secondOutFileName) throws IntValueException, IOException,
            InputMismatchException {
		Integer[] arr = {};
		try (BufferedReader reader = new BufferedReader(new FileReader(inFileName));
	             Scanner scanner = new Scanner(reader)) {
			while(scanner.hasNext()){
				double d = Double.parseDouble(scanner.next());
				int n = (int)Math.round(d);
				if(n <= 0 | d != Math.round(d)){
					throw new IntValueException(n);
				}
				Integer[] arr1 = new Integer[arr.length + 1];
				System.arraycopy(arr, 0, arr1, 0, arr.length);
				arr1[arr.length] = n;
				arr = arr1;
			}
		}
		
        PrintWriter firstWriter = new PrintWriter(new FileWriter(firstOutFileName));
        PrintWriter secondWriter = new PrintWriter(new FileWriter(secondOutFileName));
        try {
            Arrays.sort(arr, Collections.reverseOrder());
            for (Integer x : arr)
                firstWriter.print(x + " ");
            Arrays.sort(arr, compareBySumOfDigits());
            for (Integer x : arr)
                secondWriter.print(x + " ");
        }
        
        finally {
            firstWriter.close();
            secondWriter.close();
        }
	}

}