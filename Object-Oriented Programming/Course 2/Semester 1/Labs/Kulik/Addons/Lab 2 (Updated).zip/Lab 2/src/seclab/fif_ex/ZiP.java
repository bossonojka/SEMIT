package seclab.fif_ex;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class ZiP {
	public static void main(String[] args) {
	StudentInf[] students = { new StudentInf("Vlada","Sushko",18), new StudentInf("Vlas","Antonenko",19), new StudentInf("Vadim","Gordychuk",18) };
	Groupp groupp = new Groupp(students);
	
	try (ZipOutputStream zOut = new ZipOutputStream(new FileOutputStream("36AGroup.zip"));
            DataOutputStream out = new DataOutputStream(zOut)) {
            for (StudentInf student : groupp.getStudents()) {
                ZipEntry zipEntry = new ZipEntry(student.getLastname());
                zOut.putNextEntry(zipEntry);
                out.writeUTF(student.getName());
                out.writeInt(student.getYearsold());
                zOut.closeEntry();
            }
            FileWriter fw = new FileWriter("results.txt");
        }
        catch (IOException e) {
            e.printStackTrace();
        }
	
		try (ZipInputStream zIn = new ZipInputStream(new FileInputStream("36AGroup.zip"));DataInputStream in = new DataInputStream(zIn)) {
				ZipEntry entry;
				while ((entry = zIn.getNextEntry()) != null) {
				System.out.println("Last name: " + entry.getName());
				System.out.println("Name: " + in.readUTF());
				System.out.println("Years old: " + in.readInt());
				System.out.println();
				zIn.closeEntry();
			}
		}
		catch (IOException e) {
		e.printStackTrace();
		}
	}
}
