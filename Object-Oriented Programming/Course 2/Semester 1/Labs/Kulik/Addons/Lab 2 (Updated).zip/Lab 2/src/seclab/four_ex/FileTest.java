package seclab.four_ex;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class FileTest {
	public static void findDir(String path) throws IOException {
		File file = new File(path);
		//File[]list=file.listFiles();
		for (File f : file.listFiles()) {
			if (f.list() != null) {
				System.out.println(f.getAbsolutePath());
				findDir(f.getAbsolutePath());
			}
			else
				System.out.println(f.getAbsolutePath());
			
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) throws IOException {
		@SuppressWarnings("resource")
		Scanner s=new Scanner(System.in);
		System.out.println("������� ���� ��� ������ ������: ");
		String dirName=s.next();
		File dir = new File(dirName);
		if(!dir.isDirectory()){
			do{
			System.out.println("������� ���� �� ����������:");
			dirName=s.next();
			dir = new File(dirName);
		}while(!dir.isDirectory());}
			findDir(dirName);
	}
}
