package seclab.third_ex;

import java.beans.XMLEncoder;
import java.io.*;


public class XMLSerialization {

    public static void main(String[] args) {
        AcademGroup c = new AcademGroup();
        c.setName("36A");
        Student a = new Student();
        a.setName("Vlas Kurduk");
        a.setAge(18);
        Student b = new Student();
        b.setName("Yulia Juya");
        b.setAge(20);
        c.setStudents(a, b);

        try (XMLEncoder xmlEncoder = new XMLEncoder(new FileOutputStream("AcademGroup.xml"))) {
            xmlEncoder.writeObject(a);
            xmlEncoder.writeObject(b);
            xmlEncoder.writeObject(c);
            xmlEncoder.flush();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

    }

}

