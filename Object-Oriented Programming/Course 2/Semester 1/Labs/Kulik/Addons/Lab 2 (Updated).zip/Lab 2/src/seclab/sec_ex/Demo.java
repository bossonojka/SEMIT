package seclab.sec_ex;

import java.io.IOException;
import java.util.InputMismatchException;

import seclab.sec_ex.IntNumbers.IntValueException;

public class Demo {
	
	final static String FILE_IN = "src\\seclab\\sec_ex\\file_in.txt";
	final static String FILE_OUT1 = "src\\seclab\\sec_ex\\file_out1.txt";
	final static String FILE_OUT2 = "src\\seclab\\sec_ex\\file_out2.txt";
	
	public static void main(String[] args) {
		try {
			IntNumbers.sortIntegers(FILE_IN, FILE_OUT1, FILE_OUT2);
		} catch (InputMismatchException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IntValueException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}