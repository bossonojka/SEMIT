package seclab.f_ex;

import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DocArrTXT extends DocArr {
	public DocArrTXT() {
	}

	public DocArrTXT(String name, String spec, Recept[] recepts) {
		super(name, spec, recepts);
	}

	public void toTxt(String name) {
		try (FileWriter fReader = new FileWriter(name)) {
			fReader.write(this.getName() + "\n");
			fReader.write(this.getSpec() + "\n");
			for (Recept rec : getRecepts()) {
				fReader.write(rec.toString() + "\n");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public DocArrTXT fromTxt() {
		DocArrTXT sArr = new DocArrTXT();
		try (Scanner scanner = new Scanner(new FileReader("Doctor.txt"))) {

			sArr.setName(scanner.nextLine());
			sArr.setSpec(scanner.nextLine());

			List<Recept> sList = new ArrayList<>();
			while (scanner.hasNext()) {
				String[] string = scanner.nextLine().split(",");
		        Integer integer = Integer.parseInt(string[2].replaceAll(" ", ""));
		        sList.add(new Recept(integer, string[0], string[1]));
			}
			sArr.setRecepts(sList.toArray(new Recept[sList.size()]));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sArr;
	}
}
