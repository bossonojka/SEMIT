package seclab.fif_ex;

public class StudentInf {
	public String name;
	public String lastname;
	public int yearsold;
	
	public String getName() {
		return name;
	}
	@Override
	public String toString() {
		return "Students name is " + name + "\nStudents lastname is " + lastname
				+ "\nYearsold: " + yearsold;
	}
	public StudentInf(String name, String lastname, int yearsold) {
		super();
		this.name = name;
		this.lastname = lastname;
		this.yearsold = yearsold;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public int getYearsold() {
		return yearsold;
	}
	public void setYearsold(int yearsold) {
		this.yearsold = yearsold;
	}
}
