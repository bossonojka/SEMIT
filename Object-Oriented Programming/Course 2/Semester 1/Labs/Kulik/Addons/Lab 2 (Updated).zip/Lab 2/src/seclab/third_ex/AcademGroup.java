package seclab.third_ex;

import java.io.Serializable;

public class AcademGroup implements Serializable {
    private static final long serialVersionUID = 8433147861334322335L;
    private String name;
    private Student[] students;

    public AcademGroup(String name, Student... students) {
        this.name = name;
        this.students = students;
    }

    public AcademGroup() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Student[] getStudents() {
        return students;
    }

    public void setStudents(Student... students) {
        this.students = students;
    }

}
