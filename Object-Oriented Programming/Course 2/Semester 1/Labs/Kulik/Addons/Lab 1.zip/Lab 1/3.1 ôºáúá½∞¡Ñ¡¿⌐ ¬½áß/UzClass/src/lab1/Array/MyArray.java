package lab1.Array;

public class MyArray<T> {
    public Object[] arr = {};

    public MyArray(T... arr) {
        this.arr = arr;
    }

    public MyArray(int size) {
        arr = new Object[size];
    }

    public int size() {
        return arr.length;
    }

    public T get(int i) {
        return (T) arr[i];
    }

    public void set(int i, T t) {
        arr[i] = t;
    }

    public void add(T t) {
        Object[] temp = new Object[arr.length + 1];
        System.arraycopy(arr, 0, temp, 0, arr.length);
        arr = temp;
        arr[arr.length - 1] = t;
    }

    public <T> void addGroup(T[] a) {

        Object[] temp = new Object[arr.length + a.length];
        System.arraycopy(arr, 0, temp, 0, arr.length);
        arr = temp;
        for (int i = 1; i <= a.length; i++)
            arr[arr.length - i] = a[a.length-i];


    }

    public void printAll() {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }

    public void delElem(int t) {
        arr[t] = null;
        for (int k = t; k < arr.length - 1; k++)
            arr[k] = arr[k + 1];

        Object[] temp = new Object[arr.length - 1];
        System.arraycopy(arr, 0, temp, 0, arr.length - 1);
        arr = temp;
    }
}
