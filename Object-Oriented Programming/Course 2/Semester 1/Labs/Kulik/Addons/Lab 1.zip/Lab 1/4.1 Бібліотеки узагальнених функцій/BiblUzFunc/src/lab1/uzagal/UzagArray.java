package lab1.uzagal;

/**
 * Created by �������� on 15/10/2017.
 */

import java.util.Arrays;
import java.util.*;

public class UzagArray {
    public static <E> void ZamenaGroup(List<E> arr, int ot1, int do1, int ot2, int do2) {
        for (int i = 0; i <= do1 - ot1; i++) {
            E temp = arr.get(ot2 + i);
            arr.add(ot2 + i,arr.get(ot1 + i));
            arr.add(ot1 + i,temp);
        }
        for (int i = 0; i < arr.size(); i++) {
            System.out.println(arr.get(i));
        }
    }
    public static <E> void ZamenaGroup(E[] arr, int ot1, int do1, int ot2, int do2) {
        for (int i = 0; i <= do1 - ot1; i++) {
            E temp = arr[ot2 + i];
            arr[ot2 + i] = arr[ot1 + i];
            arr[ot1 + i] = temp;
        }
        System.out.println(Arrays.toString(arr));
    }

    public static <E> void ParAndNepar(List<E> arr) {
        int x = arr.size();
        if (arr.size() % 2 != 0) {
            x -= 1;
        }
        for (int i = 0; i < x; i += 2) {
            E temp = arr.get(i);
            arr.add(i, arr.get(i + 1));
            arr.add(i + 1, temp);
        }
        for (int i = 0; i < arr.size(); i++) {
            System.out.println(arr.get(i));
        }
    }
    public static <E> void ParAndNepar(E[] arr) {
        int x = arr.length;
        if (arr.length % 2 != 0) {
            x -= 1;
        }
        for (int i = 0; i < x; i += 2) {
            E temp = arr[i];
            arr[i] = arr[i + 1];
            arr[i + 1] = temp;
        }
        System.out.println(Arrays.toString(arr));
    }

    public static <E> void ZamenaGroupArray(List<E> arr1, List<E> arr2, int ot1, int do1, int ot2, int do2) {
        for (int i = 0; i <= do1 - ot1; i++) {
            E temp = arr2.get(ot2 + i);
            arr2.add(ot2 + i, arr1.get(ot1 + i));
            arr1.add(ot1 + i, temp);

        }
        for (int i = 0; i < arr1.size(); i++) {
            System.out.println(arr1.get(i));
        }
        for (int i = 0; i < arr2.size(); i++) {
            System.out.println(arr2.get(i));
        }
    }
    public static <E> void ZamenaGroupArray(E[] arr1, E[] arr2, int ot1, int do1, int ot2, int do2) {
        for (int i = 0; i <= do1 - ot1; i++) {
            E temp = arr2[ot2 + i];
            arr2[ot2 + i] = arr1[ot1 + i];
            arr1[ot1 + i] = temp;

        }
        System.out.println(Arrays.toString(arr1));
        System.out.println(Arrays.toString(arr2));
    }

    public static <E> void InsertArray(List<E> arr1, List<E> arr2, int psn) {
        List<E> temp = new ArrayList<E>();
        for (int i = 0; i < psn; i++) {
            temp.add(i, arr1.get(i));
        }
        int t = 0;
        for (int i = psn; i < arr2.size() + psn; i++) {
            temp.add(i, arr2.get(t));
            t++;
        }
        t = psn;
        for (int i = arr2.size() + psn; i < arr1.size() + arr2.size(); i++) {
            temp.add(i, arr1.get(t));
            t++;
        }
        arr1 = temp;
        for (int i = 0; i < arr1.size(); i++) {
            System.out.println(arr1.get(i));
        }
    }
    public static <E> void InsertArray(E[] arr1, E[] arr2, int psn) {
        Object[] temp = new Object[arr1.length + arr2.length];
        for (int i = 0; i < psn; i++) {
            temp[i] = arr1[i];
        }
        int t = 0;
        for (int i = psn; i < arr2.length + psn; i++) {
            temp[i] = arr2[t];
            t++;
        }
        t = psn;
        for (int i = arr2.length + psn; i < arr1.length + arr2.length; i++) {
            temp[i] = arr1[t];
            t++;
        }
        arr1 = (E[]) temp;
        System.out.println(Arrays.toString(arr1));
    }
    public static void main(String[] args) {
        Integer[] a = {1, 2, 11, 4, 5, 8, 11, 3, 4, 6, 0};
        Integer[] d = {1, 2, 11, 4, 5, 8, 11, 3, 4, 6, 0};
        List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        list.add("c");
        list.add("d");
        list.add("e");
        list.add("r");
        list.add("t");
        list.add("y");
        list.add("u");
        list.add("i");
        list.add("o");
        Double[] b = {1.0, 2.0, 11.4, 4.7, 5.0, 8.0, 11.0, 3.0, 4.0, 6.0, 8.0};
        Double[] f = {1.0, 2.0, 11.4, 4.7, 5.0, 8.0, 11.0, 3.0, 4.0, 6.0, 8.0};
        String[] c = {"a", "s", "d", "f", "g", "h", "j", "k", "l", "z", "x"};
        String[] e = {"a", "s", "d", "f", "g", "h", "j", "k", "l", "z", "x"};
        ZamenaGroup(list, 2, 4, 7, 9);
        ZamenaGroup(a, 2, 4, 7, 9);
        ZamenaGroup(b, 2, 4, 7, 9);
        ZamenaGroup(c, 2, 4, 7, 9);
        ParAndNepar(a);
        ParAndNepar(b);
        ParAndNepar(c);
        ZamenaGroupArray(a, d, 2, 4, 7, 9);
        ZamenaGroupArray(b, f, 2, 4, 7, 9);
        ZamenaGroupArray(c, e, 2, 4, 7, 9);
        InsertArray(a, d, 5);
        InsertArray(b, f, 5);
        InsertArray(c, e, 5);
    }
}
