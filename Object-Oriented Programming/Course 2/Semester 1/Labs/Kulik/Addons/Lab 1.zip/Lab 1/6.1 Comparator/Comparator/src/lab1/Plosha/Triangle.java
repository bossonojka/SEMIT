package lab1.Plosha;

import java.util.Comparator;

public class Triangle implements Comparator<Triangle> {
    private double a;
    private double b;
    private double c;
    Triangle(){

    }
    public Triangle(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public double getA() {
        return a;
    }

    public void setA(double a) {
        this.a = a;
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        this.b = b;
    }

    public double getC() {
        return c;
    }

    public void setC(double c) {
        this.c = c;
    }

    public double Geron(){
        if((a+b+c)*(b+c-a)*(a+c-b)*(a+b-c)>= 0){
            return 0.25 * Math.sqrt((a+b+c)*(b+c-a)*(a+c-b)*(a+b-c));
        }
        else {
            System.out.println("sqrt less than: ");
            return 0;
        }
    }

    public double Geron2(){
        if((a+b+c)*(b+c-a)*(a+c-b)*(a+b-c)>= 0){
            return 0.25 * Math.sqrt((a+b+c)*(b+c-a)*(a+c-b)*(a+b-c));
        }
        else {
            return -1;
        }
    }

    @Override
    public int compare(Triangle o1, Triangle o2) {
        Double p1 = ((Triangle) o1).Geron2();
        Double p2 = ((Triangle) o2).Geron2();
        if (p1 < p2) {
            return 1;
        } else if (p1 > p2){
            return -1;
        } else {
            return 0;
        }
    }
}
