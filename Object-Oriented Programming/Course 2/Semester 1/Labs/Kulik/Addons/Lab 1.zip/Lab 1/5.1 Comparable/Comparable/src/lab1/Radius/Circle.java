package lab1.Radius;

class Cicle implements Comparable<Cicle>{

    private int radius;

    public Cicle(int radius) {
        super();
        this.radius = radius;
    }

    public int getRadius() {
        return radius;
    }
    public void setRadius(int radius) {
        this.radius = radius;
    }

    public int compareTo(Cicle compareCircle) {

        int compareQuantity = ((Cicle) compareCircle).getRadius();

        return compareQuantity - this.radius;

    }
}

