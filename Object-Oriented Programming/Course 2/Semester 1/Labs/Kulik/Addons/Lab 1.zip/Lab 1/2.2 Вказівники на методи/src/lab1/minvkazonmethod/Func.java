package lab1.minvkazonmethod;

public interface Func {
    double f(double x);
}

