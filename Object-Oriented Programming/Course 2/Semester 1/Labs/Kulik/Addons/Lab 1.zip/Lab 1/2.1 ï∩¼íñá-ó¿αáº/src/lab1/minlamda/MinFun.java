package lab1.minlamda;

public interface MinFun {
    public double f(double x);
    default double min(double x) {
         return f(x);
    }
    static void printTable(double from, double to, double step, MinFun func) {
        double min = func.min(from);
        for (double x = from + step; x <= to; x += step) {
            if(min > func.min(x)){
                min = func.min(x);
            }
        }
        System.out.println("min = " + min);
    }
}
