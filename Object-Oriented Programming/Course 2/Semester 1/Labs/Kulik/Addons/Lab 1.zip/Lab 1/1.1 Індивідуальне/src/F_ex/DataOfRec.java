package F_ex;


import java.util.Arrays;
import java.util.Comparator;

public class DataOfRec extends BaseAbstract{
	private Reception [] recept=null;
	@Override
	public Reception getReception(int i){
		return recept[i];
	}
	@Override
    public void setReception(int i, Reception recep) {  
		recept[i]=recep;
	}
	@Override
	public int receptionsCount(){
		return recept==null?0:recept.length;
	}
	@Override
	public void addReception(Reception recep){
		Reception[] temp=new Reception[receptionsCount()+1];
		if(recept!=null)
			System.arraycopy(recept, 0, temp, 0, recept.length);
			temp[receptionsCount()]=recep;
			recept=temp;
	}
	@Override
	public void clearReception(){
		recept=null;
	}
	@Override
	public void sortByVisitors(){
		Arrays.sort(recept,new CompareByVisitors());
	}
	@Override
	public void sortByDate(){
		Arrays.sort(recept, new CompareByDate());
	}

}
