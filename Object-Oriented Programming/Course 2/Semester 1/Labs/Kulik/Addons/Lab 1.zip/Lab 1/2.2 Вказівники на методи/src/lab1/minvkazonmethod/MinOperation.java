package lab1.minvkazonmethod;

public interface MinOperation {
    double min(double from, double to, double step, Func c);
}
