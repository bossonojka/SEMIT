package lab1.Radius;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Test {
    public static void main(String args[]) {
        List<Cicle> al = new ArrayList<Cicle>();
        Cicle nameArray[] = {
                new Cicle(8),
                new Cicle(13),
                new Cicle(5),
                new Cicle(6),
        };
        List<Cicle> names = Arrays.asList(nameArray);
        Collections.sort(names);
        System.out.println(names.get(0).getRadius());
        System.out.println(names.get(1).getRadius());
        System.out.println(names.get(2).getRadius());
        System.out.println(names.get(3).getRadius());


    }
}

