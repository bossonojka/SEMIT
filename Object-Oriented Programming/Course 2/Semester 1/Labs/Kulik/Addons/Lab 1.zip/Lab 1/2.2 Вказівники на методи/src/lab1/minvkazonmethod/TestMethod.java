package lab1.minvkazonmethod;

public class TestMethod {
    static void print(MinOperation op, double from, double to, double step, Func c) {
        System.out.println(op.min(from, to, step, c));
    }

    static double ret_min(Func op, double p) {
        return op.f(p);
    }

    public static void main(String[] args) {
        MinMethod dm = new MinMethod();
        print(dm::min, -2, 2, 0.5, dm::function);
        print(dm::min, -4, 6, 0.5, dm::function);
    }
}

