package lab1.Plosha;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

public class Test {
    public static void main(String[] args) {
        List<Triangle> list = new ArrayList<Triangle>();
        Triangle a = new Triangle(5.3, 2.2, 4.1);
        list.add(a);
        list.add(new Triangle(7.9, 2.9, 6.2));
        list.add(new Triangle(10.1, 5.3, 9.3));
        list.add(new Triangle(17.5, 37.0, 30.0));
        list.add(new Triangle(1.6, 7.4, 9.2));

        Collections.sort(list,new Triangle());
        System.out.println(list.get(0).Geron());
        System.out.println(list.get(1).Geron());
        System.out.println(list.get(2).Geron());
        System.out.println(list.get(3).Geron());
        System.out.println(list.get(4).Geron());


    }
}

