package F_ex;

import java.util.Comparator;



public class CompareByDate implements Comparator<Reception> {

	public int compare(Reception c1, Reception c2) {
        return c2.getDay().compareTo(c1.getDay());
    }

}
