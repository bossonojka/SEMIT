package F_ex;

public class Reception {
	private int numOfVisit;
	private String day;
	private String shift;
	public Reception(int numOfVisit, String day, String shift) {
		super();
		this.numOfVisit = numOfVisit;
		this.day = day;
		this.shift = shift;
	}
	public int getNumOfVisit() {
		return numOfVisit;
	}
	public void setNumOfVisit(int numOfVisit) {
		this.numOfVisit = numOfVisit;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getShift() {
		return shift;
	}
	public void setShift(String shift) {
		this.shift = shift;
	}

}
