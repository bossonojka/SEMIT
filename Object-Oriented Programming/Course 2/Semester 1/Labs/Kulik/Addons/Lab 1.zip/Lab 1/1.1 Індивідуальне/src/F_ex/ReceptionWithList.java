package F_ex;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;


public class ReceptionWithList extends BaseAbstract{
	List<Reception> recept = new ArrayList<>();
	@Override
    public Reception getReception(int i) {
        return recept.get(i);
    }
	@Override
    public void setReception(int i, Reception recep) {
        recept.set(i, recep);
    }

    @Override
    public int receptionsCount() {
        return recept.size();
    }

    @Override
    public void addReception(Reception recep) {
        recept.add(recep);
    }

    @Override
    public void clearReception() {
        recept = new ArrayList<Reception>();
    }
    @Override
	public void sortByVisitors(){
		Collections.sort(recept,new CompareByVisitors());
	}
	@Override
	public void sortByDate(){
		Collections.sort(recept, new CompareByDate());
	}
	public static void main(String[] args) {
        new ReceptionWithList().test();
    }

}
