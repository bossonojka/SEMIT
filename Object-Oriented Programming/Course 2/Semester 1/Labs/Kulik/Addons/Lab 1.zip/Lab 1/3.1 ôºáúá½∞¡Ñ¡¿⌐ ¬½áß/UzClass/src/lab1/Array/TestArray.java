package lab1.Array;

public class TestArray {
    public static void main(String[] args) {
        MyArray<Double> a = new MyArray<>(4.0, 5.6);
        a.set(0, 7.4);
        a.printAll();
        MyArray<Double> b = new MyArray<>(3);
        b.set(0, 1.0);
        b.set(1, 2.0);
        b.set(2, 4.0);
        b.add(9.0);
        b.delElem(1);
        Double[] j = {2.3, 7.8, 3.5};
        b.addGroup(j);
        b.printAll();
    }
}
