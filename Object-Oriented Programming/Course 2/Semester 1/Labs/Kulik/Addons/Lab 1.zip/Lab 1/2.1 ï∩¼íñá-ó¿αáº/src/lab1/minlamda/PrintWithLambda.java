package lab1.minlamda;

import lab1.minlamda.MinFun;

public class PrintWithLambda {
    public static void main(String[] args) {
        MinFun.printTable(-2.0, 2.0, 0.5, x -> x * x * x);
    }
}

