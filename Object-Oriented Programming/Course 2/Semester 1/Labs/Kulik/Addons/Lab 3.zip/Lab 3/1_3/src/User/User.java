package User;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class User{
    @SuppressWarnings("resource")
    public static void main(String[] args) {
        System.out.println("Введите количество пользователей в массиве: ");
        String s=new Scanner(System.in).nextLine();
        Pattern p = Pattern.compile("-[0-9]+|[0-1]");
        Matcher m = p.matcher(s);
        if(s.matches("(\\D|\\s)+")||m.find()){
            do{
                System.out.print("Не корректное значение. Введите еще раз: ");
                s=new Scanner(System.in).nextLine();
                m = p.matcher(s);
            }
            while(s.matches("(\\D|\\s)+")||m.find());
        }
        int size = Integer.parseInt(s);
        SortedMap<String, String> users = new TreeMap<>();
        for(int i=0;i<size;i++){
            System.out.println("Введите имя пользователя под № "+(i+1)+": ");
            String key=new Scanner(System.in).nextLine();
            if(users.containsKey(key)) {
                do {
                    System.out.println("Такой пользователь уже существует!");
                    System.out.println("Введите имя пользователя под № "+(i+1)+": ");
                    key=new Scanner(System.in).nextLine();}while(users.containsKey(key));
            }

            System.out.println("Введите пароль: ");
            String value=new Scanner(System.in).nextLine();
            users.put(key,value);
        }
        System.out.println("\nПользователи с длинной пароля больше 6 цифр: \n");
        for (Map.Entry<?, ?> entry : users.entrySet()){
            if(entry.getValue().toString().length()>6)
                System.out.println("Имя пользователя: "+entry.getKey() + " \nПароль: " + entry.getValue()+"\n");}
    }
}