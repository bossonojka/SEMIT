package generated;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Recept" maxOccurs="unbounded" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>string">
 *                 &lt;attribute name="day" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="numOfVisit" type="{http://www.w3.org/2001/XMLSchema}byte" />
 *                 &lt;attribute name="shift" type="{http://www.w3.org/2001/XMLSchema}string" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="name" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="spec" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "recept"
})
@XmlRootElement(name = "Doc")
public class Doc {

    @XmlElement(name = "Recept")
    protected List<Doc.Recept> recept;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "spec")
    protected String spec;

    /**
     * Gets the value of the recept property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the recept property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRecept().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Doc.Recept }
     *
     *
     */
    public List<Doc.Recept> getRecept() {
        if (recept == null) {
            recept = new ArrayList<Doc.Recept>();
        }
        return this.recept;
    }

    /**
     * Gets the value of the name property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the spec property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getSpec() {
        return spec;
    }

    /**
     * Sets the value of the spec property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setSpec(String value) {
        this.spec = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     *
     * <p>The following schema fragment specifies the expected content contained within this class.
     *
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>string">
     *       &lt;attribute name="day" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="numOfVisit" type="{http://www.w3.org/2001/XMLSchema}byte" />
     *       &lt;attribute name="shift" type="{http://www.w3.org/2001/XMLSchema}string" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     *
     *
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
            "value"
    })
    public static class Recept {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "day")
        protected String day;
        @XmlAttribute(name = "numOfVisit")
        protected Integer numOfVisit;
        @XmlAttribute(name = "shift")
        protected String shift;

        /**
         * Gets the value of the value property.
         *
         * @return
         *     possible object is
         *     {@link String }
         *
         */

        public Recept(Integer num,String day,String shift) {
            numOfVisit=num;
            this.day=day;
            this.shift=shift;
        }

        public Recept() {
            // TODO Auto-generated constructor stub
        }

        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         *
         * @param value
         *     allowed object is
         *     {@link String }
         *
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the day property.
         *
         * @return
         *     possible object is
         *     {@link String }
         *
         */
        public String getDay() {
            return day;
        }

        /**
         * Sets the value of the day property.
         *
         * @param value
         *     allowed object is
         *     {@link String }
         *
         */
        public void setDay(String value) {
            this.day = value;
        }

        /**
         * Gets the value of the numOfVisit property.
         *
         * @return
         *     possible object is
         *     {@link Byte }
         *
         */
        public Integer getNumOfVisit() {
            return numOfVisit;
        }

        /**
         * Sets the value of the numOfVisit property.
         *
         * @param value
         *     allowed object is
         *     {@link Byte }
         *
         */
        public void setNumOfVisit(Integer value) {
            this.numOfVisit = value;
        }

        /**
         * Gets the value of the shift property.
         *
         * @return
         *     possible object is
         *     {@link String }
         *
         */
        public String getShift() {
            return shift;
        }

        /**
         * Sets the value of the shift property.
         *
         * @param value
         *     allowed object is
         *     {@link String }
         *
         */
        public void setShift(String value) {
            this.shift = value;
        }

    }

}
