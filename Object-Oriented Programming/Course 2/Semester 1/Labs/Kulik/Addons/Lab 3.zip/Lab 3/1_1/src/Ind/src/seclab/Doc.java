package seclab;

public abstract class Doc {
    private String name;
    private String spec;

    public Doc() {
    }

    public Doc(String name, String spec) {
        this.name = name;
        this.spec = spec;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpec() {
        return spec;
    }

    public void setSpec(String spec) {
        this.spec = spec;
    }


    abstract public Recept minOfVisitors();
    abstract public int sumOfVisitors();
    abstract public void addRecept(Recept recept);
    abstract public void sortByVisitors();
    abstract public void clearRecept();
    abstract public void sortByDay();
    abstract public Recept getRecept(int i);
    abstract public void setRecept(int i , Recept recept);
    abstract public int receptCount();
}