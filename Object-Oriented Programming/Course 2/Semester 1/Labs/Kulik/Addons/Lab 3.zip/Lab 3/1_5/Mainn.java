

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.AbstractMap;
import java.util.Comparator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;

public class Mainn extends Application {

	private VBox vBox;private VBox vBox1;
	private Map<String, String> map = new TreeMap<>();
	private ObservableList<Map.Entry<String, String>> observable;
	private TableView<Map.Entry<String, String>> table = new TableView<>();
	private TableColumn<Map.Entry<String, String>, String> russian = new TableColumn<>("Russian");
	private TableColumn<Map.Entry<String, String>, String> english = new TableColumn<>("English");
	private TextArea tArea = new TextArea();

	@Override
	public void start(Stage primaryStage) throws Exception {
		table.setEditable(true);
		fillList();
		initColumns();
		initPane();
		find();

		observable = FXCollections.observableArrayList(map.entrySet());
		BorderPane root = new BorderPane();
		table.getColumns().clear();
		table.setItems(observable);

		table.getColumns().setAll(english, russian);
		
		root.setCenter(table);
		root.setLeft(vBox);
		root.setRight(vBox1);

		Scene scene = new Scene(root);
		primaryStage.setTitle("Vocabulary");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	private void initColumns() {
		russian.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Map.Entry<String, String>, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(
							TableColumn.CellDataFeatures<Map.Entry<String, String>, String> p) {
						return new SimpleStringProperty(p.getValue().getValue());
					}
				});
		english.setCellValueFactory(
				new Callback<TableColumn.CellDataFeatures<Map.Entry<String, String>, String>, ObservableValue<String>>() {

					@Override
					public ObservableValue<String> call(
							TableColumn.CellDataFeatures<Map.Entry<String, String>, String> p) {
						return new SimpleStringProperty(p.getValue().getKey());
					}
				});

		russian.setCellFactory(TextFieldTableCell.forTableColumn());

		english.setCellFactory(TextFieldTableCell.forTableColumn());
	}
	
	@Override
	public void stop() {
		FXCollections.sort(observable, new CompareFXCollect());
		try (PrintWriter pWriter = new PrintWriter(new FileWriter("dictionary.txt"));) {
			for (Entry<String, String> entry : observable) {
				pWriter.println(entry.getKey() + " - " + entry.getValue());
			}

		} catch (Exception e) {
			System.out.println("error");
			e.printStackTrace();
		}
	}
	private void find() {
		Label l =new Label("Search");
		TextField tField = new TextField();
		vBox1=new VBox(l,tField, tArea);
		vBox1.setMaxSize(200,100);
		vBox1.setPadding(new Insets(20, 30, 30, 30));
		tField.textProperty().addListener((obs, oldValue, newValue) -> {
			tArea.clear();
		     for (Entry<String, String> entry : observable) {
		       if (entry.getKey().contains(newValue) || contain(newValue, entry.getValue())) {
		          tArea.setText(entry.toString());
		        }
		      }
		    });
		
	}

	private void initPane() {
		Button buttonAdd = new Button("Add word");
		TextField tField = new TextField();
		TextField result = new TextField();
		Label l1=new Label("Englsih word");
		Label l2=new Label("Russian word");
		vBox = new VBox(buttonAdd,l1, tField,l2, result);
		vBox.setPadding(new Insets(7, 7, 7, 7));
		buttonAdd.setOnAction(event -> {
			observable.add(new AbstractMap.SimpleEntry(tField.getText(),result.getText()));
			table.scrollTo(observable.size());
			FXCollections.sort(observable, new CompareFXCollect());
		});
		
	}

	private boolean contain(String value, String entryValues) {
		String[] strings = entryValues.split(",");
		for (int i=0;i<strings.length;i++) {
			char[] m=strings[i].toCharArray();
			for(int j=0;j<m.length;j++) {
			if (strings[i].equals(value)||strings[i].equals(m[j])) {
				return true;
			}
		}}
		return false;
	}

	private void fillList() {
		try {
			int count = 0;
			FileReader fReader = new FileReader("dictionary.txt");
			BufferedReader bReader = new BufferedReader(fReader);
			String[] strings;
			String string;
			while (count++ < 200) {
				string = bReader.readLine();
				if (string == null) {
					continue;
				}
				strings = string.split(" - ");
				if (strings == null || strings[0].contains(":")) {
					continue;
				}
				for (int i = 1; i < strings.length; i++) {
					map.put(strings[0], strings[i]);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}

	class CompareFXCollect implements Comparator<Map.Entry<String, String>> {

		@Override
		public int compare(Entry<String, String> o1, Entry<String, String> o2) {
			int res = String.CASE_INSENSITIVE_ORDER.compare(o1.getKey(), o2.getKey());
			if (res == 0) {
				res = o1.getKey().compareTo(o2.getKey());
			}
			return res;
		}
	}

}
