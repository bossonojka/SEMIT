package sample;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.FlowPane;
import javafx.event.Event;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


public class Calc extends Application{
    private TextField f1, f2, f3;
    private RadioButton r1,r2,r3,r4;

    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("Calc");
        r1 = new RadioButton("Plus");
        r2 = new RadioButton("Minus");
        r3 = new RadioButton("Multiply");
        r4 = new RadioButton("Division");
        r1.setOnAction(this::buttonClick1);
        r2.setOnAction(this::buttonClick2);
        r3.setOnAction(this::buttonClick3);
        r4.setOnAction(this::buttonClick4);
        ToggleGroup radioGroup = new ToggleGroup();
        r1.setToggleGroup(radioGroup);
        r2.setToggleGroup(radioGroup);
        r3.setToggleGroup(radioGroup);
        r4.setToggleGroup(radioGroup);

        FlowPane rootNode = new FlowPane(10, 10);
        rootNode.setAlignment(Pos.CENTER);
        Scene scene = new Scene(rootNode, 200, 200);
        stage.setScene(scene);

        f1 = new TextField();
        f2 = new TextField();
        f3 = new TextField(""); f3.setEditable(false);
        rootNode.getChildren().addAll(f1, f2, r1,r2,r3,r4, f3);
        stage.show();
    }
    private void buttonClick1(Event event) {
        try {
            double i = Double.parseDouble(f1.getText());
            double j = Double.parseDouble(f2.getText());
            double k = i + j;
            f3.setText(k + "");
        }
        catch (NumberFormatException e1) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Please enter values!");
            alert.showAndWait();
        }
    }

    private void buttonClick2(Event event) {
        try {
            double i = Double.parseDouble(f1.getText());
            double j = Double.parseDouble(f2.getText());
            double k = i - j;
            f3.setText(k + "");
        }
        catch (NumberFormatException e1) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Please enter values!");
            alert.showAndWait();
        }
    }

    private void buttonClick3(Event event) {
        try {
            double i = Double.parseDouble(f1.getText());
            double j = Double.parseDouble(f2.getText());
            double k = i * j;
            f3.setText(k + "");
        }
        catch (NumberFormatException e1) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Please enter values!");
            alert.showAndWait();
        }
    }

    private void buttonClick4(Event event) {
        try {
            double i = Double.parseDouble(f1.getText());
            double j = Double.parseDouble(f2.getText());
            double k = i / j;
            f3.setText(k + "");
        }
        catch (NumberFormatException e1) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Please enter values!");
            alert.showAndWait();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}