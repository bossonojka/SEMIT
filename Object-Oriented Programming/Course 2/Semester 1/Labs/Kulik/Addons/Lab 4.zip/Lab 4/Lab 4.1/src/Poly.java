import org.mariuszgromada.math.mxparser.Argument;
import org.mariuszgromada.math.mxparser.Expression;

import java.util.function.Function;

public class Poly implements Function<Double, Double> {

    Argument argX = new Argument("x");
    Expression y;

    @Override
    public Double apply(Double x) {
        argX.setArgumentValue(x);
        return y.calculate();
    }
    public Poly(String fun) {
        fun = fun.replaceAll(" ", "");
        y = new Expression(fun, argX);
    }
}
