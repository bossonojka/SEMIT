
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

class Producer implements Runnable {
    private BlockingQueue<Integer> queue;
    int countToAdd;

    public Producer(BlockingQueue<Integer> queue, int countToAdd) {
        this.queue = queue;
        this.countToAdd = countToAdd;
    }

    public void run() {
        // Добавление чисел:
        try {
            for (int i = 1; i <= countToAdd; i++) {
                queue.put(i);
                System.out.printf("Added: %d%n", i);
                Thread.sleep(100);
            }
        }
        catch (InterruptedException e) {
            System.out.println("Producer interrupted");
        }
    }
}

class Consumer implements Runnable {
    private BlockingQueue<Integer> queue;
    int countToTake;

    public Consumer(BlockingQueue<Integer> queue, int countToTake) {
        this.queue = queue;
        this.countToTake = countToTake;
    }

    public void run() {
        // Вычитание чисел:
        double j=0;
        try {
            for (double i = 1; i <= countToTake; i++) {
                j+=(double)queue.take();
                double d = j/i;
                System.out.println("Average:"+d);
            }
        }
        catch (InterruptedException e) {
            System.out.println("Consumer interrupted");
        }
    }
}

public class BlockingQueueDemo {

    public static void main(String[] args) throws InterruptedException {
        System.out.println("Enter the value elements of the line");
        Scanner in = new Scanner(System.in);
        int count = in.nextInt();
        BlockingQueue<Integer> queue = new ArrayBlockingQueue<>(count);

        // Создаем два потока - для записи и чтения:
        Thread producerThread = new Thread(new Producer(queue, count));
        Thread consumerThread = new Thread(new Consumer(queue, count));
        producerThread.start();
        consumerThread.start();

        // Ждем 10 секунд и прерываем 1 поток:
        Thread.sleep(10000);
        producerThread.interrupt();
    }

}