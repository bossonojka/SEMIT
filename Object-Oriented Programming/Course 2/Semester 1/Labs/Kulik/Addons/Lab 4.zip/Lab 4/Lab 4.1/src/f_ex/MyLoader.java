package f_ex;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;

public class MyLoader extends ClassLoader {

	public MyLoader() {
	}

	public Class loadFG() {
		try {
			InputStream input = new FileInputStream("C://Users//lena//workspace//f_ex//bin//FGFunc.class");
			ByteArrayOutputStream buffer = new ByteArrayOutputStream();
			int data = input.read();

			while (data != -1) {
				buffer.write(data);
				data = input.read();
			}

			input.close();

			byte[] classData = buffer.toByteArray();

			return defineClass("FGFunc", classData, 0, classData.length);
		} catch (Exception e) {
			System.out.println("error");
			e.printStackTrace();

		}
		return null;
	}

}

