import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;

import java.util.function.Function;

public class Controller {
    Main main;

    @FXML
    private TextField af;
    @FXML
    private TextField bf;
    @FXML
    private TextField ff;
    @FXML
    private TextField gf;
    @FXML
    private LineChart<Number,Number> chart;


    public Controller() {
    }

    public void setMain(Main main) {
        this.main = main;
    }


    @FXML
    private void handleDraw() {
        Function<Double,Double> f = new Poly(ff.getText());
        Function<Double,Double> g = new Poly(gf.getText());
        chart.getData().clear();
        double a = Double.parseDouble(af.getText());
        double b = Double.parseDouble(bf.getText());
        XYChart.Series poly = new XYChart.Series<>();

        Function<Double,Double> h = (Double x) -> {return a*f.apply(x) - b*g.apply(x);};

        for (double j = 0.1; j <= 50; j += 0.1)
            poly.getData().add(new XYChart.Data<Number, Number>(j, h.apply(j)));

        chart.getData().add(poly);
        for (XYChart.Data<Number, Number> data : chart.getData().get(0).getData()) {
            StackPane stackPane = (StackPane) data.getNode();
            stackPane.setDisable(true);
            stackPane.setVisible(false);
        }
    }

}
