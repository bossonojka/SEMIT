package application;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import xml.StoreData;
import xml.StoreData.HourData;

public class XmlStore extends AbstractStore{

	private StoreData sd;
	
	public XmlStore(){
		sd = new StoreData();
	}
	
	@Override
	public String getName() {
		return sd.getName();
	}

	@Override
	public void setName(String name) {
		sd.setName(name);
	}

	@Override
	public String getAddress() {
		return sd.getAddress();
	}

	@Override
	public void setAddress(String address) {
		sd.setAddress(address);
	}

	@Override
	public Hour getHour(int i) {
		HourData hourData = sd.getHourData().get(i);
		return new Hour(hourData.getCustomers(), hourData.getComment());
	}

	@Override
	public void setHour(int i, Hour hour) {
		HourData hourData = new HourData();
		hourData.setCustomers(hour.getCustomers());
		hourData.setComment(hour.getComment());
		sd.getHourData().set(i, hourData);
	}

	@Override
	public void addHour(Hour hour) {
		HourData hourData = new HourData();
		hourData.setCustomers(hour.getCustomers());
		hourData.setComment(hour.getComment());
		sd.getHourData().add(hourData);
	}

	@Override
	public int hoursCount() {
		return sd.getHourData().size();
	}

	@Override
	public void clearHours() {
		sd.getHourData().clear();
		
	}

	@Override
	public void sortByCustomers() {
		Hour[] arr = new Hour[hoursCount()];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = getHour(i);
        }
        Arrays.sort(arr, Collections.reverseOrder());
        for (int i = 0; i < arr.length; i++) {
            setHour(i, arr[i]);
        }
	}

	@Override
	public void sortByComments() {
		Hour[] arr = new Hour[hoursCount()];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = getHour(i);
        }
        Arrays.sort(arr, new CompareByComments());
        for (int i = 0; i < arr.length; i++) {
            setHour(i, arr[i]);
        }
	}

	@Override
	public boolean readFromFile(String fileName) {
		try {
            JAXBContext jaxbContext = JAXBContext.newInstance("xml");
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            sd = (StoreData) unmarshaller.unmarshal(new FileInputStream(fileName));
            return true;
        }
        catch (FileNotFoundException | JAXBException e) {
            return false;
        }  
	}

	@Override
	public boolean writeToFile(String fileName) {
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance("xml");
            Marshaller marshaller = jaxbContext.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            marshaller.marshal(sd, new FileWriter(fileName));
            return true;
        }
        catch (JAXBException | IOException e) {
            return false;
        }
	}

}
