package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

public class SampleController {
	@FXML TextField field1, field2, result;
	@FXML RadioButton radio1, radio2, radio3, radio4;
	@FXML ToggleGroup group;
	@FXML Button button;
	@FXML Label label1, label2, label3, label4;
	
	@FXML public void calculate(ActionEvent Event){
		double res = 0;
		try {
		double first = Double.parseDouble(field1.getText());
		double second = Double.parseDouble(field2.getText());
			if(radio1.isSelected()){
				res = first + second;
			}
			if(radio2.isSelected()){
				res = first - second;
			}
			if(radio3.isSelected()){
				res = first * second;
			}
			if(radio4.isSelected()){
				if (second == 0){
					throw new ArithmeticException();
				}
				res = first / second;
			}
			result.setText("" + res);
		} catch (NumberFormatException e){
			result.setText("Некорректные данные");
		} catch (ArithmeticException e){
			result.setText("Деление на ноль");
		}
		
	}
}
