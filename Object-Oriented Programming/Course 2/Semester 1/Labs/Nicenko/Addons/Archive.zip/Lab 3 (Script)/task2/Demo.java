package oop.lab3.task2;

public class Demo {
	public static void main(String[] args) {
		Month m = Month.APRIL;
		System.out.println("Текущий месяц: " + m);
		System.out.println("Предыдущий месяц: " + m.prev());
		System.out.println("Следующий месяц: " + m.next());
		System.out.println("Все месяцы: ");
		System.out.println(m.allMonths());
	}
}
