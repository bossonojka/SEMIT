package application;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;

import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.FileChooser;
import javafx.util.converter.IntegerStringConverter;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;


public class SampleController implements Initializable {

    private XmlStore store = new XmlStore();

    private ObservableList<Hour> observableList;
    
    public static void showMessage(String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("");
        alert.setHeaderText(message);
        alert.showAndWait();
    }

    public static void showError(String message) {
    	 Alert alert = new Alert(AlertType.ERROR);
         alert.setTitle("Ошибка");
         alert.setHeaderText(message);
         alert.showAndWait();
    }
 
    public static FileChooser getFileChooser(String title) {
    	  FileChooser fileChooser = new FileChooser();
          fileChooser.setInitialDirectory(new File(".")); 
          fileChooser.getExtensionFilters().add(
              new FileChooser.ExtensionFilter("XML-файлы (*.xml)", "*.xml"));
          fileChooser.getExtensionFilters().add(
              new FileChooser.ExtensionFilter("Все файлы (*.*)", "*.*"));
          fileChooser.setTitle(title);
          return fileChooser;
    }
    
    @FXML TextField textFieldStore;
    @FXML TextField textFieldAddress;
    @FXML TextField textFieldText;
    @FXML TextArea textAreaResults;
    @FXML TableView<Hour> tableViewHours;
    @FXML TableColumn<Hour, Integer> tableColumnCustomers;
    @FXML TableColumn<Hour, String> tableColumnComments;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
    	tableViewHours.setPlaceholder(new Label(""));
    }
    
    
    @FXML public void doNew(ActionEvent event) {
    	store = new XmlStore();
        observableList = null;
        textFieldStore.setText("");
        textFieldAddress.setText("");
        textFieldText.setText("");
        textAreaResults.setText("");
        tableViewHours.setItems(null);
        tableViewHours.setPlaceholder(new Label(""));
    }
    
    @FXML public void doOpen(ActionEvent event) {
    	 FileChooser fileChooser = getFileChooser("Открыть XML-файл");
         File file;
         if ((file = fileChooser.showOpenDialog(null)) != null) {
             try {
                 store.readFromFile(file.getCanonicalPath());
                 textFieldStore.setText(store.getName());
                 textFieldAddress.setText(store.getAddress() + "");
                 textAreaResults.setText("");
                 tableViewHours.setItems(null);
                 updateTable();
             }
             catch (IOException e) {
                 showError("Файл не найден");
             }
         }
    }

    @FXML public void doSave(ActionEvent event) {
    	 FileChooser fileChooser = getFileChooser("Сохрани XML-файл");
         File file;
         if ((file = fileChooser.showSaveDialog(null)) != null) {
             try {
                 updateSourceData();
                 store.writeToFile(file.getCanonicalPath());
                 showMessage("Результаты успешно сохранены");
             }
             catch (Exception e) {
                 showError("Ошибка записи в файл");
             }
         }
    }
    
    @FXML public void doExit(ActionEvent event) {
    	Platform.exit();
    }
    
    @FXML public void doAdd(ActionEvent event) {
    	 if (observableList == null) { 
             updateTable();
         }
         observableList.add(new Hour(0, ""));
    }
    
    @FXML public void doRemove(ActionEvent event) {
        if (observableList == null) {
            return;
        }
        if (observableList.size() > 0) {
            observableList.remove(observableList.size() - 1);
        }
        if (observableList.size() <= 0) {
            observableList = null;
        }
    }
    
    @FXML public void doSortByCustomers(ActionEvent event) {
    	updateSourceData();
        store.sortByCustomers();
        updateTable();
    }
    
    @FXML public void doSortByComments(ActionEvent event) {
        updateSourceData();
        store.sortByComments();
        updateTable();
    }
    
    @FXML public void doAbout(ActionEvent event) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("О программе...");
        alert.setHeaderText("Данные про посетителей");
        alert.setContentText("Версия 1.0");
        alert.showAndWait();
    } 

    
    @FXML public void nameChanged(ActionEvent event) {
        store.setName(textFieldStore.getText());
    }
   
    @FXML public void addressChanged(ActionEvent event) { 
        try {
            String address = textFieldAddress.getText();
            store.setAddress(address);
        }
        catch (NumberFormatException e) {
        	textFieldAddress.setText(store.getAddress() + "");
        }
    }
    
    @FXML public void doSearchByWord(ActionEvent event) {
    	updateSourceData();
        textAreaResults.setText("");
        for (int i = 0; i < store.hoursCount(); i++) {
            Hour c = store.getHour(i);          
            if (c.containsWord(textFieldText.getText())) {
                showResults(c);
            }
        }
    }

    private void showResults(Hour hour) {
    	textAreaResults.appendText("Посетителей " + hour.getCustomers() + "\n");
        textAreaResults.appendText("Комvентарий: " + hour.getComment() + "\n");
        textAreaResults.appendText("\n");     
    }
   
    private void updateSourceData() {
    	 store.clearHours();
         for (Hour c : observableList) {
             store.addHour(c);
         }
    }

    
    private void updateCustomers(CellEditEvent<Hour, Integer> t) {
    	Hour c = (Hour) t.getTableView().getItems().get(t.getTablePosition().getRow());
    	if (t.getNewValue() < 0){
    		c.setCustomers(0);
    	} else {
    		c.setCustomers(t.getNewValue());
    	}
    }
   
    private void updateComments(CellEditEvent<Hour, String> t) {
        Hour c = (Hour) t.getTableView().getItems().get(t.getTablePosition().getRow());
        c.setComment(t.getNewValue());
    }
    
    private void updateTable() {
        List<Hour> list = new ArrayList<Hour>();
        observableList = FXCollections.observableList(list);
        for (int i = 0; i < store.hoursCount(); i++) {
            list.add(store.getHour(i));
        }
        tableViewHours.setItems(observableList);
        
        tableColumnCustomers.setCellValueFactory(new PropertyValueFactory<>("customers"));
        tableColumnCustomers.setCellFactory(
            TextFieldTableCell.<Hour, Integer>forTableColumn(new IntegerStringConverter()));
        tableColumnCustomers.setOnEditCommit(t -> updateCustomers(t));
        tableColumnComments.setCellValueFactory(new PropertyValueFactory<>("comment"));
        tableColumnComments.setCellFactory(TextFieldTableCell.forTableColumn());
        tableColumnComments.setOnEditCommit(t -> updateComments(t));
    }

}