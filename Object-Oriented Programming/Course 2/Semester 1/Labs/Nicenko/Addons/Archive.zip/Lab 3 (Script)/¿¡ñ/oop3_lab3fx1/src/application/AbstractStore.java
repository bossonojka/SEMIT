package application;

import java.util.Comparator;

public abstract class AbstractStore {
	
	public abstract String getName();
    public abstract void setName(String name);
    public abstract String getAddress();
    public abstract void setAddress(String address);
	abstract public Hour getHour(int i);
	abstract public void setHour(int i, Hour hour);
	abstract public int hoursCount();
	abstract public void addHour(Hour hour);
	abstract public void clearHours();
	abstract public void sortByCustomers();
	abstract public void sortByComments();
	abstract public boolean readFromFile(String fileName);
    abstract public boolean writeToFile(String fileName);
    
    public String toString() {
        StringBuffer result = new StringBuffer();
        result.append(getName() + ", " + getAddress());
        for (int i = 0; i < hoursCount(); i++) {
            result.append("\nCustomers: " + getHour(i).getCustomers() + "; comment: " + getHour(i).getComment());
        }
        return result.toString();
    }
    
    public int customersCount(){
    	int sum = 0;
    		for (int i = 0; i < hoursCount(); i++){
    			sum += getHour(i).getCustomers();
    		}
    	return sum;
    }
    
    public int minHour(){
    	int minIndex = 0, minValue = getHour(0).getCustomers();
    	for (int i = 0; i < hoursCount(); i++){
    		if(getHour(i).getCustomers() < minValue){
    			minValue = getHour(i).getCustomers();
    			minIndex = i;
    		}
    	}
    	return minIndex;
    }
    
    public void findWord(String word) {
    	boolean isFound = false;
    	for(int i = 0; i < hoursCount(); i++){
            if (getHour(i).containsWord(word)) {
            	System.out.print("Hour " + i + " has word " + word.toLowerCase() + "\n");
            	isFound = true;
            }
    	}
    	if(!isFound){
			System.out.print("Word " + word.toLowerCase() + " not found at any hour");
		}
    }
    
    class CompareByComments implements Comparator<Hour> {

        public int compare(Hour c1, Hour c2) {
            return c1.getComment().compareTo(c2.getComment());
        }

    }

}