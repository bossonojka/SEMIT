package oop.lab3.task2;

import java.text.DecimalFormat;

public enum Month {
	JANUARY(31),
	FEBRUARY(28),
	MARCH(31),
	APRIL(30),
	MAY(31),
	JUNE(30),
	JULY(31),
	AUGUST(31),
	SEPTEMBER(30),
	OCTOBER(31),
	NOVEMBER(30),
	DECEMBER(31);
	
	private final int days;
	Month(int days){
		this.days = days;
	}
	public int getDays() {
		return days;
	}
	
	public String toString(){
		switch(this){
		case JANUARY: return "Январь";
		case FEBRUARY: return "Февраль";
		case MARCH: return "Март";
		case APRIL: return "Апрель";
		case MAY: return "Май";
		case JUNE: return "Июнь";
		case JULY: return "Июль";
		case AUGUST: return "Август";
		case SEPTEMBER: return "Сентябрь";
		case OCTOBER: return "Октябрь";
		case NOVEMBER: return "Ноябрь";
		case DECEMBER: return "Декабрь";
		}
		return null;
	}
	
	public String season(){
		switch(this.ordinal() + 1){
		case 1 | 2: return "Зима";
		case 3 | 4 | 5: return "Весна";
		case 6 | 7 | 8: return "Лето";
		case 9 | 10 | 11: return "Осень";
		case 12: return "Зима";
		}
		return null;
	}
	
	Month next(){
		return values()[(ordinal() + 1) % values().length];
	}
	
	Month prev(){
		return values()[(ordinal() - 1) % values().length];
	}
	
	public String allMonths(){
		StringBuffer res = new StringBuffer();
		DecimalFormat df = new DecimalFormat("00");
		for (int i = 0; i < values().length; i++){
			res.append(df.format((values()[i].ordinal() + 1)) + " ");
			res.append(values()[i] + ", дней " + values()[i].getDays() + "\n");
		}
		return res.toString();
	}
}