package oop.lab3.task3;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {
	public static void main(String[] args) {
		Map<String, String> map = new HashMap<>();
		map.put("Efsef", "ls=-6q4GAR");
		map.put("Acscc", "sv]x*vm");
		map.put("Acscc", "sv]x*vmadaef");
		map.put("Awdawf", "Q3№");
		map.put("Fgnyf", "lA0№=6q4GAR");
		map.put("Afaf", "PSWKe");
		map.put("Ahnf", "T?GjktgM");

		for (Map.Entry<String, String> entry : map.entrySet()) {
		    System.out.println("name = " + entry.getKey() + " pass =" + entry.getValue());
		}
	}
}
