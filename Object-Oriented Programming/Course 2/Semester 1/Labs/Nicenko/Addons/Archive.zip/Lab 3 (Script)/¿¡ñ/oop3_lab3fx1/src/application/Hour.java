package application;

import java.util.StringTokenizer;

public class Hour implements Comparable<Hour>{
	private int customers;
	private String comment;
	
	public Hour(int customers, String comment){
		this.customers = customers;
		this.comment = comment;
	}

	
	public String getComment() {
        return comment;
	}
	
	public void setComment(String comment) {
        this.comment = comment;
    }
	
	public int getCustomers(){
		return customers;
    }
		
    public void setCustomers(int customers){
        this.customers = customers;
    }
    
    public boolean containsWord(String word) {
        StringTokenizer st = new StringTokenizer(comment);
        while(st.hasMoreTokens()){
        	if(st.nextToken().equalsIgnoreCase(word)){
        		return true;
        	}
        }
		return false;
        
    }
    
    private void testWord(String word){
    	if(containsWord(word)){
    		System.out.print("Comment of hour has word " + word + "\n");
    	}
    	else{
    		System.out.print("Comment of hour has not word " + word + "\n");
    	}
    		
    }

	public int compareTo(Hour h) {
		return Integer.compare(getCustomers(), h.getCustomers());
	}

}