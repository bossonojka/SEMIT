package lab3_2;

import java.util.Scanner;

public class ShowAllMethods {
    @SuppressWarnings("resource")
    public static void main(String[] args) {
        System.out.println("Please, enter a name of class: ");
        String nameOfClass = new Scanner(System.in).next();
        try{
            Class<?> c = Class.forName(nameOfClass);
            for(int i=0;i<c.getDeclaredFields().length;i++) {
              c.getDeclaredFields()[i].setAccessible(true);
              System.out.println("Name: "+c.getDeclaredFields()[1].getName()+" Type: "+c.getDeclaredFields()[i].getType());
              if(c.getDeclaredFields()[i].getModifiers()==1)
                  System.out.println("Modifiers: public");
                if(c.getDeclaredFields()[i].getModifiers()==2)
                    System.out.println("Modifiers: private");
                if(c.getDeclaredFields()[i].getModifiers()==3)
                    System.out.println("Modifiers: protected");
            }
        }
        catch(ClassNotFoundException e){
            System.err.println("Wrong the name of class");
        }
    }
}
