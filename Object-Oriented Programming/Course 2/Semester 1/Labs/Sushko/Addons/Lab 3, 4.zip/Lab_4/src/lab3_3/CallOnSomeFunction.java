package lab3_3;

import java.util.Scanner;

class A{
    public void a(){System.out.println("It is class \"A\" ");}
}

class B{
    public void b(){System.out.println("It is class \"B\" ");}
}

class C{
    public void c(){System.out.println("It is class \"C\" ");}
}
public class CallOnSomeFunction {
    public static void main(String[] args) {
        Object o;
        System.out.println("Enter a number of some class: ");
        int i = new Scanner(System.in).nextInt();
        switch (i){
            case 1 :
                o = new A();
                break;
            case 2 :
                o = new B();
                break;
            case 3 :
                o = new C();
                break;
            default:
                System.out.println("This number of class is not correct ");
                return;
        }
        if(o instanceof A)
            ((A) o).a();
        if(o instanceof B)
            ((B) o).b();
        if(o instanceof C)
            ((C) o).c();
    }
}
