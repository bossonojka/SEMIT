package lab3_2;

public enum Month {
    January(31), FEBRUARY(28), MARCH(31), APRIL(30), MAY(31), JUNE(30), JULY(31),
    AUGUST(31), SEPTEMBER(30), OCTOBER(31), NOVEMBER(30), DECEMBER(31);
    private int day;
    Month(int i) {
        this.day = i;
    }

    Month next(){
        if(ordinal()==11) {
            Month month = Month.values()[0];
            return month;
        }
        Month month = Month.values()[ordinal()+1];
        return month;
    }

    Month prev(){
        if(ordinal()==0) {
            Month month = Month.values()[11];
            return month;
        }
        Month month = Month.values()[ordinal()-1];
        return month;
    }

    void season(){
        switch(ordinal()){
            case 0:
                System.out.println("Winter");
            case 1:
                System.out.println("Winter");
            case 11:
                System.out.println("Winter");
            case 2:
                System.out.println("Spring");
            case 3:
                System.out.println("Spring");
            case 4:
                System.out.println("Spring");
            case 5:
                System.out.println("Summer");
            case 6:
                System.out.println("Summer");
            case 7:
                System.out.println("Summer");
            case 8:
                System.out.println("Fall");
            case 9:
                System.out.println("Fall");
            case 10:
                System.out.println("Fall");
        }

    }

    void print(){
        System.out.println("Январь Февраль Март Апрель Май Июнь Июль Август Сентябрь Ноябрь Октябрь Декабрь");
    }

    public static void println(){
        for(Month month:values()){
            System.out.println(month.name()+" "+month.day);
        }
    }

    public static void main(String[] args) {
        Month month = Month.APRIL;
        System.out.println("Next month: ");
        System.out.println(month.next().name());
        System.out.println("Prev month: ");
        System.out.println(month.prev().name());
        month.print();
        println();
    }

}

