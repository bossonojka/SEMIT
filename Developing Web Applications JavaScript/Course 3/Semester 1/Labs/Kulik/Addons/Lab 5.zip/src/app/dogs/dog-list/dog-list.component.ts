import {Component, OnDestroy, OnInit} from '@angular/core';
import {DogService} from '../../dog.service';
import {Dog} from '../../dog.model';
import {Subscription} from 'rxjs';


@Component({
    selector: 'app-dog-list',
    templateUrl: './dog-list.component.html',
    styleUrls: ['./dog-list.component.css']
})
export class DogListComponent implements OnInit, OnDestroy {
    dogs: Dog[] = [];
    private postSub: Subscription;

    constructor(public dogService: DogService) {
    }

    ngOnInit() {
        this.dogService.getDogs();
        this.postSub = this.dogService.getDogUpdateListener().subscribe((data: Dog[]) => {
            this.dogs = data;
        });
    }

    onDelete(postID: string) {
        this.dogService.deleteDog(postID);
    }

    ngOnDestroy() {
        this.postSub.unsubscribe();
    }
}
