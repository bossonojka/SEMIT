export interface Dog {
    id: string;
    name: string;
    age: string;
    color: string;
    typeDog: {
        typeDog: string,
        nationality: string
    };
}