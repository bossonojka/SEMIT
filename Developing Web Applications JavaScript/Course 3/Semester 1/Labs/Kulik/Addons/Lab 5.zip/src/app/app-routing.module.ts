import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {DogListComponent} from './dogs/dog-list/dog-list.component';
import {DogComponent} from './dogs/dog/dog.component';

const routes: Routes = [
    {path: '', component: DogListComponent},
    {path: 'create' , component : DogComponent },
    {path : 'edit/:dogId' , component: DogComponent}
    ];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule {
}
