import {Dog} from './dog.model';
import {Injectable} from '@angular/core';
import {Subject} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import {map} from 'rxjs/operators';
import {Router} from '@angular/router';

@Injectable({
    providedIn: 'root',

})
export class DogService {
    private fishs: Dog [] = [];
    private fishUpdates = new Subject<Dog []>();


    constructor(private http: HttpClient , private router : Router) {

    }

    getDogs() {
        this.http.get<any>('http://localhost:3000/fishs').pipe(map(function (postData) {
            return postData.map(post => {
                return {
                    id: post._id,
                    name: post.name,
                    age: post.age,
                    color: post.color,
                    typeDog: {
                        typeDog: post.typeDog.typeDog,
                        nationality: post.typeDog.nationality,
                    }
                };
            });
        })).subscribe((transDog) => {
            this.fishs = transDog;
            this.fishUpdates.next([...this.fishs]);
        });
    }

    getDog(id: string) {
        return this.http.get<Dog>('http://localhost:3000/fishs/' + id);
    }

    deleteDog(fishId: string) {
        console.log('delete Elem');
        this.http.delete('http://localhost:3000/fishs/' + fishId).subscribe(() => {
        });
        const newDogList = this.fishs.filter(fish => fish.id !== fishId);
        this.fishs = newDogList;
        this.fishUpdates.next([...this.fishs]);
    }

    getDogUpdateListener() {
        return this.fishUpdates.asObservable();
    }

    addDog(fish: Dog) {
        this.http.post<any>('http://localhost:3000/fishs', fish).pipe(map(function (addDog) {
            // return addDog.map(post => {
            return {
                id: addDog._id,
                name: addDog.name,
                age: addDog.age,
                color: addDog.color,
                typeDog: {
                    typeDog: addDog.typeDog.typeDog,
                    nationality: addDog.typeDog.nationality,
                }
            };
            // });
        })).subscribe((newDog) => {
            this.fishs.push(newDog);
            this.fishUpdates.next([...this.fishs]);
            this.router.navigate(['/']);
        });
    }

    updatePost(updateDog: Dog) {
        this.http.put<Dog>('http://localhost:3000/fishs/' + updateDog.id, updateDog).subscribe(response => {
            const updatedPosts = this.fishs;
            const oldPostIndex = updatedPosts.find(p => p.id === updateDog.id);
            // updatedPosts[oldPostIndex] = response;
            this.fishs = updatedPosts;
            this.fishUpdates.next([...this.fishs]);
            this.router.navigate(['/']);
        });
    }
}