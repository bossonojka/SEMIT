import {Component, OnInit} from '@angular/core';
import {NgForm, NgModel} from '@angular/forms';
import {AppModule} from '../../app.module';

// Для получение параметров URL
import {ActivatedRoute, ParamMap} from '@angular/router';

import {Dog} from '../../dog.model';
import {DogService} from '../../dog.service';
import {MatProgressSpinnerModule} from '@angular/material';

@Component({
    selector: 'app-dog',
    templateUrl: './dog.component.html',
    styleUrls: ['./dog.component.css']
})
export class DogComponent implements OnInit {

    private mode = 'create';
    private dogId: string;
    isLoading = false;
    dog: Dog;

    constructor(public dogService: DogService, public route: ActivatedRoute) {
    }

    ngOnInit() {
        this.route.paramMap.subscribe((paramMap: ParamMap) => {
            if (paramMap.has('dogId')) {
                this.mode = 'edit';
                this.dogId = paramMap.get('dogId');
                this.isLoading = true;
                this.dogService.getDog(this.dogId).subscribe(result => {
                    this.isLoading = false;
                    this.dog = result;
                });
            } else {
                this.mode = 'create';
                this.dogId = null;
            }
        });
    }

    onSavePost(form: NgForm) {
        if (form.invalid) {
            return;
        }
       this.isLoading = true;
        if (this.mode === 'create') {
            const newDog = {
                id: null,
                name: form.value.name,
                age: form.value.age,
                color: form.value.color,
                typeDog: {
                    typeDog: form.value.typeDog,
                    nationality: form.value.nationality,
                }
            };
            this.dogService.addDog(newDog);
        } else {
            const upgradeDog = {
                id: this.dogId,
                name: form.value.name,
                age: form.value.age,
                color: form.value.color,
                typeDog: {
                    typeDog: form.value.typeDog,
                    nationality: form.value.nationality,
                }
            };
            this.dogService.updatePost(upgradeDog);
        }
        form.resetForm();
    }


}
