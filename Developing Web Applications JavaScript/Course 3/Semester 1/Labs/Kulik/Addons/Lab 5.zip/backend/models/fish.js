var mongoose = require('mongoose');

var typeDog = new mongoose.Schema({
    typeDog: String,
    nationality: String
});

var dogsSchema = new mongoose.Schema({
    name: String,
    age: String,
    color: String,
    typeDog: typeDog,
});



var db =  mongoose.model('dog', dogsSchema);

module.exports = db;
