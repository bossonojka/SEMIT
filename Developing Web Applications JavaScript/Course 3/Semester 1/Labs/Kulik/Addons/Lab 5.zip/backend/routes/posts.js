const express = require("express");

const router = express.Router();
var DogModel = require('../models/fish');


router.post("", function (req, res, next) {

    const fish = new DogModel({
        name: req.body.name,
        age: req.body.age,
        color: req.body.color,
        typeDog: {
            typeDog: req.body.typeDog.typeDog,
            size: req.body.typeDog.size
        }
    });
    fish.save();

    res.status(201).json(fish);
    next();
});


router.get('', (req, res, next) => {
    DogModel.find({}, function (err, result) {
        if (err) {
            console.log(err);
        }

        res.status(200).json(result);

    })
})

router.get('/:id', function (req, res, next) {
    DogModel.findById(req.params.id).then(result => {
        if (result)
            res.status(200).json(result);
        else
            res.status(404).json({message: 'Dog not found'});
    })
})

router.put('/:id', function (req, res) {

    var id = req.params["id"];
    var name = req.body.name;
    var age = req.body.age;
    var color = req.body.color;
    var typeDog = req.body.typeDog;

    DogModel.findOneAndUpdate({_id: id},
        {
            name,
            age,
            color,
            typeDog
        },
        {
            returnOriginal: true
        },
        function (err, result) {
            if (err)
                console.log(err);
            console.log(result);
            res.send(result);
        });
});


router.delete('/:id', (req, res, next) => {
    DogModel.deleteOne({_id: req.params.id}).then(result => {
// res.status(200).json(result);
        console.log('delet elem' + result);
    })
});

module.exports = router;