const express = require('express');
const bodyPareser = require('body-parser');
const Routes = require('./routes/posts');

var mongoose = require('mongoose');



const app = express();

mongoose.connect('mongodb://localhost:27017/lab5').then(() => {
    console.log('connected DataBase');
}).catch(() => {
    console.log('connected is fail');
});

app.use(bodyPareser.json());
app.use(bodyPareser.urlencoded({extended: false}));

//Для того чтобы на бек и фронтенд работали на разных поратх
app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type , Accept");
    res.setHeader("Access-Control-Allow-Methods", "GET , POST , DELETE , PUT, PATCH , OPTIONS");
    next();
});

app.use("/fishs" ,Routes);

module.exports = app;
