const express = require('express')

const app = express()

const morgan = require('morgan')

const bookRoutes = require('./api/routes/books')
const languagesRoutes = require('./api/routes/languages')
const bodyParser = require('body-parser')

app.use(express.static('lab5'));

// MongoDB
// const mongoClient = require('mongodb').MongoClient
// const assert = require('assert')
// const url = 'mongodb://localhost:27017/test' // mongodb location
// const router = express.Router()

// app.use('/get-data', (req, res, next) => {
//     let resultArray = []
//     mongoClient.connect(url, (err, client) => {
//         assert.equal(null, err)
//         console.log('Connected to MongoDb')
//         let cursor = client.db('test').collection('books').find()
//         cursor.forEach((element, err) => {
//             assert.equal(null, err)
//             resultArray.push(element)
            
//         }, () => {
//             client.close()
//             res.json({items : resultArray})
//         });
//     })
// })

// Mongoose
const mongoose = require('mongoose')
mongoose.connect('mongodb://localhost:27017/test')
const Schema = mongoose.Schema
const booksSchema = new Schema({
    name: {type : String, required : true},
    price : Number,
    language : String,
})

const BookData = mongoose.model('books', booksSchema)

app.use('/get-data', (req, res, next) => {
    BookData.find().then(doc => {res.json({ items : doc})})
})



app.use(morgan('dev')) // logger
app.use(bodyParser.urlencoded({ extended : false})) // which kind of bodies to parse
app.use(bodyParser.json()) // extract json data and parses it

app.use('/insert', (req, res, next) => {
    let book = {
        name : req.body.name,
        price : req.body.price,
        language : req.body.language
    }

    let data = new BookData(book)
    data.save()
    res.send('Done')
    // res.redirect('/')
})

app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header(
      "Access-Control-Allow-Headers",
      "Origin, X-Requested-With, Content-Type, Accept, Authorization"
    );
    if (req.method === 'OPTIONS') {
        console.log("options method")
        res.header('Access-Control-Allow-Methods', 'PUT, POST, PATCH, DELETE, GET');
        return res.status(200).json({});
    }
    next();
});

app.use('/api/books', bookRoutes)
app.use('/api/languages', languagesRoutes)

app.use((req,res,next) => {
    const error = new Error('Not found')
    error.status(404)
    next(error)
})

app.use((error, req, res, next) => {
    res.status(error.status || 500).json({error: { message : error.message}})
})

module.exports = app