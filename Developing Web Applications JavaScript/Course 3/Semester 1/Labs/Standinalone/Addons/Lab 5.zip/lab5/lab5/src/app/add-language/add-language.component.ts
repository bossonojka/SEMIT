import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Component({
  selector: 'app-add-language',
  templateUrl: './add-language.component.html',
  styleUrls: ['./add-language.component.css']
})
export class AddLanguageComponent implements OnInit {

  constructor(private http: HttpClient) { }

  ngOnInit() {
  }

  name = ''
  onAddLanguage(){
    let language = {
      name : this.name
    }
    console.log(language)
    this.http.post('/api/languages/', language).subscribe((data:any) => {
    }, error =>
    {});
  }
  setName(name){
    this.name = name
  }

}
