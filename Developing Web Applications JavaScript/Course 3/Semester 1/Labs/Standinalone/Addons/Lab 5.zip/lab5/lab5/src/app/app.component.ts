import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  stored_books = []

  onRemove(book){
    this.stored_books.splice(this.stored_books.indexOf(book), 1)
  }

  onBookAdded(book) {
    console.log('new books added')
    this.stored_books.push(book)
  }

  print(x) {
    console.log(x)
  }
  
  title = 'lab5';
}
