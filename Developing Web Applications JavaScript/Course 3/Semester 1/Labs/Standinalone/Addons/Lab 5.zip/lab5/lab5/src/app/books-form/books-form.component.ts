import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'books-form',
  templateUrl: './books-form.component.html',
  styleUrls: ['./books-form.component.css']
})
export class BooksFormComponent implements OnInit {
  constructor() { }

  ngOnInit() {
  }
  log(x) {console.log(x)}
}
