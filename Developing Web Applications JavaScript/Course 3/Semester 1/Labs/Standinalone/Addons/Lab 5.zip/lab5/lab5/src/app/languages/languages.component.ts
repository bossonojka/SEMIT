import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Component({
  selector: 'app-languages',
  templateUrl: './languages.component.html',
  styleUrls: ['./languages.component.css']
})

export class LanguagesComponent implements OnInit {
  languages = []
  constructor( private http: HttpClient) { 
    this.http.get('/api/languages').subscribe((data:any) => {
      this.languages = data; console.log(this.languages)
    }, error => {});
    
  }
  ngOnInit() {
  }

  remove(language){
    this.http.delete('/api/languages/'+ this.languages.indexOf(language)).subscribe((data:any) => {
    }, error =>
    {});
  }
}
