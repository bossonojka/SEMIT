import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-language-item',
  templateUrl: './language-item.component.html',
  styleUrls: ['./language-item.component.css']
})
export class LanguageItemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
