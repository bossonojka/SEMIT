const http = require ('http')
const app = require('./app')
const Database = require('./db')

const port = process.env.PORT || 3000

const server = http.createServer(app)

const db = new Database()
db.loadDatabase()

module.exports.db = db

server.listen(port)


