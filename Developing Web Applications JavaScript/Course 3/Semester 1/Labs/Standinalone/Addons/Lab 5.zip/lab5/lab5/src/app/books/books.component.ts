import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Component({
  selector: 'books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {
  books = []
  constructor( private http: HttpClient) { 
    this.http.get('/api/books').subscribe((data:any) => {
      this.books = data;console.log(this.books)
    }, error => {});
    
  }

  ngOnInit() {
  }

  // @Input() books = []

  log(){console.log(this.books)}

  remove(book){
    this.http.delete('/api/books/'+ this.books.indexOf(book)).subscribe((data:any) => {
    }, error =>
    {});
  }

}
