import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Component({
  selector: 'app-add-book-component',
  templateUrl: './add-book-component.component.html',
  styleUrls: ['./add-book-component.component.css']
})
export class AddBookComponentComponent implements OnInit {

  n = ''
  p = 0
  l = ''
  @Output() bookCreated = new EventEmitter()

  constructor( private http: HttpClient) { }

  ngOnInit() {
  }
  name = ''
  price = 0
  language = ''
  onAddBook(){
    let book = {
      name : this.name,
      price : this.price,
      language : this.language 
    }
    console.log(book)
    this.http.post('/api/books/', book).subscribe((data:any) => {
    }, error =>
    {});
  }
  setLanguage(language){
    this.language = language
  }
  setName(name){
    this.name = name
  }
  setPrice(price){
    this.price = price
  }
  log(x) {console.log(x.viewModel)}

}
