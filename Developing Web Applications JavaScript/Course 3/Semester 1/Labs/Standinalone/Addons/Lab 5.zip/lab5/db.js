const fs = require('fs')

const Db = function(){
    this.books = undefined
    this.languages = undefined
}
Db.prototype = {
    booksTable : './database/books.json',
    languagesTable : './database/languages.json',

    loadDatabase : function(){
        this.books = JSON.parse(fs.readFileSync(this.booksTable, 'utf-8'))
        this.languages = JSON.parse(fs.readFileSync(this.languagesTable, 'utf-8'))
    },

    updateBookByID : function(book_id, book){
        this.books[book_id] = book
        fs.writeFileSync(this.booksTable, JSON.stringify(this.books), {encoding : 'utf-8'})
        return this.books
    },
    
    updateLanguageByID : function(language_id, language){
        this.languages[language_id] = language
        fs.writeFileSync(this.languagesTable, JSON.stringify(this.languages), {encoding : 'utf-8'})
        return this.languages
    },


    deleteBookByID : function(book_id){
        let deleted_book = this.books[book_id]
        this.books.splice(book_id,1)
        return { deleted_book : deleted_book, books : this.books}
    },
    
    deleteLanguageByID : function(language_id){
        let deleted_language = this.books[language_id]
        this.languages.splice(language_id,1)
        return { deleted_language : deleted_language, languages : this.languages}
    },

    getBooks : function(){
        return this.books
    },
    
    getLanguages : function(){
        return this.languages
    },

    getBookById : function(book_id){
        // const result = this.books.filter(value => {value.name === book_name})
        // return result.length > 0 ? result[0] : null
        const result = this.books[book_id]
        return result == undefined ? 'Not Found' : result
    },

    getLanguageById : function(language_id){
        const result = this.languages[language_id]
        return result == undefined ? 'Not Found' : result
    },

    addBook : function(book){
        this.books.push(book)
        fs.writeFileSync(this.booksTable, JSON.stringify(this.books), {encoding : 'utf-8'})
    },
    
    addLanguage : function(language){
        this.languages.push(language)
        fs.writeFileSync(this.languagesTable, JSON.stringify(this.languages), {encoding : 'utf-8'})
    }
}

module.exports = Db