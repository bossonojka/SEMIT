import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { NoopAnimationsModule } from '@angular/platform-browser/animations'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BooksComponent } from './books/books.component';
import { BooksFormComponent } from './books-form/books-form.component';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { HomeComponentComponent } from './home-component/home-component.component';
import { AddBookComponentComponent } from './add-book-component/add-book-component.component';
import { NotFoundComponentComponent } from './not-found-component/not-found-component.component'

import { RouterModule } from '@angular/router';
import { NavbarComponent } from './navbar/navbar.component';
import { LanguagesComponent } from './languages/languages.component';
import { BookItemComponent } from './book-item/book-item.component';
import { LanguageItemComponent } from './language-item/language-item.component'

import { HttpClientModule } from '@angular/common/http';
import { 
  MatExpansionModule, 
  MatButtonModule 
} from '@angular/material';
import { AddLanguageComponent } from './add-language/add-language.component';

@NgModule({
  declarations: [
    AppComponent,
    BooksComponent,
    BooksFormComponent,
    HomeComponentComponent,
    AddBookComponentComponent,
    NotFoundComponentComponent,
    NavbarComponent,
    LanguagesComponent,
    BookItemComponent,
    LanguageItemComponent,
    AddLanguageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    NoopAnimationsModule,
    MatCheckboxModule,
    HttpClientModule,
    MatExpansionModule,
    MatButtonModule,
    RouterModule.forRoot([
    {
      path : 'books', component : BooksComponent
    },
    {
      path : 'books/:book_id', component : BookItemComponent
    },
    {
      path : 'languages', component : LanguagesComponent
    },
    {
      path : 'languages/:language_id', component : LanguageItemComponent
    },
    {
      path : 'add-book', component : AddBookComponentComponent
    },
    {
      path : 'add-language', component : AddLanguageComponent
    },
    {
      path : '', component : HomeComponentComponent
    },
    {
      path : '**', component : NotFoundComponentComponent
    }
  ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
