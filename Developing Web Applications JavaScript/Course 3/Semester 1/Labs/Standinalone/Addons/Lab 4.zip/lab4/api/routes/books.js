const express = require('express')
const router = express.Router()
const server = require('../../server')


router.get('/', (req, res, next)  => {
    // res.status(200).json({message : "handling get request to /books"})
    
    result = server.db.getBooks()
    res.status(200).json(result)
})


router.post('/', (req, res, next)  => {
    // const book = { 
    //     name : req.body.name,
    //     price : req.body.price
    // }
    // res.status(200).json({
    //     message : "handling post request to /books",
    //     book : book
    // })
    const book = {
        name : req.body.name,
        price : req.body.price,
        language : req.body.language
    }
    server.db.addBook(book)
    res.status(200).json({
        book_added : book
    })
})



router.get('/:bookName', (req, res, next)  => {
    const id = req.params.bookName
    // res.status(200).json({message : name})
    res.status(200).json(server.db.getBookById(id))
})

router.delete('/:book_id', (req, res, next) => {
    const book_id = req.params.book_id
    res.status(200).json(server.db.deleteBookByID(book_id))
})

router.patch('/:book_id', (req, res, next) => {
    const book_id = req.params.book_id
    
    const book = {
        name : req.body.name,
        price : req.body.price,
        language : req.body.language
    }
    res.status(200).json(server.db.updateBookByID(book_id, book))
})
module.exports = router