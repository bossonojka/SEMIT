const express = require('express')
const router = express.Router()
const server = require('../../server')

router.get('/', (req, res, next) => {
    result = server.db.getLanguages()
    res.status(200).json(result)
})

// router.post('/', (req, res, next) => {
//     const language = {
//         name : req.body.name
//     }
//     res.status(200).json({
//         message : "handling post request",
//         createdLanguage : language
//     })
// })

router.post('/', (req, res, next)  => {
    // const book = { 
    //     name : req.body.name,
    //     price : req.body.price
    // }
    // res.status(200).json({
    //     message : "handling post request to /books",
    //     book : book
    // })
    const language = {
        name : req.body.name,
    }
    server.db.addLanguage(language)
    res.status(200).json({
        language_added : language
    })
})

router.get('/:languageId', (req, res, next)  => {
    const languageId = req.params.languageId
    // res.status(200).json({message : name})
    res.status(200).json(server.db.getLanguageById(languageId))
})

router.delete('/:language_id', (req, res, next) => {
    const language_id = req.params.language_id
    res.status(200).json(server.db.deleteLanguageByID(language_id))
})

router.patch('/:language_id', (req, res, next) => {
    const language_id = req.params.language_id
    
    const language = {
        name : req.body.name,
    }
    res.status(200).json(server.db.updateLanguageByID(language_id, language))
})

module.exports = router