document.addEventListener("DOMContentLoaded", () => {
	
	
	document.getElementById("btn1").addEventListener("click", () =>{
		let arr = document.getElementById("input").value.split(",").map(Number)
		document.getElementById("result").innerHTML = Shell(arr)
	})
	document.getElementById("btn2").addEventListener("click", () =>{
		document.getElementById("input").value = "";
	})
})

function Shell(arr){
	var increment = arr.length / 2;
	while (increment > 0) {
		for (i = increment; i < arr.length; i++) {
			var j = i;
			var temp = arr[i];

			while (j >= increment && arr[j-increment] > temp) {
				arr[j] = arr[j-increment];
				j = j - increment;
			}

			arr[j] = temp;
		}

		if (increment == 2) {
			increment = 1;
		} else {
			increment = parseInt(increment*5 / 11);
		}
	}
	return arr;
}