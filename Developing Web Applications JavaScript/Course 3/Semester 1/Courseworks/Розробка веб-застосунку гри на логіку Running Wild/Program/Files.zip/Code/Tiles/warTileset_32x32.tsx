<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.5" name="warTileset_32x32" tilewidth="32" tileheight="32" tilecount="64" columns="8">
 <image source="warTileset_32x32.png" width="256" height="256"/>
</tileset>
