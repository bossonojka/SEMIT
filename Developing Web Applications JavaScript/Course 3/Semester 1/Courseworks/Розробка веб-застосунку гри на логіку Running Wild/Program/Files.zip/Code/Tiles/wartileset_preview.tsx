<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.5" name="wartileset_preview" tilewidth="32" tileheight="32" tilecount="925" columns="37">
 <image source="WarTileset_VitalZigns/wartileset_preview.jpg" width="1200" height="800"/>
</tileset>
