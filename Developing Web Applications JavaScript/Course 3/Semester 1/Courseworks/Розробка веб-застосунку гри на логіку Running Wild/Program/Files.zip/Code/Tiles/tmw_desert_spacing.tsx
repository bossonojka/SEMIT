<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.5" name="tmw_desert_spacing" tilewidth="32" tileheight="32" tilecount="48" columns="8">
 <image source="D:/Programs/TileEditor/examples/tmw_desert_spacing.png" width="265" height="199"/>
</tileset>
