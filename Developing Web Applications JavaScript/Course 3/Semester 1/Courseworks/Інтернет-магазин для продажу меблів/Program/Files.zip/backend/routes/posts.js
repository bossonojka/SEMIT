const express = require("express");
const bodyPareser = require('body-parser');

const router = express.Router();
var ProductModel = require('../models/productScheme');

router.post("", function (req, res, next) {

    const product = new ProductModel({
        name: req.body.name,
        firm: req.body.firm,
        description: req.body.description,
        price: req.body.price,
        url: req.body.url,
        bestProduct: req.body.bestProduct
    });

    product.save();
    res.status(201).json(product);
    next();
});

router.delete('/:id', (req, res, next) => {
    ProductModel.deleteOne({_id: req.params.id}).then(result => {
// res.status(200).json(result);
        console.log('delet elem' + result);
    })
});

router.put('/:id', function (req, res) {

    var id = req.params.id;
    var name = req.body.name;
    var firm = req.body.firm;
    var description = req.body.description;
    var price = req.body.price;
    var url = req.body.url;
    var bestProduct = req.body.bestProduct;

    ProductModel.findOneAndUpdate({_id: id},
        {
            name,
            firm,
            description,
            price,
            url,
            bestProduct
        },
        {
            returnOriginal: true
        },
        function (err, result) {
            if (err)
            res.send(result);
        });
});


router.get('', (req, res, next) => {
    ProductModel.find({}, function (err, result) {
        if (err) {
            console.log(err);
        }
        res.send(result);
    })
})

router.get('/:id', function (req, res, next) {

    var id = req.params.id;

    ProductModel.findById(id, function (err, result) {
        if (err) {
            res.status(404).json({message: 'not found'});
        }

        res.status(200).json(result);
    })
})

// router.get('/:findFirm', function (req, res, next) {
//     ProductModel.findOne({firm: req.params.findFirm}).then(result => {
//             console.log(result);
//             if (result)
//                 res.status(200).json(reuslt);
//             else
//                 res.status(404).json({message: 'Product not found'});
//         }
//     )
// })


router.delete('/:id', (req, res, next) => {
    ProductModel.deleteOne({_id: req.params.id}).then(result => {
// res.status(200).json(result);
        console.log('delet elem' + result);
    })
})

module.exports = router;