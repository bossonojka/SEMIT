#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <sys/resource.h>
#include <syslog.h>


void user_handler(int sig)
{
    switch(sig)
    {
        case SIGUSR1 :
        {
            syslog(LOG_INFO, "Daemon working \n");
            signal(SIGUSR1, user_handler);
            break;
        }
        case SIGINT :
        {
            syslog(LOG_INFO, "Daemon killed \n");
            signal(SIGINT, user_handler);
            exit(0);
        }
    }
}

int main() {

    pid_t pid;
    pid = fork();
    if (pid < 0)
    {
        printf("Err");
        return -1;
    }
    if (pid != 0) // parent
    {
        exit(0);
    }
    else // children
    {
        //set session
        setsid();
        chdir("/");

        //close file descriptors
        struct rlimit flim;
        getrlimit(RLIMIT_NOFILE, &flim);
        int fd;
        for (fd = 0; fd < flim.rlim_max; fd++)
        close(fd);

        //open system log
        openlog("OS_LAB4", LOG_PID, LOG_LOCAL0);
        syslog(LOG_INFO, "Daemon summoned with code: %i \n", getppid());

        signal(SIGINT, user_handler);
        signal(SIGUSR1, user_handler);

        closelog();
        //wait signal
        for (; ; )pause();

    }
    return (EXIT_SUCCESS);
}

