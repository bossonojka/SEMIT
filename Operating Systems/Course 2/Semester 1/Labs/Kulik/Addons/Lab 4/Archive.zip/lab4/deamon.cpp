
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <syslog.h>
#include <string.h>
#include <signal.h>

using namespace std;
/*
 * 
 */
void hdl(int signum)
{
    switch(signum)
    {
        case SIGUSR1:
            syslog(LOG_INFO, "I've got a signal\n");
            break;
        case SIGINT:
            syslog(LOG_INFO, "I've got a break signal. Breaking...\n");
            closelog();
            exit(1);
            break;
        default:
            syslog(LOG_INFO, "Wrong signal\n");
            break;
    }
}

int main(int argc, char* argv[]) 
{
    pid_t pid;
    pid = fork();
    if (pid < 0) exit(EXIT_FAILURE);
    if (pid > 0) exit(EXIT_SUCCESS);
    umask(0);
    openlog("myDemon", LOG_INFO, LOG_LOCAL0);
    pid_t sid;
    sid = setsid();
    if(sid < 0)
    {
        syslog(LOG_INFO, "Can't create sid\n");
        exit(EXIT_FAILURE);
    }
    chdir("/");
    close(STDIN_FILENO);
    close(STDOUT_FILENO);
    close(STDERR_FILENO);
    for(int i = 1; i == 1;)
    {
        struct sigaction act;
        memset(&act, 0, sizeof(act));
        act.sa_handler = hdl;
        sigset_t   set; 
        sigemptyset(&set);                                                             
        sigaddset(&set, SIGUSR1); 
        sigaddset(&set, SIGINT);
        act.sa_mask = set;
        sigaction(SIGUSR1, &act, 0);
        sigaction(SIGINT, &act, 0);
        sleep(30);
    }
    return 0;
}

