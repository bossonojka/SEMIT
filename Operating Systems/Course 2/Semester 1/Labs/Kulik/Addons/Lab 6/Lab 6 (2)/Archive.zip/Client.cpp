#include <stdio.h>
#include <unistd.h>
#define FIFO_FILE "./fifofile"

//находим рекурсией. нумерация чисел с 0!
int fibo(int n)
{
  if (n==0 || n==1) return 1;  
  return fibo(n-1) + fibo(n-2);
}

int main ()
{
	FILE *f;
	int num;

	printf ("~~~Fibonacci client~~~\n");
	f = fopen(FIFO_FILE, "r");
	while (1)
	{
	fread(&num,sizeof(num),1,f);		//чтение из буфера
	if (num == -1) break;
	printf("F%d = %d\n",num, fibo(num));
	}

	fclose(f);
	unlink(FIFO_FILE);
	return 0;
}
