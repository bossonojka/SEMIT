#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;

#define FIFO_FILE "./fifofile"		//имя канала

int main(int argc, char *argv[])
{
	FILE *f;
	string s1, s2;
	  		
	cout << "\n === Server ===\n";
		
	mkfifo(FIFO_FILE, 0600);		//создаем канал
	f = fopen(FIFO_FILE, "w");		//открываем канал
	  
	if (f == NULL)
	{
	    cout << "\n Can not open file\n";
	    return -1;
	}

	cout << "\n\n Please, enter the first string" << "\t ->  ";
	cin >> s1;
	cout << " Now, enter the second" << "\t\t ->  ";
	cin >> s2;
	
	
	fwrite((char*)s1.c_str(),1,s1.length(),f);	//запись в буфер	
	fflush(f);
	fwrite((char*)s2.c_str(),1,s2.length(),f);	//запись в буфер
 	fflush(f);
	  					
	 
	fclose(f);
	unlink(FIFO_FILE);
  
	return 0;
}
