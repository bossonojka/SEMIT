#include <stdio.h>
#include <unistd.h>
#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;


#define FIFO_FILE "./fifofile"


int main ()
{
	FILE *f;
	string s1, s2;
	printf ("\n === Client ===\n");

	f = fopen(FIFO_FILE, "r");
	
	fread((char*)s1.c_str(), 1, s1.length(), f); 
	fread((char*)s2.c_str(), 1, s2.length(), f); 


	bool b1 = true, b2 = true;
	int len = s1.length();

	/////
	for (int i = 1; i < len; i++)
	{
		if (!isdigit(s1[i]))
		{
			b1 = false;
			break;
		}
	}

	if (! isdigit(s1[0]) && s1[0] != '+' && s1[0] != '-')
		b1 = false;

	/////
	if (b1 = true)
	{
		len = s2.length();

		for (int i = 1; i < len; i++)
			if (!isdigit(s2[i]))
			{
				b2 = false;
				break;
			}

		if (!isdigit(s2[0]) && s2[0] != '+' && s2[0] != '-')
			b2 = false;
	}

	/////
	if (b1 && b2)
	{
		cout << "\n\n Your strings are signed integer numbers.\n"
			<< " The result: ";
		cout << atoi(s1.c_str()) + atoi(s2.c_str());
		cout << "\n\n";
	}
	else
	{
		cout << "\n\n Your strings are not the integer numbres.\n"
			<< " The result: ";
		cout << s1 << s2;
		cout << "\n\n";
	}

	fclose(f);
	unlink(FIFO_FILE);

	return 0;
}

