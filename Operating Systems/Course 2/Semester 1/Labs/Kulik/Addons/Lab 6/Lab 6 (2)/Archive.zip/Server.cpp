#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#define FIFO_FILE "./fifofile"		//имя канала

int main(int argc, char *argv[])
{
  FILE *f;
  int num;
  
  printf ("\n~~~Fibonacci server~~~\n");				
  mkfifo(FIFO_FILE, 0600);		//создаем канал
  f = fopen(FIFO_FILE, "w");		//открываем канал
  if (f == NULL)
  {
    printf("Can't open file\n");
    return -1;
  }

  printf ("Enter the position of Fibonacci number\n");
  printf ("Type -1 for exit\n");
  
  do
  {
    scanf("%d",&num);			//читаем число
    fwrite(&num,sizeof(num),1,f);	//запись в буфер
    fflush(f);
  } while (num != -1);			//выход, если прочитали -1
  
  fclose(f);
  unlink(FIFO_FILE);
  return 0;
}
