#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <iostream>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

#define FIFO "./fifofile"

using namespace std;

int KMP (char s[], char p[])
{
	int i, j, N, M;
	N = strlen(s);
	M = strlen(p);
	int *d = new int [M];
	d[0]=0;
	for(i=1,j=0;i<M;i++)
	{
		while(j>0 && p[j]!=p[i])
			j = d[j-1];
		if(p[j]==p[i])
			j++;
		d[i]=j;
	}

	for(i=0,j=0;i<N; i++)
	{
		while(j>0 && p[j]!=s[i])
			j=d[j-1];
		if(p[j]==s[i])
                        j++;
		if (j==M)
                {
		        delete [] d;
                        return i-j+2;
                }
	}
        delete [] d;
	return -1;
}

int main () {
	FILE * f;
	char buf [62] = " ";
	char str1 [31] = " ";
	char str2 [31] = " ";

	mkfifo (FIFO);
	f = fopen (FIFO, "r");

	fgets (buf, 62, f);

	int i = 0;
	while (buf [i] != ' ') {
		i++;
	}
	for (int j = 0; j < i; j++) {
		str1[j] = buf[j];
	}
	i++;
	int k = 0;
	while (buf [i] != '\0') {
		str2[k] = buf[i];
		i++;
		k++;
	}
	cout << "Получена первая строка: " << str1 << endl;
	cout << "Получена вторая строка: " << str2 << endl;

	int res = KMP (str1, str2);
	if (res < 0)
		cout << "Вторая строка не входит в первую" << endl;
	else
		cout << "Номер элемента с которого начинается вхождение: " << res << endl;

	fclose (f);

	unlink (FIFO);
	return 0;
}
