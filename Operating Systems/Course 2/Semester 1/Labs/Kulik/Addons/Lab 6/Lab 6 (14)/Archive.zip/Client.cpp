#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <iostream>
#include <unistd.h>
#include <fcntl.h>

#define FIFO "./fifofile"

using namespace std;

int main(int argc, char * argv[]) {
	FILE * f;
	char str1 [31];
	char str2 [31];
	cout << "Введите первую строку\n-> ";
	cin >> str1;

	cout << "Введите вторую строку\n-> ";
	cin >> str2;

	if ((f = fopen (FIFO, "w")) == NULL) {
		cout << "Ошибка!" << endl;
		return -1;
	}

	fputs (str1, f);
	fputs (" ", f);
	fputs (str2, f);
	fclose (f);

	unlink (FIFO);
	return 0;
}
