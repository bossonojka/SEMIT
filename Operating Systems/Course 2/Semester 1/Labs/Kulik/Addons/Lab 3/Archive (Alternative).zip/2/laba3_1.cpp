#include <iostream>
#include <sys/types.h> 
#include <sys/wait.h> 
#include <unistd.h> 
#include <getopt.h>
#include <stdlib.h>
#include <stdio.h>

using namespace std;

int main(int argc, char* argv[]){

	pid_t pid;

	if ((pid = fork()) < 0) exit (-1);
	if (pid == 0) { // потомок загружает вместо себя другую	программу
		//char* prog = "./laba3_2";
		//const char* args[] = {"./laba3_2", NULL};
		if (execl ("./laba3_2","./laba3_2", NULL) == -1) {
			printf("error starting the child\n");
			exit (-1);
		}
	}else {// предок продолжает работу (например, ждет окончания потомка)
		printf ("потомок запущен с кодом %d\n", pid);
	}
	return 0;
}


