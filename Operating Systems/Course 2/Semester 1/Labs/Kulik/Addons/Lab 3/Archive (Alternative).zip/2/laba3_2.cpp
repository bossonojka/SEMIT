#include <iostream>
#include <string>
#include <stdlib.h>

using namespace std;

int main(){

	int a = 0;
	int b = 0;
	int sum =0;
	int comp = 1;

	std::cout << "Input A: ";
	std::cin >> a;
	std::cout << "Input B: ";
	std::cin >> b;

	for(int i = a - 1; i < b; i++){
	    sum += i;
	    comp *= i;	
	}

	std::cout << "Summa ot A do B= " << sum << "\n" << "Proizvedenie ot A do B = " << comp;
	return 0;
}
