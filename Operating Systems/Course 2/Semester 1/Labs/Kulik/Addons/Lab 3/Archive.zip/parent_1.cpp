#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
using namespace std;
int main(int argc,char **argv)
{
int c;
pid_t pid;
do{
	c=getopt(argc, argv, "f:w:"); 
	switch(c)
	{	
		case 'w': if ((pid=fork())<0) exit(-1);
			if (pid==0)
			{
				execv(optarg,argv);
			}
			else
			{
			int status;
			waitpid(pid,&status,0);
			if (WIFEXITED(status))
			cout<<"Exited with"<<WIFEXITED(status); 
			}
			break;
		case 'f': if ((pid=fork())<0) exit(-1);
			if (pid==0)
				{
					int pid2;
					if ((pid2=fork())<0) exit(-1);
					if (pid2==0) execv(optarg,argv);
					else exit(0);
				}
				else waitpid(pid,NULL,0); 
				break;
	}
} while(c != -1);
			
return 0;

}

