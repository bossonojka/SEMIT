#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
	pid_t pid;
	if (pid = fork() < 0)
	{
		exit(-1);
	}
	if (pid == 0)
	{
		execv("child", argv);
	}
	else
	{
		exit(-1);
	}
	return 0;
}
