#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <pwd.h>
#include <grp.h>

using namespace std;

int main(int argc, char *argv[]){
	struct passwd *pwd;
	pwd = getpwuid(getuid());
	struct group *grp;
	grp = getgrgid(getgid());
	pid_t pid, ppid, sid, pgid;
	pid = getpid();
	ppid = getppid();
	sid = getsid(0);
	pgid = getpgid(pid);
	for (int i = 0; argv[i]; i++)
		cout << argv[i] << " " << endl;
	cout << "Pid: " << pid << endl;
	cout << "Ppid: " << ppid << endl;
	cout << "Sid: " << sid << endl;
	cout << "Pgid: " << pgid << endl;
	cout << "User: " << pwd->pw_name << endl;
	cout << "Group: " << grp->gr_name << endl;
	exit(0);
}
