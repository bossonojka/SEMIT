#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <unistd.h>
#include <iostream>
using namespace std;

int main()
{
    int sock;
    struct sockaddr_in addr;
    char buf[1024];
    int bytes_read;

    sock = socket(AF_INET, SOCK_DGRAM, 0);//Для создания сокета используется функция socket
    //Домен определяет пространство адресов, в котором располагается сокет
    //Константа AF_INET соответствует Internet-домену. Сокеты, размещённые в этом домене, могут использоваться для работы в любой IP-сети
    //Тип сокета определяет способ передачи данных по сети.
    //SOCK_DGRAM. Передача данных в виде отдельных сообщений (датаграмм)
    //последний атрибут определяет протокол, используемый для передачи данных.
    if(sock < 0)
    {
       cout<<"Error socket"<<endl;
       return -1;
    }
    
    addr.sin_family = AF_INET;//Семейство адресов
    addr.sin_port = htons(3425);// Номер порта
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    //Прежде чем передавать данные через сокет, его необходимо связать с адресом в выбранном домене 
    //Для явного связывания сокета с некоторым адресом используется функция bind
    //В качестве первого параметра передаётся дескриптор сокета, который мы хотим привязать к заданному адресу. Второй параметр, addr, содержит указатель на структуру с адресом, а третий - длину этой структуры. Посмотрим, что она собой представляет.
    //// IP-адрес
    if(bind(sock, (struct sockaddr *)&addr, sizeof(addr)) < 0)
    {
       cout<<"Error bind"<<endl;
       return -1;
    }

    while(1)
    {
        bytes_read = recvfrom(sock, buf, 1024, 0, NULL, NULL);
        buf[bytes_read] = '\0';
        cout<<buf<<endl;
    }
    
    return 0;
}
