#include <cmath>
#include "b.h"
double func_b(double x, double y, double z)
{
	return ((y - x)*(((y-z)/(y-x))/(1+pow((y+x), 2))));
}
