double func_b(double, double, double);
