#include <cmath>
#include "a.h"
double func_a(double x, double y)
{
	return std::abs((pow(x, (y/x))) - sqrt((y/x)));
}
