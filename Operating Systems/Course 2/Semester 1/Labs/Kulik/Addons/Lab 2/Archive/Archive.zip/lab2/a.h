double func_a(double, double);
