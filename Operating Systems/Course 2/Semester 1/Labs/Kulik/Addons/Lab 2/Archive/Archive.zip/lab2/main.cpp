#include "a.h"
#include "b.h"
#include <iostream>
using namespace std;
int main(int argc, char *argv[])
{
double x= 1.82, y=18.5, z=-3.29;
cout << "A = " << func_a(x,y) << endl;
cout << "B = " << func_b(x,y,z) << endl;
return 0;
}

