#include <pthread.h>
#include <fstream>
#include <semaphore.h>
#include <errno.h>
#include <limits.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include <iostream>
using namespace std;

pthread_mutex_t work_mutex;

ofstream out("mutex.txt");
ifstream in("test.txt");
char arr[50];

void *function1(void *arg)
{
	pthread_mutex_lock(&work_mutex);
	out << "Mutex #1" << endl;
	in.getline(arr, 50);
	cout << arr << endl;
	pthread_mutex_unlock(&work_mutex);

}

void *function2(void * arg)
{
	pthread_mutex_lock(&work_mutex);
	out << "Mutex #2" << endl;
	in.getline(arr, 50);
	cout << arr << endl;
	pthread_mutex_unlock(&work_mutex);
}
int main()
{
	pthread_mutex_init(&work_mutex,NULL);// значение по умолчанию
	pthread_t thread1;
	pthread_t thread2;

	pthread_create(&thread1,NULL,&function1,NULL);
	pthread_create(&thread2,NULL,&function2,NULL);

	pthread_join(thread1,NULL);
	pthread_join(thread2,NULL);

	pthread_mutex_destroy(&work_mutex);

	out.close();
	
}
