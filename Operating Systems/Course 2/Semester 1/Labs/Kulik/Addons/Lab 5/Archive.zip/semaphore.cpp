#include <semaphore.h>
#include <pthread.h>
#include <errno.h>
#include <limits.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <iostream>
using namespace std;
int sum;
sem_t sem;

void* function(void* arg)
{
	intptr_t s =(intptr_t)arg;//Целочисленный тип, способный удерживать значение, преобразованное из указателя void, а затем преобразовываться обратно в этот тип со значением, которое сравнивается с исходным указателем.
	sem_wait(&sem); 
	for (int i = 0; i < 5; i++)
	{
		sum = sum + s;
		cout << sum << endl;
	}
	sem_post(&sem); 
	return NULL;
}

int main()
{
	sem_init(&sem,0,0);  
	sem_post(&sem);  
	pthread_t thread1, thread2;
	pthread_create(&thread1,NULL,&function,(void*)5);
	pthread_create(&thread2,NULL,&function,(void*)-5);
	pthread_join(thread1,NULL);
	pthread_join(thread2,NULL); 
	sem_destroy(&sem);
	return 0;
}
