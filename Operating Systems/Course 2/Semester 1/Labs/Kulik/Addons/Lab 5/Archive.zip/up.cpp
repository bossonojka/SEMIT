#include <pthread.h>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
using namespace std;
void* mx(void *arg)
{
        for (int i = 0; i < 5; i++, value++)
        {
                pthread_mutex_lock(&mutex);
                cout << value << endl;
                pthread_cond_signal(&cond);   //события потоков на усл переменной
                pthread_cond_wait(&cond, &mutex);   //ожидания события на УП
                pthread_mutex_unlock(&mutex);
        }
}
void* minimal(void *arg)
{
        while (true)
        {
                pthread_mutex_lock(&mutex);
                cout << value << endl;              
                while (value > 0) value--;
                pthread_cond_signal(&cond); 
                pthread_cond_wait(&cond, &mutex);
                pthread_mutex_unlock(&mutex); 
        }
}
int value;
pthread_mutex_t mutex;
pthread_cond_t cond;  
int main()
{
        pthread_mutex_init(&mutex,0);
        pthread_cond_init(&cond,0);  //инициализация условной переменной
        pthread_t plusT;
        pthread_create(&plusT,NULL,mx,NULL);
        pthread_t minT;
        pthread_create(&minT,NULL,minimal,NULL);
        pthread_join(plusT, NULL);
        pthread_cancel(minT);
        pthread_mutex_destroy(&mutex);
        pthread_cond_destroy(&cond);
}
