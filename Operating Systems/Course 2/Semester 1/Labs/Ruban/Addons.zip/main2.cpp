#include<pthread.h>
#include<iostream>
#include<semaphore.h>
using namespace std;

int variable = 0;
pthread_mutex_t mutex;

void* inc(void*)
{
	pthread_mutex_lock(&mutex);
	for(int i =0;i<=10;i++)variable++;
	pthread_mutex_unlock(&mutex);
	return NULL;
}
void* decr(void*)
{
	pthread_mutex_lock(&mutex);
	for(int i =0;i<=10;i++)variable--;
	pthread_mutex_unlock(&mutex);
	return NULL;
}



int main()
{
	pthread_mutex_init(&mutex,NULL);
	pthread_t inct,dect;
	pthread_create(&inct,NULL,inc,NULL);
	pthread_create(&dect,NULL,decr,NULL);
	pthread_join(inct,NULL);
	pthread_join(dect,NULL);
	cout<<variable<<endl;

	return 0;
}
