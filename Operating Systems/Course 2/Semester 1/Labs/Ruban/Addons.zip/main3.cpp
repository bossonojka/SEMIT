#include<pthread.h>
#include<iostream>
#include<semaphore.h>
using namespace std;

int variable = 0;
int protected_variable=1;

void* inc(void*)
{
	if(protected_variable==1)
	{
	for(int i =0;i<=10;i++)variable++;
	protected_variable=0;
	}
	return NULL;
}
void* decr(void*)
{
	if(protected_variable==0)
	{
	for(int i =0;i<=10;i++)variable--;
	protected_variable=1;
	}
	return NULL;
}



int main()
{
	pthread_t inct,dect;
	pthread_create(&inct,NULL,inc,NULL);
	pthread_create(&dect,NULL,decr,NULL);
	pthread_join(inct,NULL);
	pthread_join(dect,NULL);
	cout<<variable<<endl;

	return 0;
}
