#include<pthread.h>
#include<iostream>
#include<semaphore.h>
using namespace std;

int variable = 0;
sem_t sem;

void* inc(void*)
{
	sem_wait(&sem);
	for(int i =0;i<=10;i++)variable++;
	sem_post(&sem);
	return NULL;
}
void* decr(void*)
{
	sem_wait(&sem);
	for(int i =0;i<=10;i++)variable--;
	sem_post(&sem);
	return NULL;
}



int main()
{
	sem_init(&sem,0,1);
	pthread_t inct,dect;
	pthread_create(&inct,NULL,inc,NULL);
	pthread_create(&dect,NULL,decr,NULL);
	pthread_join(inct,NULL);
	pthread_join(dect,NULL);
	cout<<variable<<endl;

	return 0;
}
