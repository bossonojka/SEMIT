﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Letters
{
    class Letters
    {
        string words;

        string result;

        public Letters(string words)
        {
            this.words = words;
        }

        public bool alternatingVowelConsonant(String str)
        {
            var b = isVowel(str[0]);
            for (var i = 1; i < str.Length; i++)
            {
                b = !b;
                if (b != isVowel(str[i]))
                {
                    return false;
                }
            }
            return true;
        }

        public bool isVowel(Char ch)
        {
            switch (ch)
            {
                case 'a':
                case 'e':
                case 'i':
                case 'o':
                case 'u': return true;
            }
            return false;
        }

        static void Main(string[] args)
        {
            Letters let = new Letters("Bolivar can not carry double");

            String[] wordsArray = let.words.Split(' ');

            for (int i = 0; i < wordsArray.Length; i++)
            {
                if (let.alternatingVowelConsonant(wordsArray[i]) == true)
                {
                    let.result += wordsArray[i] + " ";
                }
            }

            Console.Write(let.result);
            Console.Read();
        }
    }
}

