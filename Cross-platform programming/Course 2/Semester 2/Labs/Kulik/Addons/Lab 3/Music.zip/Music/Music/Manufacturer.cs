﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Music
{
    public class Instrument : Product
    {
        private string manufacturer;

        public Instrument(string nameOfTheCompany)
        {
            throw new System.NotImplementedException();
        }

        public Instrument()
        {
            throw new System.NotImplementedException();
        }

        public string Manufacturer
        {
            get => default(int);
            set
            {
            }
        }

        public void toString()
        {
            throw new System.NotImplementedException();
        }
    }
}