﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Music
{
    public class Guitar : Instrument
    {
        private int guitarNeck;
        private int numberOfStrings;
        private string typeOfStrings;

        public Guitar(string NumberOfStrings, string GuitarNeck, string TypeOfStrings)
        {
            throw new System.NotImplementedException();
        }

        public Guitar()
        {
            throw new System.NotImplementedException();
        }

        public int NumberOfStrings
        {
            get => default(int);
            set
            {
            }
        }

        public int TypeOfStrings
        {
            get => default(int);
            set
            {
            }
        }

        public int GuitarNeck
        {
            get => default(int);
            set
            {
            }
        }

        public void toString()
        {
            throw new System.NotImplementedException();
        }
    }
}