﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Music
{
    public class Drum : Instrument
    {
        private int depth;
        private int material;

        public Drum(string Depth, string Material)
        {
            throw new System.NotImplementedException();
        }

        public Drum()
        {
            throw new System.NotImplementedException();
        }

        public int Material
        {
            get => default(int);
            set
            {
            }
        }

        public int Depth
        {
            get => default(int);
            set
            {
            }
        }

        public void toString()
        {
            throw new System.NotImplementedException();
        }
    }
}