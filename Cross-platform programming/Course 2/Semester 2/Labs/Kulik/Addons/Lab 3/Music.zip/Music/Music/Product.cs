﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Music
{
    public class Product
    {
        private string name;
        private decimal price;

        public Product()
        {
            throw new System.NotImplementedException();
        }

        public Product(string Name, decimal Price)
        {
            throw new System.NotImplementedException();
        }

        public string Name
        {
            get => default(int);
            set
            {
            }
        }

        public decimal Price
        {
            get => default(int);
            set
            {
            }
        }

        public void toString()
        {
            throw new System.NotImplementedException();
        }
    }
}