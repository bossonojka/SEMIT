﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Music
{
    public class DigitalPiano : Instrument
    {
        private int numberOfKeys;
        private int typeOfMechanics;

        public DigitalPiano()
        {
            throw new System.NotImplementedException();
        }

        public DigitalPiano(string numberOfStrings, string typeOfMechanics)
        {
            throw new System.NotImplementedException();
        }

        public int TypeOfMechanics
        {
            get => default(int);
            set
            {
            }
        }

        public int NumberOfKeys
        {
            get => default(int);
            set
            {
            }
        }

        public void toString()
        {
            throw new System.NotImplementedException();
        }
    }
}