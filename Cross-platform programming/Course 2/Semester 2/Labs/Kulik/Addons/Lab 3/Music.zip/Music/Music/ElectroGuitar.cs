﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Music
{
    public class ElectroGuitar : Guitar
    {
        private int numberOfSoundRes;
        private int field;

        public int Field
        {
            get => default(int);
            set
            {
            }
        }

        public int NumberOfSoundRes
        {
            get => default(int);
            set
            {
            }
        }
    }
}