﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music
{
    class LinkedListContainer<T> : IContainer<T> where T : Product
    {
        LinkedListNode<T> head;
        public int Count { get; private set; }

        public LinkedListContainer()
        {
            Count = 0;
        }

        public T this[int index]
        {
            get
            {
                if (index > Count) throw new OutOfRangeException("Removal is not possible. The index is outside the array."); 
                var temp = head;
                for (int i = 0; i < index; i++)
                {
                    temp = temp.Next;
                }
                return temp.data;
            }
            set
            {
                var temp = head;
                for (int i = 0; i < index; i++)
                {
                    temp = temp.Next;
                }
                temp.data = value;
            }
        }

        public void Add(T obj)
        {
            if (head == null)
            {
                head = new LinkedListNode<T>();
                head.data = obj;
            }
            else
            {
                var temp = head;
                while (temp.Next != null)
                {
                    temp = temp.Next;
                }
                temp.Next = new LinkedListNode<T>();
                temp.Next.data = obj;

            }
            Count++;
        }

        public void RemoveAt(int index)
        {
            if (index == 0)
            { head = head.Next; Count--; return; }
            var temp = head;
            LinkedListNode<T> prev = temp;
            for (int i = 0; i < index; i++)
            {
                if (temp.Next != null)
                {
                    if (i == index - 1)
                        prev = temp;
                    temp = temp.Next;
                }
                else return;
            }
            prev.Next = temp.Next;
            Count--;
        }

        public void Sort()
        {
            T[] temp = new T[Count];
            for (int i = 0; i < Count; i++)
            {
                temp[i] = this[i];
            }

            temp = temp.OrderBy(x => x.Price).ToArray();
            
            for (int i = 0; i < Count; i++)
            {
                this[i] = temp[i];
            }
        }

        public override string ToString()
        {
            StringBuilder str = new StringBuilder();
            foreach (var c in this)
            {
                str.Append(c.ToString() + "\n");
            }
            return str.ToString();
        }

        public IEnumerator GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }
}
