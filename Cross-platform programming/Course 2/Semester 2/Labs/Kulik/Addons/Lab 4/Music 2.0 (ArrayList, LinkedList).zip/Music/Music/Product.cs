﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Music
{
    public class Product
    {
        protected string name;
        protected decimal price;

        public Product()
        {
            this.Name = "";
            this.Price = 0;
        }

        public Product(string name, decimal price)
        {
            this.Name = name;
            this.Price = price;
        }

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        public decimal Price
        {
            get
            {
                return price;
            }
            set
            {
                    if (price < 0) throw new ZeroPriceException("The price can`t be a negative value.");
                price = value;
            }
        }

        public override string ToString()
        {
            return string.Format($"Name:{name},Price:{price}");
        }
    }
}