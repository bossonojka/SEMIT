﻿using System.Collections;

namespace Music
{
    public interface IContainer<T> : IEnumerable where T : Product
    {
        void Add(T obj);
        void RemoveAt(int index);
    }
}