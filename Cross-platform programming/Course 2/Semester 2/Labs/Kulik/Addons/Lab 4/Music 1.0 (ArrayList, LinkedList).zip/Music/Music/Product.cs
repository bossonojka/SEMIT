﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Music
{
    public class Product
    {
        protected string name;
        protected decimal price;

        public Product(string name, decimal price)
        {
            this.name = name;
            this.price = price;
        }

        public Product()
        {
            this.Name = "";
            this.Price = 0;
        }

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        public decimal Price
        {
            get
            {
                return price;
            }
            set
            {
                price = value;
            }
        }

        public override string ToString()
        {
            return string.Format($"Name:{name},Price:{price}");
        }
    }
}