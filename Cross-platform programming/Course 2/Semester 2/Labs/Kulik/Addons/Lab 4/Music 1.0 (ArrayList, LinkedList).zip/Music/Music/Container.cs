﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Music
{
    public class Container
    {
        private Product[] repository = new Product[0];

        public Product[] Repository
        {
            get
            {
                return repository;
            }
            set
            {
                repository = value;
            }
        }

        public void AddOne(Product arg)
        {
            int length = repository.Length + 1;

            Product[] newRepository = new Product[length];

            for (var i = 0; i < repository.Length; i++)
            {
                newRepository[i] = repository[i];
            }

            newRepository[length - 1] = arg;

            repository = newRepository;

        }

        public void Add(params Product[] arg)
        {

            foreach (Product a in arg)
            {
                int length = repository.Length + 1;

                Product[] newRepository = new Product[length];
                
                for (var i = 0; i < repository.Length; i++)
                {
                    if (repository[i] != null) newRepository[i] = repository[i];
                }

                newRepository[length - 1] = a;

                repository = newRepository;
            }
        }

        public void Remove(int index)
        {
            Product[] newRepository = new Product[repository.Length-1];

            for (int i = 0; i < repository.Length; i++)
            {
                if (i < index)
                {
                    newRepository[i] = repository[i];
                }
                else if (i > index)
                {
                    newRepository[i - 1] = repository[i];
                }
            }

            repository = newRepository;
        }

        public void Sort()
        {
            repository = repository.OrderBy(x => x.Price).ToArray();
        }

        public override string ToString()
        {
            StringBuilder result = new StringBuilder("");
            foreach (Product a in repository)
            {
                result.Append(a);
                result.Append("\n");
            }
            return result.ToString();
        }
    }
}