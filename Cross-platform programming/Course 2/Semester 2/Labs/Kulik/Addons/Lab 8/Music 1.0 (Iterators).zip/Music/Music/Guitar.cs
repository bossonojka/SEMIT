﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Music
{
    public class Guitar : Instrument
    {
        protected string guitarNeck;
        protected int numberOfStrings;
        protected string typeOfStrings;

        public Guitar(string name, decimal price, string manufacturer, int numberOfStrings, string guitarNeck, string typeOfStrings):base(name, price, manufacturer)
        {
            this.guitarNeck = guitarNeck;
            this.numberOfStrings = numberOfStrings;
            this.typeOfStrings = typeOfStrings;
        }

        public Guitar()
        {
            
        }

        public int NumberOfStrings
        {
            get
            {
                return numberOfStrings;
            }
            set
            {

                if (numberOfStrings < 0) throw new ZeroPriceException("The number Of strings can`t be a negative value.");
                numberOfStrings = value;   
            }
        }

        public string TypeOfStrings
        {
            get
            {
                return typeOfStrings;
            }
            set
            {
                typeOfStrings = value;
            }
        }

        public string GuitarNeck
        {
            get
            {
                return guitarNeck;
            }
            set
            {
                guitarNeck = value;
            }
        }

        public override string ToString()
        {
            return string.Format($"Name:{name},Price:{price},manufacturer:{manufacturer},guitarNeck:{guitarNeck},numberOfStrings:{numberOfStrings},typeOfStrings:{typeOfStrings}");
        }
    }
}