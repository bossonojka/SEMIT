﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Music
{
    public class Program
    {
        public static void Main()
        {
            //ArrayList
            /*Product elgr = new ElectroGuitar("SPG900", 3500, "FANNDEC", 6, "rosewood", "metal", "H-S-H");
            Product drm1 = new Drum("VMX-2218B/C250", 20628, "PEARL", 18, "maple");
            Product drm2 = new Drum("VMX-2216B/C280", 18850, "TAMA", 16, "bubinga");
            Product drm3 = new Drum("VMX-2168B/C270", 22150, "PEARL", 18, "maple");
            Product drm4 = new Drum("TBB2216S", 25448, "TAMA", 16, "bubinga");
            Product drm5 = new Drum("VMX-2218B/C280", 20627, "PEARL", 18, "maple");
            Product drm6 = new Drum("TBB2168S", 20700, "TAMA", 18, "bubinga");

            Container<Product> con = new Container<Product>();

            con.Add(elgr, drm1, drm2, drm3, drm4, drm5, drm6);

            Console.WriteLine(con.FindByString("TBB2168S"));
            Console.Read();

            con.Remove(1);
            con.Sort();

            Console.WriteLine(con.ToString());*/

            //LinkedList
            Product item1 = new Product("Guitar", 3500);
            Product item2 = new Product("Drum", 4000);
            Product item3 = new Product("Piano", 18999);
            Product item4 = new Product("Violin", 8045);

            LinkedListContainer<Product> list = new LinkedListContainer<Product>();

            list.Add(item1);
            list["Guitar"] = item2;

            list.Sort();

            foreach(var c in list.InOrder()){

            }

            Console.ReadKey();
        }
    }
}