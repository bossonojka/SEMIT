﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music
{
    class CustomContainer
    {
        public CustomIterator GetEnumerator()
        {
            return new CustomIterator(this);
        }

        public struct CustomIterator
        {
            internal CustomIterator(CustomContainer container)
            {
                this.container = container;
                currentIndex = -1;
            }

            public int Current
            {
                get
                {
                    if (currentIndex == -1 ||
                        currentIndex == container.Count)
                    {
                        throw new InvalidOperationException();
                    }
                    return container[currentIndex];
                }
            }

            public bool MoveNext()
            {
                if (currentIndex != container.Count)
                {
                    currentIndex++;
                }
                return currentIndex < container.Count;
            }

            public void Reset()
            {
                currentIndex = -1;
            }

            private readonly CustomContainer container;
            private int currentIndex;
        }
    }
}
