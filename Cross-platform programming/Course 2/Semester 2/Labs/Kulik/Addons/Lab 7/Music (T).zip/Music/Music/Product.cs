﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Music
{
    public class Product : IName<Product>, IName
    {
        protected string name;
        protected decimal price;

        public Product()
        {
            this.Name = "";
            this.Price = 0;
        }

        public Product(string name, decimal price)
        {
            this.Name = name;
            this.Price = price;
        }

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        public decimal Price
        {
            get
            {
                return price;
            }
            set
            {
                if (price < 0) throw new ZeroPriceException("The price can`t be a negative value.");
                price = value;
            }
        }

        public int CompareTo(object obj)
        {
            return Name.CompareTo((obj as IName).Name);
        }

        public int CompareTo(Product obj)
        {
            return Name.CompareTo(obj.Name);
        }

        public override string ToString()
        {
            return Name + " : " + Price;
        }
    }
}