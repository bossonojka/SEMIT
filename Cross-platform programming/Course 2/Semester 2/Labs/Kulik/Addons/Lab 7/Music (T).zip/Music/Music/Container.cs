﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Music
{
    class Container<T> where T: IName<T>
    {
        private T[] repository = new T[0];

        public T[] Repository
        {
            get
            {
                return repository;
            }
            set
            {
                repository = value;
            }
        }

        public T this[int index]
        {
            get
            {
                if (index < 0 || index > repository.Length)
                {
                    throw new OutOfRangeException("The index is outside the array.");
                }
                return repository[index];
            }
            set
            {
                repository[index] = value;
            }
        }

        public T this[string name]
        {
            get
            {
                foreach (T p in repository)
                {
                    if (p.Name == name)
                    {
                        return p;
                    }
                }
                return default(T);
            }
            set
            {
                for (int i = 0; i < repository.Length; i++)
                {
                    if (repository[i].Name == name)
                    {
                        repository[i] = value;
                    }
                }
            }
        }

        public void Add(params T[] arg)
        {

            foreach (T p in arg)
            {
                if (p == null)
                {
                    throw new AddNullException("A null object was found in the array.");
                }
            }

            foreach (T a in arg)
            {
                int length = repository.Length + 1;

                T[] newRepository = new T[length];

                for (var i = 0; i < repository.Length; i++)
                {
                    if (repository[i] != null) newRepository[i] = repository[i];
                }

                newRepository[length - 1] = a;

                repository = newRepository;
            }
        }

        public void Remove(int index)
        {
            if (index >= repository.Length || index < 0)
            {
                throw new OutOfRangeException("Removal is not possible. The index is outside the array.");
            }

            T[] newRepository = new T[repository.Length - 1];

                for (int i = 0; i < repository.Length; i++)
                {
                    if (i < index)
                    {
                        newRepository[i] = repository[i];
                    }
                    else if (i > index)
                    {
                        newRepository[i - 1] = repository[i];
                    }
                }

                repository = newRepository;
        }

        public void Sort()
        {
            repository = repository.OrderBy(x => x.Name).ToArray();
        }

        public override string ToString()
        {
            StringBuilder result = new StringBuilder("");
            foreach (T a in repository)
            {
                result.Append(a);
                result.Append("\n");
            }
            return result.ToString();
        }
    }
}