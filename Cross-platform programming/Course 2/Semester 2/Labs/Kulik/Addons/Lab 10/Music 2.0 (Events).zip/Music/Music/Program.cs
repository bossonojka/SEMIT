﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Music
{
    public class Program
    {
        public static void Main()
        {
            //ArrayList
            Product elgr = new ElectroGuitar("SPG900", 2000, "FANNDEC", 6, "rosewood", "metal", "H-S-H");
            Product drm1 = new Drum("VMX-2218B/C250", 89500, "PEARL", 18, "maple");
            Product drm2 = new Drum("VMX-2216B/C280", 28540, "TAMA", 16, "bubinga");
            Product drm3 = new Drum("VMX-2168B/C270", 8940, "PEARL", 18, "maple");
            Product drm4 = new Drum("TBB2216S", 7585, "TAMA", 16, "bubinga");
            Product drm5 = new Drum("VMX-2218B/C280", 9995, "PEARL", 18, "maple");
            Product drm6 = new Drum("TBB2168S", 6980, "TAMA", 18, "bubinga");

            Container<Product> con = new Container<Product>();

            con.Added += ((x) => { Console.ForegroundColor = ConsoleColor.Green; Console.WriteLine("Sum of added products: " + x); });

            Product.Editing += ((x) => { con.Sum -= x; });
            Product.Edited += ((x) => { con.Sum += x; });

            con.Add(elgr, drm1, drm2, drm3, drm4, drm5, drm6);

            Console.WriteLine(con.Sum);

            //con.Remove(1);

            Compare<Product> del1 = new Compare<Product>((Product a, Product b) => { return a.Name.CompareTo(b.Name); });
            Compare<Product> del2 = new Compare<Product>((Product a, Product b) => { return a.Price.CompareTo(b.Price); });

            con.Sort(del2);

            Find<Product> del3 = new Find<Product>((Product a) => { return(a.Price > 5000 && a.Price < 10000); });

            //Console.WriteLine(con.FindAll(del3)[0]);

            //LinkedList
            Product item1 = new Product("Guitar", 3500);
            Product item2 = new Product("Violin", 4000);
            Product item3 = new Product("Harp", 18999);
            Product item4 = new Product("Guitar", 8045);

            LinkedListContainer<Product> list = new LinkedListContainer<Product>();

            list.Added += ((x) => { Console.ForegroundColor = ConsoleColor.Green; Console.WriteLine("Sum of added products: " + x); });

            Product.Editing += ((x) => { list.Sum -= x; });
            Product.Edited += ((x) => { list.Sum += x; });

            list.Add(item1);
            list.Add(item2);
            list.Add(item3);
            list.Add(item4);

            Compare<Product> del4 = new Compare<Product>((Product a, Product b) => { return a.Name.CompareTo(b.Name); });
            Compare<Product> del5 = new Compare<Product>((Product a, Product b) => { return a.Price.CompareTo(b.Price); });

            list.Sort(del5);

            Find<Product> del7 = new Find<Product>((Product a) => { return (a.Price > 3000 && a.Name == "Guitar"); });

            Console.WriteLine(list.FindAll(del7)[1]);

            Console.ReadKey();
        }
    }
}