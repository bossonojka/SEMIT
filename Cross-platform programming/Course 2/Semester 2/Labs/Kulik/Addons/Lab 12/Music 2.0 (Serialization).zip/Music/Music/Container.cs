﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization.Formatters.Binary;

namespace Music
{
    [Serializable]
    class Container<T> : IEnumerable<T> where T : IName<T>
    {
        private T[] repository = new T[0];

        public T[] Repository
        {
            get
            {
                return repository;
            }
            set
            {
                repository = value;
            }
        }

        public decimal Sum { get; set; }

        public void PriceChanging(object sender, EventArgs e)
        {
            Sum -= (sender as Product).Price;
        }

        public void PriceChanged(object sender, EventArgs e)
        {
            Sum += (sender as Product).Price;
        }

        public T this[int index]
        {
            get
            {
                if (index < 0 || index > repository.Length)
                {
                    throw new OutOfRangeException("The index is outside the array.");
                }
                return repository[index];
            }
            set
            {
                repository[index] = value;
            }
        }

        public T this[string name]
        {
            get
            {
                foreach (T p in repository)
                {
                    if (p.Name == name)
                    {
                        return p;
                    }
                }
                return default(T);
            }
            set
            {
                for (int i = 0; i < repository.Length; i++)
                {
                    if (repository[i].Name == name)
                    {
                        repository[i] = value;
                    }
                }
            }
        }

        public void Add(params T[] arg)
        {
            foreach (T p in arg)
            {
                if (p == null)
                {
                    throw new AddNullException("A null object was found in the array.");
                }
            }

            foreach (T a in arg)
            {
                (a as Product).Editing += PriceChanging;
                (a as Product).Edited += PriceChanged;
                Sum += (a as Product).Price;

                int length = repository.Length + 1;

                T[] newRepository = new T[length];

                for (var i = 0; i < repository.Length; i++)
                {
                    if (repository[i] != null) newRepository[i] = repository[i];
                }

                newRepository[length - 1] = a;

                repository = newRepository;
            }
        }

        public void Remove(int index)
        {
            (this[index] as Product).Editing -= PriceChanging;
            (this[index] as Product).Edited -= PriceChanged;
            Sum -= (this[index] as Product).Price;

            if (index >= repository.Length || index < 0)
            {
                throw new OutOfRangeException("Removal is not possible. The index is outside the array.");
            }

            T[] newRepository = new T[repository.Length - 1];

                for (int i = 0; i < repository.Length; i++)
                {
                    if (i < index)
                    {
                        newRepository[i] = repository[i];
                    }
                    else if (i > index)
                    {
                        newRepository[i - 1] = repository[i];
                    }
                }

                repository = newRepository;
        }

        public void Sort()
        {
            //Sort((x, y) => { return x.CompareTo(y); });

            for (int i = 0; i < repository.Length; i++)
            {
                for (int j = i + 1; j < repository.Length; j++)
                {
                    if (repository[i].CompareTo(repository[j]) > 0)
                    {
                        var temp = repository[i];
                        repository[i] = repository[j];
                        repository[j] = temp;
                    }
                }
            }
        }

        public void Sort(Compare<T> del)
        {
            //Array.Sort(repository, (T x, T y) => { return del(x, y); });

            for (int i = 0; i < repository.Length; i++)
            {
                for (int j = i + 1; j < repository.Length; j++)
                {
                    if (del(repository[i], repository[j]) > 0)
                    {
                        var obj = repository[i];
                        repository[i] = repository[j];
                        repository[j] = obj;
                    }
                }
            }
        }

        public T Find(Find<T> del)
        {
            foreach (T obj in this)
            {
                if (del(obj))
                {
                    return obj;
                }
            }
            return default(T);
        }

        public T[] FindAll(Find<T> del)
        {
            T[] main = new T[0];

            foreach (T obj in this)
            {
                if (del(obj))
                {
                    T[] temp = new T[main.Length + 1];

                    for (var i = 0; i < main.Length; i++)
                    {
                        temp[i] = main[i];
                    }

                    temp[temp.Length - 1] = obj;

                    main = temp;
                }
            }
            return main;
        }

        public override string ToString()
        {
            StringBuilder result = new StringBuilder("");
            foreach (T a in repository)
            {
                result.Append(a);
                result.Append("\n");
            }
            return result.ToString();
        }

        public IEnumerable Reverse()
        {
            for (int i = repository.Length - 1; i >= 0; i--)
            {
                yield return repository[i];
            }
        }

        public IEnumerable FindByString(string s)
        {
            for (int i = 0; i < repository.Length; i++)
            {
                if (repository[i].Name.Contains(s))
                {
                    yield return repository[i];
                }
            }
        }

        public IEnumerable InOrder()
        {
            T[] temp = new T[repository.Length];
            
            //temp = repository.OrderBy(x => x.Name).ToArray();

            for (int i = 0; i < repository.Length; i++)
            {
                temp[i] = repository[i];
            }

            for (int i = 0; i < temp.Length; i++)
            {
                for (int j = i + 1; j < temp.Length; j++)
                {
                    if ((temp[i] as Product).Price > (temp[j] as Product).Price)
                    {
                        var obj = temp[i];
                        temp[i] = temp[j];
                        temp[j] = obj;
                    }
                }
            }

            for (int i = 0; i < temp.Length; i++)
            {
                yield return temp[i];
            }
        }

        public IEnumerator<T> GetEnumerator()
        {
            return new ArrayListIterator<T>(this);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}