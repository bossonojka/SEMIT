﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Music
{
    [Serializable]
    public class ElectroGuitar : Guitar
    {
    
        private string typeOfPickups;

        public ElectroGuitar(string name, decimal price, string manufacturer, int numberOfStrings, string guitarNeck, string typeOfStrings, string typeOfPickups) : base(name, price, manufacturer, numberOfStrings, guitarNeck, typeOfStrings)
        {
            this.typeOfPickups = typeOfPickups;
        }

        public ElectroGuitar()
        {
            
        }

        public string TypeOfPickups
        {
            get
            {
                return typeOfPickups;
            }
            set
            {
                typeOfPickups = value;
            }
        }

        public override string ToString()
        {
            return string.Format($"Name:{name},Price:{price},manufacturer:{manufacturer},guitarNeck:{guitarNeck},numberOfStrings:{numberOfStrings},typeOfStrings:{typeOfStrings},typeOfPickups:{typeOfPickups}");
        }
    }
}