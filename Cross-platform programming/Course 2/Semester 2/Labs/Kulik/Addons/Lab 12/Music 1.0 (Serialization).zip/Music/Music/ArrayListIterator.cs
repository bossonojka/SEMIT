﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music
{
    class ArrayListIterator<T> : IEnumerator<T> where T : IName<T>
    {
        Container<T> parent;

        private int position;

        public ArrayListIterator(Container<T> parent)
        {
            this.parent = parent;
            position = -1;
        }

        public bool MoveNext()
        {
            if (position != parent.Repository.Length)
            {
                position++;
            }
            return position < parent.Repository.Length;
        }

        object IEnumerator.Current
        {
            get
            {
                if (position == -1 || position == parent.Repository.Length)
                {
                    throw new InvalidOperationException();
                }
                return parent[position];
            }
        }

        T IEnumerator<T>.Current
        {
            get
            {
                if (position == -1 || position == parent.Repository.Length)
                {
                    throw new InvalidOperationException();
                }
                return parent[position];
            }
        }

        public void Reset()
        {
            position = -1;
        }

        public void Dispose() { }
    }
}
