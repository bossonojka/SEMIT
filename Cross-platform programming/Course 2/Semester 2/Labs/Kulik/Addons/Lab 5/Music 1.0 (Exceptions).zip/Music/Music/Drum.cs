﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Music
{
    public class Drum : Instrument
    {
        private int depth;
        private string material;

        public Drum(string name, decimal price, string manufacturer, int depth, string material):base(name,price,manufacturer)
        {
            this.depth = depth;
            this.material = material;
        }

        public Drum()
        {
            throw new System.NotImplementedException();
        }

        public string Material
        {
            get
            {
                return material;
            }
            set
            {
                material = value;
            }
        }

        public int Depth
        {
            get
            {
                return depth;
            }
            set
            {
                depth = value;
            }
        }

        public override string ToString()
        {
            return string.Format($"Name:{name},Price:{price},manufacturer:{manufacturer},depth:{depth},material:{material}");
        }
    }
}