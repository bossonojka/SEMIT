﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Music
{
    public class DigitalPiano : Instrument
    {
        private int numberOfKeys;
        private string typeOfMechanics;

        public DigitalPiano()
        {
            throw new System.NotImplementedException();
        }

        public DigitalPiano(string name, decimal price, string manufacturer, int numberOfKeys, string typeOfMechanics):base(name, price, manufacturer)
        {
            this.numberOfKeys = numberOfKeys;
            this.typeOfMechanics = typeOfMechanics;
        }

        public string TypeOfMechanics
        {
            get
            {
                return typeOfMechanics;
            }
            set
            {
                typeOfMechanics = value;
            }
        }

        public int NumberOfKeys
        {
            get
            {
                return NumberOfKeys;
            }
            set
            {
                numberOfKeys = value;
            }
        }

        public override string ToString()
        {
            return string.Format($"Name:{name},Price:{price},manufacturer:{manufacturer},numberOfKeys:{numberOfKeys},typeOfMechanics:{typeOfMechanics}");
        }
    }
}