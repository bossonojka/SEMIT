﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music
{
    class OutOfRangeException : Exception
    {
        public int Length { get; set; }

        public OutOfRangeException(string message) : base(message)
        {

        }

        public OutOfRangeException() : base()
        {

        }
    }
}
