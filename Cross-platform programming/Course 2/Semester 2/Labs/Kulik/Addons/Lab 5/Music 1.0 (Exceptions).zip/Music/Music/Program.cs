﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Music
{
    public class Program
    {
        public static void Main()
        {
            //ArrayList
            Product elgr = new ElectroGuitar("SPG900", 3500, "FANNDEC", 6, "rosewood", "metal", "H-S-H");
            Product drm1 = new Drum("VMX-2218B/C250", 20628, "PEARL", 18, "maple");
            Product drm2 = new Drum("VMX-2216B/C280", 18850, "TAMA", 16, "bubinga");
            Product drm3 = new Drum("VMX-2168B/C270", 22150, "PEARL", 18, "maple");
            Product drm4 = new Drum("TBB2216S", 25448, "TAMA", 16, "bubinga");
            Product drm5 = new Drum("VMX-2218B/C280", 20627, "PEARL", 18, "maple");
            Product drm6 = new Drum("TBB2168S", 20700, "TAMA", 18, "bubinga");

            Container con = new Container();

            con.Add(elgr, drm1, drm2, drm3, drm4, drm5, drm6);

            con.Remove(1);
            con.Sort();

            Console.WriteLine(con.ToString());

            //LinkedList
            Product p1 = new ElectroGuitar("SPG800", 4895, "FANNDEC", 6, "redwood", "metal", "H-S-H");
            Product p2 = new Drum("VMX-2218BV/C270", 18745, "PEARL", 18, "maple");

            LinkedListContainer<Product> list = new LinkedListContainer<Product>();
            list.Add(p1);
            list.Add(p2);
            list.RemoveAt(1);

            Console.Read();
        }
    }
}