﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music
{
    class LinkedListContainer<T> : IEnumerable<T> where T: IName<T>
    {
        public event PriceChangingHadler Added;

        LinkedListNode<T> start;
        LinkedListNode<T> end;

        public uint Count { get; private set; }
        public decimal Sum { get; set; }

        public T this[int index]
        {
            get
            {
                if (index < 0 || index >= Count)
                {
                    throw new OutOfRangeException("The index is outside the list.");
                }

                var temp = start;
                for (int i = 0; i < index; i++)
                {
                    temp = temp.Next;
                }
                return temp.Data;
            }
            set
            {
                if (index < 0 || index >= Count)
                {
                    throw new OutOfRangeException("Specifying is not possible. The index is outside the list.");
                }

                var temp = start;
                for (int i = 0; i < index; i++)
                {
                    temp = temp.Next;
                }
                temp.Data = value;
            }
        }

        public T this[string name]
        {
            get
            {
                var temp = start;
                for (int i = 0; i < Count; i++)
                {
                    if (temp.Data.Name == name)
                    {
                        return temp.Data;
                    }

                    temp = temp.Next;
                }
                return default(T);
            }
            set
            {
                var temp = start;
                for (int i = 0; i < Count; i++)
                {
                    if (temp.Data.Name == name)
                    {
                        temp.Data = value;
                    }
                    temp = temp.Next;
                }
            }
        }

        public void Add(T obj)
        {
            if (obj == null)
            {
                throw new AddNullException("Adding is not possible. Object is null.");
            }

            LinkedListNode<T> node = new LinkedListNode<T>();
            node.Data = obj;
            if (start == null)
            {
                start = node;
                end = node;
            }
            else
            {
                end.Next = node;
                node.Previous = end;
                end = node;
            }
            Added(Sum += (obj as Product).Price);
            Count++;
        }

        public void Remove(int index)
        {
            if (index < 0 || index >= Count)
            {
                throw new OutOfRangeException("Specifying is not possible. The index is outside the list.");
            }
            else if (index == 0) // Если индекс равен начальному объекту в списке
            {
                if (start == null)
                {
                    throw new NullReferenceException();
                }
                else
                {
                    if (start.Next != null)
                    {
                        start.Next.Previous = null;
                    }
                    start = start.Next;
                    Count--;
                }
            }
            else if (index == Count - 1) // Если индекс равен последнему объекту в списке
            {
                if (end == null)
                {
                    throw new NullReferenceException();
                }
                else
                {
                    if (end.Previous != null)
                    {
                        end.Previous.Next = null;
                    }
                    end = end.Previous;
                    Count--;
                }
            }
            else
            {
                var temp = start;
                for (int i = 0; i < index; i++)
                {
                    temp = start.Next;
                }
                temp.Previous.Next = temp.Next;
                temp.Next.Previous = temp.Previous;
                Count--;
            }
        }

        public void Display()
        {
            if (start == null)
            {
                Console.WriteLine("Linked List is empty!");
                return;
            }

            var temp = start;

            for (int i = 0; i < Count; i++)
            {
                Console.WriteLine(temp.Data.ToString());
                temp = temp.Next;
            }
        }

        public void Sort()
        {
            T[] temp = new T[Count];
            for (int i = 0; i < Count; i++)
            {
                temp[i] = this[i];
            }

            temp = temp.OrderBy(x => x.Name).ToArray();

            for (int i = 0; i < Count; i++)
            {
                this[i] = temp[i];
            }
        }

        public void Sort(Compare<T> del)
        {
            T[] temp = new T[Count];

            for (var i = 0; i < Count; i++)
            {
                temp[i] = this[i];
            }

            Array.Sort(temp, (T x, T y) => { return del(x, y); });

            for (int i = 0; i < Count; i++)
            {
                this[i] = temp[i];
            }
        }

        public T Find(Find<T> del)
        {
            foreach (T obj in this)
            {
                if (del(obj)) return obj;
            }
            return default(T);
        }

        public T[] FindAll(Find<T> del)
        {
            T[] main = new T[0];

            foreach (T obj in this)
            {
                if (del(obj))
                {
                    T[] temp = new T[main.Length + 1];

                    for (var i = 0; i < main.Length; i++)
                    {
                        temp[i] = main[i];
                    }

                    temp[temp.Length - 1] = obj;

                    main = temp;
                }
            }
            return main;
        }

        public override string ToString()
        {
            StringBuilder result = new StringBuilder("");
            var temp = start;

            for (int i = 0; i < Count; i++)
            {
                result.Append(temp.Data);
                temp = temp.Next;
                result.Append("\n");
            }
            return result.ToString();
        }

        public IEnumerable Reverse()
        {
            for (int i = (int)Count - 1; i >= 0; i--)
            {
                yield return this[i];
            }
        }

        public IEnumerable FindByString(string s)
        {
            for (int i = 0; i < Count; i++)
            {
                if (this[i].Name.Contains(s))
                {
                    yield return this[i];
                }
            }
        }

        public IEnumerable InOrder()
        {
            T[] temp = new T[Count];
            var node = start;

            for (int i = 0; i < Count; i++)
            {
                temp[i] = node.Data;
                node = node.Next;
                
            }
           
            temp = temp.OrderBy(x => x.Name).ToArray();

            for (int i = 0; i < Count; i++)
            {
                yield return temp[i];
            }   
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }

        IEnumerator<T> IEnumerable<T>.GetEnumerator()
        {
            return new LinkedListIterator<T>(this);
        }
    }
}
