﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music
{
    class LinkedListIterator<T> : IEnumerator<T> where T : IName<T>
    {
        LinkedListContainer<T> parent;

        private int position;

        public LinkedListIterator(LinkedListContainer<T> parent)
        {
            this.parent = parent;
            position = -1;
        }

        public bool MoveNext()
        {
            if (position != parent.Count)
            {
                position++;
            }
            return position < parent.Count;
        }

        object IEnumerator.Current
        {
            get
            {
                if (position == -1 || position == parent.Count) throw new InvalidOperationException();
                return parent[position];
            }
        }

        T IEnumerator<T>.Current
        {
            get
            {
                if (position == -1 || position == parent.Count) throw new InvalidOperationException();
                return parent[position];
            }
        }

        public void Reset()
        {
            position = -1;
        }

        public void Dispose() { }
    }
}
