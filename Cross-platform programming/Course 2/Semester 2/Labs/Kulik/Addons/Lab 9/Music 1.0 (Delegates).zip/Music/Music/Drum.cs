﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Music
{
    public class Drum : Instrument
    {
        private int depth;
        private string material;

        public Drum(string name, decimal price, string manufacturer, int depth, string material):base(name,price,manufacturer)
        {
            this.depth = depth;
            this.material = material;
        }

        public Drum()
        {
            
        }

        public string Material
        {
            get
            {
                return material;
            }
            set
            {
                material = value;
            }
        }

        public int Depth
        {
            get
            {
                return depth;
            }
            set
            {
                if (depth < 0) throw new ZeroPriceException("The depth can`t be a negative value.");
                depth = value;
            }
        }

        public override string ToString()
        {
            return string.Format($"Name:{name},Price:{price},manufacturer:{manufacturer},depth:{depth},material:{material}");
        }
    }
}