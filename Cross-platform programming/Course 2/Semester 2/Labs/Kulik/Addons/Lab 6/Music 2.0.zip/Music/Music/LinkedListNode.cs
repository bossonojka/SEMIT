﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music
{
    class LinkedListNode
    {
        public LinkedListNode Next { get; set; }
        public LinkedListNode Previous { get; set; }
        public IName Data { get; set; }
    }
}
