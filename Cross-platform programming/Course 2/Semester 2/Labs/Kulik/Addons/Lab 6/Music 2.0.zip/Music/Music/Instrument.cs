﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Music
{
    public class Instrument : Product
    {
        protected string manufacturer;

        public Instrument(string name, decimal price, string manufacturer):base(name, price)
        {
            this.manufacturer = manufacturer;
        }

        public Instrument()
        {
            
        }

        public string Manufacturer
        {
            get
            {
                return manufacturer;
            }
            set
            {
                manufacturer = value;
            }
        }

        public override string ToString()
        {
            return string.Format($"Name:{name},Price:{price},manufacturer:{manufacturer}");
        }
    }
}