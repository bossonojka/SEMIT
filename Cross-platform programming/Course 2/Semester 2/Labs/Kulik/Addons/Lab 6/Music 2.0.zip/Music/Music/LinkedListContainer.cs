﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music
{
    class LinkedListContainer : Product
    {
        LinkedListNode start;
        LinkedListNode end;

        public uint Count { get; private set; }

        public IName this[int index]
        {
            get
            {
                if (index < 0 || index >= Count)
                {
                    throw new OutOfRangeException("The index is outside the list.");
                }

                var temp = start;
                for (int i = 0; i < index; i++)
                {
                    temp = temp.Next;
                }
                return temp.Data;
            }
            set
            {
                if (index < 0 || index >= Count)
                {
                    throw new OutOfRangeException("Specifying is not possible. The index is outside the list.");
                }

                var temp = start;
                for (int i = 0; i < index; i++)
                {
                    temp = temp.Next;
                }
                temp.Data = value;
            }
        }

        public IName this[string name]
        {
            get
            {
                var temp = start;
                for (int i = 0; i < Count; i++)
                {
                    if (temp.Data.Name == name)
                    {
                        return temp.Data;
                    }

                    temp = temp.Next;
                }
                return null;
            }
            set
            {
                var temp = start;
                for (int i = 0; i < Count; i++)
                {
                    if (temp.Data.Name == name)
                    {
                        temp.Data = value;
                    }
                    temp = temp.Next;
                }
            }
        }

        public void Add(IName obj)
        {
            if (obj == null)
            {
                throw new AddNullException("Adding is not possible. Object is null.");
            }

            LinkedListNode node = new LinkedListNode();
            node.Data = obj;
            if (start == null)
            {
                start = node;
                end = node;
            }
            else
            {
                end.Next = node;
                node.Previous = end;
                end = node;
            }
            Count++;
        }

        public void Remove(int index)
        {
            if (index < 0 || index >= Count)
            {
                throw new OutOfRangeException("Specifying is not possible. The index is outside the list.");
            }
            else if (index == 0) // Если индекс равен начальному объекту в списке
            {
                if (start == null)
                {
                    throw new NullReferenceException();
                }
                else
                {
                    if (start.Next != null)
                    {
                        start.Next.Previous = null;
                    }
                    start = start.Next;
                    Count--;
                }
            }
            else if (index == Count - 1) // Если индекс равен последнему объекту в списке
            {
                if (end == null)
                {
                    throw new NullReferenceException();
                }
                else
                {
                    if (end.Previous != null)
                    {
                        end.Previous.Next = null;
                    }
                    end = end.Previous;
                    Count--;
                }
            }
            else
            {
                var temp = start;
                for (int i = 0; i < index; i++)
                {
                    temp = start.Next;
                }
                temp.Previous.Next = temp.Next;
                temp.Next.Previous = temp.Previous;
                Count--;
            }
        }

        public void Display()
        {
            if (start == null)
            {
                Console.WriteLine("Linked List is empty!");
                return;
            }

            var temp = start;

            for (int i = 0; i < Count; i++)
            {
                Console.WriteLine(temp.Data.ToString());
                temp = temp.Next;
            }
        }

        public void Sort()
        {
            IName[] temp = new IName[Count];
            for (int i = 0; i < Count; i++)
            {
                temp[i] = this[i];
            }

            temp = temp.OrderBy(x => x.Name).ToArray();

            for (int i = 0; i < Count; i++)
            {
                this[i] = temp[i];
            }
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
