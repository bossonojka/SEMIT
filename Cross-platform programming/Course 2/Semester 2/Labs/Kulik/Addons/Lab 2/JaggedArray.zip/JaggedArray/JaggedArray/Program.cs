﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JaggedArray
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите количество строк: \n");
            int n = int.Parse(Console.ReadLine());
            int[][] arr = new int[n][];
            for (int i = 0; i < arr.Length; i++)
            {
                string s = Console.ReadLine();
                string[] s1 = s.Split(new char[] { ' ', '\t' });
                arr[i] = new int[s1.Length];

                for (int j = 0; j < s1.Length; j++)
                    arr[i][j] = int.Parse(s1[j]);
            }


            Console.WriteLine("Начальный массив:");
            PrintArr(arr);

            Console.WriteLine("Удаляем нулевые строки:");
            arr = deleteArrElement(arr);
            Console.WriteLine();
            PrintArr(arr);

            Console.WriteLine("Отредактированный массив:");
            Console.WriteLine();
            PrintArr(editByTask(arr));
            Console.ReadLine();
        }

        public static bool isNullStr(int[] arr)
        {
            bool result = false;

            int sum = 0;


            for (int i = 0; i < arr.Length; i++)
            {

                sum = sum + arr[i];
            }

            if (sum == 0)
            {

                result = true;
            }
            //bool check = false;

            //for (int i = 0; i < arr.Length; i++)
            //{
            //    if (arr[i] == 0)
            //    {
            //        check = true;

            //    }

            //    else
            //    {
            //        check = false;

            //    }

            //}

            //if (check == true)
            //{

            //    result = true;
            //}

            return result;

        }

        static void PrintArr(int[][] arr)
        {

            for (int i = 0; i < arr.Length; i++)
            {

                for (int j = 0; j < arr[i].Length; j++)
                {

                    Console.Write(arr[i][j] + " ");
                }
                Console.WriteLine();
            }

            Console.WriteLine();
        }

        static int[][] deleteArrElement(int[][] arr)
        {

            List<int[]> intArrList = new List<int[]>();
            var numberList = arr[0].ToList();

            for (int i = 0; i < arr.Length; i++)
            {
                if (isNullStr(arr[i]) == false)
                {
                    intArrList.Add(arr[i]);

                }
            }

            arr = intArrList.ToArray();

            return arr;
        }

        public static bool isPalindrom(int[] s)
        {
            for (int i = 0; i < s.Length / 2; i++)
                if (s[i] != s[s.Length - i - 1])
                    return false;

            return true;
        }

        public static int[][] editByTask(int[][] arr)
        {

            List<int[]> intArrList = new List<int[]>();
            int[] temp;
            for (int i = 0; i < arr.Length; i++)
            {

                intArrList.Add(arr[i]);
                if (isPalindrom(arr[i]) == false)
                {
                    temp = new int[arr[i].Length];
                    Array.Copy(arr[i], temp, arr[i].Length);
                    Array.Reverse(temp);
                    intArrList.Add(temp);


                }

                //intArrList.Add(arr[i]);



                //if (isPalindrom(arr[i]) == false)
                //{

                //    intArrList.Add(ReverseArr(arr[i]));        

                //}

            }

            

            arr = intArrList.ToArray();
            return arr;
        }

        public static int[] ReverseArr(int[] arr)
        {
            Array.Reverse(arr);
            return arr;
        }
    }
}
