#include <iostream>
#include <cstdlib>

using namespace std;

void First() {
	int a;
	int b;
	int c;

	cout << "������� a, b, c\n";
	cin >> a >> b >> c;
	int D = b * b - 4 * a * c;

	if (D < 0)
		cout << "D<0, ���� �������\n";
	if (D == 0) {
		double x = (double)(-1 * b / (2 * a));
		cout << "D=0, � = " << x << endl;
	}
	if (D > 0) {
		double x1 = (double)((-1 * b + sqrt(D)) / (2 * a));
		double x2 = (double)((-1 * b - sqrt(D)) / (2 * a));

		cout << "D>0, x1 = " << x1 << " x2 = " << x2 << endl;
		system("pause");
	}
}
