package MIn;

public abstract class minOfFunc {

    abstract double f(double x);

    double solve(double a, double b, double h) {

        double x = 0;

        double temp = 0;

        for( ; a<=b;a+=h){

            x= f(a);

            temp =x;

            if (x<temp)temp=x;

        }

        return temp;

    }}

