package com.myprog;

import java.util.Comparator;

public class CompareComments implements Comparator<Station> {

    public int compare(Station o1, Station o2) {

        return Integer.compare(o1.getCommentLenght(),(o2.getCommentLenght()));

    }

}
