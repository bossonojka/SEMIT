package hierarchy;

public class Human {

    private String name;

    private int age;

    public Human(String name, int age){

        this.name = name;

        this.age = age;

    }

    public String getName(){

        return name;

    }

    public int getAge(){

        return age;

    }

    public String toString(){

        return"Name of human: "+name+"Age of Human" +age;

    }

}

class Citizen extends Human{

    private int pass;

    public Citizen(String name, int age, int pass){

        super(name,age);

        this.pass = pass;

    }

    public int getPass(){

        return pass;

    }

    public String toString(){

        return"Name of Citizen: "+" "+getName()+" "+"Ages: "+" "+getAge()+" "+"Passport: "+pass;

    }

}

class Staff extends Citizen{

    private int income;

    public Staff(String name, int age, int pass, int income){

        super(name,age,pass);

        this.income = income;

    }

    public int getIncome(){

        return income;

    }

    public String toString(){

        return"Name of Staff: "+" "+getName()+" "+"Age: "+" "+getAge()+" "+"Passport: "

                +" "+getPass()+" "+"Income: "+" "+income;

    }

}

class Student extends Human{

    private String pulpit;

    public Student(String name, int age, String pulpit){

        super(name,age);

        this.pulpit = pulpit;

    }

    public String getPulpit(){

        return pulpit;

    }

    public String toString(){

        return"Name of Student: "+" "+getName()+" "+"Age: "+" "+getAge()+" "+"Pulpit: "+" "+pulpit;

    }

}