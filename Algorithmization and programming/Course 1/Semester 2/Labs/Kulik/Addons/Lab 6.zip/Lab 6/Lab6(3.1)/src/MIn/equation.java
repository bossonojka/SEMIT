package MIn;

public class equation extends minOfFunc {

    double f(double x) {

        return x * x - 2; }

    public static void main(String[] args) {

        equation se = new equation();

        System.out.println(se.solve(-3, 6, 1));}}
