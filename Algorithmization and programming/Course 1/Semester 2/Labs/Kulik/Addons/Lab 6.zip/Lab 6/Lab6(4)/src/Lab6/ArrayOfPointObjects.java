package Lab6;

public class ArrayOfPointObjects extends AbstractArrayOfPoints {
    private double[][] p = new double[2][0];
    @Override
    public void setPoint(int i, double x, double y) {
        if (i < count()) {
            p[0][i] = x;
            p[1][i] = y;
        }
    }

    @Override
    public double getX(int i) {
        return p[0][i];
    }

    @Override
    public double getY(int i) {
        return p[1][i];
    }

    @Override
    public int count() {
        return p[0].length;
    }

    @Override
    public void addPoint(double x, double y) {
        double[][] p1 = new double[2][p[0].length+1];
        for (int k = 0; k < p.length; k++) {
            System.arraycopy(p[k], 0, p1[k], 0, p[k].length);
        }
        // Записуємо нову точку в останній елемент:
        p1[0][p[0].length] = x;
        p1[1][p[0].length] = y;
        p = p1; // Тепер p вказує на новий масив
    }

    @Override
    public void removeLast() {
        if (p.length == 0) {
            return; // Масив уже порожній
        }
        // Створюємо масив, менший на один елемент:
        double[][] p1 = new double[2][p[0].length];
        // Копіюємо всі елементи, крім останнього:
        for (int k = 0; k < p.length; k++) {
            System.arraycopy(p[k], 0, p1[k], 0, p[k].length-1);
        }
        p = p1;
    }

    public static void main(String[] args) {
        // Можна створити безіменний об'єкт:
        new ArrayOfPointObjects().test();
    }
}
