package com.myprog;

import java.util.Arrays;
import java.util.Comparator;

public class Time {
    private String name;
    private int year;
    private Station[] Stationes;

    public static Station[] addToArray(Station[] arr, Station item) {
        Station[] newArr;
        if (arr != null) {
            newArr = new Station[arr.length + 1];
            System.arraycopy(arr, 0, newArr, 0, arr.length);
        }
        else {
            newArr = new Station[1];
        }
        newArr[newArr.length - 1] = item;
        return newArr;
    }

    public Time(String name, int year, Station[] Stationes) {
        this.name = name;
        this.year = year;
        this.Stationes = Stationes;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof Time)) {
            return false;
        }
       Time c = (Time) obj;
        if (!getName().equals(c.getName()) || getyear() != c.getyear()) {
            return false;
        }
        return Arrays.equals(getStationes(), c.getStationes());
    }

    public boolean addStations(Station tem){

        if(getStationes() != null){

            for(Station p : getStationes()){

                if(p.equals(tem)){

                    return true;

                }

            }

        }

        setStationes(addToArray(getStationes(),tem));

        return false;

    }

    @Override
    public String toString() {
        String result = getName() + ". Год: " + getyear() + " кв. км.";
        for (int i = 0; i < getcountwords(); i++) {
            result += "\n" + getStationes();
        }
        return result;
    }

    public int getyear() {
        return this.year;
    }

    public boolean addStation(Station station) {
        if (getStationes() != null) {
            for (Station c : getStationes()) {
                if (c.equals(station)) {
                    return false;
                }
            }
        }
        getStationes();
        return true;
    }

    public void setyear(int year) {
        this.year = year;
    }

    public Station[] getStationes() {
        return this.Stationes;
    }

    public void setStationes(Station[] Stationes) {
        this.Stationes = Stationes;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String maxtime() {
        Station Station = this.Stationes[0];

        for(int i = 1; i < this.Stationes.length; ++i) {
            if(Station.getpassangers() > this.Stationes[i].getpassangers()) {
                Station = this.Stationes[i];
            }
        }

        return Station.gettime();
    }

    public int getcount(Station[] Stationes) {
        int sum = 0;

        for(int i = 0; i < Stationes.length; ++i) {
            sum += Stationes[i].getpassangers();
        }

        return sum;
    }

    public int getcountwords() {
        int sum = 0;

        for(int i = 0; i < Stationes.length; ++i) {
            sum += Stationes[i].getpassangers();
        }

        return sum;
    }

    public String Findminword() {
        Station min = this.Stationes[0];

        for(int i = 0; i < this.Stationes.length; ++i) {
            if(this.Stationes[i].getComments().split(" ").length < min.getComments().split(" ").length) {
                min = this.Stationes[i];
            }
        }

        return min.getComments();
    }

    public Station[] findWord(String word) {
        Station[] result = null;
        for (Station station : getStationes()) {
            if (station.containsWord(word)) {
                result = addToArray(result, station);
            }
        }
        return result;
    }

    private void printWord(String word) {
        Station[] result = findWord(word);
        if (result == null) {
            System.out.println("Слово \"" + word + "\" не міститься в коментарях.");
        }
        else {
            System.out.println("Слово \"" + word + "\" міститься в коментарях:");
            for (Station station : result) {
                System.out.println(station);
            }
        }
    }

    public void sortByPassangers() {
        Arrays.sort(Stationes);
    }

    public static void main(String[] args) {
        Station[] Stationes = new Station[]{new Station("10.25", 400, "Загрузка метро не максимальная"),
                new Station("12.35", 300, "Загрузка ниже среднего"),
                new Station("14.30", 200, "Метро в данное время не загружено"),
                new Station("16.25", 550, "Загруженность метро после обеда"),
                new Station("8.30", 500, "Загруженность метро утром")};
        Time Time = new Time("Холодная гора", 1978, Stationes);
        //System.out.println("Время с наименьшим количеством пассажиров: " + Time.maxtime());
       // System.out.println("Суммароное количество пассажиров: " + Time.getcount(Stationes));
       // System.out.println("Минимальное количество слов в комментарии: " + Time.Findminword());

        Time.printWord("Загрузка");
        Time.printWord("Загруженность");

        System.out.println("\nЗа зб кількості пасажирів:");
        Arrays.sort(Stationes);
        System.out.println(Arrays.asList(Stationes));

        System.out.println("\nЗа зб довжини коментаря:");

        Arrays.sort(Stationes,new CompareComments());

        System.out.println(Arrays.asList(Stationes));

        Station day = new Station ("10.25", 400, "Загружка метро не максимальная");

        Time.addStations(day);

    }
}

