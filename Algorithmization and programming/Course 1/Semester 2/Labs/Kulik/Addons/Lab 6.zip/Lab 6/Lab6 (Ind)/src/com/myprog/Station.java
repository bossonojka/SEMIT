package com.myprog;

import java.util.StringTokenizer;

public class Station implements Comparable<Station> {
    private String time;
    private int passangers;
    private String comments;

    @Override
    public String toString() {
        return "Время " + gettime() + ". Пассажиры: " + getpassangers() +
                ". Комментарий: " + getComments();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof Station)) {
            return false;
        }
        Station c = (Station) obj;
        return c.getpassangers() == getpassangers() &&
                c.getpassangers() == getpassangers() &&
                c.getComments().equals(getComments());
    }

    @Override
    public int compareTo(Station c) {
        return Integer.compare(getpassangers(), c.getpassangers());
    }

    public Station(String time, int passangers, String comments) {
        this.time = time;
        this.passangers = passangers;
        this.comments = comments;
    }

    public String getComments() {
        return this.comments;
    }

    public int getCommentLenght() {

        int length = comments.length();

        return length;

    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public int getpassangers() {
        return this.passangers;
    }

    public void setpassangers(int passangers) {
        this.passangers = passangers;
    }

    public String gettime() {
        return this.time;
    }

    public void settime(String time) {
        this.time = time;
    }

    public boolean containsWord(String word) {
        StringTokenizer st = new StringTokenizer(this.comments);

        String s;
        do {
            if(!st.hasMoreTokens()) {
                return false;
            }

            s = st.nextToken();
        } while(!s.toUpperCase().equals(word.toUpperCase()));

        return true;
    }
    public boolean containsSubstring(String substring) {
        return getComments().toUpperCase().indexOf(substring.toUpperCase()) >= 0;
    }

    private void testWord(String word) {
        if (containsWord(word)) {
            System.out.println("Слово \"" + word + "\" міститься у коментарі");
        } else {
            System.out.println("Слово \"" + word + "\" не міститься у коментарі");
        }
        if (containsSubstring(word)) {
            System.out.println("Текст \"" + word + "\" міститься у коментарі");
        } else {
            System.out.println("Текст \"" + word + "\" не міститься у коментарі");
        }
    }

    public static void main(String[] args) {
        Station station = new Station("14.30",200,"Метро Холодная гора");
        station.testWord("Метро");
        station.testWord("Холодная");
        station.testWord("Горы");

    }
}


