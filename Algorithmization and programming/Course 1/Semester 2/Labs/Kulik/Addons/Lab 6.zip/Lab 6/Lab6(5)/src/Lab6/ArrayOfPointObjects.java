package Lab6;

public class ArrayOfPointObjects extends AbstractArrayOfPoints {
    private double[] p = {};
    @Override
    public void setPoint(int i, double x, double y) {
        if (i < count()) {
            p[i*2] = x;
            p[i*2+1] = y;
        }
    }

    @Override
    public double getX(int i) {
        return p[i*2];
    }

    @Override
    public double getY(int i) {
        return p[i*2+1];
    }

    @Override
    public int count() {
        return p.length/2;
    }

    @Override
    public void addPoint(double x, double y) {
        double[] p1 = new double[p.length+2];
        System.arraycopy(p, 0, p1, 0, p.length);
        // Записуємо нову точку в останній елемент:
        p1[p.length] = x;
        p1[p.length+1] = y;
        p = p1; // Тепер p вказує на новий масив
    }

    @Override
    public void removeLast() {
        if (p.length == 0) {
            return; // Масив уже порожній
        }
        // Створюємо масив, менший на один елемент:
        double[] p1 = new double[p.length];
        // Копіюємо всі елементи, крім останнього:
        System.arraycopy(p, 0, p1, 0, p.length-2);
        p = p1;
    }

    public static void main(String[] args) {
        // Можна створити безіменний об'єкт:
        new ArrayOfPointObjects().test();
    }
}


