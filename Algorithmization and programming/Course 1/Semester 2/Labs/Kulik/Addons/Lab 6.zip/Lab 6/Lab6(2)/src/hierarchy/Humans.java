package hierarchy;

public class Humans {

    public static void main(String[] args) {

        Human[] a = {new Staff("Bogdan", 25, 200321, 25000),

                new Student("Andrew", 18, "Computer Technologies"),

                new Citizen("John", 20, 212030)

        };

        for (Human human : a) {

            System.out.println(human);

        }

    }
}