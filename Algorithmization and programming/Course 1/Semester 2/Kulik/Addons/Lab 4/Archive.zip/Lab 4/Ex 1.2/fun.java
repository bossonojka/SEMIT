package ko;

import java.util.Scanner;
import java.lang.Math;

/**
 * Created by Vlad on 16.04.2017.
 */
public class fun {
    public static double f(double x) {
        final int n = 10;
        double y;
        if (x < 0) {
            y = 0;
            for (int i = 1; i <= n; i++) {
                y += 0.25 * x + 14 * Math.pow(Math.sin(0.5 * x - 2), i);
            }
        } else {
            y = 1;
            for (int i = 1; i <= n; i++) {
                y += Math.sqrt(x-3);
            }
        }
        return y;
    }

    @SuppressWarnings("resource")
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Уведiть x: ");
        double x = s.nextDouble();
        double y = f(x); // Виклик функції
        System.out.println("x = " + x + "\ty = " + y);
    }

}
