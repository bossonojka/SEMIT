package ko;

import java.util.Scanner;
/**
 * Created by Vlad on 17.04.2017.
 */
public class step2 {
    @SuppressWarnings("resource")
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Уведіть n у діапазоні від 0 до 10");
        int n = scanner.nextInt();
        if (n < 0 || n > 10) {
            System.err.println("Неправильне значення n");
        }
        else {
            for (int i = 0; i <= n; i++) {
                if(i==0)
                {
                    System.out.printf("8 ^ %2d = %d\n", i, 0);
                }
                System.out.printf("8 ^ %2d = %d\n", i+1, 8<< i*3);
            }
        }
    }

}
