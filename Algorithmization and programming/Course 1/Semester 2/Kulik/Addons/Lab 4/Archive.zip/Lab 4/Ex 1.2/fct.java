package ko;

import java.util.Scanner;

/**
 * Created by Vlad on 17.04.2017.
 */
public class fct {
    @SuppressWarnings("resource")
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Уведiть n факторіал: ");
        int n = scanner.nextInt();
        int fac = 1;
        for (int i = 1; i <= n; i++) {
            fac *=i;
        }
        System.out.println(n+"!=" + fac);
    }

}
