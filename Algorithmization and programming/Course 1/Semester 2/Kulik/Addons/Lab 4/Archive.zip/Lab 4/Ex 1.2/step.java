package ko;

import java.util.Scanner;
/**
 * Created by Vlad on 17.04.2017.
 */
public class step {
    @SuppressWarnings("resource")
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Уведіть n у діапазоні від 0 до 10");
        int n = scanner.nextInt();
        int power = 1;
        final int k = 8;
        if (n < 0 || n > 10) {
            System.err.println("Неправильне значення n");
        } else {
            for (int i = 0; i <= n; i++) {
                System.out.printf("8 ^ %2d = %d\n", i, power);
                power *= k;
            }
        }
    }

}
