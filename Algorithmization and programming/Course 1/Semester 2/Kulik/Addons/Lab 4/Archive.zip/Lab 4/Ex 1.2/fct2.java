package ko;

import java.util.Scanner;
/**
 * Created by Vlad on 17.04.2017.
 */
public class fct2 {
    static int fac(int n)
    {
        if(n > 0)
        {
            return n * fac(n-1);
        }
        return 1;
    }
    @SuppressWarnings("resource")
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Уведіть факторіал:");
        int x = scanner.nextInt();
        int p = fac(x);
        System.out.println(x+"!=" + p);


    }

}
