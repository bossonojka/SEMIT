package com.company;

import java.util.StringTokenizer;


public class Time {
    private String name;
    private int year;
    private Station[] Stationes;

    public Time(String name, int year, Station[] Stationes) {
        this.name = name;
        this.year = year;
        this.Stationes = Stationes;
    }

    public int getyear() {
        return year;
    }

    public void setyear(int year) {
        this.year = year;
    }

    public Station[] getStationes() {
        return Stationes;
    }

    public void setStationes(Station[] Stationes) {
        this.Stationes = Stationes;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String maxtime() {
        Station Station = Stationes[0];
        for (int i = 1; i < Stationes.length; i++) {
            if (Station.getpassangers() > Stationes[i].getpassangers()) {
                Station = Stationes[i];
            }
        }
        return Station.gettime();
    }


    public int getcount(Station[] Stationes) {
        int sum = 0;
        for (int i=0; i < Stationes.length; i++){
            sum += Stationes[i].getpassangers();
        }
        return sum;
    }

    public int getcountwords(Station[] Stationes) {
        int sum = 0;
        for (int i=0; i < Stationes.length; i++){
            sum += Stationes[i].getpassangers();
        }
        return sum;
    }

    public String Findminword(){
        Station min = this.Stationes[0];

        for (int i = 0; i < this.Stationes.length; i++){
            if (this.Stationes[i].getComments().split(" ").length < min.getComments().split(" ").length){
                min = this.Stationes[i];
            }
        }
        return min.getComments();
    }

    public static void main(String[] args) {
        Station[] Stationes = {
                new Station("10.25", 400, "Загружка метро не максимальная"),
                new Station("12.35", 300, "Загрузка ниже среднего"),
                new Station("14.30", 200, "Метро в данное время не загружено"),
                new Station("16.25", 550, "Загруженность метро после обеда"),
                new Station("8.30", 500, "Загруженность метро утром")
        };
        Time Time = new Time("Холодная гора", 1978, Stationes);
        System.out.println("Время с наименьшим количеством пассажиров: " + Time.maxtime());
        System.out.println("Суммароное количество пассажиров: " + Time.getcount(Stationes));
        System.out.println("Минимальное количество слов в комментарии: " + Time.Findminword());
    }
}