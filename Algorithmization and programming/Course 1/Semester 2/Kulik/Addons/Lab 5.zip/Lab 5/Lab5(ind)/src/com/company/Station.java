package com.company;

import java.util.StringTokenizer;

public class Station {
    private String time;
    private int passangers;
    private String comments;

    public Station(String time, int passangers, String comments) {
        this.time = time;
        this.passangers = passangers;
        this.comments = comments;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public int getpassangers() {
        return passangers;
    }

    public void setpassangers(int passangers) {
        this.passangers = passangers;
    }

    public String gettime() {
        return time;
    }

    public void settime(String time) {
        this.time = time;
    }

    public boolean containsWord(String word) {
        StringTokenizer st = new StringTokenizer(comments);
        String s;
        while (st.hasMoreTokens()) {
            s = st.nextToken();
            if (s.toUpperCase().equals(word.toUpperCase())) {
                return true;
            }
        }
        return false;
    }
}