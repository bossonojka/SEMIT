package com.company;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        long[] Mas=new long[92];
        for(int i=0;i<Mas.length;i++){
            if(i<2)
                Mas[i]=1;
            else
                Mas[i]=Mas[i-2]+Mas[i-1];
            System.out.print(Mas[i]+" ");
        }
    }
}
