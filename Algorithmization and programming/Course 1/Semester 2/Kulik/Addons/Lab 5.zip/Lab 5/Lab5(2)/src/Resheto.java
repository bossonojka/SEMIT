public class Resheto
{

    public static void main(String[] args)
    {
        int []number = new int[300];
        for (int i = 0; i<300 ; i++)
            number[i]=i;
        int p=2;
        do
            {
            for(int i=2*p; i<300; i = i + p)
                number[i]=-1;
            int j=p+1;
            while(number[j]<0)
                j++;
            p=j;
        }
        while(p*p<300);
        for (int i = 1; i<300 ; i++)
            if(number[i]>0)
                System.out.println(number[i]);
    }
}
