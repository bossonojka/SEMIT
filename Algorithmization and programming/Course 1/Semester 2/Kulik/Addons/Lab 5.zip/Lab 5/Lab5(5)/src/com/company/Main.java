package com.company;

import java.util.Scanner;

public class Main {

    public static void main (String[] args){
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        scan.close();
        String s = args[0];
        System.out.println("Basicstring: "+s+" "+s.length());
        while(s.length()<n)
        {
            s+=" ";
        }
        System.out.println("ResultString: "+s+s.length());
    }
}
