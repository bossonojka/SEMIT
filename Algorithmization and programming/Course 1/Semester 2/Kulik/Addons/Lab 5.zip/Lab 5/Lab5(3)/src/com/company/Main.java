package com.company;

public class Main {

    public static void main(String args[]) {
        int[] a = new int[5];
        System.out.println("Primary array: ");
        for (int i = 0; i < a.length; i++) {
            a[i] = (int) (Math.random() * 100);
            System.out.print(a[i] + "  ");
        }

        for (int i = 0; i < a.length - 1; i++) {
            int iMin = i;
            for (int j = i + 1; j < a.length; j++) {
                if (a[j] < a[iMin])
                    iMin = j;
            }

            int z = a[i];
            a[i] = a[iMin];
            a[iMin] = z;
        }
        System.out.println("\nSorted array: ");
        for (int i = 0; i < a.length; i++)
            System.out.print(a[i] + "  ");

    }
}
