package com.company;

import java.lang.String;
import java.util.StringTokenizer;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Введіть текст:");
        String str = scan.nextLine();
        scan.close();
        StringTokenizer st = new StringTokenizer(str);
        while (st.hasMoreTokens()) {
            str = st.nextToken();
            System.out.print(str.toUpperCase().charAt(0));
        }
    }

}

