#include <iostream>
using std::cin;
using std::cout;
using std::endl;
using std::istream;
using std::ostream;

class Fraction {
	friend istream& operator >> (istream& in, Fraction& fr) { return in >> fr.numerator >> fr.denominator; }
	friend ostream& operator<<(ostream& out, const Fraction& fr) { return out << "numerator=" << fr.numerator << " denominator=" << fr.denominator; }
	friend Fraction operator*(Fraction fr1, Fraction fr2) { return Fraction(fr1.numerator * fr2.numerator, fr1.denominator * fr2.denominator); }
	friend Fraction operator* (Fraction fr, int val) { return Fraction(fr.numerator * val, fr.denominator); }
	friend Fraction operator/(Fraction fr1, Fraction fr2) { return Fraction(fr1.numerator * fr2.denominator, fr1.denominator * fr2.numerator); }
	friend Fraction operator/ (Fraction fr, int val) { return Fraction(fr.numerator, fr.denominator * val); }
	friend Fraction operator+(Fraction fr1, Fraction fr2)
	{
		int new_den = fr1.denominator*fr2.denominator;
		int new_num = (new_den / fr1.denominator*fr1.numerator) + (new_den / fr2.denominator*fr2.numerator);
		return Fraction(new_num, new_den);
	}
	friend Fraction operator-(Fraction fr1, Fraction fr2)
	{
		int new_den = fr1.denominator*fr2.denominator;
		int new_num = (new_den / fr1.denominator*fr1.numerator) - (new_den / fr2.denominator*fr2.numerator);
		return Fraction(new_num, new_den);
	}

private:
	int numerator;
	int denominator;
public:
	Fraction() { numerator = denominator = 0; }
	Fraction(int numerator, int denominator);
	void Socr(int a, int b);
	double getX() { return numerator; }
	void setX(int numerator) { this->numerator = numerator; }
	double getY() { return denominator; }
	void setY(int denominator) { this->denominator = denominator; }
};
Fraction::Fraction(int numerator, int denominator)
{
	if (denominator == 0)
		throw std::runtime_error("zero division error");
	Socr(numerator, denominator);
}
void Fraction::Socr(int a, int b)
{
	int x = (a < b) ? a : b;
	for (int i = 2; i <= x; i++)
		if (a%i == 0 && b%i == 0)
		{
			a /= i;
			b /= i;
		}
	numerator = a;
	denominator = b;
}

void main()
{
	Fraction fr1, fr2;
	cout << "Input first fraction: ";
	cin >> fr1;
	cout << "Input second fraction: ";
	cin >> fr2;
	cout << fr1 * fr2 << endl;
	cout << fr1 * 4 << endl;
	cout << fr1 / fr2 << endl;
	cout << fr1 / 4 << endl;
	cout << fr1 + fr2 << endl;
	cout << fr1 - fr2 << endl;
}
