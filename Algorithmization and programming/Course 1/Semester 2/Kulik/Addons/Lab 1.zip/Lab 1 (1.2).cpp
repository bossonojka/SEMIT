#include <iostream>
using std::cout;
using std::endl;
using std::cin;
using std::istream;
using std::ostream;

class IntArray
{
	friend ostream& operator<<(ostream& out, const IntArray& a)
	{
		for (int i = 0; i < a.m; i++)
		{
			for (int j = 0; j < a.n; j++)
			{
				out << a.pa[i][j] << ' ';
			}
			cout << "\n";
		}
		return out;
	}
	friend istream& operator >> (istream& in, IntArray& a)
	{
		for (int i = 0; i < a.m; i++)
		{
			for (int j = 0; j < a.n; j++)
			{
				in >> a.pa[i][j];
			}
		}
		return in;
	}
	friend int operator*(IntArray& v1, IntArray& v2)
	{
		if (v1.n == v2.m)
		{
			IntArray a = IntArray(v1.m, v2.n);
			for (int i = 0; i < v1.m; i++)
			{
				for (int j = 0; j < v2.n; j++)
				{
					int sum = 0;
					for (int k = 0; k < v1.n; k++)
					{
						sum += v1.pa[i][k] * v2.pa[k][j];
					}
					a.pa[i][j] = sum;
				}
			}
			cout << a;
			return 0;
		}
		else
		{
			return 1;
		}
	}
	friend int operator+(IntArray& v1, IntArray& v2)
	{
		if (v1.m == v2.m && v1.n == v2.n)
		{
			IntArray a = IntArray(v1.m, v1.n);
			for (int i = 0; i < v1.m; i++)
			{
				for (int j = 0; j < v1.n; j++)
				{
					a.pa[i][j] = v1.pa[i][j] + v2.pa[i][j];
				}
			}
			cout << a;
			return 0;
		}
		else
		{
			return 1;
		}
	}
	friend int operator-(IntArray& v1, IntArray& v2)
	{
		if (v1.m == v2.m && v1.n == v2.n)
		{
			IntArray a = IntArray(v1.m, v1.n);
			for (int i = 0; i < v1.m; i++)
			{
				for (int j = 0; j < v1.n; j++)
				{
					a.pa[i][j] = v1.pa[i][j] - v2.pa[i][j];
				}
			}
			cout << a;
			return 0;
		}
		else
		{
			return 1;
		}
	}

private:
	int **pa;
	int  m;
	int  n;
public:
	class OutOfBounds
	{
		int index;
	public:
		OutOfBounds(int i) : index(i) { }
		int getIndex() const { return index; }
	};
	IntArray() { pa = 0;  m = 0;  n = 0; }
	IntArray(int j, int k);
	IntArray(IntArray& arr);
	~IntArray() { if (pa) delete[] pa; };
	int& operator()(int index1, int index2);
	int elemget(int index1, int index2) { return pa[index1][index2]; }
	int getSize() const { return n*m; }
	int getM() const { return m; }
	int getN() const { return n; }
};

IntArray::IntArray(int j, int k)
{
	pa = new int*[m = j];
	for (int i = 0; i < m; i++)
	{
		pa[i] = new int[n = k];
	}
}

IntArray::IntArray(IntArray& arr)
{
	m = arr.m;
	n = arr.n;
	pa = new int*[m];
	for (int i = 0; i < m; i++)
	{
		pa[i] = new int[n];
	}
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			pa[i][j] = arr.pa[i][j];
		}
	}
}

int& IntArray::operator()(int index1, int index2)
{
	return pa[index1][index2];
}

int fun(IntArray& f)
{
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			if (f(i, j) < 0)
			{
				f(i, j) = f(i, j) * (i, j);
			}
		}
	}
	cout << f << endl;
	return 0;
}

void main()
{
	IntArray a(3, 3);
	IntArray b(3, 3);
	cin >> a;
	cin >> b;
	cout << a << endl;
	cout << b(1, 1) << endl;
	cout << a*b << endl;
	cout << a + b << endl;
	cout << a - b << endl;
	cout << fun(a) << endl;
	system("pause");
}