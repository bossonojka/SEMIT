#include <iostream>
using std::cout;
using std::endl;

class ObjectSum
{
private:
	int x;
	static int sum;
public:
	static int getSum()
	{
		return sum;
	}
	ObjectSum(int y)
	{
		x = y;
		sum += x;
	}
	ObjectSum()
	{
		x = 0;
		sum = 0;
	}
	~ObjectSum()
	{
		sum--;
	}
};

int ObjectSum::sum = 0;

void main()
{
	ObjectSum c1;
	cout << c1.getSum() << endl; 
	ObjectSum *p1 = &c1; 
	cout << p1->getSum() << endl; 
	ObjectSum *p2 = new ObjectSum(4);
	cout << p2->getSum() << endl; 
	delete p2;
	cout << p2->getSum() << endl; 
	system("pause");
}
