﻿import sys

def make_fibonacci(n):
    fib = (0,) # Упаковка
    a, b = 0, 1
    for i in range(n):
        a, b = (b, a+b) # Распаковка 
        fib = fib + (a,) # Упаковка
    return fib
		


if __name__ == "__main__":
	n = int(sys.argv[1])
	tuple = make_fibonacci(n)

	list = tuple # Распаковка кортежа в лист

	print(list[-1])
	#print(tuple[-1]) # или так

"""

python 3.3.13.py 10

55


"""
