import sys
from instream import InStream

if __name__ == "__main__":

	instream = InStream("3.1.27\keys.txt")
	str1 = instream.readLine().lower()
	str2 = instream.readLine().lower()

	dict = {}

	for i in range(len(str1)):
		dict[str1[i]] = str2[i]

	for i in range(len(str2)):
		dict[str2[i]] = str1[i]

	text = sys.argv[1].lower()
	for i in range (len(text)):
		print(dict[text[i]], end = "")

"""

3.1.27\keys.txt

abcdefghijklm
nopqrstuvwxyz

python 3.1.27.py "MEET AT ELEVEN"

QJJF BF JKJCJG

python 3.1.27.py "QJJF BF JKJCJG"

MEET AT ELEVEN


"""