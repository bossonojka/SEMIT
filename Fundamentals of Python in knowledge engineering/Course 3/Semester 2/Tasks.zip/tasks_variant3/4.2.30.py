﻿import sys
	
def partition(arr, smaller, larger, left, right, n):
    if left >= right:
        return
    if arr[left] == smaller:
        partition(arr, smaller, larger, left+1, right, n)
    elif arr[right] == larger:
        partition(arr, smaller, larger, left, right-1, n)
    else:
        arr[left], arr[right] = arr[right], arr[left]
        partition(arr, smaller, larger, left+1, right-1, n)

if __name__ == "__main__":
	array = [4,5,4,5,5,5,5,5,5]

	partition(array, 4, 5, 0, len(array)-1, len(array))
	for i in array: print (i, end = " ")
		
			

"""

python 4.2.30.py


"""
