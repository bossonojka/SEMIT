import stdarray
import sys
import stdrandom


if __name__ == "__main__":

	m = int(sys.argv[1])
	n = int(sys.argv[2])
	p = float(sys.argv[3])

	game = stdarray.create2D(m+2,n+2,"-")
	mines = stdarray.create2D(m+2,n+2,0)
	for i in range(1, m+1):
		for j in range(1, n+1):
			mine = stdrandom.bernoulli(p)
			game[i][j] = "*" if mine else "."
			
			if mine:
				mines[i-1][j-1] += 1
				mines[i-1][j] += 1
				mines[i-1][j+1] += 1
				mines[i][j-1] += 1
				mines[i][j+1] += 1
				mines[i+1][j-1] += 1
				mines[i+1][j] += 1
				mines[i+1][j+1] += 1

	game2 = stdarray.create2D(m,n,"-")
	mines2 = stdarray.create2D(m,n,"-")
	for i in range(m):
		for j in range(n):
			game2[i][j] = game[i+1][j+1]
			mines2 [i][j] = "*" if game[i+1][j+1] == "*" else mines[i+1][j+1]

	stdarray.write2D(game2)
	print()
	stdarray.write2D(mines2)


"""
python 1.4.31.py 5 10 0.5
python 1.4.31.py 15 15 0.1

"""
	
