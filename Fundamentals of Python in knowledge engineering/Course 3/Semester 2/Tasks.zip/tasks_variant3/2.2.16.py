﻿import stdarray
import sys
import stdstats
import stdio
import stddraw
import stdarray


if __name__ == "__main__":
	arr = stdio.readAllFloats()

	n = int(sys.argv[1])
	l = float(sys.argv[2])
	r = float(sys.argv[3])
	
	section = (r-l)/n
	#print (section)
	
	histogram = stdarray.create1D(n,0)
	for i in range(len(arr)):
		#print((arr[i]-l)/section)
		index = (arr[i]-l)/section
		if index >= 0 and index < n:
			histogram[int(index)] += 1

	stddraw.setYscale(-50, 50)
	stdstats.plotBars(histogram)


	for i in range(len(histogram)):
		print (str(i*section+l) + " - " + str((i+1)*section+l) + ": " + str(histogram[i]))

	stddraw.show()

"""

data.txt
1.2 2 3 6.3 9 2 2.1 2 3 9 -2.4



python 2.2.16.py < data.txt 5 0 10

0.0 - 2.0: 1
2.0 - 4.0: 6
4.0 - 6.0: 0
6.0 - 8.0: 1
8.0 - 10.0: 2

Будет построена гистограмма для значений от 0 до 10 с пятью столбцами распределений


"""

