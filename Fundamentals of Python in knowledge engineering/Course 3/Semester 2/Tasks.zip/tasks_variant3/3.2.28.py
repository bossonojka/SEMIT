import sys
from instream import InStream
import re

class Element:
	def __init__(self, name, atomic_number, symbol, atomic_weight):
		self.name = name
		self.atomic_number = atomic_number
		self.symbol = symbol
		self.atomic_weight = atomic_weight

	def getName(self):
		return self.name

	def getAtomicNumber(self):
		return self.atomic_number

	def getSymbol(self):
		return self.symbol

	def getAtomicWeight(self):
		return self.atomic_weight

	def __str__(self):
		return self.name


class PeriodicTable:


	def __init__(self):
		self.elements = []
		instream = InStream("3.2.28\elements.csv")
		while (instream.hasNextLine()):
			count = 4
			arr = instream.readLine().split(",")
			self.elements.append(Element(arr[0], float(arr[1]), arr[2], float(arr[3])))
	
	def getAtomicWeight(self, molecule):
		atomic_mass_float = 0
		#formula = [char for char in molecule.upper()]
		formula = self.camel_case_split(molecule)
		print(formula)
		for i, ch in enumerate(formula):
			print(ch, end=" ")
			if len([x for x in self.elements if x.symbol.upper() == ch.upper()]) == 1:
				elem = [x for x in self.elements if x.symbol.upper() == ch.upper()][0]
				print(elem.atomic_weight)
				if i < len(formula)-1 and formula[i + 1].isdigit() == True:
					atomic_mass_float += elem.atomic_weight * int(formula[i + 1])
				else:
					atomic_mass_float += elem.atomic_weight
			else:
				print()
		return atomic_mass_float
		
	def camel_case_split(self, str): 
		words = [[str[0]]] 
  
		for c in str[1:]: 
			if (words[-1][-1].islower() and c.isupper()) or (not words[-1][-1].isdigit() and c.isdigit()) or (words[-1][-1].isdigit() and not c.isdigit()) or (words[-1][-1].islower() and c.islower()) or (words[-1][-1].isupper() and c.isupper()): 
				words.append(list(c)) 
			else: 
				words[-1].append(c) 
		return [''.join(word) for word in words] 


if __name__ == "__main__":
	molecule = sys.argv[1]
	pt = PeriodicTable()
	print(pt.getAtomicWeight(molecule))


"""

python 3.2.28.py H2O

['H', '2', 'O']
H 1.01
2 
O 16.0
18.02

python 3.2.28.py NaCl

['Na', 'Cl']
Na 22.99
Cl 35.45
58.44


"""
