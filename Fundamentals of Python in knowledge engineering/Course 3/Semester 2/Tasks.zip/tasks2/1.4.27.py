﻿import sys
import stdarray

def printAdamar(n):
	H = stdarray.create2D(n, n, True)
	#print(H)
	i1 = 1
	while i1 < n:
		for i2 in range(i1):
			for i3 in range(i1):
				H[i2+i1][i3]    = H[i2][i3]
				H[i2][i3+i1]    = H[i2][i3]
				H[i2+i1][i3+i1] = not H[i2][i3]
		i1 += i1

# Write the matrix.
	for i in range(n):
		for j in range(n):
			if H[i][j]:
				print('T ', end = '')
			else:
				print('F ', end = '')
		print()
	print()
    


if __name__ == "__main__":
	n = int(sys.argv[1])
	printAdamar(n)

"""

python 1.4.27.py 4 (только степени двойки)

T T T T 
T F T F 
T T F F 
T F F T 


"""

