﻿import stdarray
import stdio
import stdstats
import stddraw
from instream import InStream
import stdrandom
from color import Color

def main():

	stddraw.setYscale(-50, 50)

	while stdio.hasNextLine():
		stddraw.setPenColor(Color(stdrandom.uniformInt(0, 255),stdrandom.uniformInt(0, 255),stdrandom.uniformInt(0, 255)))
		a = list(map(float, stdio.readLine().split(" ")))
		#stdarray.write1D(a)

		stdio.writef('       min %7.3f\n', stdstats.min(a))
		stdio.writef('       max %7.3f\n', stdstats.max(a))
		stdio.writef('      mean %7.3f\n', stdstats.mean(a))
		stdio.writef('   std dev %7.3f\n', stdstats.stddev(a))
		stdio.writef('    median %7.3f\n', stdstats.median(a))
		stdio.writef('    var %7.3f\n', stdstats.var(a))

		stdstats.plotPoints(a)
		stdstats.plotLines(a)
		stdstats.plotBars(a)
		stddraw.show(100)

	stddraw.show()
	

if __name__ == "__main__":
	main()


"""

python generatedata.py 100 | python 2.2.20.py

Данные поступают из generatedata.py в python 2.2.20.py. 100 - количество наборов данных


"""
