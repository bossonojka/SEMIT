﻿import sys
import stdio
import stddraw

def drawTile(x, y, color):
	w = 1
	h = 1

	stddraw.setPenRadius(0.01)

	stddraw.setPenColor(stddraw.BLUE)
	stddraw.filledRectangle(x,y,w,h)

	switcher = {
		0: stddraw.PINK,
		1: stddraw.BLACK,
		2: stddraw.ORANGE,
	}
	stddraw.setPenColor(switcher.get(color,stddraw.PINK))
	stddraw.filledPolygon([x,w*2/4 + x,w*4/4 + x,w*2/4 + x],[h*2/4 + y,h*4/4 + y,h*2/4 + y,y])
	stddraw.setPenColor(stddraw.BLACK)

	stddraw.setPenColor(stddraw.GREEN)
	stddraw.filledPolygon([x,w*1/4 + x,w*1/4 + x],[h*3/4 + y,h + y,h*3/4 + y])
	stddraw.filledPolygon([x,w*1/4 + x,w*1/4 + x],[h*1/4 + y,h*1/4 + y,y])
	stddraw.filledPolygon([w*3/4 + x,w*4/4 + x,w*3/4 + x],[h*4/4 + y,h*3/4 + y,h*3/4 + y])
	stddraw.filledPolygon([w*3/4 + x,w*3/4 + x,w*4/4 + x],[y,h*1/4 + y,h*1/4 + y])

	stddraw.setPenColor(stddraw.BLACK)
	stddraw.setPenRadius(0.001)
	stddraw.rectangle(x,y,w,h)


if __name__ == "__main__":
	X_TILES = int(sys.argv[1])
	Y_TILES = int(sys.argv[1])
	chessed = bool(int(sys.argv[2]))
	color = int(sys.argv[3])

	stddraw.setXscale(0, X_TILES)
	stddraw.setYscale(0, Y_TILES)

	for x in range (X_TILES):
		for y in range (Y_TILES):
			if chessed and ((x % 2 != 0 and y % 2 == 0) or (x % 2 == 0 and y % 2 != 0)):
				continue
			else:
				drawTile(x, y,color)

	stddraw.show()


"""

Последний параметр это цвет: 0 - розовый, 1 - черный, 2 - оранжевый
python 1.5.37.py 8 1 2 
python 1.5.37.py 8 0 2 


"""