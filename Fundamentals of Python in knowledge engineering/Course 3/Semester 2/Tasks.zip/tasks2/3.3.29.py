﻿import stdio
from matplotlib.pyplot import imread
import cv2
import numpy as np
import scipy.spatial

#image_files = os.listdir()
image_files = [
"3.3.29/em1.png",
"3.3.29/em2.jpg",
"3.3.29/em3.png",
"3.3.29/food.jpg",
"3.3.29/lio1.jpg",
"3.3.29/sky1.jpg",
"3.3.29/sky2.jpg",
"3.3.29/lio2.jpg",
]


def file_hash(filepath):
	with open(filepath, 'rb') as f:
		return md5(f.read()).hexdigest()

#gradient direction based on intensity 

def intensity_diff(row_res, col_res):
    difference_row = np.diff(row_res)
    difference_col = np.diff(col_res)
    difference_row = difference_row > 0
    difference_col = difference_col > 0
    return np.vstack((difference_row, difference_col)).flatten()
    #return difference_row
    #return np.vstack((difference_row, difference_col)) #str method

def difference_score(image, height = 30, width = 30):
    gray = img_gray(image)
    row_res, col_res = resize(gray, height, width)
    difference = intensity_diff(row_res, col_res)
    
    return difference

def img_gray(image):
    image = imread(image)
    return np.average(image, weights=[0.299, 0.587, 0.114], axis=2)

#resize image and flatten
def resize(image, height=30, width=30):
    row_res = cv2.resize(image,(height, width), interpolation = cv2.INTER_AREA).flatten()
    col_res = cv2.resize(image,(height, width), interpolation = cv2.INTER_AREA).flatten('F')
    return row_res, col_res

def hamming_distance(image, image2):
    score =scipy.spatial.distance.hamming(image, image2)
    return score


def filter_images(images):
    image_list = []
    for image in images:
        try:
            assert imread(image).shape[2] == 3
            image_list.append(image)
        except  AssertionError as e:
            print(e)
    return image_list

#Hamming

def difference_score_dict(image_list):
	ds_dict = {}
	duplicates = []
	for image in image_list:
		ds = difference_score(image)
        
		if image not in ds_dict:
			ds_dict[image] = ds
		else:
			duplicates.append((image, ds_dict[image]) )
    
	return  duplicates, ds_dict

image_files = filter_images(image_files)
duplicates, ds_dict = difference_score_dict(image_files)


stdio.write('    ')
for i in range(len(image_files)):
    stdio.writef('%8.4s', image_files[i].split('/')[1])
stdio.writeln()

for i in ds_dict.keys():
	stdio.writef('%.4s', i.split('/')[1])
	for j in ds_dict.keys():
		stdio.writef('%8.2f', 1 - hamming_distance(ds_dict[i], ds_dict[j]))
	stdio.writeln()

"""

Программа сравнивает каждое изображение с каждым и выводит результат
Чем ближе значение к единице тем изображения более одинаковы.
Изображения переводятся в чернобелые (img_gray) изменяются в размере (30 х 30 px) и первращаются в строки (resize)
Это и есть эскизы, которые используются для картинок. Для расчета различия используется метод hamming пакета scipy.
Изображения находсятся в папке 3.3.29

python 3.3.29.py

        	em1.    em2.    em3.    food    lion    sky1    sky2
	em1.    1.00    0.69    0.90    0.61    0.54    0.43    0.44
	em2.    0.69    1.00    0.64    0.68    0.51    0.42    0.43
	em3.    0.90    0.64    1.00    0.56    0.53    0.45    0.46
	food    0.61    0.68    0.56    1.00    0.50    0.45    0.46
	lion    0.54    0.51    0.53    0.50    1.00    0.47    0.47
	sky1    0.43    0.42    0.45    0.45    0.47    1.00    0.97
	sky2    0.44    0.43    0.46    0.46    0.47    0.97    1.00

"""



