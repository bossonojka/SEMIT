﻿import sys
from bst import OrderedSymbolTable
import stdio

count = 0

def addToMap(map, aud, list):
	for lecturer_index, lecturer in enumerate(list):
		mayBeAdded = True
		for key in map:
			for added_lecturer_index, added_lecturer in enumerate(map[key]):
				if added_lecturer == lecturer and added_lecturer_index == lecturer_index:
					print(lecturer + ' already in audience ' + key)
					mayBeAdded = False
		if not mayBeAdded:
			list[lecturer_index] = None
	map[key] = list



def main():
	aud_lect = OrderedSymbolTable()
	print("Without checking")
	aud_lect['314'] = ['Sedgewick', 'Wayne', None, 'Dondero', 'Carnegie'] # Поставили Седжвика на 9:00, Карнеги на 14:00
	aud_lect['618'] = ['Sedgewick', None, 'Wayne', 'Kernighan', 'Carnegie'] # Снова поставили Седжвика на 9:00 и Карнеги на 14:00

	stdio.writeln('314 audience: ' + str(aud_lect['314']))
	stdio.writeln('618 audience: ' + str(aud_lect['618']))
	
	#Удалим расписание для 618 ауд. и предотвратим ошибку добавления

	aud_lect['618'] = []


	stdio.writeln()
	print("With checking")
	addToMap(aud_lect, '618', ['Sedgewick', None, 'Wayne', 'Kernighan', 'Carnegie']) # Попытка снова добавить Седжвика с Карнеги в 618 ауд. 
	
	stdio.writeln('314 audience: ' + str(aud_lect['314']))
	stdio.writeln('618 audience: ' + str(aud_lect['618']))
	
	

if __name__ == "__main__":
	main()

"""

python 4.4.62.py

Without checking
314 audience: ['Sedgewick', 'Wayne', None, 'Dondero', 'Carnegie']
618 audience: ['Sedgewick', None, 'Wayne', 'Kernighan', 'Carnegie']

With checking
Sedgewick already in audience 314
Carnegie already in audience 314
314 audience: ['Sedgewick', 'Wayne', None, 'Dondero', 'Carnegie']
618 audience: [None, None, 'Wayne', 'Kernighan', None]


"""