﻿import sys

def getExp(x):
	term = 1.0
	total = 0.0
	n = 1
	while total != total + term :
		total += term
		term *= x/n
		n += 1 
	#print (term)
	#print(n)
	return total
	


if __name__ == "__main__":
	x = float(sys.argv[1])
	print (getExp(x))

"""

python 1.3.37.py 5

148.4131591025766

"""

