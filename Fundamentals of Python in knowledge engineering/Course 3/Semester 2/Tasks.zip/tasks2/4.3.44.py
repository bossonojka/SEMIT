﻿import sys
from linkedqueue import Queue

count = 0


def main():
	queue1 = Queue()
	queue1.enqueue("this")
	queue1.enqueue("is")
	queue1.enqueue("a")
	queue1.enqueue("queue")

	print("queue1: " + str(queue1))

	queue2 = queue1.copy()
	print("After copying")

	print("queue1: " + str(queue1))
	print("queue2: " + str(queue2))

	

if __name__ == "__main__":
	main()

"""

python 4.3.44.py

queue1: this is a queue 
After copying
queue1: 
queue2: this is a queue 


"""