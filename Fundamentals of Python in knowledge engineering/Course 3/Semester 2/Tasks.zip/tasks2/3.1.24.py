﻿import sys
from instream import InStream

if __name__ == "__main__":
	sprtr = str(sys.argv[1])
	inFilenames = sys.argv[2:len(sys.argv)]
	for filename in inFilenames:
		instream = InStream(filename)
		while instream.hasNextLine():
			print(instream.readLine())
			print(sprtr)

"""

3.1.24\file1.txt
string1
string2


3.1.24\file2.txt
string3


python 3.1.24.py === 3.1.24\file1.txt 3.1.24\file2.txt

string1
===
string2
===
string3
===


"""