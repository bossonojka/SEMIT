import sys
import math
def getProjection(l0, latitude, longitude):
	x = longitude - l0
	y = 0.5 * math.log((1 + math.sin(latitude)) / (1 - math.sin(latitude)))
	return x, y
	


if __name__ == "__main__":
	l0 = float(sys.argv[1])
	latitude = float(sys.argv[2])
	longitude = float(sys.argv[3])
	x, y = getProjection(l0, latitude, longitude)
	print (str(x) + ' ' + str(y))

"""

python 1.2.28.py 0 50 50


50.0 -0.2686571333729562


"""

