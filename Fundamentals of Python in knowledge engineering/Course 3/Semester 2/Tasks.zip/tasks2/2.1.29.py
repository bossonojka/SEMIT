﻿import sys
import math

def evaluate (x, a):
	result = a[len(a)-1]

	for i in range(len(a)-2, -1, -1): 
		result = result*x + a[i] 
   	
	return result 

def exp(x):

	n = 20
	array = [1/math.factorial(i) for i in range(n)]
	return evaluate(x, array)
	

if __name__ == "__main__":
	x = int(sys.argv[1])
	print(exp(x))

"""

python 2.1.29.py 3

20.085536921517672


"""
