﻿import sys
from stopwatch import Stopwatch
import mandelbrot

if __name__ == "__main__":
	n = int(sys.argv[1])
	xc = float(sys.argv[2])
	yc = float(sys.argv[3])
	size = float(sys.argv[4])

	watch1 = Stopwatch()
	mandelbrot.default_mandelbrot(n,xc,yc,size)
	time1 = watch1.elapsedTime()

	watch2 = Stopwatch()
	mandelbrot.custom_mandelbrot(n,xc,yc,size)
	time2 = watch2.elapsedTime()

	print("time1 (complex type): " + str(time1))
	print("time2 (Complex type): " + str(time2))


"""

В модуль mandelbrot (от авторов учебника) был добавлен метод custom_madelbrot, который использует класс Complex от авторов учебника

python 3.2.22.py 512 .1015 -.633 .01

time1 (complex type): 0.3760213851928711
time2 (Complex type): 0.5220301151275635


"""