﻿import sys
import stdarray
import stdrandom

def create_p():
	n = stdrandom.uniformInt(5,10)
	p = stdarray.create1D(n, 0.0)
	sum = 0

	for i in range(n):
		rnd = stdrandom.uniformFloat(0.0, 1.0)
		p[i] = rnd
		sum += rnd

	for i in range(n):
		p[i] = p[i]/sum
	
	return p

def create_s(arr):
	s = stdarray.create1D(len(arr), 0.0)
	sum = 0

	for i in range(len(arr)):
		s[i] += arr[i] + sum
		sum += arr[i]

	return s
	
def find_i(r, s, lo, hi):
	mid = (lo + hi) // 2
	if hi <= lo:
		return mid-1

	if r < s[mid]:
		return find_i(r, s, lo, mid)
	elif s[mid] < r:
		return find_i(r, s, mid+1, hi)
	else:
		return mid
	

if __name__ == "__main__":
	p = create_p()
	s = create_s(p)
	print ("Possibility array: ")
	stdarray.write1D(p)
	print ("Cumulative distribution array: ")
	stdarray.write1D(s)
	
	r = stdrandom.uniformFloat(0.0, 1.0)
	print("Randomly generated float: " + str(r))
	print ("Index: " + str(find_i(r, s, 0, len(s))))
	
"""

python 4.2.35.py

Possibility array: 
9
0.1664703033010335 0.09446044205240568 0.054525607684298656 0.08942895607045816 0.13705724537676703 0.008808832534754252 0.13282613167528848 0.15221852665824667 0.16420395464674747 
Cumulative distribution array: 
9
0.1664703033010335 0.2609307453534392 0.31545635303773784 0.404885309108196 0.541942554484963 0.5507513870197173 0.6835775186950057 0.8357960453532524 0.9999999999999998 
Randomly generated float: 0.5558376899036027
Index: 5


Формируется случайный массив (от 5 до 10 значений) распределения вероятностей p. Далее массив значений функции распределения s, который уже отсортирован после создания.

* В задании очепятка - создать надо случайное значение r типа float (не s, s - это массив)

"""










