﻿import sys
from bst import *


if __name__ == "__main__":
	st = OrderedSymbolTable()

	st['Sedgewick'] = 'Bob'
	st['Wayne'] = 'Kevin'
	st['Dondero'] = 'Bob'
	st['Hopkins'] = 'Entony'
	st['Pratt'] = 'Criss'
	st['Hardy'] = 'Tom'
	print("Left subtree size: " + str(st.rank("Sedgewick")))

			

"""


В класс OrderedSymbolTable были добавлены методы rank(self, key) и findNote(self, x, key)
В класс Node был добавлне параметр self.subnodes_count
В метод _set(self, x, key, val) класса OrderedSymbolTable был добавлен функционал увеличения количества счетчика оличества элементов в поддереве

Метод rank находит узел и если он найден, то возвращает subnodes_count левого узла с добавлением единицы

python 4.4.65.py

Node: Sedgewick - Bob
Left subtree size: 4

"""
