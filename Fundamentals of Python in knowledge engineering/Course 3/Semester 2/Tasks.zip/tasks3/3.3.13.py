import sys

def make_fibonacci(n):
    fib = []
    a, b = 0, 1
    for i in range(n):
        a, b = b, a+b
        fib.append(a)
    return tuple(fib)
		


if __name__ == "__main__":
	n = int(sys.argv[1])
	tuple = make_fibonacci(n)
	print(tuple)
	print(tuple[-1])

"""

python 3.3.13.py 10

(1, 1, 2, 3, 5, 8, 13, 21, 34, 55)
55



"""
