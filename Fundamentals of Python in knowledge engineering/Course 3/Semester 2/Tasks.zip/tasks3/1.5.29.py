import sys
from instream import InStream
import stdarray

def getPeaks():
	
	array = stdarray.readInt2D()
	
	peaks = 0

	for row in range(len(array)):
		for col in range(len(array[row])):
			#print(array[row][col])
			if ((row != 0 and array[row][col] > array[row-1][col]) and (row != len(array)-1 and array[row][col] > array[row+1][col]) and (col != 0 and array[row][col] > array[row][col-1]) and (col != len(array[row])-1 and array[row][col] > array[row][col+1])):
				peaks += 1
	return peaks
		
	


if __name__ == "__main__":
	print(getPeaks())

"""

python 1.5.29 < 1.5.29\landscape1.txt

1


"""

