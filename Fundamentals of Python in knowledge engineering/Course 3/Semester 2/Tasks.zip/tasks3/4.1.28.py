import sys
import stdarray


if __name__ == "__main__":
	array = [42,63,12,765,32,853,123,342]

	number1 = None
	number2 = None

	diff = array[1] - array[0]
	for i in range(len(array)):
		for j in range (len(array)):
			if i!= j and abs(array[j] - array[i]) < diff:
				diff = abs(array[j] - array[i])
				number1 = array[i]
				number2 = array[j]
	print(number1)
	print(number2)
	print("abs(number1 - number2) = " + str(abs(number1 - number2)))
			

"""

python 4.1.28.py

42
32
abs(number1 - number2) = 10


"""
