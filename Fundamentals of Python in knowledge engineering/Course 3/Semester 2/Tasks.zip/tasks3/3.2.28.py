import sys
from instream import InStream

class Element:
	def __init__(self, name, atomic_number, symbol, atomic_weight):
		self.name = name
		self.atomic_number = atomic_number
		self.symbol = symbol
		self.atomic_weight = atomic_weight


class PeriodicTable:
	def __init__(self):
		self.elements = []
		instream = InStream("3.2.28\elements.csv")
		while (instream.hasNextLine()):
			count = 4
			arr = instream.readLine().split(",")
			self.elements.append(Element(arr[0], float(arr[1]), arr[2], float(arr[3])))
	
	def getAtomicWeight(self, molecule):
		atomic_mass_float = 0
		formula = [char for char in molecule.upper()]
		for i, ch in enumerate(formula):
			print(ch, end=" ")
			if len([x for x in self.elements if x.symbol.upper() == ch]) == 1:
				elem = [x for x in self.elements if x.symbol.upper() == ch][0]
				print(elem.atomic_weight)
				if i < len(formula)-1 and formula[i + 1].isdigit() == True:
					atomic_mass_float += elem.atomic_weight * int(formula[i + 1])
				else:
					atomic_mass_float += elem.atomic_weight
			else:
				print()
		return atomic_mass_float
		


if __name__ == "__main__":
	molecule = sys.argv[1]
	pt = PeriodicTable()
	print(pt.getAtomicWeight(molecule))


"""

python 3.2.28.py h2o

H 1.01
2 
O 16.0
18.02

"""
