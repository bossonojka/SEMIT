import sys
from instream import InStream

if __name__ == "__main__":

	instream = InStream("3.1.27\keys.txt")
	str1 = instream.readLine()
	str2 = instream.readLine()

	dict = {}

	for i in range(len(str1)):
		dict[str2[i]] = str1[i]

	text = sys.argv[1]
	for i in range (len(text)):
		print(dict[text[i]], end = "")

"""

3.1.27\keys.txt

mnopqrstuvwxyzabcdefghijkl
abcdefghijklmnopqrstuvwxyz


python 3.1.27.py "meet at eleven"

yqqf mf qxqhqz


"""