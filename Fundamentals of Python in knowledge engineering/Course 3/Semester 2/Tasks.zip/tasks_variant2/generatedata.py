﻿import stdrandom
import sys
import stdio

def main(sets):
	for j in range(sets): # количество наборов данных - 100
		n = stdrandom.uniformInt(2, 10) # количество данных в одной строке - от 2 до 20
		for i in range (n-1):
			stdio.write(str(stdrandom.uniformFloat(-50.0, 50)) + " ")
		stdio.write(str(stdrandom.uniformFloat(-50.0, 50.0)))
		stdio.writeln("")
	



if __name__ == "__main__":
	sets = int(sys.argv[1])
	main(sets)


