﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab2OR
{
    public partial class HykJivs : Form
    {
        public HykJivs()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.panel1.Enabled = false;
            double x1 = double.Parse(x1Box.Text.Replace(".", ","));
            double x2 = double.Parse(x2Box.Text.Replace(".", ","));
            double epsel = double.Parse(epsBox.Text.Replace(".", ","));
            double f(double[] variable)
            {
                //double res = Math.Pow(variable[0], 2) + 3 * Math.Pow(variable[1], 2) + Math.Cos(variable[0] + variable[1]);
                double res = Math.Pow(variable[0], 3) - variable[0] + Math.Pow(variable[1], 3) - 3 * Math.Pow(variable[1], 2) - 1;
                return res;
            }

            double[] addVecToVec(double[] var1, double[] var2)
            {
                double[] res = new double[var1.GetLength(0)];
                for (int i = 0; i < var1.GetLength(0); i++)
                {
                    res[i] += var1[i] + var2[i];
                }
                return res;
            }

            double[] subtractVecToVec(double[] var1, double[] var2)
            {
                double[] res = new double[var1.GetLength(0)];
                for (int i = 0; i < var1.GetLength(0); i++)
                {
                    res[i] += var1[i] - var2[i];
                }
                
                return res;
            }

            double[] multVector(double[] var1, double m)
            {
                double[] res = new double[var1.GetLength(0)];
                for (int i = 0; i < var1.GetLength(0); i++)
                {
                    res[i] += var1[i] * m;
                }
                return res;
            }

            double func_minimization(double[] var, double[] d_mas)
            {
                double opt_lyambda, l1, l2, f1, f2;
                double epselent = 0.001;
                double a = -1;
                double b = 1;
                double[][] x_var = new double[2][];

                do
                {
                    opt_lyambda = Math.Round((a + b) / 2,4);
                    l1 = Math.Round(opt_lyambda - (epselent / 2),4);
                    l2 = Math.Round(opt_lyambda + (epselent / 2),4);

                    x_var[0] = new double[] { var[0] + l1 * d_mas[0], var[1] + l1 * d_mas[1] };
                    x_var[1] = new double[] { var[0] + l2 * d_mas[0], var[1] + l2 * d_mas[1] };

                    f1 = f(x_var[0]);
                    f2 = f(x_var[1]);

                    if (f1 > f2)
                    {
                        a = opt_lyambda;
                    }
                    if (f1 < f2)
                    {
                        b = opt_lyambda;
                    }
                } while (Math.Abs(b - a) > epselent);
                opt_lyambda = (a + b) / 2;
                return opt_lyambda;
            }

            double norma(double[] var)
            {
                double max = double.MinValue;
                for (int i = 0; i < var.Length; i++)
                {
                    if (var[i] > max)
                    {
                        max = var[i];
                    }
                }
                return max;
            }

            //Вспомогательный шаг
            int k = 0; int j = 0;
            double[][] d_inner = new double[2][];
            d_inner[0] = new double[] { 1, 0 };
            d_inner[1] = new double[] { 0, 1 };

            double[][] x = new double[100][];
            int n = 2;
            double[][] lyambda = new double[100][];
            double[] d_opt = new double[100];
            x[k] = new double[] { x1, x2 };
            double[][] y = new double[n + 1][];
            y[j] = new double[x[k].Length];
            y[j] = x[k];
            double eps = epsel;
            double lyambda_optim;

            solutionBox.Text = "Выберем в качестве направлений:";
            solutionBox.SelectionStart = solutionBox.TextLength;
            solutionBox.ScrollToCaret();
            for (int i = 0; i < d_inner.Length; i++)
            {
                solutionBox.Text += Environment.NewLine+"d" +(i+1)+"=(";
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();
                for (int ii = 0; ii < d_inner[i].Length; ii++)
                {
                    solutionBox.Text += $"{ d_inner[i][ii]} ";
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                }
                solutionBox.Text += ")";
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();
            }

            solutionBox.Text += Environment.NewLine + "Критерий для остановки алгоритма ε = " + eps + Environment.NewLine;



            do
            {
                k++;
                solutionBox.Text += Environment.NewLine+"Итерация №" +k+" (k)"+Environment.NewLine;
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();
                solutionBox.Text += Environment.NewLine + "y1 = (";
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();
                for (int i = 0; i < y[j].Length; i++)
                {
                    solutionBox.Text += Math.Round(y[j][i], 4) + " ";
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                }
                solutionBox.Text += ") " + Environment.NewLine;
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();
                //Шаг1
                do
                {
                    j++;
                    solutionBox.Text += Environment.NewLine + "Итерация №" + j + " (j)" + Environment.NewLine;
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();

                    solutionBox.Text += "Произведем оптимизационное решение задачи минимизации "+ Environment.NewLine;
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                    lyambda[j - 1] = new double[] { func_minimization(y[j - 1], d_inner[j - 1]) };
                    solutionBox.Text += "λопт("+j+") = "+ lyambda[j-1][0] + Environment.NewLine;
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();

                    y[j] = new double[y[j - 1].Length];
                    y[j] = addVecToVec(y[j - 1], multVector(d_inner[j - 1], lyambda[j - 1][0]));
                    solutionBox.Text += Environment.NewLine+"y["+(j+1)+"] = (";
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                    for (int i = 0;i<y[j].Length;i++)
                    {
                        solutionBox.Text += Math.Round(y[j][i],4) + " ";
                        solutionBox.SelectionStart = solutionBox.TextLength;
                        solutionBox.ScrollToCaret();
                    }
                    solutionBox.Text += ") "+Environment.NewLine;
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();

                } while (j < n);

                x[k] = new double[y[n].Length];
                solutionBox.Text += Environment.NewLine+"x["+k+"] = y[" + (n + 1) + "]" + Environment.NewLine;
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();
                for (int i = 0; i < x[k].Length; i++) x[k][i] = y[n][i];

                //Шаг2
                Array.Resize<double>(ref d_opt, 0);
                d_opt = subtractVecToVec(x[k], x[k - 1]);
                lyambda_optim = func_minimization(x[k], d_opt);
                if (norma(subtractVecToVec(x[k], x[k - 1])) > eps)
                {
                    solutionBox.Text += Environment.NewLine + "||x[k+1] - x[k]|| ≥ ε" + Environment.NewLine;
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                    solutionBox.Text += Environment.NewLine + "d=x[" + (k + 1) + "] - x[" + k + "] = (";
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                    for (int i = 0; i < d_opt.Length; i++)
                    {
                        solutionBox.Text += Math.Round(d_opt[i], 4) + " ";
                        solutionBox.SelectionStart = solutionBox.TextLength;
                        solutionBox.ScrollToCaret();
                    }
                    solutionBox.Text += ")" + Environment.NewLine;
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                    solutionBox.Text += Environment.NewLine + "Оптимизационное решение задачи задачи минимизации:" + Environment.NewLine + "λ = " + lyambda_optim + Environment.NewLine;
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                }
                Array.Resize(ref y, 100);
                for (int i = 0; i < y.Length; i++)
                {
                    Array.Resize(ref y[i], 0);
                }
                Array.Resize(ref lyambda, 100);
                for (int i = 0; i < lyambda.Length; i++)
                {
                    Array.Resize(ref lyambda[i], 0);
                }
                j = 0;
                y[j] = new double[x[k].Length];
                y[j] = addVecToVec(x[k], multVector(d_opt, lyambda_optim));

            } while (norma(subtractVecToVec(x[k], x[k - 1])) > eps);

            solutionBox.Text += Environment.NewLine+Environment.NewLine+"Оптимизация завершена!!" +Environment.NewLine+"Вектор x* = (";
            solutionBox.SelectionStart = solutionBox.TextLength;
            solutionBox.ScrollToCaret();
            for(int i = 0; i < x[k].Length; i++)
            {
                solutionBox.Text += Math.Round(x[k][i],4)+"   ";
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();
            }
            solutionBox.Text += ")" + Environment.NewLine + "f(x*) = " + Math.Round(f(x[k]), 4) + Environment.NewLine;
            solutionBox.SelectionStart = solutionBox.TextLength;
            solutionBox.ScrollToCaret();

        }

        private void x1Box_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != '-' && e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }

        private void x2Box_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != '-' && e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }

        private void epsBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.x1Box.Clear();
            this.x2Box.Clear();
            this.solutionBox.Clear();
            this.epsBox.Clear();
            this.panel1.Enabled = true;
        }
    }
}
