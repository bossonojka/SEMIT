﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab2OR
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void методХукаДживсаСМинимизToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["Rosenbrok"];
            if (fc != null)
                fc.Close();
            Form hykjivs = new HykJivs();
            hykjivs.MdiParent = this;
            hykjivs.Show();
        }

        private void методРозенброкаСМинимизToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["HykJivs"];
            if (fc != null)
                fc.Close();
            Form rosenbrok = new Rosenbrok();
            rosenbrok.MdiParent = this;
            rosenbrok.Show();
        }
    }
}
