﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab3OR
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.panel1.Enabled = false;
            double x1 = double.Parse(x1Box.Text.Replace(".", ","));
            double x2 = double.Parse(x2Box.Text.Replace(".", ","));
            double x3 = double.Parse(x3Box.Text.Replace(".", ","));
            double x4 = double.Parse(x4Box.Text.Replace(".", ","));
            double beta = double.Parse(betaBox.Text.Replace(".", ","));
            double eps = double.Parse(epsBox.Text.Replace(".", ","));            

            double fx(double[] variable)
            {
                //double res = Math.Pow(variable[0]+10*variable[1], 2) + 5 * Math.Pow(variable[2]-variable[3], 2) + Math.Pow(variable[1] - 2*variable[2],4)+10*Math.Pow(variable[0]-variable[3],4);
                double res = Math.Pow(variable[0], 2) + Math.Pow(variable[1], 2) + Math.Pow(variable[2], 2) + Math.Pow(variable[3], 2);
                return res;
            }

            double[] fx_gradient(double[] x)
            {
                double[] res=new double[4];
                /*res[0] = Math.Round(2 *(x[0]+10*x[1]+40*Math.Pow(x[0]-x[3],3)),4);
                res[1] = Math.Round(20*(x[0]+10*x[1])+4*Math.Pow(x[1]-2*x[2],3),4);
                res[2] = Math.Round(10*(x[2]-x[3])-8*Math.Pow(x[1]-2*x[2],3),4);
                res[3] = Math.Round(-40*Math.Pow(x[0]-x[3],3)-10*(x[2]-x[3]),4);*/

                res[0] = Math.Round(2 * x[0]);
                res[1] = Math.Round(2 * x[1]);
                res[2] = Math.Round(2 * x[2]);
                res[3] = Math.Round(2 * x[3]);
                return res;
            }

            double norma(double[] var)
            {
                double norm;
                double norm_sum =0;
                for (int i = 0; i < var.Length; i++)
                {
                    norm_sum += Math.Pow(var[i],2);
                }
                norm = Math.Round(Math.Sqrt(norm_sum),4);
                return norm;
            }

            double[] addVecToVec(double[] var1, double[] var2)
            {
                double[] res = new double[var1.GetLength(0)];
                for (int i = 0; i < var1.GetLength(0); i++)
                {
                    res[i] += var1[i] + var2[i];
                }
                return res;
            }

            double[] multVector(double[] var1, double m)
            {
                double[] res = new double[var1.GetLength(0)];
                for (int i = 0; i < var1.GetLength(0); i++)
                {
                    res[i] += var1[i] * m;
                }
                return res;
            }

            double[] x_vect = new double[4];
            x_vect[0] = x1;
            x_vect[1] = x2;
            x_vect[2] = x3;
            x_vect[3] = x4;

            int k = 0;
            double alpha;
            double delta;
            double[] p = new double[4];

            solutionBox.Text = "Выбрано:"+ Environment.NewLine+"x0=[ ";
            solutionBox.SelectionStart = solutionBox.TextLength;
            solutionBox.ScrollToCaret();
            for (int i = 0; i < x_vect.Length; i++)
            {
                solutionBox.Text +=x_vect[i]+" ";
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();                
            }
            solutionBox.Text += "]"+Environment.NewLine+ "β = " + beta+Environment.NewLine+ "ε = " + eps;
            solutionBox.SelectionStart = solutionBox.TextLength;
            solutionBox.ScrollToCaret();

            while (norma(fx_gradient(x_vect)) > eps)
            {
                solutionBox.Text += Environment.NewLine + "||f'(x(k))|| > ε" + Environment.NewLine + "k = " + k;
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();
                solutionBox.Text += Environment.NewLine + Environment.NewLine + "f'(x(k) = [";
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();
                for (int i = 0; i < fx_gradient(x_vect).Length; i++)
                {
                    solutionBox.Text += Math.Round(fx_gradient(x_vect)[i], 4) + " ";
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                }
                solutionBox.Text += "]" + Environment.NewLine+ Environment.NewLine;
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();
                solutionBox.Text += "||f'(x(k))|| = " + Math.Round(norma(fx_gradient(x_vect)),4) + Environment.NewLine + "ε = " + eps + Environment.NewLine + Environment.NewLine;
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();

                alpha = 1;
                p = multVector(fx_gradient(x_vect), -1);

                solutionBox.Text += Environment.NewLine+Environment.NewLine + "p=[ ";
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();
                for (int i = 0; i < p.Length; i++)
                {
                    solutionBox.Text += Math.Round(p[i],4) + " ";
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                }
                solutionBox.Text += "]"+Environment.NewLine;
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();

                delta = fx(addVecToVec(x_vect, multVector(p, alpha))) - fx(x_vect) + (alpha / 2) * Math.Pow(norma(fx_gradient(x_vect)), 2);

                solutionBox.Text += Environment.NewLine + "α = " + Math.Round(alpha,4) + Environment.NewLine + "Δ = " + Math.Round(delta,4) +Environment.NewLine;
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();

                while (delta > 0)
                {
                    alpha *= beta;
                    delta = fx(addVecToVec(x_vect, multVector(p, alpha))) - fx(x_vect) + (alpha / 2) * Math.Pow(norma(fx_gradient(x_vect)), 2);
                    solutionBox.Text += Environment.NewLine+ "Δ>0 =>"+Environment.NewLine + "α = αβ = " + Math.Round(alpha,4) + Environment.NewLine + "Δ = " + Math.Round(delta,4) +Environment.NewLine;
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                }

                solutionBox.Text += Environment.NewLine + "Δ≤0 =>" + Environment.NewLine;
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();

                x_vect = addVecToVec(x_vect, multVector(p, alpha));
                k++;

                solutionBox.Text += Environment.NewLine + "Значение нового вектора x"+k+"=[ ";
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();
                for (int i = 0; i < x_vect.Length; i++)
                {
                    solutionBox.Text += Math.Round(x_vect[i],4) + " ";
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                }
                solutionBox.Text += "]" + Environment.NewLine;
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();
            }

            solutionBox.Text += Environment.NewLine + "||f'(x(k))|| ≤ ε => Решение найдено!" + Environment.NewLine;
            solutionBox.SelectionStart = solutionBox.TextLength;
            solutionBox.ScrollToCaret();
            solutionBox.Text += Environment.NewLine + Environment.NewLine + "f'(x(k) = [";
            solutionBox.SelectionStart = solutionBox.TextLength;
            solutionBox.ScrollToCaret();
            for (int i = 0; i < fx_gradient(x_vect).Length; i++)
            {
                solutionBox.Text += Math.Round(fx_gradient(x_vect)[i], 4) + " ";
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();
            }
            solutionBox.Text += "]" + Environment.NewLine + Environment.NewLine;
            solutionBox.SelectionStart = solutionBox.TextLength;
            solutionBox.ScrollToCaret();
            solutionBox.Text += "||f'(x(k))|| = " + Math.Round(norma(fx_gradient(x_vect)), 4) + Environment.NewLine + "ε = " + eps + Environment.NewLine + Environment.NewLine;
            solutionBox.SelectionStart = solutionBox.TextLength;
            solutionBox.ScrollToCaret();
            solutionBox.Text += Environment.NewLine + "Значение вектора x*=[ ";
            solutionBox.SelectionStart = solutionBox.TextLength;
            solutionBox.ScrollToCaret();
            for (int i = 0; i < x_vect.Length; i++)
            {
                solutionBox.Text += Math.Round(x_vect[i],4) + " ";
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();
            }
            solutionBox.Text += "]" + Environment.NewLine;
            solutionBox.SelectionStart = solutionBox.TextLength;
            solutionBox.ScrollToCaret();
            solutionBox.Text += Environment.NewLine+"f(x*) = "+ Math.Round(fx(x_vect),4)+Environment.NewLine+"k = "+k;
            solutionBox.SelectionStart = solutionBox.TextLength;
            solutionBox.ScrollToCaret();
        }

        private void betaBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }

        private void epsBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }

        private void x1Box_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != 8 &&  e.KeyChar != '-' && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }

        private void x2Box_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != 8 && e.KeyChar != '-' && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }

        private void x3Box_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != 8 && e.KeyChar != '-' && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }

        private void x4Box_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != 8 && e.KeyChar != '-' && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.solutionBox.Clear();
            this.epsBox.Clear();
            this.betaBox.Clear();
            this.panel1.Enabled = true;
        }
    }
}
