﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab4OR
{
    public partial class Form1 : Form
    {
        //инициализация формы
        public Form1()
        {
            InitializeComponent();
        }

        //новые вычисления
        private void button3_Click(object sender, EventArgs e)
        {
            this.solutionBox.Clear();
            this.epsBox.Clear();
            this.mBox.Clear();
            this.panel1.Enabled = true;
        }
        
        private void x1Box_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != 8 && e.KeyChar != '-' && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }

        private void x2Box_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != 8 && e.KeyChar != '-' && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }

        private void epsBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != 8 && e.KeyChar != '-' && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }

        private void mBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != 8 && e.KeyChar != '-' && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }

        //выполение вычислений при нажатие на кнопку
        private void button1_Click(object sender, EventArgs e)
        {
            //вызов методов из класса с функцией
            Function func = new Function();
            //вызов методов из класса с действиями с векторами и матрицами
            MathActionsWithVectors mawv = new MathActionsWithVectors();

            this.panel1.Enabled = false;
            //значения начального вектора приближения x0
            double x1 = double.Parse(x1Box.Text.Replace(".", ","));
            double x2 = double.Parse(x2Box.Text.Replace(".", ","));

            //максимальное (допустимое) количество итераций
            double m = double.Parse(mBox.Text.Replace(".", ","));
            //параметр окончания поиска оптимального решения
            double eps = double.Parse(epsBox.Text.Replace(".", ","));

            //массив со значениями лямбда
            double[] lyambda = new double[1000];
            lyambda[0] = Math.Pow(10, 4);

            //вектор х(k)
            double[] x = new double[2];
            x[0] = x1;
            x[1] = x2;

            //вектор х(k+1)
            double[] x_k_plus_one = new double[2];
            x_k_plus_one[0] = 0;
            x_k_plus_one[1] = 0;

            //массив со значениями p
            double[] p = new double[2];
            p[0] = 0;
            p[1] = 0;

            //единичная матрица E
            double[,] E = { {1,0 },{ 0,1} };

            int k = 0;

            solutionBox.Text += "Выбрано:"+Environment.NewLine+"x("+k+") = ["+x1+", "+x2+"]"+Environment.NewLine+ "Критерий останова ε = "+eps+Environment.NewLine+"Максимальное число итераций: M = "+m+Environment.NewLine+ "λ("+k+") = " + lyambda[k]+Environment.NewLine+Environment.NewLine;
            solutionBox.SelectionStart = solutionBox.TextLength;
            solutionBox.ScrollToCaret();

            
            while (mawv.norma(func.fx_gradient(x)) > eps && k<m)
            {

                solutionBox.Text += "f'(x) = [ " + func.fx_gradient(x)[0] + ", " + func.fx_gradient(x)[1] + " ]" + Environment.NewLine+ "||f'(x)|| >  > ε" + Environment.NewLine+ mawv.norma(func.fx_gradient(x)) +">"+eps+Environment.NewLine;
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();

                p = mawv.matrix_mult_vector(mawv.multUnitVector(mawv.matrix_in_minus_first(mawv.matrix_on_matrix(func.fx_two_strokes(),mawv.multUnitVector(E, lyambda[k]))),-1), func.fx_gradient(x));
                x_k_plus_one = mawv.addVecToVec(x, p);

                solutionBox.Text += "p = [" + p[0] + ", " + p[1] + "]" + Environment.NewLine + "x(" + (k + 1) + ") = [" + x_k_plus_one[0] + ", " + x_k_plus_one[1] + "]" + Environment.NewLine + Environment.NewLine;
                solutionBox.SelectionStart = solutionBox.TextLength;
                solutionBox.ScrollToCaret();
                if (func.fx(x_k_plus_one) < func.fx(x))
                {
                    solutionBox.Text += "f(x) = " + func.fx(x) + Environment.NewLine + "f(x+1) = " + func.fx(x_k_plus_one) + Environment.NewLine + Environment.NewLine;
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                    lyambda[k+1] = Math.Round(0.5 * lyambda[k],4);
                    k++;
                    x = x_k_plus_one;
                    solutionBox.Text += "λ("+k+") = " + lyambda[k] + Environment.NewLine + "x(" + k + ") = [" + x[0] + ", " + x[1] + "]" + Environment.NewLine +"k = "+k+ Environment.NewLine+Environment.NewLine;
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                }
                else if (func.fx(x_k_plus_one) >= func.fx(x))
                {
                    solutionBox.Text += "f(x) = " + func.fx(x) + Environment.NewLine + "f(x+1) = " + func.fx(x_k_plus_one) + Environment.NewLine + Environment.NewLine;
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                    lyambda[k+1] = Math.Round(2 * lyambda[k],4);
                    k++;
                    x = x_k_plus_one;
                    solutionBox.Text += "λ(" + k + ") = " + lyambda[k] + Environment.NewLine + "x(" + k + ") = [" + x[0] + ", " + x[1] + "]" + Environment.NewLine + "k = " + k + Environment.NewLine + Environment.NewLine;
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                }
            }

            solutionBox.Text += " Решение найдено!! " + Environment.NewLine + Environment.NewLine;
            solutionBox.SelectionStart = solutionBox.TextLength;
            solutionBox.ScrollToCaret();
            solutionBox.Text += "f'(x) = [ " + func.fx_gradient(x)[0] + ", " + func.fx_gradient(x)[1] + " ]" + Environment.NewLine + "||f'(x)|| <= ε" + Environment.NewLine + mawv.norma(func.fx_gradient(x)) + "<" + eps + Environment.NewLine;
            solutionBox.SelectionStart = solutionBox.TextLength;
            solutionBox.ScrollToCaret();
            solutionBox.Text += "λ(" + k + ") = " + lyambda[k] +Environment.NewLine+ "p = [" + p[0] + ", " + p[1] + "]"+Environment.NewLine+ "k = " + k + Environment.NewLine + "x(" + k + ") = [" + x[0] + ", " + x[1] + "]" + Environment.NewLine + Environment.NewLine;
            solutionBox.SelectionStart = solutionBox.TextLength;
            solutionBox.ScrollToCaret();


        }
    }
}
