﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4OR
{
    //класс с заданной функцией
    public class Function
    {
        //функция
        public double fx(double[] variable)
        {
            //double res = Math.Round(2*Math.Pow(variable[0], 2) + 2 * Math.Pow(variable[1], 2) + variable[0]*variable[1] - 11*variable[0]-8*variable[1],4);
            double res = Math.Round(2 * Math.Pow(variable[0], 2) + 2 * Math.Pow(variable[1], 2) + 2 * variable[0] * variable[0] - 4 * variable[0] - 6 * variable[1]);
            return res;
        }

        //градиент
        public double[] fx_gradient(double[] x)
        {
            double[] res = new double[3];
            /*res[0] = Math.Round(4*x[0] + x[1] - 11,4);
             res[1] = Math.Round(4 * x[1] + x[0] - 8,4);*/
            res[0] = Math.Round(4 * x[0] + 2 * x[1] - 4);
            res[1] = Math.Round(2 * x[0] + 4 * x[1] - 6);
            res[2] = 0;
            return res;
        }

        //f''
        public double[,] fx_two_strokes()
        {
            double[,] res = { { 4,1 },{ 1,4 } };
            return res;
        }
    }
}
