﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4OR
{
    //класс с реализацией произведений вычислений над матрицами и векторами
    public class MathActionsWithVectors
    {
        //вычисление нормы
        public double norma(double[] var)
        {
            double norm;
            double norm_sum = 0;
            for (int i = 0; i < var.Length; i++)
            {
                norm_sum += Math.Pow(var[i], 2);
            }
            norm = Math.Round(Math.Sqrt(norm_sum), 4);
            return norm;
        }

        //сложение векторов
        public double[] addVecToVec(double[] var1, double[] var2)
        {
            double[] res = new double[var1.GetLength(0)];
            for (int i = 0; i < var1.GetLength(0); i++)
            {
                res[i] += Math.Round(var1[i] + var2[i],4);
            }
            return res;
        }
        
        //умножение матрицы на число
        public double[,] multUnitVector(double[,] var1, double m)
        {
            double[,] res = new double[2,2];
            int rows = res.GetUpperBound(0) + 1;
            int columns = res.Length / rows;

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    res[i,j]=var1[i, j]*m;
                }
            }
            return res;
        }

        //сложение матриц
        public double[,] matrix_on_matrix(double[,] var1, double[,] var2)
        {
            double[,] res = new double[2, 2];
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    res[i, j] = Math.Round(var1[i, j] + var2[i,j],4);
                }
            }
            return res;
        }

        //матрица в минус первой степени
        public double[,] matrix_in_minus_first(double[,] var1)
        {
            double[,] res = new double[2, 2];
            double det = var1[0, 0] * var1[1, 1] - var1[0, 1] * var1[1, 0];
            double[,] transpon = new double[2, 2];
            transpon[0, 0] = var1[0, 0];
            transpon[0, 1] = var1[1, 0];
            transpon[1, 0] = var1[0, 1];
            transpon[1, 1] = var1[1, 1];
            res[0, 0] = transpon[1, 1] * 1/det;
            res[0, 1] = transpon[1, 0] * 1 / det*(-1);
            res[1, 0] = transpon[0, 1] * 1 / det*(-1);
            res[1, 1] = transpon[0, 0] * 1 / det;
            return res;
        }

        //умножение матрицы на вектор
        public double[] matrix_mult_vector(double[,] matrix, double[] vector)
        {
            double[] res = new double[2];
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    res[i] += Math.Round(matrix[i,j]*vector[j],4);
                }
            }
            return res;
        }
    }
}
