﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OR_GoldenSection
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            aBox.Clear();
            bBox.Clear();
            eBox.Clear();
        }

        private void aBox_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != '-' && e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }

        private void bBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != '-' && e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }

        private void eBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
                this.panel1.Enabled = false;
                this.panel2.Enabled = true;

                double a = double.Parse(aBox.Text.Replace(".", ","));
                double b = double.Parse(bBox.Text.Replace(".", ","));
                double eps = double.Parse(eBox.Text.Replace(".", ","));
                double x1, x2;int count = 1;
                double alpha = 0.618;
                double x_res, fnc_res;

                double func_res(double x)
                {
                    double res=0;
                    if ((x - 2) < 0)
                    {
                        res +=  Math.Pow(Math.Pow(x - 1, 2), (1.0 / 3.0)) / (Math.Pow(x, 2) + 1);
                        //res += Math.Pow(x, 2) * (x + 1) * Math.Pow(-1 * (x - 2), (1.0 / 3.0));
                }
                    if ((x - 2) >= 0)
                    {
                        //res = Math.Pow(x, 2) * (x + 1) * Math.Pow((x - 2), (1.0 / 3.0));
                        res = Math.Pow(Math.Pow(x - 1, 2), (1.0 / 3.0)) / (Math.Pow(x, 2) + 1);
                }
                    //res = Math.Pow(x, 4)-14* Math.Pow(x, 3)+60* Math.Pow(x, 2)-70*x;
                    return res;
                }

                double find(double st, double end, double ep)
                {
                    x1 = Math.Round(st + (1 - alpha) * (end - st),4);
                    x2 = Math.Round(st + alpha * (end - st),4);
                    double f1 = Math.Round(func_res(x1),4);
                    double f2 = Math.Round(func_res(x2),4);
                    
                    textBox1.Text = "Шаг 1."+ Environment.NewLine+"x1 = "+ x1+ ", x2="+ x2+ Environment.NewLine+ "f(x1)=" +f1+ ", f(x2)="+f2;
                    textBox1.SelectionStart = textBox1.TextLength;
                    textBox1.ScrollToCaret();
                    chart2.Series[0].Points.AddXY(count, (end - st));
                    do
                     {
                        if (f1 <= f2)
                            {
                                end = Math.Round(x2,4);
                                x2 = Math.Round(x1,4);
                                f2 = Math.Round(f1,4);
                                x1 = Math.Round(st + (1 - alpha) * (end - st),4);
                                f1 = Math.Round(func_res(x1),4);
                                count++;
                                chart2.Series[0].Points.AddXY(count, (end - st));
                                textBox1.Text += Environment.NewLine + Environment.NewLine + "Шаг " + count + "." + Environment.NewLine + "f(x1)>=f(x2) =>" + Environment.NewLine + "Новые значения:" + Environment.NewLine + "b=" + end + ", a=" + st + Environment.NewLine + "x1=" + x1 + ", x2=" + x2 + Environment.NewLine + "f(x1)=" + f1 + ", f(x2)=" + f2;
                                textBox1.SelectionStart = textBox1.TextLength;
                                textBox1.ScrollToCaret();
                            }
                        if (f1 > f2)
                         {
                                st = Math.Round(x1,4);
                                x1 = Math.Round(x2,4);
                                f1 = Math.Round(f2,4);
                                x2 = Math.Round(st + alpha * (end - st),4);
                                f2 = Math.Round(func_res(x2),4);
                                count++;
                                chart2.Series[0].Points.AddXY(count, (end - st));
                                textBox1.Text += Environment.NewLine + Environment.NewLine + "Шаг " + count + "." + Environment.NewLine + "f(x1)<f(x2) =>" + Environment.NewLine + "Новые значения:" + Environment.NewLine + "b=" + end + ", a=" + st + Environment.NewLine + "x1=" + x1 + ", x2=" + x2 + Environment.NewLine + "f(x1)=" + f1 + ", f(x2)=" + f2;
                                textBox1.SelectionStart = textBox1.TextLength;
                                textBox1.ScrollToCaret();
                            }
                } while(Math.Abs(end - st) >= eps);
                    textBox1.Text += Environment.NewLine + Environment.NewLine + "b-a<eps" + Environment.NewLine + Math.Round(end,4) + "- (" + Math.Round(st,4) + ") <" + eps;
                    textBox1.SelectionStart = textBox1.TextLength;
                    textBox1.ScrollToCaret();
                return (st+end)/2.0;
                }

                x_res = Math.Round(find(a, b, eps),4);
                fnc_res = Math.Round(func_res(x_res),4);

                xres.Text = x_res.ToString();
                funcres.Text = fnc_res.ToString();

                //Chart
                for (double i = a; i <= b; i += eps)
                {
                    chart1.Series[0].Points.AddXY(i, func_res(i));
                }
                chart1.Series[1].Points.AddXY(x_res, fnc_res);
            
        }

        class intervalException : Exception
        {
            public intervalException(string message)
                : base(message)
            { }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.panel1.Enabled = true;
            this.panel2.Enabled = false;
            this.aBox.Clear();
            this.bBox.Clear();
            this.eBox.Clear();
            foreach (var series in chart1.Series)
            {
                series.Points.Clear();
            }
            this.aBox.Enabled = true;
            this.bBox.Enabled = true;
            this.eBox.Enabled = true;
            this.textBox1.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                this.panel1.Enabled = true;
                this.panel2.Enabled = false;
                this.eBox.Enabled = false;
                this.chart1.Series[0].Points.Clear();
                this.xres.Text = "";
                this.funcres.Text = "";
                if (eBox.Text == "")
                {
                    throw new Exception("Пусто!");
                }
                foreach (var series in chart1.Series)
                {
                    series.Points.Clear();
                }
                this.textBox1.Clear();
            }
            catch
            {
                MessageBox.Show("Точность не задана!!");
                this.eBox.Enabled = true;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                this.panel1.Enabled = true;
                this.panel2.Enabled = false;
                this.aBox.Enabled = false;
                this.bBox.Enabled = false;
                this.chart1.Series[0].Points.Clear();
                this.xres.Text = "";
                this.funcres.Text = "";
                foreach (var series in chart1.Series)
                {
                    series.Points.Clear();
                }
                this.textBox1.Clear();
                if (aBox.Text == "" || bBox.Text == "")
                {
                    throw new Exception("Пусто!");
                }
            }
            catch
            {
                MessageBox.Show("Интервал не обнаружен!");
                this.aBox.Enabled = true;
                this.bBox.Enabled = true;
            }
        }
    }
}
