﻿namespace OR_GoldenSection
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.золотоеСечениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.кубическаяАпроксимацияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.золотоеСечениеToolStripMenuItem,
            this.кубическаяАпроксимацияToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(821, 24);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // золотоеСечениеToolStripMenuItem
            // 
            this.золотоеСечениеToolStripMenuItem.Name = "золотоеСечениеToolStripMenuItem";
            this.золотоеСечениеToolStripMenuItem.Size = new System.Drawing.Size(113, 20);
            this.золотоеСечениеToolStripMenuItem.Text = "Золотое сечение";
            this.золотоеСечениеToolStripMenuItem.Click += new System.EventHandler(this.золотоеСечениеToolStripMenuItem_Click);
            // 
            // кубическаяАпроксимацияToolStripMenuItem
            // 
            this.кубическаяАпроксимацияToolStripMenuItem.Name = "кубическаяАпроксимацияToolStripMenuItem";
            this.кубическаяАпроксимацияToolStripMenuItem.Size = new System.Drawing.Size(186, 20);
            //this.кубическаяАпроксимацияToolStripMenuItem.Text = "Квадратичная аппроксимация";
            this.кубическаяАпроксимацияToolStripMenuItem.Click += new System.EventHandler(this.кубическаяАпроксимацияToolStripMenuItem_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(821, 571);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Лабораторная работа №1.";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem золотоеСечениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem кубическаяАпроксимацияToolStripMenuItem;
    }
}