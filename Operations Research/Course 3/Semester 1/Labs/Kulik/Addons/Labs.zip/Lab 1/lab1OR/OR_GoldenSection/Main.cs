﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OR_GoldenSection
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void золотоеСечениеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["Form2"];
            if (fc != null)
                fc.Close();
            Form goldensec = new Form1();
            goldensec.MdiParent = this;
            goldensec.Show();
        }

        private void кубическаяАпроксимацияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["Form1"];
            if (fc != null)
                fc.Close();
            Form aproc = new Form2();
            aproc.MdiParent = this;
            aproc.Show();
        }
    }
}
