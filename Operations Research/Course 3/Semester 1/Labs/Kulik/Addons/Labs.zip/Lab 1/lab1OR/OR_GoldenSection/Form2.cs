﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OR_GoldenSection
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            x1Box.Clear();
            deltaxBox.Clear();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            this.panel1.Enabled = false;
            this.panel2.Enabled = true;

            double x1 = double.Parse(x1Box.Text.Replace(".", ","));
            double delta = double.Parse(deltaxBox.Text.Replace(".", ","));
            double eps1 = double.Parse(eps1Box.Text.Replace(".", ","));
            double eps2 = double.Parse(eps2Box.Text.Replace(".", ","));
            double x2, f1, f2, f3, fMin, a0, a1, a2, x_upperline, newx1, newx2;
            double xMin = 0.0,x3 = 0;
            int it_count = 1;

            double func(double x)
            {
                double res;
                if (x - 2 < 0)
                {
                    res = Math.Round(Math.Pow(x, 2) * (x + 1) * Math.Pow(-1 * (x - 2), (1.0 / 3.0)),4);
                }
                else
                {
                    res = Math.Round(Math.Pow(x, 2) * (x + 1) * Math.Pow((x - 2), (1.0 / 3.0)),4);
                }
                //res = Math.Pow(x, 4)-14* Math.Pow(x, 3)+60* Math.Pow(x, 2)-70*x;
                return res;
            }
            //double quadratic_polynom(double x)
            //{
            //    double qp = a0 + a1 * (x - x1) + a2 * (x - x1) * (x - x2);
            //    return qp;
            //}

            x2 = Math.Round(x1 + delta,4);
            f1 = Math.Round(func(x1),4);
            f2 = Math.Round(func(x2),4);
            conditionBox.Text = "x2=" + x2 + Environment.NewLine + "f(x1) = " + f1 + ",  f(x2)=" + f2;
            conditionBox.SelectionStart = conditionBox.TextLength;
            conditionBox.ScrollToCaret();
            if (f1 > f2)
            {
                x3 = Math.Round(x1 + 2 * delta,4);
                conditionBox.Text += Environment.NewLine+"f(x1)>f(x2) => x3=" + x3;
                conditionBox.SelectionStart = conditionBox.TextLength;
                conditionBox.ScrollToCaret();
            }
            else if (f1 <= f2)
            {
                x3 = Math.Round(x1 - delta,4);
                conditionBox.Text += Environment.NewLine + "f(x1)<=f(x2) => x3=" + x3;
                conditionBox.SelectionStart = conditionBox.TextLength;
                conditionBox.ScrollToCaret();
            }
            
            f3 = Math.Round(func(x3),4);
            solutionBox.Text += Environment.NewLine + "f(x3)=" + f3;
            solutionBox.SelectionStart = solutionBox.TextLength;
            solutionBox.ScrollToCaret();
            fMin = Math.Min(Math.Min(f1, f2), f3);
            if (fMin == f1) xMin = x1;
            if (fMin == f2) xMin = x2;
            if (fMin == f3) xMin = x3;
            solutionBox.Text += Environment.NewLine + "x(min)=" + xMin + ", F(x(min))=" + fMin + Environment.NewLine;
            solutionBox.SelectionStart = solutionBox.TextLength;
            solutionBox.ScrollToCaret();
            a0 = Math.Round(f1,4);
            a1 = Math.Round((f2 - f1) / (x2 - x1),4);
            a2 = Math.Round((1 / (x3 - x2)) * ((f3 - f1) / (x3 - x1) - (f2 - f1) / (x2 - x1)),4);
            x_upperline = Math.Round(((x1 + x2) / 2) + (a1 / 2 * a2),4);
            solutionBox.Text += Environment.NewLine + Environment.NewLine + "a0=" + a0 + ", a1=" + a1 + ", a2=" + a2 + "=>" + Environment.NewLine + "x(upperline)=" + x_upperline;
            solutionBox.SelectionStart = solutionBox.TextLength;
            solutionBox.ScrollToCaret();
            if (Math.Abs(fMin - func(x_upperline)) > eps1 && Math.Abs(xMin - x_upperline) > eps2)
            {
                do
                {
                    if(xMin<0&&x_upperline<0) x3 = Math.Round(Math.Max(xMin, x_upperline), 4);
                    else if (xMin > 0 && x_upperline > 0) x3 = Math.Round(Math.Min(xMin, x_upperline),4);
                    solutionBox.Text += Environment.NewLine + Environment.NewLine + "|F(x(min))-f(x(upperline))|> ε1," + Environment.NewLine + "|x(min)-x(upperline)|> ε2  =>" + Environment.NewLine + "x3=min{x(min),x(upperline)}=" + x3;
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                    newx1 = Math.Round(x3 - delta,4);
                    newx2 = Math.Round(x3 + delta+(delta/2),4);
                    x1 = newx1; x2 = newx2;
                    it_count++;
                    solutionBox.Text += Environment.NewLine + "Новые значения для x1 и x2:" + Environment.NewLine + "x1=" + x1 + ", x2=" + x2 + Environment.NewLine + "Переходим на новую итерацию №" + it_count;
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                    f1 = Math.Round(func(x1),4);
                    f2 = Math.Round(func(x2),4);
                    f3 = Math.Round(func(x3),4);
                    solutionBox.Text += Environment.NewLine + "f(x1)=" + f1 + ", f(x2)=" + f2 + ", f(x3)=" + f3;
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                    fMin = Math.Min(Math.Min(f1, f2), f3);
                    if (fMin == f1) xMin = x1;
                    if (fMin == f2) xMin = x2;
                    if (fMin == f3) xMin = x3;
                    solutionBox.Text += Environment.NewLine+ Environment.NewLine + "x(min)=" + xMin + ", F(x(min))=" + fMin + Environment.NewLine;
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                    a0 = Math.Round(f1,4);
                    a1 = Math.Round((f2 - f1) / (x2 - x1),4);
                    a2 = Math.Round((1 / (x3 - x2)) * (((f3 - f1) / (x3 - x1)) - a1),4);
                    x_upperline = Math.Round(((x1 + x2) / 2) + (a1 / 2 * a2),4);
                    solutionBox.Text += Environment.NewLine + Environment.NewLine + "a0=" + a0 + ", a1=" + a1 + ", a2=" + a2 + "=>" + Environment.NewLine + "x(upperline)=" + x_upperline;
                    solutionBox.SelectionStart = solutionBox.TextLength;
                    solutionBox.ScrollToCaret();
                    if (x_upperline-x3>=delta * 3)
                    {
                        do
                        {
                            solutionBox.Text += Environment.NewLine + Environment.NewLine + "x_upperline находится дальше,чем в три раза от x3:" + Environment.NewLine + "x(upperline)-x3=" + (x_upperline - x3) + Environment.NewLine + "Переопределим точки:";
                            solutionBox.SelectionStart = solutionBox.TextLength;
                            solutionBox.ScrollToCaret();
                            x1 = x2;
                            x2 = x3;
                            x3 =Math.Round(x2 + delta,4);
                            it_count++;
                            solutionBox.Text += Environment.NewLine + Environment.NewLine + "Новые значения для x1 и x2:" + Environment.NewLine + "x1=" + x1 + ", x2=" + x2 + ", x3=" + x3 + Environment.NewLine + "Переходим на новую итерацию №" + it_count;
                            solutionBox.SelectionStart = solutionBox.TextLength;
                            solutionBox.ScrollToCaret();
                            f1 = Math.Round(func(x1),4);
                            f2 = Math.Round(func(x2),4);
                            f3 = Math.Round(func(x3),4);
                            solutionBox.Text += Environment.NewLine +"f(x1)="+f1+ ", f(x2)="+f2 + ", f(x3)=" + f3;
                            solutionBox.SelectionStart = solutionBox.TextLength;
                            solutionBox.ScrollToCaret();
                            fMin = Math.Min(Math.Min(f1, f2), f3);
                            if (fMin == f1) xMin = x1;
                            if (fMin == f2) xMin = x2;
                            if (fMin == f3) xMin = x3;
                            solutionBox.Text += Environment.NewLine + "x(min)=" + xMin + ", F(x(min))=" + fMin + Environment.NewLine;
                            solutionBox.SelectionStart = solutionBox.TextLength;
                            solutionBox.ScrollToCaret();
                            a0 = Math.Round(f1,4);
                            a1 = Math.Round((f2 - f1) / (x2 - x1),4);
                            a2 = Math.Round((1 / (x3 - x2)) * ((f3 - f1) / (x3 - x1) - a1),4);
                            x_upperline = ((x1 + x2) / 2) + (a1 / 2 * a2);
                            solutionBox.Text += Environment.NewLine + Environment.NewLine + "a0=" + a0 + ", a1=" + a1 + ", a2=" + a2 + "=>" + Environment.NewLine + "x(upperline)=" + x_upperline;
                            solutionBox.SelectionStart = solutionBox.TextLength;
                            solutionBox.ScrollToCaret();
                        } while (x_upperline - x3 >= delta * 3);
                    }
                } while (Math.Abs(fMin - func(x_upperline)) > eps1 && Math.Abs(xMin - x_upperline) > eps2 && xMin<=0.5);
            }
            solutionBox.Text += Environment.NewLine + Environment.NewLine + "|F(x(min))-f(x(upperline))|<= ε1," + Environment.NewLine + "|x(min)-x(upperline)|<= ε2  =>" + Environment.NewLine + "Решение найдено:";
            solutionBox.SelectionStart = solutionBox.TextLength;
            solutionBox.ScrollToCaret();
            xres.Text = xMin.ToString();
            funcres.Text = fMin.ToString();
        }

        private void x1Box_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != '-' && e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }

        private void deltaxBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.panel1.Enabled = true;
            this.panel2.Enabled = false;
            this.x1Box.Clear();
            this.deltaxBox.Clear();
            this.conditionBox.Clear();
            this.solutionBox.Clear();
            this.xres.Clear();
            this.funcres.Clear();
            this.eps1Box.Clear();
            this.eps2Box.Clear();
        }

        private void eps1Box_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }

        private void eps2Box_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }

        private void newX1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != '-' && e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }

        private void newX2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar != '.' && e.KeyChar != '-' && e.KeyChar != 8 && (e.KeyChar < 48 || e.KeyChar > 57))
            {
                e.Handled = true;
            }
        }
    }
}
