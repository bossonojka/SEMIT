"use strict"
let log = ""
document.addEventListener("DOMContentLoaded", () => {
	let eps = document.getElementById('epsilon').value
	let x_start = document.getElementById('start').value.split(',').map(Number)
	
	let input1 = document.getElementById('epsilon')
	input1.addEventListener("change", () =>{
		eps = input1.value;
	})

	let input2 = document.getElementById('start')
	input2.addEventListener("change", () =>{
		x_start = input2.value.split(',').map(Number)
	})

	document.getElementById('run').addEventListener('click', () => Levenberg(eps, x_start))
});
const eps = 0.000001
// const myFunction = x_vector => x_vector[0]**3 + x_vector[1]**3
//const myFunction = x_vector => x_vector[0] + x_vector[1] * x_vector[1] + ((x_vector[0]+x_vector[1]-10)/3)**2
// const myFunction = x_vector => 2 * Math.pow(x_vector[0], 2) + 2 * Math.pow(x_vector[1], 2) + 2 * x_vector[0] * x_vector[1] - 4 * x_vector[0] - 6 * x_vector[1]
const myFunction = x_vector => (x_vector[0] - x_vector[1])**2 + ((x_vector[0]+x_vector[1]-10)/3)**2
// const myFunction = x_vector => x_vector[0] + x_vector[1] * x_vector[1] + ((x_vector[0]+x_vector[1]-10)/3)**2

function findDerivative(func,x_vector,num){
	let arr_second = [...x_vector]
	arr_second[num] += eps
	return (func(arr_second)-func(x_vector))/eps
}

function gradient (x_vector){
	let grad = []
	for (let i = 0; i < x_vector.length; i++){
		grad.push(findDerivative(myFunction, x_vector, i))
	}
	return grad
}

const getScalar = (vector1, vector2) => vector1.reduce((total, value, index, array) => total + value*vector2[index],0)

function matrixVectorMul(matrix, p_k){
	let res = new Array(p_k.length).fill(0)
	for (let row = 0; row < matrix.length; row++){
		for (let col = 0; col < matrix[row].length; col++){
			res[col] += matrix[row][col] * p_k[row]
		}
	}
	return res
}
function getStep(x_k,p_k){
	return -getScalar(gradient(x_k),p_k)/getScalar(p_k, matrixVectorMul(secondDerivativeMatrix(myFunction,x_k), p_k))
}

function getNorm(x_vector){
	return Math.pow(x_vector.reduce((t,v,i,a) => t+v*v,0),1/2)
}

function getSum(a,b){
	return a.map((v,i,a) => v += b[i])
}

function secondDerivativeMatrix(func,x_k){
	let matrix = []
	let grad = gradient(x_k)

	for (let i = 0; i < x_k.length; i++){
		let x_k_new = [...x_k]
		x_k_new[i] += eps
		let gradI = gradient(x_k_new)
		let row = []
		for (let j = 0; j < x_k.length; j++){
			row.push((gradI[j] - grad[j])/eps)
		}
		matrix.push(row)
	}

	return matrix
}
function createUnitMatrix(size){
	let um = []
	for (let i = 0; i < size; i++){
		let string = []
		for (let j = 0; j < size; j++){
			string.push(j==i ? 1 : 0)
		}
		um.push(string)
	}
	return um
}
function scalarMatrixMul(scalar, matrix){
	let result = []
	for (var i = 0; i < matrix.length; i++)
		result[i] = matrix[i].slice();
	for (let i = 0; i < result[0].length; i++){
		for (let j = 0; j < result[0].length; j++){
			result[i][j] *= scalar
		}
	}
	return result
}
function getInverseMatrix(matrix){
	let inversed = []

	return inversed
}
function matricesSum(m1, m2){
	for (let i = 0; i < m1[0].length; i++){
		for (let j = 0; j < m1[0].length; j++){
			m2[i][j] += m1[i][j]
		}
	}
	return m2
}
function Levenberg(e1, x_start){
	let p = []
	let x = [x_start]
	let um = createUnitMatrix(x_start.length)
	// Step 1
	let max_iterations = 100
	let eps = 0.0001
	let k = 0
	// let l = [10**4]
	let l_k = 10**4
	let l_k_1 = 10**4
	let x_k = [...x_start]
	let x_k_1 = [...x_start]
	let p_k = []

	while(true){
		// Step 2
		let grad = gradient([...x_k])

		console.log("grad " + grad)
		// Step 3
		if (getNorm(grad)<eps || k > max_iterations){
			break
		}

		while(true){
			console.log("step : " + l_k)
			console.log("k : " + k)
			log += "<br>Итерация " + (k+1) + "<br>"
			// Step 4
			// console.log("var1 : " + scalarMatrixMul(l_k,um))
			// console.log("var2 : " + secondDerivativeMatrix(myFunction, x_k))
			// console.log("var3 : " + matricesSum(secondDerivativeMatrix(myFunction, x_k), scalarMatrixMul(l_k,um)))
			// console.log("var4 : " + matrix_invert(matricesSum(secondDerivativeMatrix(myFunction, x_k), scalarMatrixMul(l_k,um))))
			// console.log("var5 : " + scalarMatrixMul(-1, matrix_invert(matricesSum(secondDerivativeMatrix(myFunction, x_k), scalarMatrixMul(l_k,um)))))
			p_k =  matrixVectorMul(scalarMatrixMul(-1,(matrix_invert(matricesSum(secondDerivativeMatrix(myFunction, x_k), scalarMatrixMul(l_k,um))))), gradient(x_k)) 

			// Step 5
			// x.push(x[k].map((el, i) => el += p[k][i]))
			x_k_1 = x_k.map((el, i) => el + p_k[i])

			log += ("lambda: " + l_k) + "<br>"
			log += ("p: " + p_k.map(el => el.toFixed(4))) + "<br>"
			log += ("x: " + x_k.map(el => el.toFixed(4))) + "<br>"
			log += ("x_k+1: " + x_k_1.map(el => el.toFixed(4))) + "<br>"
			log += ("z(x_k+1): " + myFunction(x_k_1).toFixed(4)) + "<br>"
			log += ("z(x): " + myFunction(x_k).toFixed(4)) + "<br>"
						// console.log("z(x): " + myFunction(x_k))

			// Step 6
			k++
			if (myFunction(x_k_1) < myFunction(x_k)){
				l_k = 1/2 * l_k
				x_k = x_k_1
				break
			}
			else{		
				l_k *= 2
				x_k = x_k_1
			}
		}
	}

	log+='Iterations: '+k
	console.log('Iterations: '+k)
	document.getElementById("answer").innerHTML = log
}
