"use strict"
let log = ""
document.addEventListener("DOMContentLoaded", () => {
	let eps = document.getElementById('epsilon').value
	let x_start = document.getElementById('start').value.split(',').map(Number)
	document.getElementById('run').addEventListener('click', () => FletcherRivz(eps, x_start))
});

// const myFunction = x_vector => x_vector[0]**3 + x_vector[1]**3
// const myFunction = x_vector => x_vector[0] + x_vector[1] * x_vector[1] + ((x_vector[0]+x_vector[1]-10)/3)**2
// const myFunction = x_vector => (x_vector[0] - x_vector[1])**2 + ((x_vector[0]+x_vector[1]-10)/3)**2
//const myFunction = x_vector => (x_vector[0] - x_vector[1])**2 + ((x_vector[0]+x_vector[1]-10)/3)**2
const myFunction = x_vector => 5 * (x_vector[0] - 3)** 2 + (x_vector[1] - 5 ) ** 2
const eps = 0.0001

function findDerivative(func,x_vector,num){
	let arr_second = [...x_vector]
	arr_second[num] += eps
	return (func(arr_second)-func(x_vector))/eps
}

function gradient (x_vector){
	let grad = []
	for (let i = 0; i < x_vector.length; i++){
		grad.push(findDerivative(myFunction, x_vector, i))
	}
	return grad
}

const getScalar = (vector1, vector2) => vector1.reduce((total, value, index, array) => total + value*vector2[index],0)

function matrixVectorMul(matrix, p_k){
	let res = new Array(p_k.length).fill(0)
	for (let row = 0; row < matrix.length; row++){
		for (let col = 0; col < matrix[row].length; col++){
			res[col] += matrix[row][col] * p_k[row]
		}
	}
	console.log(res)
	return res
}
function getStep(x_k,p_k){
	return -getScalar(gradient(x_k),p_k)/getScalar(p_k, matrixVectorMul(secondDerivativeMatrix(myFunction,x_k), p_k))
}

function getNorm(x_vector){
	return Math.pow(x_vector.reduce((t,v,i,a) => t+v*v,0),1/2)
}

function getSum(a,b){
	return a.map((v,i,a) => v += b[i])
}

function secondDerivativeMatrix(func,x_k){
	let matrix = []
	let grad = gradient(x_k)

	for (let i = 0; i < x_k.length; i++){
		let x_k_new = [...x_k]
		x_k_new[i] += eps
		let gradI = gradient(x_k_new)
		let row = []
		for (let j = 0; j < x_k.length; j++){
			row.push((gradI[j] - grad[j])/eps)
		}
		matrix.push(row)
	}

	console.log(matrix)
	return matrix
}

function FletcherRivz(e1, x_start){
	// Step 1
	let max_iterations = 1000

	//Step 2
	let p_0 = gradient([...x_start]).map(el=>-el)
	log += 'x_0: ' + x_start + "<br>"
	log += 'p_0: ' + p_0 + "<br>"
	log += 'z_0: ' + myFunction(x_start).toFixed(2) + "<br>"
	secondDerivativeMatrix(myFunction,x_start)
	log += 'a_0: ' + getStep(x_start, p_0) + "<br>"

	let k = 0
	let a_k = 0
	let p_k = [...p_0]
	let p_k_1 = [...p_0]
	let x_k = [...x_start]
	let x_k_1 = [...x_start]


	while(k<max_iterations){
		
		k++

		log += '===' + '<br>'

		//Step 3

		a_k = getStep(x_k, p_k)
		
		log+='a_k: '+a_k + '<br>'

		//Step 4

		x_k = getSum(x_k,p_k.map(el=>el*a_k))
		log+='x_k: '+x_k.map(el=>el.toFixed(2)) + '<br>'
		log+='z(x_k): '+myFunction(x_k).toFixed(2) + '<br>'
		log+='Norm: '+getNorm(gradient(x_k)) + '<br>'

		//Step 5-6

		if (getNorm(gradient(x_k))<e1){
			break
		}

		//Step 7

		let temp = getScalar(gradient(x_k),gradient(x_k))/getScalar(gradient(x_k_1),gradient(x_k_1))
		p_k = getSum(gradient(x_k).map(el => -el),p_k_1.map(el=>el*temp))
		
		log+='p_k: '+p_k + '<br>'
		// console.log('p_k: '+p_k)

		x_k_1 = x_k
		p_k_1 = p_k
	}
	// console.log('Finished')
	log+='Iterations: '+k
	console.log('Iterations: '+k)
	document.getElementById("answer").innerHTML = log
}
