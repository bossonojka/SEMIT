P=tf(0.09, [19.4 1 0] );
R0 = tf(1, [2 0]);
R = feedback(R0,1);
G=P*R;
H=tf(1,[6 1]);
L=G*H;
Cpd = 1 + tf([19.4 0],[1 1]);
W = C*G / (1 + C*G*H);
W = minreal(W);
pW = pole(W);
dcW = dcain(W);
H = tf(2*0.06,[1,1]);
W = C*G / (1 + C*G*H);
W = minreal(W);
dcW2 = dcgain(W);
Wu = minreal(C/ (1 + C*G*H));
step(Wu)