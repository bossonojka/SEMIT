function y = MyFunc(x)
y = (10*x.^2 + 3*x.^2+x+5).^2;