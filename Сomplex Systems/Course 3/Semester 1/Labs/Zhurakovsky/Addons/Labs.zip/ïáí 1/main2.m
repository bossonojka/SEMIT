%% main function - minimization Toolbox Algorithm
clc, clear, close all
[x,fval] = fminunc(@myFitnessFunction, 15);
