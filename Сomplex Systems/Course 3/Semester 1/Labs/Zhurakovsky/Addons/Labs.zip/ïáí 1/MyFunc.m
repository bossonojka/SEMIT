function y = MyFunc(x)
y = x.^2+2*x;

end