%% Fitness function
function y = myFitnessFunction(x)
y = x.^2 + 2*x;
end
