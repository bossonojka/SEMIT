%% main function � minimization Genetic Algorithm
clc, clear, close all
rng default
FitnessFunction=@myFitnessFunction;
NumberOfVariables=1; 
[x] = ga(FitnessFunction, NumberOfVariables,[],[],[],[],0.004);
