function y = MyFunc(x)
y = 4*((x(1)-5).^2) +(x(2)-6).^2;

