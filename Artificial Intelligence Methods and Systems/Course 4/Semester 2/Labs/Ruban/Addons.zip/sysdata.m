clear all;
clc;
K=0.07;     Ts=19.0;
Tr=2;   Toc=4;
ddMax=3;    deltaMax=30;
phiZad=30;
fConst = 0;
TI=200; Kc=0.7045;
Tv=1;
