sysdata;

aSi = []; aTpp = [];
for phiZad = 1:100
    sim ( 'model_unlinear' )
    [si,Tpp] = overshoot ( phi.Time, phi.Data);
    aSi = [aSi si];
    aTpp = [aTpp Tpp];
end;
subplot(2, 1, 1);
plot(aSi);
subplot(2, 1, 2);
plot(aTpp);
