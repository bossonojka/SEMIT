sysdata;

Ts0 = Ts;
aTs = linspace(0.8, 1.2, 100) * Ts0;
aSi = []; aTpp = [];
for Ts=aTs
    sim ( 'model_unlinear1' )
    [si,Tpp] = overshoot ( phi.Time, phi.Data);
    aSi = [aSi si];
    aTpp = [aTpp Tpp];
end;
subplot(2, 1, 1);
plot(aSi);
subplot(2, 1, 2);
plot(aTpp);
