sysdata;
sim('model_unlinear');
plotPhiDelta(phi, delta);