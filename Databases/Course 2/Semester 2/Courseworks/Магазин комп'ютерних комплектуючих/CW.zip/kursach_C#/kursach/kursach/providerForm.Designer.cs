﻿namespace kursach
{
    partial class providerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tab_entity = new System.Windows.Forms.TabPage();
            this.btn_deleteEnt = new System.Windows.Forms.Button();
            this.entityDataGridView = new System.Windows.Forms.DataGridView();
            this.companyNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.documentVATnmbrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idProviderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.entityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kursachDataSet = new kursach.kursachDataSet();
            this.tab_individual = new System.Windows.Forms.TabPage();
            this.btn_deleteInd = new System.Windows.Forms.Button();
            this.dataGrid_Individual = new System.Windows.Forms.DataGridView();
            this.secondNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.documentNmbrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idProviderDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.individualBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.rProviderDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewProviderBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewAdressBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rProviderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rContractDataGridView = new System.Windows.Forms.DataGridView();
            this.idContractDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idProviderDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewProviderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.contractDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r23BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btn_refresh = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.btn_deleteCntr = new System.Windows.Forms.Button();
            this.storageBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.entityTableAdapter = new kursach.kursachDataSetTableAdapters.EntityTableAdapter();
            this.tableAdapterManager = new kursach.kursachDataSetTableAdapters.TableAdapterManager();
            this.individualTableAdapter = new kursach.kursachDataSetTableAdapters.IndividualTableAdapter();
            this.rContractTableAdapter = new kursach.kursachDataSetTableAdapters.RContractTableAdapter();
            this.storageTableAdapter = new kursach.kursachDataSetTableAdapters.StorageTableAdapter();
            this.rContractBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rProviderTableAdapter = new kursach.kursachDataSetTableAdapters.RProviderTableAdapter();
            this.rCntcInfoTableAdapter = new kursach.kursachDataSetTableAdapters.RCntcInfoTableAdapter();
            this.rSaleDetailTableAdapter = new kursach.kursachDataSetTableAdapters.RSaleDetailTableAdapter();
            this.view_ProviderTableAdapter = new kursach.kursachDataSetTableAdapters.view_ProviderTableAdapter();
            this.view_AdressTableAdapter = new kursach.kursachDataSetTableAdapters.view_AdressTableAdapter();
            this.btn_AddEntity = new System.Windows.Forms.Button();
            this.btn_AddIndivid = new System.Windows.Forms.Button();
            this.btn_AddContr = new System.Windows.Forms.Button();
            this.tabControl.SuspendLayout();
            this.tab_entity.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.entityDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.entityBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).BeginInit();
            this.tab_individual.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid_Individual)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.individualBindingSource)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rProviderDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewProviderBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewAdressBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rProviderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rContractDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewProviderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r23BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.storageBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rContractBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tab_entity);
            this.tabControl.Controls.Add(this.tab_individual);
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Location = new System.Drawing.Point(13, 13);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(770, 195);
            this.tabControl.TabIndex = 0;
            // 
            // tab_entity
            // 
            this.tab_entity.AutoScroll = true;
            this.tab_entity.Controls.Add(this.btn_AddEntity);
            this.tab_entity.Controls.Add(this.btn_deleteEnt);
            this.tab_entity.Controls.Add(this.entityDataGridView);
            this.tab_entity.Location = new System.Drawing.Point(4, 22);
            this.tab_entity.Name = "tab_entity";
            this.tab_entity.Padding = new System.Windows.Forms.Padding(3);
            this.tab_entity.Size = new System.Drawing.Size(762, 169);
            this.tab_entity.TabIndex = 0;
            this.tab_entity.Text = "Entity";
            this.tab_entity.UseVisualStyleBackColor = true;
            // 
            // btn_deleteEnt
            // 
            this.btn_deleteEnt.Location = new System.Drawing.Point(6, 141);
            this.btn_deleteEnt.Name = "btn_deleteEnt";
            this.btn_deleteEnt.Size = new System.Drawing.Size(75, 23);
            this.btn_deleteEnt.TabIndex = 1;
            this.btn_deleteEnt.Text = "Delete";
            this.btn_deleteEnt.UseVisualStyleBackColor = true;
            this.btn_deleteEnt.Click += new System.EventHandler(this.btn_deleteEnt_Click);
            // 
            // entityDataGridView
            // 
            this.entityDataGridView.AutoGenerateColumns = false;
            this.entityDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.entityDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.companyNameDataGridViewTextBoxColumn,
            this.taxNumberDataGridViewTextBoxColumn,
            this.documentVATnmbrDataGridViewTextBoxColumn,
            this.idProviderDataGridViewTextBoxColumn});
            this.entityDataGridView.DataSource = this.entityBindingSource;
            this.entityDataGridView.Location = new System.Drawing.Point(0, 0);
            this.entityDataGridView.Name = "entityDataGridView";
            this.entityDataGridView.ReadOnly = true;
            this.entityDataGridView.Size = new System.Drawing.Size(759, 135);
            this.entityDataGridView.TabIndex = 0;
            // 
            // companyNameDataGridViewTextBoxColumn
            // 
            this.companyNameDataGridViewTextBoxColumn.DataPropertyName = "companyName";
            this.companyNameDataGridViewTextBoxColumn.HeaderText = "companyName";
            this.companyNameDataGridViewTextBoxColumn.Name = "companyNameDataGridViewTextBoxColumn";
            this.companyNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // taxNumberDataGridViewTextBoxColumn
            // 
            this.taxNumberDataGridViewTextBoxColumn.DataPropertyName = "taxNumber";
            this.taxNumberDataGridViewTextBoxColumn.HeaderText = "taxNumber";
            this.taxNumberDataGridViewTextBoxColumn.Name = "taxNumberDataGridViewTextBoxColumn";
            this.taxNumberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // documentVATnmbrDataGridViewTextBoxColumn
            // 
            this.documentVATnmbrDataGridViewTextBoxColumn.DataPropertyName = "documentVATnmbr";
            this.documentVATnmbrDataGridViewTextBoxColumn.HeaderText = "documentVATnmbr";
            this.documentVATnmbrDataGridViewTextBoxColumn.Name = "documentVATnmbrDataGridViewTextBoxColumn";
            this.documentVATnmbrDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // idProviderDataGridViewTextBoxColumn
            // 
            this.idProviderDataGridViewTextBoxColumn.DataPropertyName = "idProvider";
            this.idProviderDataGridViewTextBoxColumn.HeaderText = "idProvider";
            this.idProviderDataGridViewTextBoxColumn.Name = "idProviderDataGridViewTextBoxColumn";
            this.idProviderDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // entityBindingSource
            // 
            this.entityBindingSource.DataMember = "Entity";
            this.entityBindingSource.DataSource = this.kursachDataSet;
            // 
            // kursachDataSet
            // 
            this.kursachDataSet.DataSetName = "kursachDataSet";
            this.kursachDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tab_individual
            // 
            this.tab_individual.Controls.Add(this.btn_AddIndivid);
            this.tab_individual.Controls.Add(this.btn_deleteInd);
            this.tab_individual.Controls.Add(this.dataGrid_Individual);
            this.tab_individual.Location = new System.Drawing.Point(4, 22);
            this.tab_individual.Name = "tab_individual";
            this.tab_individual.Padding = new System.Windows.Forms.Padding(3);
            this.tab_individual.Size = new System.Drawing.Size(762, 169);
            this.tab_individual.TabIndex = 1;
            this.tab_individual.Text = "Individual";
            this.tab_individual.UseVisualStyleBackColor = true;
            // 
            // btn_deleteInd
            // 
            this.btn_deleteInd.Location = new System.Drawing.Point(6, 140);
            this.btn_deleteInd.Name = "btn_deleteInd";
            this.btn_deleteInd.Size = new System.Drawing.Size(75, 23);
            this.btn_deleteInd.TabIndex = 1;
            this.btn_deleteInd.Text = "Delete";
            this.btn_deleteInd.UseVisualStyleBackColor = true;
            this.btn_deleteInd.Click += new System.EventHandler(this.btn_deleteInd_Click);
            // 
            // dataGrid_Individual
            // 
            this.dataGrid_Individual.AutoGenerateColumns = false;
            this.dataGrid_Individual.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid_Individual.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.secondNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.documentNmbrDataGridViewTextBoxColumn,
            this.idProviderDataGridViewTextBoxColumn1});
            this.dataGrid_Individual.DataSource = this.individualBindingSource;
            this.dataGrid_Individual.Location = new System.Drawing.Point(0, 0);
            this.dataGrid_Individual.Name = "dataGrid_Individual";
            this.dataGrid_Individual.Size = new System.Drawing.Size(762, 135);
            this.dataGrid_Individual.TabIndex = 0;
            // 
            // secondNameDataGridViewTextBoxColumn
            // 
            this.secondNameDataGridViewTextBoxColumn.DataPropertyName = "secondName";
            this.secondNameDataGridViewTextBoxColumn.HeaderText = "secondName";
            this.secondNameDataGridViewTextBoxColumn.Name = "secondNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "firstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "firstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // documentNmbrDataGridViewTextBoxColumn
            // 
            this.documentNmbrDataGridViewTextBoxColumn.DataPropertyName = "documentNmbr";
            this.documentNmbrDataGridViewTextBoxColumn.HeaderText = "documentNmbr";
            this.documentNmbrDataGridViewTextBoxColumn.Name = "documentNmbrDataGridViewTextBoxColumn";
            // 
            // idProviderDataGridViewTextBoxColumn1
            // 
            this.idProviderDataGridViewTextBoxColumn1.DataPropertyName = "idProvider";
            this.idProviderDataGridViewTextBoxColumn1.HeaderText = "idProvider";
            this.idProviderDataGridViewTextBoxColumn1.Name = "idProviderDataGridViewTextBoxColumn1";
            // 
            // individualBindingSource
            // 
            this.individualBindingSource.DataMember = "Individual";
            this.individualBindingSource.DataSource = this.kursachDataSet;
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.Controls.Add(this.rProviderDataGridView);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(762, 169);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "Provider";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // rProviderDataGridView
            // 
            this.rProviderDataGridView.AllowUserToAddRows = false;
            this.rProviderDataGridView.AllowUserToDeleteRows = false;
            this.rProviderDataGridView.AutoGenerateColumns = false;
            this.rProviderDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rProviderDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.rProviderDataGridView.DataSource = this.rProviderBindingSource;
            this.rProviderDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rProviderDataGridView.Location = new System.Drawing.Point(3, 3);
            this.rProviderDataGridView.Name = "rProviderDataGridView";
            this.rProviderDataGridView.ReadOnly = true;
            this.rProviderDataGridView.Size = new System.Drawing.Size(756, 163);
            this.rProviderDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "idProvider";
            this.dataGridViewTextBoxColumn1.DataSource = this.viewProviderBindingSource1;
            this.dataGridViewTextBoxColumn1.DisplayMember = "_Provider";
            this.dataGridViewTextBoxColumn1.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn1.HeaderText = "idProvider";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn1.ValueMember = "idProvider";
            // 
            // viewProviderBindingSource1
            // 
            this.viewProviderBindingSource1.DataMember = "view_Provider";
            this.viewProviderBindingSource1.DataSource = this.kursachDataSet;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "idAdress";
            this.dataGridViewTextBoxColumn2.DataSource = this.viewAdressBindingSource;
            this.dataGridViewTextBoxColumn2.DisplayMember = "Adress";
            this.dataGridViewTextBoxColumn2.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn2.HeaderText = "idAdress";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn2.ValueMember = "idAdress";
            // 
            // viewAdressBindingSource
            // 
            this.viewAdressBindingSource.DataMember = "view_Adress";
            this.viewAdressBindingSource.DataSource = this.kursachDataSet;
            // 
            // rProviderBindingSource
            // 
            this.rProviderBindingSource.DataMember = "RProvider";
            this.rProviderBindingSource.DataSource = this.kursachDataSet;
            // 
            // rContractDataGridView
            // 
            this.rContractDataGridView.AutoGenerateColumns = false;
            this.rContractDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rContractDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idContractDataGridViewTextBoxColumn,
            this.idProviderDataGridViewTextBoxColumn2,
            this.contractDateDataGridViewTextBoxColumn});
            this.rContractDataGridView.DataSource = this.r23BindingSource;
            this.rContractDataGridView.Location = new System.Drawing.Point(13, 214);
            this.rContractDataGridView.Name = "rContractDataGridView";
            this.rContractDataGridView.Size = new System.Drawing.Size(563, 180);
            this.rContractDataGridView.TabIndex = 1;
            // 
            // idContractDataGridViewTextBoxColumn
            // 
            this.idContractDataGridViewTextBoxColumn.DataPropertyName = "idContract";
            this.idContractDataGridViewTextBoxColumn.HeaderText = "idContract";
            this.idContractDataGridViewTextBoxColumn.Name = "idContractDataGridViewTextBoxColumn";
            this.idContractDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // idProviderDataGridViewTextBoxColumn2
            // 
            this.idProviderDataGridViewTextBoxColumn2.DataPropertyName = "idProvider";
            this.idProviderDataGridViewTextBoxColumn2.DataSource = this.viewProviderBindingSource;
            this.idProviderDataGridViewTextBoxColumn2.DisplayMember = "_Provider";
            this.idProviderDataGridViewTextBoxColumn2.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.idProviderDataGridViewTextBoxColumn2.HeaderText = "idProvider";
            this.idProviderDataGridViewTextBoxColumn2.Name = "idProviderDataGridViewTextBoxColumn2";
            this.idProviderDataGridViewTextBoxColumn2.ReadOnly = true;
            this.idProviderDataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.idProviderDataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.idProviderDataGridViewTextBoxColumn2.ValueMember = "idProvider";
            // 
            // viewProviderBindingSource
            // 
            this.viewProviderBindingSource.DataMember = "view_Provider";
            this.viewProviderBindingSource.DataSource = this.kursachDataSet;
            // 
            // contractDateDataGridViewTextBoxColumn
            // 
            this.contractDateDataGridViewTextBoxColumn.DataPropertyName = "contractDate";
            this.contractDateDataGridViewTextBoxColumn.HeaderText = "contractDate";
            this.contractDateDataGridViewTextBoxColumn.Name = "contractDateDataGridViewTextBoxColumn";
            this.contractDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // r23BindingSource
            // 
            this.r23BindingSource.DataMember = "R_23";
            this.r23BindingSource.DataSource = this.rProviderBindingSource;
            // 
            // btn_refresh
            // 
            this.btn_refresh.Location = new System.Drawing.Point(13, 405);
            this.btn_refresh.Name = "btn_refresh";
            this.btn_refresh.Size = new System.Drawing.Size(100, 35);
            this.btn_refresh.TabIndex = 3;
            this.btn_refresh.Text = "Refresh";
            this.btn_refresh.UseVisualStyleBackColor = true;
            this.btn_refresh.Click += new System.EventHandler(this.btn_refresh_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Location = new System.Drawing.Point(679, 405);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(100, 35);
            this.btn_Exit.TabIndex = 4;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // btn_deleteCntr
            // 
            this.btn_deleteCntr.Location = new System.Drawing.Point(582, 359);
            this.btn_deleteCntr.Name = "btn_deleteCntr";
            this.btn_deleteCntr.Size = new System.Drawing.Size(100, 35);
            this.btn_deleteCntr.TabIndex = 5;
            this.btn_deleteCntr.Text = "Delete contract";
            this.btn_deleteCntr.UseVisualStyleBackColor = true;
            this.btn_deleteCntr.Click += new System.EventHandler(this.btn_deleteCntr_Click);
            // 
            // storageBindingSource
            // 
            this.storageBindingSource.DataMember = "Storage";
            this.storageBindingSource.DataSource = this.kursachDataSet;
            // 
            // entityTableAdapter
            // 
            this.entityTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AllowableChrtrcsTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CGenderTableAdapter = null;
            this.tableAdapterManager.CharacteristicsTableAdapter = null;
            this.tableAdapterManager.CManufacturerTableAdapter = null;
            this.tableAdapterManager.COperatorNumberTableAdapter = null;
            this.tableAdapterManager.COperatorTableAdapter = null;
            this.tableAdapterManager.CRefundTypeTableAdapter = null;
            this.tableAdapterManager.CStrtTypeTableAdapter = null;
            this.tableAdapterManager.CUnitTableAdapter = null;
            this.tableAdapterManager.DlvryTableAdapter = null;
            this.tableAdapterManager.EntityTableAdapter = this.entityTableAdapter;
            this.tableAdapterManager.IndividualTableAdapter = this.individualTableAdapter;
            this.tableAdapterManager.JRefundTableAdapter = null;
            this.tableAdapterManager.JSaleTableAdapter = null;
            this.tableAdapterManager.LandlinePhoneTableAdapter = null;
            this.tableAdapterManager.MobilePhoneTableAdapter = null;
            this.tableAdapterManager.PrdctInstanceTableAdapter = null;
            this.tableAdapterManager.RAdressTableAdapter = null;
            this.tableAdapterManager.RBuyerTableAdapter = null;
            this.tableAdapterManager.RCntcInfoTableAdapter = null;
            this.tableAdapterManager.RContractTableAdapter = this.rContractTableAdapter;
            this.tableAdapterManager.RPhoneTableAdapter = null;
            this.tableAdapterManager.RPrdctInfoTableAdapter = null;
            this.tableAdapterManager.RProviderTableAdapter = null;
            this.tableAdapterManager.RSaleDetailTableAdapter = null;
            this.tableAdapterManager.SCountryTableAdapter = null;
            this.tableAdapterManager.SLocalityTableAdapter = null;
            this.tableAdapterManager.SModelTableAdapter = null;
            this.tableAdapterManager.SParameterTableAdapter = null;
            this.tableAdapterManager.SRegionTableAdapter = null;
            this.tableAdapterManager.SStaffTableAdapter = null;
            this.tableAdapterManager.SStreetTableAdapter = null;
            this.tableAdapterManager.StorageTableAdapter = this.storageTableAdapter;
            this.tableAdapterManager.STrdGrpTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = kursach.kursachDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // individualTableAdapter
            // 
            this.individualTableAdapter.ClearBeforeFill = true;
            // 
            // rContractTableAdapter
            // 
            this.rContractTableAdapter.ClearBeforeFill = true;
            // 
            // storageTableAdapter
            // 
            this.storageTableAdapter.ClearBeforeFill = true;
            // 
            // rContractBindingSource
            // 
            this.rContractBindingSource.DataMember = "RContract";
            this.rContractBindingSource.DataSource = this.kursachDataSet;
            // 
            // rProviderTableAdapter
            // 
            this.rProviderTableAdapter.ClearBeforeFill = true;
            // 
            // rCntcInfoTableAdapter
            // 
            this.rCntcInfoTableAdapter.ClearBeforeFill = true;
            // 
            // rSaleDetailTableAdapter
            // 
            this.rSaleDetailTableAdapter.ClearBeforeFill = true;
            // 
            // view_ProviderTableAdapter
            // 
            this.view_ProviderTableAdapter.ClearBeforeFill = true;
            // 
            // view_AdressTableAdapter
            // 
            this.view_AdressTableAdapter.ClearBeforeFill = true;
            // 
            // btn_AddEntity
            // 
            this.btn_AddEntity.Location = new System.Drawing.Point(87, 140);
            this.btn_AddEntity.Name = "btn_AddEntity";
            this.btn_AddEntity.Size = new System.Drawing.Size(75, 23);
            this.btn_AddEntity.TabIndex = 2;
            this.btn_AddEntity.Text = "Add new";
            this.btn_AddEntity.UseVisualStyleBackColor = true;
            this.btn_AddEntity.Click += new System.EventHandler(this.btn_AddEntity_Click);
            // 
            // btn_AddIndivid
            // 
            this.btn_AddIndivid.Location = new System.Drawing.Point(87, 140);
            this.btn_AddIndivid.Name = "btn_AddIndivid";
            this.btn_AddIndivid.Size = new System.Drawing.Size(75, 23);
            this.btn_AddIndivid.TabIndex = 3;
            this.btn_AddIndivid.Text = "Add new";
            this.btn_AddIndivid.UseVisualStyleBackColor = true;
            this.btn_AddIndivid.Click += new System.EventHandler(this.btn_AddIndivid_Click);
            // 
            // btn_AddContr
            // 
            this.btn_AddContr.Location = new System.Drawing.Point(582, 214);
            this.btn_AddContr.Name = "btn_AddContr";
            this.btn_AddContr.Size = new System.Drawing.Size(100, 35);
            this.btn_AddContr.TabIndex = 6;
            this.btn_AddContr.Text = "Add new";
            this.btn_AddContr.UseVisualStyleBackColor = true;
            this.btn_AddContr.Click += new System.EventHandler(this.btn_AddContr_Click);
            // 
            // providerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(805, 452);
            this.Controls.Add(this.btn_AddContr);
            this.Controls.Add(this.btn_deleteCntr);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_refresh);
            this.Controls.Add(this.rContractDataGridView);
            this.Controls.Add(this.tabControl);
            this.Name = "providerForm";
            this.Text = "providerForm";
            this.Load += new System.EventHandler(this.providerForm_Load);
            this.tabControl.ResumeLayout(false);
            this.tab_entity.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.entityDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.entityBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).EndInit();
            this.tab_individual.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid_Individual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.individualBindingSource)).EndInit();
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rProviderDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewProviderBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewAdressBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rProviderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rContractDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewProviderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r23BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.storageBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rContractBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tab_entity;
        private System.Windows.Forms.TabPage tab_individual;
        private kursachDataSet kursachDataSet;
        private System.Windows.Forms.DataGridView dataGrid_Individual;
        private System.Windows.Forms.DataGridView entityDataGridView;
        private System.Windows.Forms.BindingSource entityBindingSource;
        private kursachDataSetTableAdapters.EntityTableAdapter entityTableAdapter;
        private kursachDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridViewTextBoxColumn companyNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn documentVATnmbrDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idProviderDataGridViewTextBoxColumn;
        private kursachDataSetTableAdapters.IndividualTableAdapter individualTableAdapter;
        private System.Windows.Forms.BindingSource individualBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn secondNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn documentNmbrDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idProviderDataGridViewTextBoxColumn1;
        private kursachDataSetTableAdapters.RContractTableAdapter rContractTableAdapter;
        private System.Windows.Forms.BindingSource rContractBindingSource;
        private kursachDataSetTableAdapters.StorageTableAdapter storageTableAdapter;
        private System.Windows.Forms.DataGridView rContractDataGridView;
        private System.Windows.Forms.BindingSource storageBindingSource;
        private System.Windows.Forms.Button btn_refresh;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Button btn_deleteEnt;
        private System.Windows.Forms.Button btn_deleteInd;
        private System.Windows.Forms.Button btn_deleteCntr;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.BindingSource rProviderBindingSource;
        private kursachDataSetTableAdapters.RProviderTableAdapter rProviderTableAdapter;
        private kursachDataSetTableAdapters.RCntcInfoTableAdapter rCntcInfoTableAdapter;
        private kursachDataSetTableAdapters.RSaleDetailTableAdapter rSaleDetailTableAdapter;
        private System.Windows.Forms.BindingSource r23BindingSource;
        private kursachDataSetTableAdapters.view_ProviderTableAdapter view_ProviderTableAdapter;
        private System.Windows.Forms.DataGridView rProviderDataGridView;
        private System.Windows.Forms.BindingSource viewProviderBindingSource;
        private System.Windows.Forms.BindingSource viewProviderBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idContractDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn idProviderDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn contractDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource viewAdressBindingSource;
        private kursachDataSetTableAdapters.view_AdressTableAdapter view_AdressTableAdapter;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.Button btn_AddEntity;
        private System.Windows.Forms.Button btn_AddIndivid;
        private System.Windows.Forms.Button btn_AddContr;
    }
}