﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class staffForm : Form
    {
        public staffForm()
        {
            InitializeComponent();
        }

        private void sStaffBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.sStaffBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.kursachDataSet);

        }

        private void staffForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kursachDataSet.view_Adress' table. You can move, or remove it, as needed.
            this.view_AdressTableAdapter.Fill(this.kursachDataSet.view_Adress);
            // TODO: This line of code loads data into the 'kursachDataSet.view_Gender' table. You can move, or remove it, as needed.
            this.view_GenderTableAdapter.Fill(this.kursachDataSet.view_Gender);
            // TODO: This line of code loads data into the 'kursachDataSet.SStaff' table. You can move, or remove it, as needed.
            this.sStaffTableAdapter.Fill(this.kursachDataSet.SStaff);

        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kursachDataSet.view_Adress' table. You can move, or remove it, as needed.
            this.view_AdressTableAdapter.Fill(this.kursachDataSet.view_Adress);
            // TODO: This line of code loads data into the 'kursachDataSet.view_Gender' table. You can move, or remove it, as needed.
            this.view_GenderTableAdapter.Fill(this.kursachDataSet.view_Gender);
            // TODO: This line of code loads data into the 'kursachDataSet.SStaff' table. You can move, or remove it, as needed.
            this.sStaffTableAdapter.Fill(this.kursachDataSet.SStaff);
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            foreach(DataGridViewRow row in sStaffDataGridView.SelectedRows)
            {
                sStaffDataGridView.Rows.Remove(row);
            }
        }

        private void btn_AddStaff_Click(object sender, EventArgs e)
        {
            add_NewStaffForm frm = new add_NewStaffForm();
            frm.Show();
        }
    }
}
