﻿namespace kursach
{
    partial class storageForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kursachDataSet = new kursach.kursachDataSet();
            this.storageBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.storageTableAdapter = new kursach.kursachDataSetTableAdapters.StorageTableAdapter();
            this.tableAdapterManager = new kursach.kursachDataSetTableAdapters.TableAdapterManager();
            this.storageDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.btn_AddPdct = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.storageBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.storageDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // kursachDataSet
            // 
            this.kursachDataSet.DataSetName = "kursachDataSet";
            this.kursachDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // storageBindingSource
            // 
            this.storageBindingSource.DataMember = "Storage";
            this.storageBindingSource.DataSource = this.kursachDataSet;
            // 
            // storageTableAdapter
            // 
            this.storageTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AllowableChrtrcsTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CGenderTableAdapter = null;
            this.tableAdapterManager.CharacteristicsTableAdapter = null;
            this.tableAdapterManager.CManufacturerTableAdapter = null;
            this.tableAdapterManager.COperatorNumberTableAdapter = null;
            this.tableAdapterManager.COperatorTableAdapter = null;
            this.tableAdapterManager.CRefundTypeTableAdapter = null;
            this.tableAdapterManager.CStrtTypeTableAdapter = null;
            this.tableAdapterManager.CUnitTableAdapter = null;
            this.tableAdapterManager.DlvryTableAdapter = null;
            this.tableAdapterManager.EntityTableAdapter = null;
            this.tableAdapterManager.IndividualTableAdapter = null;
            this.tableAdapterManager.JRefundTableAdapter = null;
            this.tableAdapterManager.JSaleTableAdapter = null;
            this.tableAdapterManager.LandlinePhoneTableAdapter = null;
            this.tableAdapterManager.MobilePhoneTableAdapter = null;
            this.tableAdapterManager.PrdctInstanceTableAdapter = null;
            this.tableAdapterManager.RAdressTableAdapter = null;
            this.tableAdapterManager.RBuyerTableAdapter = null;
            this.tableAdapterManager.RCntcInfoTableAdapter = null;
            this.tableAdapterManager.RContractTableAdapter = null;
            this.tableAdapterManager.RPhoneTableAdapter = null;
            this.tableAdapterManager.RPrdctInfoTableAdapter = null;
            this.tableAdapterManager.RProviderTableAdapter = null;
            this.tableAdapterManager.RSaleDetailTableAdapter = null;
            this.tableAdapterManager.SCountryTableAdapter = null;
            this.tableAdapterManager.SLocalityTableAdapter = null;
            this.tableAdapterManager.SModelTableAdapter = null;
            this.tableAdapterManager.SParameterTableAdapter = null;
            this.tableAdapterManager.SRegionTableAdapter = null;
            this.tableAdapterManager.SStaffTableAdapter = null;
            this.tableAdapterManager.SStreetTableAdapter = null;
            this.tableAdapterManager.StorageTableAdapter = this.storageTableAdapter;
            this.tableAdapterManager.STrdGrpTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = kursach.kursachDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // storageDataGridView
            // 
            this.storageDataGridView.AutoGenerateColumns = false;
            this.storageDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.storageDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.storageDataGridView.DataSource = this.storageBindingSource;
            this.storageDataGridView.Location = new System.Drawing.Point(12, 12);
            this.storageDataGridView.Name = "storageDataGridView";
            this.storageDataGridView.Size = new System.Drawing.Size(563, 220);
            this.storageDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "idContract";
            this.dataGridViewTextBoxColumn1.HeaderText = "idContract";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "serialNumber";
            this.dataGridViewTextBoxColumn2.HeaderText = "serialNumber";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "deliveryPrice";
            this.dataGridViewTextBoxColumn3.HeaderText = "deliveryPrice";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.Location = new System.Drawing.Point(12, 348);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(100, 35);
            this.btn_Refresh.TabIndex = 2;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = true;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Location = new System.Drawing.Point(475, 348);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(100, 35);
            this.btn_Exit.TabIndex = 3;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(475, 238);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(100, 35);
            this.btn_Delete.TabIndex = 4;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // btn_AddPdct
            // 
            this.btn_AddPdct.Location = new System.Drawing.Point(12, 238);
            this.btn_AddPdct.Name = "btn_AddPdct";
            this.btn_AddPdct.Size = new System.Drawing.Size(100, 35);
            this.btn_AddPdct.TabIndex = 5;
            this.btn_AddPdct.Text = "Add new";
            this.btn_AddPdct.UseVisualStyleBackColor = true;
            this.btn_AddPdct.Click += new System.EventHandler(this.btn_AddPdct_Click);
            // 
            // storageForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(587, 395);
            this.Controls.Add(this.btn_AddPdct);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.storageDataGridView);
            this.Name = "storageForm";
            this.Text = "storageForm";
            this.Load += new System.EventHandler(this.storageForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.storageBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.storageDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private kursachDataSet kursachDataSet;
        private System.Windows.Forms.BindingSource storageBindingSource;
        private kursachDataSetTableAdapters.StorageTableAdapter storageTableAdapter;
        private kursachDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView storageDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.Button btn_AddPdct;
    }
}