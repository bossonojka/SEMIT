﻿namespace kursach
{
    partial class productionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabNav_1 = new System.Windows.Forms.TabControl();
            this.tab_TrdGrp = new System.Windows.Forms.TabPage();
            this.btn_deleteTRdGrp = new System.Windows.Forms.Button();
            this.sTrdGrpDataGridView = new System.Windows.Forms.DataGridView();
            this.idTrdGrpDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.trdGrpNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sTrdGrpBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kursachDataSet = new kursach.kursachDataSet();
            this.tab_modl = new System.Windows.Forms.TabPage();
            this.btn_deleteModel = new System.Windows.Forms.Button();
            this.sModelDataGridView = new System.Windows.Forms.DataGridView();
            this.idModelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idManufactrerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewManufacturerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.modelNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tab_prdct = new System.Windows.Forms.TabPage();
            this.btn_deletePrdct = new System.Windows.Forms.Button();
            this.rPrdctInfoDataGridView = new System.Windows.Forms.DataGridView();
            this.idProductDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idModelDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewModelBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.idTrdGrpDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewTrdGrpBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.warntyPeriodDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rPrdctInfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tab_Manufact = new System.Windows.Forms.TabPage();
            this.btn_DeleteManufact = new System.Windows.Forms.Button();
            this.cManufacturerDataGridView = new System.Windows.Forms.DataGridView();
            this.idManufactrerDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.manufacturerNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cManufacturerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btn_refresh = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.tabNav_2 = new System.Windows.Forms.TabControl();
            this.tab_chrcrst = new System.Windows.Forms.TabPage();
            this.btn_deleteChrc = new System.Windows.Forms.Button();
            this.characteristicsDataGridView = new System.Windows.Forms.DataGridView();
            this.idProductDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idParameterDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewParameterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.parValueDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitName = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.r34BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tab_param = new System.Windows.Forms.TabPage();
            this.btn_deleteParam = new System.Windows.Forms.Button();
            this.sParameterDataGridView = new System.Windows.Forms.DataGridView();
            this.idParameterDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idUnitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewUnitBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.parameterNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sParameterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.characteristicsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sTrdGrpTableAdapter = new kursach.kursachDataSetTableAdapters.STrdGrpTableAdapter();
            this.tableAdapterManager = new kursach.kursachDataSetTableAdapters.TableAdapterManager();
            this.characteristicsTableAdapter = new kursach.kursachDataSetTableAdapters.CharacteristicsTableAdapter();
            this.cManufacturerTableAdapter = new kursach.kursachDataSetTableAdapters.CManufacturerTableAdapter();
            this.rPrdctInfoTableAdapter = new kursach.kursachDataSetTableAdapters.RPrdctInfoTableAdapter();
            this.sModelTableAdapter = new kursach.kursachDataSetTableAdapters.SModelTableAdapter();
            this.sParameterTableAdapter = new kursach.kursachDataSetTableAdapters.SParameterTableAdapter();
            this.view_ManufacturerTableAdapter = new kursach.kursachDataSetTableAdapters.view_ManufacturerTableAdapter();
            this.viewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.view_ModelTableAdapter = new kursach.kursachDataSetTableAdapters.view_ModelTableAdapter();
            this.view_TrdGrpTableAdapter = new kursach.kursachDataSetTableAdapters.view_TrdGrpTableAdapter();
            this.view_UnitTableAdapter = new kursach.kursachDataSetTableAdapters.view_UnitTableAdapter();
            this.view_ParameterTableAdapter = new kursach.kursachDataSetTableAdapters.view_ParameterTableAdapter();
            this.btn_AddTrdGrp = new System.Windows.Forms.Button();
            this.btn_AddModel = new System.Windows.Forms.Button();
            this.btn_AddPrdct = new System.Windows.Forms.Button();
            this.btn_AddManufact = new System.Windows.Forms.Button();
            this.btn_AddCharcht = new System.Windows.Forms.Button();
            this.btn_AddParam = new System.Windows.Forms.Button();
            this.tabNav_1.SuspendLayout();
            this.tab_TrdGrp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sTrdGrpDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sTrdGrpBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).BeginInit();
            this.tab_modl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sModelDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewManufacturerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sModelBindingSource)).BeginInit();
            this.tab_prdct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rPrdctInfoDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewModelBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewTrdGrpBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rPrdctInfoBindingSource)).BeginInit();
            this.tab_Manufact.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cManufacturerDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cManufacturerBindingSource)).BeginInit();
            this.tabNav_2.SuspendLayout();
            this.tab_chrcrst.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.characteristicsDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewParameterBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r34BindingSource)).BeginInit();
            this.tab_param.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sParameterDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewUnitBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sParameterBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.characteristicsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewModelBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabNav_1
            // 
            this.tabNav_1.Controls.Add(this.tab_TrdGrp);
            this.tabNav_1.Controls.Add(this.tab_modl);
            this.tabNav_1.Controls.Add(this.tab_prdct);
            this.tabNav_1.Controls.Add(this.tab_Manufact);
            this.tabNav_1.Location = new System.Drawing.Point(12, 12);
            this.tabNav_1.Name = "tabNav_1";
            this.tabNav_1.SelectedIndex = 0;
            this.tabNav_1.Size = new System.Drawing.Size(677, 176);
            this.tabNav_1.TabIndex = 0;
            // 
            // tab_TrdGrp
            // 
            this.tab_TrdGrp.AutoScroll = true;
            this.tab_TrdGrp.Controls.Add(this.btn_AddTrdGrp);
            this.tab_TrdGrp.Controls.Add(this.btn_deleteTRdGrp);
            this.tab_TrdGrp.Controls.Add(this.sTrdGrpDataGridView);
            this.tab_TrdGrp.Location = new System.Drawing.Point(4, 22);
            this.tab_TrdGrp.Name = "tab_TrdGrp";
            this.tab_TrdGrp.Padding = new System.Windows.Forms.Padding(3);
            this.tab_TrdGrp.Size = new System.Drawing.Size(669, 150);
            this.tab_TrdGrp.TabIndex = 0;
            this.tab_TrdGrp.Text = "Trade Group";
            this.tab_TrdGrp.UseVisualStyleBackColor = true;
            // 
            // btn_deleteTRdGrp
            // 
            this.btn_deleteTRdGrp.Location = new System.Drawing.Point(6, 121);
            this.btn_deleteTRdGrp.Name = "btn_deleteTRdGrp";
            this.btn_deleteTRdGrp.Size = new System.Drawing.Size(75, 23);
            this.btn_deleteTRdGrp.TabIndex = 1;
            this.btn_deleteTRdGrp.Text = "Delete";
            this.btn_deleteTRdGrp.UseVisualStyleBackColor = true;
            this.btn_deleteTRdGrp.Click += new System.EventHandler(this.btn_deleteTRdGrp_Click);
            // 
            // sTrdGrpDataGridView
            // 
            this.sTrdGrpDataGridView.AutoGenerateColumns = false;
            this.sTrdGrpDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sTrdGrpDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idTrdGrpDataGridViewTextBoxColumn,
            this.trdGrpNameDataGridViewTextBoxColumn});
            this.sTrdGrpDataGridView.DataSource = this.sTrdGrpBindingSource;
            this.sTrdGrpDataGridView.Location = new System.Drawing.Point(3, 3);
            this.sTrdGrpDataGridView.Name = "sTrdGrpDataGridView";
            this.sTrdGrpDataGridView.Size = new System.Drawing.Size(663, 112);
            this.sTrdGrpDataGridView.TabIndex = 0;
            // 
            // idTrdGrpDataGridViewTextBoxColumn
            // 
            this.idTrdGrpDataGridViewTextBoxColumn.DataPropertyName = "idTrdGrp";
            this.idTrdGrpDataGridViewTextBoxColumn.HeaderText = "idTrdGrp";
            this.idTrdGrpDataGridViewTextBoxColumn.Name = "idTrdGrpDataGridViewTextBoxColumn";
            // 
            // trdGrpNameDataGridViewTextBoxColumn
            // 
            this.trdGrpNameDataGridViewTextBoxColumn.DataPropertyName = "trdGrpName";
            this.trdGrpNameDataGridViewTextBoxColumn.HeaderText = "trdGrpName";
            this.trdGrpNameDataGridViewTextBoxColumn.Name = "trdGrpNameDataGridViewTextBoxColumn";
            // 
            // sTrdGrpBindingSource
            // 
            this.sTrdGrpBindingSource.DataMember = "STrdGrp";
            this.sTrdGrpBindingSource.DataSource = this.kursachDataSet;
            // 
            // kursachDataSet
            // 
            this.kursachDataSet.DataSetName = "kursachDataSet";
            this.kursachDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tab_modl
            // 
            this.tab_modl.AutoScroll = true;
            this.tab_modl.Controls.Add(this.btn_AddModel);
            this.tab_modl.Controls.Add(this.btn_deleteModel);
            this.tab_modl.Controls.Add(this.sModelDataGridView);
            this.tab_modl.Location = new System.Drawing.Point(4, 22);
            this.tab_modl.Name = "tab_modl";
            this.tab_modl.Padding = new System.Windows.Forms.Padding(3);
            this.tab_modl.Size = new System.Drawing.Size(669, 150);
            this.tab_modl.TabIndex = 1;
            this.tab_modl.Text = "Model";
            this.tab_modl.UseVisualStyleBackColor = true;
            // 
            // btn_deleteModel
            // 
            this.btn_deleteModel.Location = new System.Drawing.Point(6, 121);
            this.btn_deleteModel.Name = "btn_deleteModel";
            this.btn_deleteModel.Size = new System.Drawing.Size(75, 23);
            this.btn_deleteModel.TabIndex = 1;
            this.btn_deleteModel.Text = "Delete";
            this.btn_deleteModel.UseVisualStyleBackColor = true;
            this.btn_deleteModel.Click += new System.EventHandler(this.btn_deleteModel_Click);
            // 
            // sModelDataGridView
            // 
            this.sModelDataGridView.AutoGenerateColumns = false;
            this.sModelDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sModelDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idModelDataGridViewTextBoxColumn,
            this.idManufactrerDataGridViewTextBoxColumn,
            this.modelNameDataGridViewTextBoxColumn});
            this.sModelDataGridView.DataSource = this.sModelBindingSource;
            this.sModelDataGridView.Location = new System.Drawing.Point(3, 3);
            this.sModelDataGridView.Name = "sModelDataGridView";
            this.sModelDataGridView.Size = new System.Drawing.Size(663, 112);
            this.sModelDataGridView.TabIndex = 0;
            // 
            // idModelDataGridViewTextBoxColumn
            // 
            this.idModelDataGridViewTextBoxColumn.DataPropertyName = "idModel";
            this.idModelDataGridViewTextBoxColumn.HeaderText = "idModel";
            this.idModelDataGridViewTextBoxColumn.Name = "idModelDataGridViewTextBoxColumn";
            // 
            // idManufactrerDataGridViewTextBoxColumn
            // 
            this.idManufactrerDataGridViewTextBoxColumn.DataPropertyName = "idManufactrer";
            this.idManufactrerDataGridViewTextBoxColumn.DataSource = this.viewManufacturerBindingSource;
            this.idManufactrerDataGridViewTextBoxColumn.DisplayMember = "manufacturerName";
            this.idManufactrerDataGridViewTextBoxColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.idManufactrerDataGridViewTextBoxColumn.HeaderText = "idManufactrer";
            this.idManufactrerDataGridViewTextBoxColumn.Name = "idManufactrerDataGridViewTextBoxColumn";
            this.idManufactrerDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.idManufactrerDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.idManufactrerDataGridViewTextBoxColumn.ValueMember = "idManufactrer";
            // 
            // viewManufacturerBindingSource
            // 
            this.viewManufacturerBindingSource.DataMember = "view_Manufacturer";
            this.viewManufacturerBindingSource.DataSource = this.kursachDataSet;
            // 
            // modelNameDataGridViewTextBoxColumn
            // 
            this.modelNameDataGridViewTextBoxColumn.DataPropertyName = "modelName";
            this.modelNameDataGridViewTextBoxColumn.HeaderText = "modelName";
            this.modelNameDataGridViewTextBoxColumn.Name = "modelNameDataGridViewTextBoxColumn";
            // 
            // sModelBindingSource
            // 
            this.sModelBindingSource.DataMember = "SModel";
            this.sModelBindingSource.DataSource = this.kursachDataSet;
            // 
            // tab_prdct
            // 
            this.tab_prdct.AutoScroll = true;
            this.tab_prdct.Controls.Add(this.btn_AddPrdct);
            this.tab_prdct.Controls.Add(this.btn_deletePrdct);
            this.tab_prdct.Controls.Add(this.rPrdctInfoDataGridView);
            this.tab_prdct.Location = new System.Drawing.Point(4, 22);
            this.tab_prdct.Name = "tab_prdct";
            this.tab_prdct.Padding = new System.Windows.Forms.Padding(3);
            this.tab_prdct.Size = new System.Drawing.Size(669, 150);
            this.tab_prdct.TabIndex = 2;
            this.tab_prdct.Text = "Production";
            this.tab_prdct.UseVisualStyleBackColor = true;
            // 
            // btn_deletePrdct
            // 
            this.btn_deletePrdct.Location = new System.Drawing.Point(6, 121);
            this.btn_deletePrdct.Name = "btn_deletePrdct";
            this.btn_deletePrdct.Size = new System.Drawing.Size(75, 23);
            this.btn_deletePrdct.TabIndex = 1;
            this.btn_deletePrdct.Text = "Delete";
            this.btn_deletePrdct.UseVisualStyleBackColor = true;
            this.btn_deletePrdct.Click += new System.EventHandler(this.btn_deletePrdct_Click);
            // 
            // rPrdctInfoDataGridView
            // 
            this.rPrdctInfoDataGridView.AutoGenerateColumns = false;
            this.rPrdctInfoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rPrdctInfoDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idProductDataGridViewTextBoxColumn,
            this.idModelDataGridViewTextBoxColumn1,
            this.idTrdGrpDataGridViewTextBoxColumn1,
            this.warntyPeriodDataGridViewTextBoxColumn});
            this.rPrdctInfoDataGridView.DataSource = this.rPrdctInfoBindingSource;
            this.rPrdctInfoDataGridView.Location = new System.Drawing.Point(3, 3);
            this.rPrdctInfoDataGridView.Name = "rPrdctInfoDataGridView";
            this.rPrdctInfoDataGridView.Size = new System.Drawing.Size(663, 112);
            this.rPrdctInfoDataGridView.TabIndex = 0;
            // 
            // idProductDataGridViewTextBoxColumn
            // 
            this.idProductDataGridViewTextBoxColumn.DataPropertyName = "idProduct";
            this.idProductDataGridViewTextBoxColumn.HeaderText = "idProduct";
            this.idProductDataGridViewTextBoxColumn.Name = "idProductDataGridViewTextBoxColumn";
            // 
            // idModelDataGridViewTextBoxColumn1
            // 
            this.idModelDataGridViewTextBoxColumn1.DataPropertyName = "idModel";
            this.idModelDataGridViewTextBoxColumn1.DataSource = this.viewModelBindingSource1;
            this.idModelDataGridViewTextBoxColumn1.DisplayMember = "Model";
            this.idModelDataGridViewTextBoxColumn1.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.idModelDataGridViewTextBoxColumn1.HeaderText = "idModel";
            this.idModelDataGridViewTextBoxColumn1.Name = "idModelDataGridViewTextBoxColumn1";
            this.idModelDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.idModelDataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.idModelDataGridViewTextBoxColumn1.ValueMember = "idModel";
            // 
            // viewModelBindingSource1
            // 
            this.viewModelBindingSource1.DataMember = "view_Model";
            this.viewModelBindingSource1.DataSource = this.kursachDataSet;
            // 
            // idTrdGrpDataGridViewTextBoxColumn1
            // 
            this.idTrdGrpDataGridViewTextBoxColumn1.DataPropertyName = "idTrdGrp";
            this.idTrdGrpDataGridViewTextBoxColumn1.DataSource = this.viewTrdGrpBindingSource;
            this.idTrdGrpDataGridViewTextBoxColumn1.DisplayMember = "trdGrpName";
            this.idTrdGrpDataGridViewTextBoxColumn1.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.idTrdGrpDataGridViewTextBoxColumn1.HeaderText = "idTrdGrp";
            this.idTrdGrpDataGridViewTextBoxColumn1.Name = "idTrdGrpDataGridViewTextBoxColumn1";
            this.idTrdGrpDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.idTrdGrpDataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.idTrdGrpDataGridViewTextBoxColumn1.ValueMember = "idTrdGrp";
            // 
            // viewTrdGrpBindingSource
            // 
            this.viewTrdGrpBindingSource.DataMember = "view_TrdGrp";
            this.viewTrdGrpBindingSource.DataSource = this.kursachDataSet;
            // 
            // warntyPeriodDataGridViewTextBoxColumn
            // 
            this.warntyPeriodDataGridViewTextBoxColumn.DataPropertyName = "warntyPeriod";
            this.warntyPeriodDataGridViewTextBoxColumn.HeaderText = "warntyPeriod";
            this.warntyPeriodDataGridViewTextBoxColumn.Name = "warntyPeriodDataGridViewTextBoxColumn";
            // 
            // rPrdctInfoBindingSource
            // 
            this.rPrdctInfoBindingSource.DataMember = "RPrdctInfo";
            this.rPrdctInfoBindingSource.DataSource = this.kursachDataSet;
            // 
            // tab_Manufact
            // 
            this.tab_Manufact.AutoScroll = true;
            this.tab_Manufact.Controls.Add(this.btn_AddManufact);
            this.tab_Manufact.Controls.Add(this.btn_DeleteManufact);
            this.tab_Manufact.Controls.Add(this.cManufacturerDataGridView);
            this.tab_Manufact.Location = new System.Drawing.Point(4, 22);
            this.tab_Manufact.Name = "tab_Manufact";
            this.tab_Manufact.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Manufact.Size = new System.Drawing.Size(669, 150);
            this.tab_Manufact.TabIndex = 3;
            this.tab_Manufact.Text = "Manufacturer";
            this.tab_Manufact.UseVisualStyleBackColor = true;
            // 
            // btn_DeleteManufact
            // 
            this.btn_DeleteManufact.Location = new System.Drawing.Point(6, 121);
            this.btn_DeleteManufact.Name = "btn_DeleteManufact";
            this.btn_DeleteManufact.Size = new System.Drawing.Size(75, 23);
            this.btn_DeleteManufact.TabIndex = 2;
            this.btn_DeleteManufact.Text = "Delete";
            this.btn_DeleteManufact.UseVisualStyleBackColor = true;
            // 
            // cManufacturerDataGridView
            // 
            this.cManufacturerDataGridView.AutoGenerateColumns = false;
            this.cManufacturerDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cManufacturerDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idManufactrerDataGridViewTextBoxColumn1,
            this.manufacturerNameDataGridViewTextBoxColumn});
            this.cManufacturerDataGridView.DataSource = this.cManufacturerBindingSource;
            this.cManufacturerDataGridView.Location = new System.Drawing.Point(3, 3);
            this.cManufacturerDataGridView.Name = "cManufacturerDataGridView";
            this.cManufacturerDataGridView.Size = new System.Drawing.Size(663, 112);
            this.cManufacturerDataGridView.TabIndex = 0;
            // 
            // idManufactrerDataGridViewTextBoxColumn1
            // 
            this.idManufactrerDataGridViewTextBoxColumn1.DataPropertyName = "idManufactrer";
            this.idManufactrerDataGridViewTextBoxColumn1.HeaderText = "idManufactrer";
            this.idManufactrerDataGridViewTextBoxColumn1.Name = "idManufactrerDataGridViewTextBoxColumn1";
            // 
            // manufacturerNameDataGridViewTextBoxColumn
            // 
            this.manufacturerNameDataGridViewTextBoxColumn.DataPropertyName = "manufacturerName";
            this.manufacturerNameDataGridViewTextBoxColumn.HeaderText = "manufacturerName";
            this.manufacturerNameDataGridViewTextBoxColumn.Name = "manufacturerNameDataGridViewTextBoxColumn";
            // 
            // cManufacturerBindingSource
            // 
            this.cManufacturerBindingSource.DataMember = "CManufacturer";
            this.cManufacturerBindingSource.DataSource = this.kursachDataSet;
            // 
            // btn_refresh
            // 
            this.btn_refresh.Location = new System.Drawing.Point(12, 326);
            this.btn_refresh.Name = "btn_refresh";
            this.btn_refresh.Size = new System.Drawing.Size(100, 35);
            this.btn_refresh.TabIndex = 2;
            this.btn_refresh.Text = "Refresh";
            this.btn_refresh.UseVisualStyleBackColor = true;
            this.btn_refresh.Click += new System.EventHandler(this.btn_refresh_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Location = new System.Drawing.Point(589, 326);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(100, 35);
            this.btn_Exit.TabIndex = 3;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // tabNav_2
            // 
            this.tabNav_2.Controls.Add(this.tab_chrcrst);
            this.tabNav_2.Controls.Add(this.tab_param);
            this.tabNav_2.Location = new System.Drawing.Point(13, 194);
            this.tabNav_2.Name = "tabNav_2";
            this.tabNav_2.SelectedIndex = 0;
            this.tabNav_2.Size = new System.Drawing.Size(672, 126);
            this.tabNav_2.TabIndex = 4;
            // 
            // tab_chrcrst
            // 
            this.tab_chrcrst.AutoScroll = true;
            this.tab_chrcrst.Controls.Add(this.btn_AddCharcht);
            this.tab_chrcrst.Controls.Add(this.btn_deleteChrc);
            this.tab_chrcrst.Controls.Add(this.characteristicsDataGridView);
            this.tab_chrcrst.Location = new System.Drawing.Point(4, 22);
            this.tab_chrcrst.Name = "tab_chrcrst";
            this.tab_chrcrst.Padding = new System.Windows.Forms.Padding(3);
            this.tab_chrcrst.Size = new System.Drawing.Size(664, 100);
            this.tab_chrcrst.TabIndex = 0;
            this.tab_chrcrst.Text = "Characteristic";
            this.tab_chrcrst.UseVisualStyleBackColor = true;
            // 
            // btn_deleteChrc
            // 
            this.btn_deleteChrc.Location = new System.Drawing.Point(558, 6);
            this.btn_deleteChrc.Name = "btn_deleteChrc";
            this.btn_deleteChrc.Size = new System.Drawing.Size(100, 35);
            this.btn_deleteChrc.TabIndex = 1;
            this.btn_deleteChrc.Text = "Delete";
            this.btn_deleteChrc.UseVisualStyleBackColor = true;
            this.btn_deleteChrc.Click += new System.EventHandler(this.btn_deleteChrc_Click);
            // 
            // characteristicsDataGridView
            // 
            this.characteristicsDataGridView.AutoGenerateColumns = false;
            this.characteristicsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.characteristicsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idProductDataGridViewTextBoxColumn1,
            this.idParameterDataGridViewTextBoxColumn,
            this.parValueDataGridViewTextBoxColumn,
            this.unitName});
            this.characteristicsDataGridView.DataSource = this.r34BindingSource;
            this.characteristicsDataGridView.Location = new System.Drawing.Point(3, 3);
            this.characteristicsDataGridView.Name = "characteristicsDataGridView";
            this.characteristicsDataGridView.Size = new System.Drawing.Size(445, 94);
            this.characteristicsDataGridView.TabIndex = 0;
            // 
            // idProductDataGridViewTextBoxColumn1
            // 
            this.idProductDataGridViewTextBoxColumn1.DataPropertyName = "idProduct";
            this.idProductDataGridViewTextBoxColumn1.HeaderText = "idProduct";
            this.idProductDataGridViewTextBoxColumn1.Name = "idProductDataGridViewTextBoxColumn1";
            // 
            // idParameterDataGridViewTextBoxColumn
            // 
            this.idParameterDataGridViewTextBoxColumn.DataPropertyName = "idParameter";
            this.idParameterDataGridViewTextBoxColumn.DataSource = this.viewParameterBindingSource;
            this.idParameterDataGridViewTextBoxColumn.DisplayMember = "parameterName";
            this.idParameterDataGridViewTextBoxColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.idParameterDataGridViewTextBoxColumn.HeaderText = "idParameter";
            this.idParameterDataGridViewTextBoxColumn.Name = "idParameterDataGridViewTextBoxColumn";
            this.idParameterDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.idParameterDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.idParameterDataGridViewTextBoxColumn.ValueMember = "idParameter";
            // 
            // viewParameterBindingSource
            // 
            this.viewParameterBindingSource.DataMember = "view_Parameter";
            this.viewParameterBindingSource.DataSource = this.kursachDataSet;
            // 
            // parValueDataGridViewTextBoxColumn
            // 
            this.parValueDataGridViewTextBoxColumn.DataPropertyName = "ParValue";
            this.parValueDataGridViewTextBoxColumn.HeaderText = "ParValue";
            this.parValueDataGridViewTextBoxColumn.Name = "parValueDataGridViewTextBoxColumn";
            // 
            // unitName
            // 
            this.unitName.DataPropertyName = "idParameter";
            this.unitName.DataSource = this.viewParameterBindingSource;
            this.unitName.DisplayMember = "unitName";
            this.unitName.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.unitName.HeaderText = "Value Type";
            this.unitName.Name = "unitName";
            this.unitName.ValueMember = "idParameter";
            // 
            // r34BindingSource
            // 
            this.r34BindingSource.DataMember = "R_34";
            this.r34BindingSource.DataSource = this.rPrdctInfoBindingSource;
            // 
            // tab_param
            // 
            this.tab_param.AutoScroll = true;
            this.tab_param.Controls.Add(this.btn_AddParam);
            this.tab_param.Controls.Add(this.btn_deleteParam);
            this.tab_param.Controls.Add(this.sParameterDataGridView);
            this.tab_param.Location = new System.Drawing.Point(4, 22);
            this.tab_param.Name = "tab_param";
            this.tab_param.Padding = new System.Windows.Forms.Padding(3);
            this.tab_param.Size = new System.Drawing.Size(664, 100);
            this.tab_param.TabIndex = 1;
            this.tab_param.Text = "Parameter";
            this.tab_param.UseVisualStyleBackColor = true;
            // 
            // btn_deleteParam
            // 
            this.btn_deleteParam.Location = new System.Drawing.Point(558, 6);
            this.btn_deleteParam.Name = "btn_deleteParam";
            this.btn_deleteParam.Size = new System.Drawing.Size(100, 35);
            this.btn_deleteParam.TabIndex = 1;
            this.btn_deleteParam.Text = "Delete";
            this.btn_deleteParam.UseVisualStyleBackColor = true;
            this.btn_deleteParam.Click += new System.EventHandler(this.btn_deleteParam_Click);
            // 
            // sParameterDataGridView
            // 
            this.sParameterDataGridView.AutoGenerateColumns = false;
            this.sParameterDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sParameterDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idParameterDataGridViewTextBoxColumn1,
            this.idUnitDataGridViewTextBoxColumn,
            this.parameterNameDataGridViewTextBoxColumn});
            this.sParameterDataGridView.DataSource = this.sParameterBindingSource;
            this.sParameterDataGridView.Location = new System.Drawing.Point(3, 3);
            this.sParameterDataGridView.Name = "sParameterDataGridView";
            this.sParameterDataGridView.Size = new System.Drawing.Size(347, 94);
            this.sParameterDataGridView.TabIndex = 0;
            // 
            // idParameterDataGridViewTextBoxColumn1
            // 
            this.idParameterDataGridViewTextBoxColumn1.DataPropertyName = "idParameter";
            this.idParameterDataGridViewTextBoxColumn1.HeaderText = "idParameter";
            this.idParameterDataGridViewTextBoxColumn1.Name = "idParameterDataGridViewTextBoxColumn1";
            // 
            // idUnitDataGridViewTextBoxColumn
            // 
            this.idUnitDataGridViewTextBoxColumn.DataPropertyName = "idUnit";
            this.idUnitDataGridViewTextBoxColumn.DataSource = this.viewUnitBindingSource;
            this.idUnitDataGridViewTextBoxColumn.DisplayMember = "unitName";
            this.idUnitDataGridViewTextBoxColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.idUnitDataGridViewTextBoxColumn.HeaderText = "idUnit";
            this.idUnitDataGridViewTextBoxColumn.Name = "idUnitDataGridViewTextBoxColumn";
            this.idUnitDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.idUnitDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.idUnitDataGridViewTextBoxColumn.ValueMember = "idUnit";
            // 
            // viewUnitBindingSource
            // 
            this.viewUnitBindingSource.DataMember = "view_Unit";
            this.viewUnitBindingSource.DataSource = this.kursachDataSet;
            // 
            // parameterNameDataGridViewTextBoxColumn
            // 
            this.parameterNameDataGridViewTextBoxColumn.DataPropertyName = "parameterName";
            this.parameterNameDataGridViewTextBoxColumn.HeaderText = "parameterName";
            this.parameterNameDataGridViewTextBoxColumn.Name = "parameterNameDataGridViewTextBoxColumn";
            // 
            // sParameterBindingSource
            // 
            this.sParameterBindingSource.DataMember = "SParameter";
            this.sParameterBindingSource.DataSource = this.kursachDataSet;
            // 
            // characteristicsBindingSource
            // 
            this.characteristicsBindingSource.DataMember = "Characteristics";
            this.characteristicsBindingSource.DataSource = this.kursachDataSet;
            // 
            // sTrdGrpTableAdapter
            // 
            this.sTrdGrpTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AllowableChrtrcsTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CGenderTableAdapter = null;
            this.tableAdapterManager.CharacteristicsTableAdapter = this.characteristicsTableAdapter;
            this.tableAdapterManager.CManufacturerTableAdapter = this.cManufacturerTableAdapter;
            this.tableAdapterManager.COperatorNumberTableAdapter = null;
            this.tableAdapterManager.COperatorTableAdapter = null;
            this.tableAdapterManager.CRefundTypeTableAdapter = null;
            this.tableAdapterManager.CStrtTypeTableAdapter = null;
            this.tableAdapterManager.CUnitTableAdapter = null;
            this.tableAdapterManager.DlvryTableAdapter = null;
            this.tableAdapterManager.EntityTableAdapter = null;
            this.tableAdapterManager.IndividualTableAdapter = null;
            this.tableAdapterManager.JRefundTableAdapter = null;
            this.tableAdapterManager.JSaleTableAdapter = null;
            this.tableAdapterManager.LandlinePhoneTableAdapter = null;
            this.tableAdapterManager.MobilePhoneTableAdapter = null;
            this.tableAdapterManager.PrdctInstanceTableAdapter = null;
            this.tableAdapterManager.RAdressTableAdapter = null;
            this.tableAdapterManager.RBuyerTableAdapter = null;
            this.tableAdapterManager.RCntcInfoTableAdapter = null;
            this.tableAdapterManager.RContractTableAdapter = null;
            this.tableAdapterManager.RPhoneTableAdapter = null;
            this.tableAdapterManager.RPrdctInfoTableAdapter = this.rPrdctInfoTableAdapter;
            this.tableAdapterManager.RProviderTableAdapter = null;
            this.tableAdapterManager.RSaleDetailTableAdapter = null;
            this.tableAdapterManager.SCountryTableAdapter = null;
            this.tableAdapterManager.SLocalityTableAdapter = null;
            this.tableAdapterManager.SModelTableAdapter = this.sModelTableAdapter;
            this.tableAdapterManager.SParameterTableAdapter = this.sParameterTableAdapter;
            this.tableAdapterManager.SRegionTableAdapter = null;
            this.tableAdapterManager.SStaffTableAdapter = null;
            this.tableAdapterManager.SStreetTableAdapter = null;
            this.tableAdapterManager.StorageTableAdapter = null;
            this.tableAdapterManager.STrdGrpTableAdapter = this.sTrdGrpTableAdapter;
            this.tableAdapterManager.UpdateOrder = kursach.kursachDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // characteristicsTableAdapter
            // 
            this.characteristicsTableAdapter.ClearBeforeFill = true;
            // 
            // cManufacturerTableAdapter
            // 
            this.cManufacturerTableAdapter.ClearBeforeFill = true;
            // 
            // rPrdctInfoTableAdapter
            // 
            this.rPrdctInfoTableAdapter.ClearBeforeFill = true;
            // 
            // sModelTableAdapter
            // 
            this.sModelTableAdapter.ClearBeforeFill = true;
            // 
            // sParameterTableAdapter
            // 
            this.sParameterTableAdapter.ClearBeforeFill = true;
            // 
            // view_ManufacturerTableAdapter
            // 
            this.view_ManufacturerTableAdapter.ClearBeforeFill = true;
            // 
            // viewModelBindingSource
            // 
            this.viewModelBindingSource.DataMember = "view_Model";
            this.viewModelBindingSource.DataSource = this.kursachDataSet;
            // 
            // view_ModelTableAdapter
            // 
            this.view_ModelTableAdapter.ClearBeforeFill = true;
            // 
            // view_TrdGrpTableAdapter
            // 
            this.view_TrdGrpTableAdapter.ClearBeforeFill = true;
            // 
            // view_UnitTableAdapter
            // 
            this.view_UnitTableAdapter.ClearBeforeFill = true;
            // 
            // view_ParameterTableAdapter
            // 
            this.view_ParameterTableAdapter.ClearBeforeFill = true;
            // 
            // btn_AddTrdGrp
            // 
            this.btn_AddTrdGrp.Location = new System.Drawing.Point(87, 121);
            this.btn_AddTrdGrp.Name = "btn_AddTrdGrp";
            this.btn_AddTrdGrp.Size = new System.Drawing.Size(75, 23);
            this.btn_AddTrdGrp.TabIndex = 2;
            this.btn_AddTrdGrp.Text = "Add new";
            this.btn_AddTrdGrp.UseVisualStyleBackColor = true;
            this.btn_AddTrdGrp.Click += new System.EventHandler(this.btn_AddTrdGrp_Click);
            // 
            // btn_AddModel
            // 
            this.btn_AddModel.Location = new System.Drawing.Point(87, 121);
            this.btn_AddModel.Name = "btn_AddModel";
            this.btn_AddModel.Size = new System.Drawing.Size(75, 23);
            this.btn_AddModel.TabIndex = 2;
            this.btn_AddModel.Text = "Add new";
            this.btn_AddModel.UseVisualStyleBackColor = true;
            this.btn_AddModel.Click += new System.EventHandler(this.btn_AddModel_Click);
            // 
            // btn_AddPrdct
            // 
            this.btn_AddPrdct.Location = new System.Drawing.Point(87, 121);
            this.btn_AddPrdct.Name = "btn_AddPrdct";
            this.btn_AddPrdct.Size = new System.Drawing.Size(75, 23);
            this.btn_AddPrdct.TabIndex = 2;
            this.btn_AddPrdct.Text = "Add new";
            this.btn_AddPrdct.UseVisualStyleBackColor = true;
            this.btn_AddPrdct.Click += new System.EventHandler(this.btn_AddPrdct_Click);
            // 
            // btn_AddManufact
            // 
            this.btn_AddManufact.Location = new System.Drawing.Point(87, 121);
            this.btn_AddManufact.Name = "btn_AddManufact";
            this.btn_AddManufact.Size = new System.Drawing.Size(75, 23);
            this.btn_AddManufact.TabIndex = 3;
            this.btn_AddManufact.Text = "Add new";
            this.btn_AddManufact.UseVisualStyleBackColor = true;
            this.btn_AddManufact.Click += new System.EventHandler(this.btn_AddManufact_Click);
            // 
            // btn_AddCharcht
            // 
            this.btn_AddCharcht.Location = new System.Drawing.Point(558, 47);
            this.btn_AddCharcht.Name = "btn_AddCharcht";
            this.btn_AddCharcht.Size = new System.Drawing.Size(100, 35);
            this.btn_AddCharcht.TabIndex = 2;
            this.btn_AddCharcht.Text = "Add new";
            this.btn_AddCharcht.UseVisualStyleBackColor = true;
            this.btn_AddCharcht.Click += new System.EventHandler(this.btn_AddCharcht_Click);
            // 
            // btn_AddParam
            // 
            this.btn_AddParam.Location = new System.Drawing.Point(558, 47);
            this.btn_AddParam.Name = "btn_AddParam";
            this.btn_AddParam.Size = new System.Drawing.Size(100, 35);
            this.btn_AddParam.TabIndex = 2;
            this.btn_AddParam.Text = "Add new";
            this.btn_AddParam.UseVisualStyleBackColor = true;
            this.btn_AddParam.Click += new System.EventHandler(this.btn_AddParam_Click);
            // 
            // productionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(701, 373);
            this.Controls.Add(this.tabNav_2);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_refresh);
            this.Controls.Add(this.tabNav_1);
            this.Name = "productionForm";
            this.Text = "productionForm";
            this.Load += new System.EventHandler(this.productionForm_Load);
            this.tabNav_1.ResumeLayout(false);
            this.tab_TrdGrp.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sTrdGrpDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sTrdGrpBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).EndInit();
            this.tab_modl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sModelDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewManufacturerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sModelBindingSource)).EndInit();
            this.tab_prdct.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rPrdctInfoDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewModelBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewTrdGrpBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rPrdctInfoBindingSource)).EndInit();
            this.tab_Manufact.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cManufacturerDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cManufacturerBindingSource)).EndInit();
            this.tabNav_2.ResumeLayout(false);
            this.tab_chrcrst.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.characteristicsDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewParameterBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r34BindingSource)).EndInit();
            this.tab_param.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sParameterDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewUnitBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sParameterBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.characteristicsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewModelBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabNav_1;
        private System.Windows.Forms.TabPage tab_TrdGrp;
        private System.Windows.Forms.TabPage tab_modl;
        private System.Windows.Forms.DataGridView sModelDataGridView;
        private System.Windows.Forms.DataGridView sTrdGrpDataGridView;
        private System.Windows.Forms.Button btn_refresh;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.TabPage tab_prdct;
        private System.Windows.Forms.DataGridView rPrdctInfoDataGridView;
        private System.Windows.Forms.TabControl tabNav_2;
        private System.Windows.Forms.TabPage tab_chrcrst;
        private System.Windows.Forms.TabPage tab_param;
        private System.Windows.Forms.DataGridView characteristicsDataGridView;
        private System.Windows.Forms.DataGridView sParameterDataGridView;
        private System.Windows.Forms.Button btn_deleteTRdGrp;
        private System.Windows.Forms.Button btn_deleteModel;
        private System.Windows.Forms.Button btn_deletePrdct;
        private System.Windows.Forms.Button btn_deleteChrc;
        private System.Windows.Forms.Button btn_deleteParam;
        private System.Windows.Forms.TabPage tab_Manufact;
        private System.Windows.Forms.DataGridView cManufacturerDataGridView;
        private System.Windows.Forms.Button btn_DeleteManufact;
        private kursachDataSet kursachDataSet;
        private System.Windows.Forms.BindingSource sTrdGrpBindingSource;
        private kursachDataSetTableAdapters.STrdGrpTableAdapter sTrdGrpTableAdapter;
        private kursachDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridViewTextBoxColumn idTrdGrpDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn trdGrpNameDataGridViewTextBoxColumn;
        private kursachDataSetTableAdapters.SModelTableAdapter sModelTableAdapter;
        private System.Windows.Forms.BindingSource sModelBindingSource;
        private kursachDataSetTableAdapters.CManufacturerTableAdapter cManufacturerTableAdapter;
        private System.Windows.Forms.BindingSource cManufacturerBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn idManufactrerDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn manufacturerNameDataGridViewTextBoxColumn;
        private kursachDataSetTableAdapters.RPrdctInfoTableAdapter rPrdctInfoTableAdapter;
        private System.Windows.Forms.BindingSource rPrdctInfoBindingSource;
        private kursachDataSetTableAdapters.CharacteristicsTableAdapter characteristicsTableAdapter;
        private System.Windows.Forms.BindingSource characteristicsBindingSource;
        private kursachDataSetTableAdapters.SParameterTableAdapter sParameterTableAdapter;
        private System.Windows.Forms.BindingSource sParameterBindingSource;
        private System.Windows.Forms.BindingSource viewManufacturerBindingSource;
        private kursachDataSetTableAdapters.view_ManufacturerTableAdapter view_ManufacturerTableAdapter;
        private System.Windows.Forms.BindingSource viewModelBindingSource;
        private kursachDataSetTableAdapters.view_ModelTableAdapter view_ModelTableAdapter;
        private System.Windows.Forms.BindingSource viewTrdGrpBindingSource;
        private kursachDataSetTableAdapters.view_TrdGrpTableAdapter view_TrdGrpTableAdapter;
        private System.Windows.Forms.BindingSource viewModelBindingSource1;
        private System.Windows.Forms.BindingSource viewUnitBindingSource;
        private kursachDataSetTableAdapters.view_UnitTableAdapter view_UnitTableAdapter;
        private System.Windows.Forms.BindingSource viewParameterBindingSource;
        private kursachDataSetTableAdapters.view_ParameterTableAdapter view_ParameterTableAdapter;
        private System.Windows.Forms.BindingSource r34BindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn idModelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn idManufactrerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn modelNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idProductDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn idModelDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewComboBoxColumn idTrdGrpDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn warntyPeriodDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idParameterDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewComboBoxColumn idUnitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn parameterNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idProductDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewComboBoxColumn idParameterDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn parValueDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn unitName;
        private System.Windows.Forms.Button btn_AddTrdGrp;
        private System.Windows.Forms.Button btn_AddModel;
        private System.Windows.Forms.Button btn_AddPrdct;
        private System.Windows.Forms.Button btn_AddManufact;
        private System.Windows.Forms.Button btn_AddCharcht;
        private System.Windows.Forms.Button btn_AddParam;
    }
}