﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class administartForm : Form
    {
        public administartForm()
        {
            InitializeComponent();
        }

        private void cGenderBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cGenderBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.kursachDataSet);

        }

        private void administartForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kursachDataSet.view_Operator' table. You can move, or remove it, as needed.
            this.view_OperatorTableAdapter.Fill(this.kursachDataSet.view_Operator);
            // TODO: This line of code loads data into the 'kursachDataSet.view_Country' table. You can move, or remove it, as needed.
            this.view_CountryTableAdapter.Fill(this.kursachDataSet.view_Country);
            // TODO: This line of code loads data into the 'kursachDataSet.view_Country' table. You can move, or remove it, as needed.
            this.view_CountryTableAdapter.Fill(this.kursachDataSet.view_Country);
            // TODO: This line of code loads data into the 'kursachDataSet.COperatorNumber' table. You can move, or remove it, as needed.
            this.cOperatorNumberTableAdapter.Fill(this.kursachDataSet.COperatorNumber);
            // TODO: This line of code loads data into the 'kursachDataSet.AllowableChrtrcs' table. You can move, or remove it, as needed.
            this.allowableChrtrcsTableAdapter.Fill(this.kursachDataSet.AllowableChrtrcs);
            // TODO: This line of code loads data into the 'kursachDataSet.COperator' table. You can move, or remove it, as needed.
            this.cOperatorTableAdapter.Fill(this.kursachDataSet.COperator);
            // TODO: This line of code loads data into the 'kursachDataSet.CStrtType' table. You can move, or remove it, as needed.
            this.cStrtTypeTableAdapter.Fill(this.kursachDataSet.CStrtType);
            // TODO: This line of code loads data into the 'kursachDataSet.CRefundType' table. You can move, or remove it, as needed.
            this.cRefundTypeTableAdapter.Fill(this.kursachDataSet.CRefundType);
            // TODO: This line of code loads data into the 'kursachDataSet.CUnit' table. You can move, or remove it, as needed.
            this.cUnitTableAdapter.Fill(this.kursachDataSet.CUnit);
            // TODO: This line of code loads data into the 'kursachDataSet.CGender' table. You can move, or remove it, as needed.
            this.cGenderTableAdapter.Fill(this.kursachDataSet.CGender);

        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kursachDataSet.view_Operator' table. You can move, or remove it, as needed.
            this.view_OperatorTableAdapter.Fill(this.kursachDataSet.view_Operator);
            // TODO: This line of code loads data into the 'kursachDataSet.view_Country' table. You can move, or remove it, as needed.
            this.view_CountryTableAdapter.Fill(this.kursachDataSet.view_Country);
            // TODO: This line of code loads data into the 'kursachDataSet.view_Country' table. You can move, or remove it, as needed.
            this.view_CountryTableAdapter.Fill(this.kursachDataSet.view_Country);
            // TODO: This line of code loads data into the 'kursachDataSet.COperatorNumber' table. You can move, or remove it, as needed.
            this.cOperatorNumberTableAdapter.Fill(this.kursachDataSet.COperatorNumber);
            // TODO: This line of code loads data into the 'kursachDataSet.AllowableChrtrcs' table. You can move, or remove it, as needed.
            this.allowableChrtrcsTableAdapter.Fill(this.kursachDataSet.AllowableChrtrcs);
            // TODO: This line of code loads data into the 'kursachDataSet.COperator' table. You can move, or remove it, as needed.
            this.cOperatorTableAdapter.Fill(this.kursachDataSet.COperator);
            // TODO: This line of code loads data into the 'kursachDataSet.CStrtType' table. You can move, or remove it, as needed.
            this.cStrtTypeTableAdapter.Fill(this.kursachDataSet.CStrtType);
            // TODO: This line of code loads data into the 'kursachDataSet.CRefundType' table. You can move, or remove it, as needed.
            this.cRefundTypeTableAdapter.Fill(this.kursachDataSet.CRefundType);
            // TODO: This line of code loads data into the 'kursachDataSet.CUnit' table. You can move, or remove it, as needed.
            this.cUnitTableAdapter.Fill(this.kursachDataSet.CUnit);
            // TODO: This line of code loads data into the 'kursachDataSet.CGender' table. You can move, or remove it, as needed.
            this.cGenderTableAdapter.Fill(this.kursachDataSet.CGender);
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_deleteSrtrType_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in cStrtTypeDataGridView.SelectedRows)
            {
                cStrtTypeDataGridView.Rows.Remove(row);
            }
        }

        private void btn_deleteUnit_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in cUnitDataGridView.SelectedRows)
            {
                cUnitDataGridView.Rows.Remove(row);
            }
        }

        private void btn_deleteGndr_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in cGenderDataGridView.SelectedRows)
            {
               cGenderDataGridView.Rows.Remove(row);
            }
        }

        private void btn_deleteRfndType_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in cRefundTypeDataGridView.SelectedRows)
            {
                cRefundTypeDataGridView.Rows.Remove(row);
            }
        }

        private void btn_AddSrtType_Click(object sender, EventArgs e)
        {
            add_NewStrtForm frm = new add_NewStrtForm();
            frm.Show();            
        }

        private void btn_AddUnit_Click(object sender, EventArgs e)
        {
            add_NewUnitForm frm = new add_NewUnitForm();
            frm.Show();
        }

        private void btn_AddGndr_Click(object sender, EventArgs e)
        {
            add_NewGndrForm frm = new add_NewGndrForm();
            frm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.allowableChrtrcsTableAdapter.Update(this.kursachDataSet);
        }

        private void btn_AddRfndType_Click(object sender, EventArgs e)
        {
            add_NewRfndTypeForm frm = new add_NewRfndTypeForm();
            frm.Show();
        }

        private void btn_AddOprtr_Click(object sender, EventArgs e)
        {
            add_NewOperatorForm frm = new add_NewOperatorForm();
            frm.Show();
        }

        private void btn_DeleteOperNmbr_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in cOperatorDataGridView.SelectedRows)
            {
                cOperatorDataGridView.Rows.Remove(row);
            }
        }

        private void btn_NewOperNmbr_Click(object sender, EventArgs e)
        {
            add_NewOperNmbrForm frm = new add_NewOperNmbrForm();
            frm.Show();
        }
    }
}
