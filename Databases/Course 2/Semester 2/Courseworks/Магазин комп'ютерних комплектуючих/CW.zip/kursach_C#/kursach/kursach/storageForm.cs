﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class storageForm : Form
    {
        public storageForm()
        {
            InitializeComponent();
        }

        private void storageBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.storageBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.kursachDataSet);

        }

        private void storageForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kursachDataSet.Storage' table. You can move, or remove it, as needed.
            this.storageTableAdapter.Fill(this.kursachDataSet.Storage);

        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            this.storageTableAdapter.Fill(this.kursachDataSet.Storage);
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in storageDataGridView.SelectedRows)
            {
                storageDataGridView.Rows.Remove(row);
            }
        }

        private void btn_AddPdct_Click(object sender, EventArgs e)
        {
            add_NewProductInst frm = new add_NewProductInst();
            frm.Show();
        }
    }
}
