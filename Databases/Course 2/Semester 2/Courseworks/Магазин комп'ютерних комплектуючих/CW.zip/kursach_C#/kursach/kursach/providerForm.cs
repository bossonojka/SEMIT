﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class providerForm : Form
    {
        public providerForm()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void providerForm_Load(object sender, EventArgs e)
        {            
            this.view_AdressTableAdapter.Fill(this.kursachDataSet.view_Adress);            
            this.view_ProviderTableAdapter.Fill(this.kursachDataSet.view_Provider);            
            this.rSaleDetailTableAdapter.Fill(this.kursachDataSet.RSaleDetail);            
            this.rCntcInfoTableAdapter.Fill(this.kursachDataSet.RCntcInfo);            
            this.rProviderTableAdapter.Fill(this.kursachDataSet.RProvider);            
            this.storageTableAdapter.Fill(this.kursachDataSet.Storage);            
            this.rContractTableAdapter.Fill(this.kursachDataSet.RContract);            
            this.individualTableAdapter.Fill(this.kursachDataSet.Individual);            
            this.entityTableAdapter.Fill(this.kursachDataSet.Entity);            
            this.storageTableAdapter.Fill(this.kursachDataSet.Storage);            
            this.rContractTableAdapter.Fill(this.kursachDataSet.RContract);            
            this.individualTableAdapter.Fill(this.kursachDataSet.Individual);            
            this.entityTableAdapter.Fill(this.kursachDataSet.Entity);

        }

        private void btn_refresh_Click(object sender, EventArgs e)
        {
            this.view_AdressTableAdapter.Fill(this.kursachDataSet.view_Adress);
            this.view_ProviderTableAdapter.Fill(this.kursachDataSet.view_Provider);
            this.rSaleDetailTableAdapter.Fill(this.kursachDataSet.RSaleDetail);
            this.rCntcInfoTableAdapter.Fill(this.kursachDataSet.RCntcInfo);
            this.rProviderTableAdapter.Fill(this.kursachDataSet.RProvider);
            this.storageTableAdapter.Fill(this.kursachDataSet.Storage);
            this.rContractTableAdapter.Fill(this.kursachDataSet.RContract);
            this.individualTableAdapter.Fill(this.kursachDataSet.Individual);
            this.entityTableAdapter.Fill(this.kursachDataSet.Entity);
            this.storageTableAdapter.Fill(this.kursachDataSet.Storage);
            this.rContractTableAdapter.Fill(this.kursachDataSet.RContract);
            this.individualTableAdapter.Fill(this.kursachDataSet.Individual);
            this.entityTableAdapter.Fill(this.kursachDataSet.Entity);
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_deleteCntr_Click(object sender, EventArgs e)
        {
            foreach(DataGridViewRow row in rContractDataGridView.SelectedRows)
            {
                rContractDataGridView.Rows.Remove(row);
            }
        }


        private void btn_deleteEnt_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in entityDataGridView.SelectedRows)
            {
                entityDataGridView.Rows.Remove(row);
            }
        }

        private void btn_deleteInd_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataGrid_Individual.SelectedRows)
            {
               dataGrid_Individual.Rows.Remove(row);
            }
        }

        private void btn_deletePrvdr_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in rProviderDataGridView.SelectedRows)
            {
                rProviderDataGridView.Rows.Remove(row);
            }
        }

        private void btn_AddEntity_Click(object sender, EventArgs e)
        {
            add_NewEntityForm frm = new add_NewEntityForm();
            frm.Show();
        }

        private void btn_AddIndivid_Click(object sender, EventArgs e)
        {
            add_NewIndividForm frm = new add_NewIndividForm();
            frm.Show();
        }

        private void btn_AddContr_Click(object sender, EventArgs e)
        {
            add_NewContractForm frm = new add_NewContractForm();
            frm.Show();
        }
    }
}
