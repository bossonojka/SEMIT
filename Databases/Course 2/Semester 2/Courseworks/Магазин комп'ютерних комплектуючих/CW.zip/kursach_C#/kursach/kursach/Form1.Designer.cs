﻿namespace kursach
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.btn_provider = new System.Windows.Forms.Button();
            this.btn_buyer = new System.Windows.Forms.Button();
            this.btn_prdctn = new System.Windows.Forms.Button();
            this.btn_help = new System.Windows.Forms.Button();
            this.btn_exit = new System.Windows.Forms.Button();
            this.btn_staff = new System.Windows.Forms.Button();
            this.btn_report = new System.Windows.Forms.Button();
            this.btn_AddressInfo = new System.Windows.Forms.Button();
            this.btn_Admin = new System.Windows.Forms.Button();
            this.btn_sale = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_Storage = new System.Windows.Forms.Button();
            this.btn_PhnBook = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_provider
            // 
            this.btn_provider.Location = new System.Drawing.Point(12, 135);
            this.btn_provider.Name = "btn_provider";
            this.btn_provider.Size = new System.Drawing.Size(100, 35);
            this.btn_provider.TabIndex = 0;
            this.btn_provider.Text = "Provider";
            this.btn_provider.UseVisualStyleBackColor = true;
            this.btn_provider.Click += new System.EventHandler(this.btn_provider_Click);
            // 
            // btn_buyer
            // 
            this.btn_buyer.Location = new System.Drawing.Point(156, 12);
            this.btn_buyer.Name = "btn_buyer";
            this.btn_buyer.Size = new System.Drawing.Size(100, 35);
            this.btn_buyer.TabIndex = 1;
            this.btn_buyer.Text = "Buyer";
            this.btn_buyer.UseVisualStyleBackColor = true;
            this.btn_buyer.Click += new System.EventHandler(this.btn_buyer_Click);
            // 
            // btn_prdctn
            // 
            this.btn_prdctn.Location = new System.Drawing.Point(12, 53);
            this.btn_prdctn.Name = "btn_prdctn";
            this.btn_prdctn.Size = new System.Drawing.Size(100, 35);
            this.btn_prdctn.TabIndex = 2;
            this.btn_prdctn.Text = "Prodution";
            this.btn_prdctn.UseVisualStyleBackColor = true;
            this.btn_prdctn.Click += new System.EventHandler(this.btn_prdctn_Click);
            // 
            // btn_help
            // 
            this.btn_help.Location = new System.Drawing.Point(364, 299);
            this.btn_help.Name = "btn_help";
            this.btn_help.Size = new System.Drawing.Size(100, 35);
            this.btn_help.TabIndex = 3;
            this.btn_help.Text = "Help";
            this.btn_help.UseVisualStyleBackColor = true;
            this.btn_help.Click += new System.EventHandler(this.btn_help_Click);
            // 
            // btn_exit
            // 
            this.btn_exit.Location = new System.Drawing.Point(470, 299);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(100, 35);
            this.btn_exit.TabIndex = 4;
            this.btn_exit.Text = "Exit";
            this.btn_exit.UseVisualStyleBackColor = true;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // btn_staff
            // 
            this.btn_staff.Location = new System.Drawing.Point(156, 53);
            this.btn_staff.Name = "btn_staff";
            this.btn_staff.Size = new System.Drawing.Size(100, 35);
            this.btn_staff.TabIndex = 5;
            this.btn_staff.Text = "Staff";
            this.btn_staff.UseVisualStyleBackColor = true;
            this.btn_staff.Click += new System.EventHandler(this.btn_staff_Click);
            // 
            // btn_report
            // 
            this.btn_report.Location = new System.Drawing.Point(12, 299);
            this.btn_report.Name = "btn_report";
            this.btn_report.Size = new System.Drawing.Size(100, 35);
            this.btn_report.TabIndex = 6;
            this.btn_report.Text = "Report";
            this.btn_report.UseVisualStyleBackColor = true;
            this.btn_report.Click += new System.EventHandler(this.btn_report_Click);
            // 
            // btn_AddressInfo
            // 
            this.btn_AddressInfo.Location = new System.Drawing.Point(470, 12);
            this.btn_AddressInfo.Name = "btn_AddressInfo";
            this.btn_AddressInfo.Size = new System.Drawing.Size(100, 35);
            this.btn_AddressInfo.TabIndex = 7;
            this.btn_AddressInfo.Text = "Address Information";
            this.btn_AddressInfo.UseVisualStyleBackColor = true;
            this.btn_AddressInfo.Click += new System.EventHandler(this.btn_AddressInfo_Click);
            // 
            // btn_Admin
            // 
            this.btn_Admin.Location = new System.Drawing.Point(156, 299);
            this.btn_Admin.Name = "btn_Admin";
            this.btn_Admin.Size = new System.Drawing.Size(100, 35);
            this.btn_Admin.TabIndex = 8;
            this.btn_Admin.Text = "Administrative";
            this.btn_Admin.UseVisualStyleBackColor = true;
            this.btn_Admin.Click += new System.EventHandler(this.btn_Admin_Click);
            // 
            // btn_sale
            // 
            this.btn_sale.Location = new System.Drawing.Point(12, 94);
            this.btn_sale.Name = "btn_sale";
            this.btn_sale.Size = new System.Drawing.Size(100, 35);
            this.btn_sale.TabIndex = 9;
            this.btn_sale.Text = "Sales";
            this.btn_sale.UseVisualStyleBackColor = true;
            this.btn_sale.Click += new System.EventHandler(this.btn_sale_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(156, 94);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(414, 199);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // btn_Storage
            // 
            this.btn_Storage.Location = new System.Drawing.Point(12, 12);
            this.btn_Storage.Name = "btn_Storage";
            this.btn_Storage.Size = new System.Drawing.Size(100, 35);
            this.btn_Storage.TabIndex = 11;
            this.btn_Storage.Text = "Storage";
            this.btn_Storage.UseVisualStyleBackColor = true;
            this.btn_Storage.Click += new System.EventHandler(this.btn_Storage_Click);
            // 
            // btn_PhnBook
            // 
            this.btn_PhnBook.Location = new System.Drawing.Point(470, 53);
            this.btn_PhnBook.Name = "btn_PhnBook";
            this.btn_PhnBook.Size = new System.Drawing.Size(100, 35);
            this.btn_PhnBook.TabIndex = 12;
            this.btn_PhnBook.Text = "Phone Book";
            this.btn_PhnBook.UseVisualStyleBackColor = true;
            this.btn_PhnBook.Click += new System.EventHandler(this.btn_PhnBook_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(582, 346);
            this.Controls.Add(this.btn_PhnBook);
            this.Controls.Add(this.btn_Storage);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_sale);
            this.Controls.Add(this.btn_Admin);
            this.Controls.Add(this.btn_AddressInfo);
            this.Controls.Add(this.btn_report);
            this.Controls.Add(this.btn_staff);
            this.Controls.Add(this.btn_exit);
            this.Controls.Add(this.btn_help);
            this.Controls.Add(this.btn_prdctn);
            this.Controls.Add(this.btn_buyer);
            this.Controls.Add(this.btn_provider);
            this.Name = "Main";
            this.Text = "PC part";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_provider;
        private System.Windows.Forms.Button btn_buyer;
        private System.Windows.Forms.Button btn_prdctn;
        private System.Windows.Forms.Button btn_help;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.Button btn_staff;
        private System.Windows.Forms.Button btn_report;
        private System.Windows.Forms.Button btn_AddressInfo;
        private System.Windows.Forms.Button btn_Admin;
        private System.Windows.Forms.Button btn_sale;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn_Storage;
        private System.Windows.Forms.Button btn_PhnBook;
    }
}

