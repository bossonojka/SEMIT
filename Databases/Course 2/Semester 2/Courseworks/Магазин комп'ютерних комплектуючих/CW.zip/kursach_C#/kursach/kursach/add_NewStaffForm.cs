﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class add_NewStaffForm : Form
    {
        public add_NewStaffForm()
        {
            InitializeComponent();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            string conS = "Data Source=ADMIN;Initial Catalog=kursach;Integrated Security=True";
            try
            {
                using (SqlConnection con = new SqlConnection(conS))
                {
                    using (SqlCommand cmd = new SqlCommand("add_Staff", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@idGender", SqlDbType.Int).Value = int.Parse(comboBox1.SelectedValue.ToString());
                        cmd.Parameters.AddWithValue("@idAdress", SqlDbType.Int).Value = int.Parse(comboBox6.SelectedValue.ToString());
                        cmd.Parameters.AddWithValue("@secondName", SqlDbType.VarChar).Value = txt_input2.Text.ToString();
                        cmd.Parameters.AddWithValue("@firstName", SqlDbType.VarChar).Value = txt_input1.Text.ToString();
                        cmd.Parameters.AddWithValue("@birthDate", SqlDbType.DateTime).Value = DateTime.Parse(dateTimePicker1.Text.ToString());
                        cmd.Parameters.AddWithValue("@position", SqlDbType.VarChar).Value = txt_input3.Text.ToString();
                        cmd.Parameters.AddWithValue("@wage", SqlDbType.VarChar).Value = txt_input4.Text.ToString();
                        cmd.Parameters.AddWithValue("@idPhone", SqlDbType.Int).Value = 1;
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Data Error!", "Error!",
               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Close();

            staffForm frm = new staffForm();
            frm.Refresh();
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void add_NewStaffForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kursachDataSet.RAdress' table. You can move, or remove it, as needed.
            this.rAdressTableAdapter.Fill(this.kursachDataSet.RAdress);
            // TODO: This line of code loads data into the 'kursachDataSet.SStreet' table. You can move, or remove it, as needed.
            this.sStreetTableAdapter.Fill(this.kursachDataSet.SStreet);
            // TODO: This line of code loads data into the 'kursachDataSet.SLocality' table. You can move, or remove it, as needed.
            this.sLocalityTableAdapter.Fill(this.kursachDataSet.SLocality);
            // TODO: This line of code loads data into the 'kursachDataSet.SRegion' table. You can move, or remove it, as needed.
            this.sRegionTableAdapter.Fill(this.kursachDataSet.SRegion);
            // TODO: This line of code loads data into the 'kursachDataSet.SCountry' table. You can move, or remove it, as needed.
            this.sCountryTableAdapter.Fill(this.kursachDataSet.SCountry);
            // TODO: This line of code loads data into the 'kursachDataSet.CGender' table. You can move, or remove it, as needed.
            this.cGenderTableAdapter.Fill(this.kursachDataSet.CGender);

        }

        private void btn_addLclty_Click(object sender, EventArgs e)
        {
            add_NewLnldPhn frm = new add_NewLnldPhn();
            frm.Show();
        }

        private void btn_addMbl_Click(object sender, EventArgs e)
        {
            add_NewMblPhn frm = new add_NewMblPhn();
            frm.Show();
        }
    }
}
