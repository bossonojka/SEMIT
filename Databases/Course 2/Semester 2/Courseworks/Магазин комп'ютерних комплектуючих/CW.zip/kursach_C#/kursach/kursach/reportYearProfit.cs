﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class reportYearProfit : Form
    {
        public reportYearProfit()
        {
            InitializeComponent();
        }
        private void reportYearProfit_Load(object sender, EventArgs e)
        {
            DateTime year = DateTime.Parse(this.txt_inpData.Text.ToString());
            this.sp_soldYearProfitTableAdapter.Fill(this.kursachDataSet.sp_soldYearProfit, year);
            this.reportViewer1.RefreshReport();
        }

        public void setContent(string txt)
        {
            this.txt_inpData.Text = "01,01," + txt;
        }

    }
}
