﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class add_NewSaleForm : Form
    {
        public add_NewSaleForm()
        {
            InitializeComponent();
        }

        private void add_NewSaleForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kursachDataSet.SStaff' table. You can move, or remove it, as needed.
            this.sStaffTableAdapter.Fill(this.kursachDataSet.SStaff);
            // TODO: This line of code loads data into the 'kursachDataSet.RBuyer' table. You can move, or remove it, as needed.
            this.rBuyerTableAdapter.Fill(this.kursachDataSet.RBuyer);

        }

        private void btn_Save_Click_1(object sender, EventArgs e)
        {
            string conS = "Data Source=ADMIN;Initial Catalog=kursach;Integrated Security=True";
            try
            {
                using (SqlConnection con = new SqlConnection(conS))
                {
                    using (SqlCommand cmd = new SqlCommand("add_Sale", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@idBuyer", SqlDbType.Int).Value = int.Parse(comboBox1.SelectedValue.ToString());
                        cmd.Parameters.AddWithValue("@idDlvry", SqlDbType.VarChar).Value = null;
                        cmd.Parameters.AddWithValue("@idStuff", SqlDbType.VarChar).Value = int.Parse(comboBox2.SelectedValue.ToString());
                        cmd.Parameters.AddWithValue("@saleDate", SqlDbType.DateTime).Value = DateTime.Parse(dateTimePicker1.ToString());
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Data Error!", "Error!",
               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Close();
        }

        private void btn_Cancel_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

