﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class add_NewProductInst : Form
    {
        public add_NewProductInst()
        {
            InitializeComponent();
        }

        private void add_NewProductInst_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kursachDataSet.Characteristics' table. You can move, or remove it, as needed.
            this.characteristicsTableAdapter.Fill(this.kursachDataSet.Characteristics);
            // TODO: This line of code loads data into the 'kursachDataSet.RPrdctInfo' table. You can move, or remove it, as needed.
            this.rPrdctInfoTableAdapter.Fill(this.kursachDataSet.RPrdctInfo);
            // TODO: This line of code loads data into the 'kursachDataSet.PrdctInstance' table. You can move, or remove it, as needed.
            this.prdctInstanceTableAdapter.Fill(this.kursachDataSet.PrdctInstance);

        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            string conS = "Data Source=ADMIN;Initial Catalog=kursach;Integrated Security=True";
            try
            {
                using (SqlConnection con = new SqlConnection(conS))
                {
                    using (SqlCommand cmd = new SqlCommand("add_PrdctInst", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@id", SqlDbType.Int).Value = int.Parse(comboBox2.SelectedValue.ToString());
                        cmd.Parameters.AddWithValue("@serialNmbr", SqlDbType.Int).Value = int.Parse(txt_input3.Text.ToString());
                        cmd.Parameters.AddWithValue("@manufactDate", SqlDbType.DateTime).Value = DateTime.Parse(dateTimePicker1.Text.ToString());
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }

                using (SqlConnection con = new SqlConnection(conS))
                {
                    using (SqlCommand cmd = new SqlCommand("add_Storage", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@idContrat", SqlDbType.VarChar).Value = int.Parse(txt_input1.Text.ToString());
                        cmd.Parameters.AddWithValue("@serialNmbr", SqlDbType.VarChar).Value = int.Parse(txt_input3.Text.ToString());
                        cmd.Parameters.AddWithValue("@dlvryPrice", SqlDbType.VarChar).Value = txt_input2.Text.ToString();
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Data Error!", "Error!",
               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Close();
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
