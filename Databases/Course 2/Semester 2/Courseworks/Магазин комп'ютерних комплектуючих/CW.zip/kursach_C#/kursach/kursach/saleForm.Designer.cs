﻿namespace kursach
{
    partial class saleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btn_AddSale = new System.Windows.Forms.Button();
            this.btn_deleteSale = new System.Windows.Forms.Button();
            this.jSaleDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewSaleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kursachDataSet = new kursach.kursachDataSet();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jSaleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btn_AddDlvr = new System.Windows.Forms.Button();
            this.btn_deleteDlvr = new System.Windows.Forms.Button();
            this.dlvryDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewAdressBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dlvryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btn_deleteSlsInfo = new System.Windows.Forms.Button();
            this.btn_refresh = new System.Windows.Forms.Button();
            this.btn_exit = new System.Windows.Forms.Button();
            this.rSaleDetailDataGridView = new System.Windows.Forms.DataGridView();
            this.idSaleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serialNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sellPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r46BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rSaleDetailBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.jSaleTableAdapter = new kursach.kursachDataSetTableAdapters.JSaleTableAdapter();
            this.tableAdapterManager = new kursach.kursachDataSetTableAdapters.TableAdapterManager();
            this.dlvryTableAdapter = new kursach.kursachDataSetTableAdapters.DlvryTableAdapter();
            this.rSaleDetailTableAdapter = new kursach.kursachDataSetTableAdapters.RSaleDetailTableAdapter();
            this.view_SaleTableAdapter = new kursach.kursachDataSetTableAdapters.view_SaleTableAdapter();
            this.view_AdressTableAdapter = new kursach.kursachDataSetTableAdapters.view_AdressTableAdapter();
            this.btn_SaleChek = new System.Windows.Forms.Button();
            this.btn_AddSaleInfo = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.jSaleDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewSaleBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jSaleBindingSource)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dlvryDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewAdressBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dlvryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rSaleDetailDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r46BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rSaleDetailBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(679, 204);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.Controls.Add(this.btn_AddSale);
            this.tabPage1.Controls.Add(this.btn_deleteSale);
            this.tabPage1.Controls.Add(this.jSaleDataGridView);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(671, 178);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Sales";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btn_AddSale
            // 
            this.btn_AddSale.Location = new System.Drawing.Point(109, 136);
            this.btn_AddSale.Name = "btn_AddSale";
            this.btn_AddSale.Size = new System.Drawing.Size(100, 35);
            this.btn_AddSale.TabIndex = 2;
            this.btn_AddSale.Text = "Add new";
            this.btn_AddSale.UseVisualStyleBackColor = true;
            this.btn_AddSale.Click += new System.EventHandler(this.btn_AddSale_Click);
            // 
            // btn_deleteSale
            // 
            this.btn_deleteSale.Location = new System.Drawing.Point(3, 136);
            this.btn_deleteSale.Name = "btn_deleteSale";
            this.btn_deleteSale.Size = new System.Drawing.Size(100, 35);
            this.btn_deleteSale.TabIndex = 1;
            this.btn_deleteSale.Text = "Delete";
            this.btn_deleteSale.UseVisualStyleBackColor = true;
            this.btn_deleteSale.Click += new System.EventHandler(this.btn_deleteSale_Click);
            // 
            // jSaleDataGridView
            // 
            this.jSaleDataGridView.AutoGenerateColumns = false;
            this.jSaleDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.jSaleDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.jSaleDataGridView.DataSource = this.jSaleBindingSource;
            this.jSaleDataGridView.Location = new System.Drawing.Point(0, 0);
            this.jSaleDataGridView.Name = "jSaleDataGridView";
            this.jSaleDataGridView.Size = new System.Drawing.Size(668, 130);
            this.jSaleDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "idSale";
            this.dataGridViewTextBoxColumn1.HeaderText = "idSale";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "idBuyer";
            this.dataGridViewTextBoxColumn2.DataSource = this.viewSaleBindingSource;
            this.dataGridViewTextBoxColumn2.DisplayMember = "Buyer";
            this.dataGridViewTextBoxColumn2.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn2.HeaderText = "idBuyer";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn2.ValueMember = "idSale";
            // 
            // viewSaleBindingSource
            // 
            this.viewSaleBindingSource.DataMember = "view_Sale";
            this.viewSaleBindingSource.DataSource = this.kursachDataSet;
            // 
            // kursachDataSet
            // 
            this.kursachDataSet.DataSetName = "kursachDataSet";
            this.kursachDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "idDlvry";
            this.dataGridViewTextBoxColumn3.HeaderText = "idDlvry";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "idStaff";
            this.dataGridViewTextBoxColumn4.DataSource = this.viewSaleBindingSource;
            this.dataGridViewTextBoxColumn4.DisplayMember = "Seller";
            this.dataGridViewTextBoxColumn4.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn4.HeaderText = "idStaff";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn4.ValueMember = "idSale";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "saleDate";
            this.dataGridViewTextBoxColumn5.HeaderText = "saleDate";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // jSaleBindingSource
            // 
            this.jSaleBindingSource.DataMember = "JSale";
            this.jSaleBindingSource.DataSource = this.kursachDataSet;
            // 
            // tabPage3
            // 
            this.tabPage3.AutoScroll = true;
            this.tabPage3.Controls.Add(this.btn_AddDlvr);
            this.tabPage3.Controls.Add(this.btn_deleteDlvr);
            this.tabPage3.Controls.Add(this.dlvryDataGridView);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(671, 178);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Delivery";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btn_AddDlvr
            // 
            this.btn_AddDlvr.Location = new System.Drawing.Point(109, 137);
            this.btn_AddDlvr.Name = "btn_AddDlvr";
            this.btn_AddDlvr.Size = new System.Drawing.Size(100, 35);
            this.btn_AddDlvr.TabIndex = 2;
            this.btn_AddDlvr.Text = "Add new";
            this.btn_AddDlvr.UseVisualStyleBackColor = true;
            this.btn_AddDlvr.Click += new System.EventHandler(this.btn_AddDlvr_Click);
            // 
            // btn_deleteDlvr
            // 
            this.btn_deleteDlvr.Location = new System.Drawing.Point(3, 137);
            this.btn_deleteDlvr.Name = "btn_deleteDlvr";
            this.btn_deleteDlvr.Size = new System.Drawing.Size(100, 35);
            this.btn_deleteDlvr.TabIndex = 1;
            this.btn_deleteDlvr.Text = "Delete";
            this.btn_deleteDlvr.UseVisualStyleBackColor = true;
            this.btn_deleteDlvr.Click += new System.EventHandler(this.btn_deleteDlvr_Click);
            // 
            // dlvryDataGridView
            // 
            this.dlvryDataGridView.AutoGenerateColumns = false;
            this.dlvryDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dlvryDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11});
            this.dlvryDataGridView.DataSource = this.dlvryBindingSource;
            this.dlvryDataGridView.Location = new System.Drawing.Point(0, 0);
            this.dlvryDataGridView.Name = "dlvryDataGridView";
            this.dlvryDataGridView.Size = new System.Drawing.Size(576, 131);
            this.dlvryDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "idDlvry";
            this.dataGridViewTextBoxColumn9.HeaderText = "idDlvry";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "idBuyer";
            this.dataGridViewTextBoxColumn10.HeaderText = "idBuyer";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "idAdress";
            this.dataGridViewTextBoxColumn11.DataSource = this.viewAdressBindingSource;
            this.dataGridViewTextBoxColumn11.DisplayMember = "Adress";
            this.dataGridViewTextBoxColumn11.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn11.HeaderText = "idAdress";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn11.ValueMember = "idAdress";
            // 
            // viewAdressBindingSource
            // 
            this.viewAdressBindingSource.DataMember = "view_Adress";
            this.viewAdressBindingSource.DataSource = this.kursachDataSet;
            // 
            // dlvryBindingSource
            // 
            this.dlvryBindingSource.DataMember = "Dlvry";
            this.dlvryBindingSource.DataSource = this.kursachDataSet;
            // 
            // btn_deleteSlsInfo
            // 
            this.btn_deleteSlsInfo.Location = new System.Drawing.Point(591, 339);
            this.btn_deleteSlsInfo.Name = "btn_deleteSlsInfo";
            this.btn_deleteSlsInfo.Size = new System.Drawing.Size(100, 35);
            this.btn_deleteSlsInfo.TabIndex = 1;
            this.btn_deleteSlsInfo.Text = "Delete Sale info";
            this.btn_deleteSlsInfo.UseVisualStyleBackColor = true;
            this.btn_deleteSlsInfo.Click += new System.EventHandler(this.btn_deleteSlsInfo_Click);
            // 
            // btn_refresh
            // 
            this.btn_refresh.Location = new System.Drawing.Point(12, 388);
            this.btn_refresh.Name = "btn_refresh";
            this.btn_refresh.Size = new System.Drawing.Size(100, 35);
            this.btn_refresh.TabIndex = 1;
            this.btn_refresh.Text = "Refresh";
            this.btn_refresh.UseVisualStyleBackColor = true;
            this.btn_refresh.Click += new System.EventHandler(this.btn_refresh_Click);
            // 
            // btn_exit
            // 
            this.btn_exit.Location = new System.Drawing.Point(591, 388);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(100, 35);
            this.btn_exit.TabIndex = 2;
            this.btn_exit.Text = "Exit";
            this.btn_exit.UseVisualStyleBackColor = true;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // rSaleDetailDataGridView
            // 
            this.rSaleDetailDataGridView.AutoGenerateColumns = false;
            this.rSaleDetailDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rSaleDetailDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idSaleDataGridViewTextBoxColumn,
            this.serialNumberDataGridViewTextBoxColumn,
            this.sellPriceDataGridViewTextBoxColumn});
            this.rSaleDetailDataGridView.DataSource = this.r46BindingSource;
            this.rSaleDetailDataGridView.Location = new System.Drawing.Point(12, 257);
            this.rSaleDetailDataGridView.Name = "rSaleDetailDataGridView";
            this.rSaleDetailDataGridView.Size = new System.Drawing.Size(573, 117);
            this.rSaleDetailDataGridView.TabIndex = 3;
            // 
            // idSaleDataGridViewTextBoxColumn
            // 
            this.idSaleDataGridViewTextBoxColumn.DataPropertyName = "idSale";
            this.idSaleDataGridViewTextBoxColumn.HeaderText = "idSale";
            this.idSaleDataGridViewTextBoxColumn.Name = "idSaleDataGridViewTextBoxColumn";
            // 
            // serialNumberDataGridViewTextBoxColumn
            // 
            this.serialNumberDataGridViewTextBoxColumn.DataPropertyName = "serialNumber";
            this.serialNumberDataGridViewTextBoxColumn.HeaderText = "serialNumber";
            this.serialNumberDataGridViewTextBoxColumn.Name = "serialNumberDataGridViewTextBoxColumn";
            // 
            // sellPriceDataGridViewTextBoxColumn
            // 
            this.sellPriceDataGridViewTextBoxColumn.DataPropertyName = "sellPrice";
            this.sellPriceDataGridViewTextBoxColumn.HeaderText = "sellPrice";
            this.sellPriceDataGridViewTextBoxColumn.Name = "sellPriceDataGridViewTextBoxColumn";
            // 
            // r46BindingSource
            // 
            this.r46BindingSource.DataMember = "R_46";
            this.r46BindingSource.DataSource = this.jSaleBindingSource;
            // 
            // rSaleDetailBindingSource
            // 
            this.rSaleDetailBindingSource.DataMember = "RSaleDetail";
            this.rSaleDetailBindingSource.DataSource = this.kursachDataSet;
            // 
            // jSaleTableAdapter
            // 
            this.jSaleTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AllowableChrtrcsTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CGenderTableAdapter = null;
            this.tableAdapterManager.CharacteristicsTableAdapter = null;
            this.tableAdapterManager.CManufacturerTableAdapter = null;
            this.tableAdapterManager.COperatorNumberTableAdapter = null;
            this.tableAdapterManager.COperatorTableAdapter = null;
            this.tableAdapterManager.CRefundTypeTableAdapter = null;
            this.tableAdapterManager.CStrtTypeTableAdapter = null;
            this.tableAdapterManager.CUnitTableAdapter = null;
            this.tableAdapterManager.DlvryTableAdapter = this.dlvryTableAdapter;
            this.tableAdapterManager.EntityTableAdapter = null;
            this.tableAdapterManager.IndividualTableAdapter = null;
            this.tableAdapterManager.JRefundTableAdapter = null;
            this.tableAdapterManager.JSaleTableAdapter = this.jSaleTableAdapter;
            this.tableAdapterManager.LandlinePhoneTableAdapter = null;
            this.tableAdapterManager.MobilePhoneTableAdapter = null;
            this.tableAdapterManager.PrdctInstanceTableAdapter = null;
            this.tableAdapterManager.RAdressTableAdapter = null;
            this.tableAdapterManager.RBuyerTableAdapter = null;
            this.tableAdapterManager.RCntcInfoTableAdapter = null;
            this.tableAdapterManager.RContractTableAdapter = null;
            this.tableAdapterManager.RPhoneTableAdapter = null;
            this.tableAdapterManager.RPrdctInfoTableAdapter = null;
            this.tableAdapterManager.RProviderTableAdapter = null;
            this.tableAdapterManager.RSaleDetailTableAdapter = this.rSaleDetailTableAdapter;
            this.tableAdapterManager.SCountryTableAdapter = null;
            this.tableAdapterManager.SLocalityTableAdapter = null;
            this.tableAdapterManager.SModelTableAdapter = null;
            this.tableAdapterManager.SParameterTableAdapter = null;
            this.tableAdapterManager.SRegionTableAdapter = null;
            this.tableAdapterManager.SStaffTableAdapter = null;
            this.tableAdapterManager.SStreetTableAdapter = null;
            this.tableAdapterManager.StorageTableAdapter = null;
            this.tableAdapterManager.STrdGrpTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = kursach.kursachDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // dlvryTableAdapter
            // 
            this.dlvryTableAdapter.ClearBeforeFill = true;
            // 
            // rSaleDetailTableAdapter
            // 
            this.rSaleDetailTableAdapter.ClearBeforeFill = true;
            // 
            // view_SaleTableAdapter
            // 
            this.view_SaleTableAdapter.ClearBeforeFill = true;
            // 
            // view_AdressTableAdapter
            // 
            this.view_AdressTableAdapter.ClearBeforeFill = true;
            // 
            // btn_SaleChek
            // 
            this.btn_SaleChek.Location = new System.Drawing.Point(591, 257);
            this.btn_SaleChek.Name = "btn_SaleChek";
            this.btn_SaleChek.Size = new System.Drawing.Size(100, 35);
            this.btn_SaleChek.TabIndex = 4;
            this.btn_SaleChek.Text = "Sale Check";
            this.btn_SaleChek.UseVisualStyleBackColor = true;
            this.btn_SaleChek.Click += new System.EventHandler(this.btn_SaleChek_Click);
            // 
            // btn_AddSaleInfo
            // 
            this.btn_AddSaleInfo.Location = new System.Drawing.Point(591, 298);
            this.btn_AddSaleInfo.Name = "btn_AddSaleInfo";
            this.btn_AddSaleInfo.Size = new System.Drawing.Size(100, 35);
            this.btn_AddSaleInfo.TabIndex = 5;
            this.btn_AddSaleInfo.Text = "Add Info";
            this.btn_AddSaleInfo.UseVisualStyleBackColor = true;
            this.btn_AddSaleInfo.Click += new System.EventHandler(this.btn_AddSaleInfo_Click);
            // 
            // saleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(703, 435);
            this.Controls.Add(this.btn_AddSaleInfo);
            this.Controls.Add(this.btn_SaleChek);
            this.Controls.Add(this.rSaleDetailDataGridView);
            this.Controls.Add(this.btn_deleteSlsInfo);
            this.Controls.Add(this.btn_exit);
            this.Controls.Add(this.btn_refresh);
            this.Controls.Add(this.tabControl1);
            this.Name = "saleForm";
            this.Text = "saleForm";
            this.Load += new System.EventHandler(this.saleForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.jSaleDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewSaleBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jSaleBindingSource)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dlvryDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewAdressBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dlvryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rSaleDetailDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r46BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rSaleDetailBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage3;
        private kursachDataSet kursachDataSet;
        private System.Windows.Forms.BindingSource jSaleBindingSource;
        private kursachDataSetTableAdapters.JSaleTableAdapter jSaleTableAdapter;
        private kursachDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView jSaleDataGridView;
        private kursachDataSetTableAdapters.RSaleDetailTableAdapter rSaleDetailTableAdapter;
        private System.Windows.Forms.BindingSource rSaleDetailBindingSource;
        private kursachDataSetTableAdapters.DlvryTableAdapter dlvryTableAdapter;
        private System.Windows.Forms.BindingSource dlvryBindingSource;
        private System.Windows.Forms.DataGridView dlvryDataGridView;
        private System.Windows.Forms.Button btn_deleteSale;
        private System.Windows.Forms.Button btn_deleteSlsInfo;
        private System.Windows.Forms.Button btn_deleteDlvr;
        private System.Windows.Forms.Button btn_refresh;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.DataGridView rSaleDetailDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn idSaleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serialNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sellPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource r46BindingSource;
        private System.Windows.Forms.BindingSource viewSaleBindingSource;
        private kursachDataSetTableAdapters.view_SaleTableAdapter view_SaleTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.BindingSource viewAdressBindingSource;
        private kursachDataSetTableAdapters.view_AdressTableAdapter view_AdressTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.Button btn_SaleChek;
        private System.Windows.Forms.Button btn_AddSale;
        private System.Windows.Forms.Button btn_AddDlvr;
        private System.Windows.Forms.Button btn_AddSaleInfo;
    }
}