﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class add_NewSaleInfoForm : Form
    {
        public add_NewSaleInfoForm()
        {
            InitializeComponent();
        }

        private void add_NewSaleInfoForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kursachDataSet.Storage' table. You can move, or remove it, as needed.
            this.storageTableAdapter.Fill(this.kursachDataSet.Storage);
            // TODO: This line of code loads data into the 'kursachDataSet.view_Sale' table. You can move, or remove it, as needed.
            // TODO: This line of code loads data into the 'kursachDataSet.Storage' table. You can move, or remove it, as needed.
            this.storageTableAdapter.Fill(this.kursachDataSet.Storage);

        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            string conS = "Data Source=ADMIN;Initial Catalog=kursach;Integrated Security=True";
            try
            {
                using (SqlConnection con = new SqlConnection(conS))
                {
                    using (SqlCommand cmd = new SqlCommand("add_SaleDetail", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@id", SqlDbType.Int).Value = txt_input1.Text.ToString();
                        cmd.Parameters.AddWithValue("@serialNmbr", SqlDbType.Int).Value = comboBox1.SelectedValue.ToString();
                        cmd.Parameters.AddWithValue("@sellPrice", SqlDbType.VarChar).Value = txt_input2.Text.ToString();
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Data Error!", "Error!",
               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Close();
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
