﻿namespace kursach
{
    partial class add_NewStreetForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.kursachDataSet = new kursach.kursachDataSet();
            this.sRegionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sRegionTableAdapter = new kursach.kursachDataSetTableAdapters.SRegionTableAdapter();
            this.sCountryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sCountryTableAdapter = new kursach.kursachDataSetTableAdapters.SCountryTableAdapter();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.r49BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.r19BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sLocalityTableAdapter = new kursach.kursachDataSetTableAdapters.SLocalityTableAdapter();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cStrtTypeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cStrtTypeTableAdapter = new kursach.kursachDataSetTableAdapters.CStrtTypeTableAdapter();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_input = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sRegionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sCountryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r49BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r19BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cStrtTypeBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Save
            // 
            this.btn_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Save.Location = new System.Drawing.Point(12, 222);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(100, 35);
            this.btn_Save.TabIndex = 0;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // btn_cancel
            // 
            this.btn_cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_cancel.Location = new System.Drawing.Point(210, 222);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(100, 35);
            this.btn_cancel.TabIndex = 1;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(157, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Choose Region";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Choose country";
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.sCountryBindingSource;
            this.comboBox1.DisplayMember = "countryName";
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(15, 29);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 4;
            this.comboBox1.ValueMember = "idCountry";
            // 
            // kursachDataSet
            // 
            this.kursachDataSet.DataSetName = "kursachDataSet";
            this.kursachDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sRegionBindingSource
            // 
            this.sRegionBindingSource.DataMember = "SRegion";
            this.sRegionBindingSource.DataSource = this.kursachDataSet;
            // 
            // sRegionTableAdapter
            // 
            this.sRegionTableAdapter.ClearBeforeFill = true;
            // 
            // sCountryBindingSource
            // 
            this.sCountryBindingSource.DataMember = "SCountry";
            this.sCountryBindingSource.DataSource = this.kursachDataSet;
            // 
            // sCountryTableAdapter
            // 
            this.sCountryTableAdapter.ClearBeforeFill = true;
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.r49BindingSource;
            this.comboBox2.DisplayMember = "regionName";
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(160, 29);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 24);
            this.comboBox2.TabIndex = 5;
            this.comboBox2.ValueMember = "idRegion";
            // 
            // r49BindingSource
            // 
            this.r49BindingSource.DataMember = "R_49";
            this.r49BindingSource.DataSource = this.sCountryBindingSource;
            // 
            // comboBox3
            // 
            this.comboBox3.DataSource = this.r19BindingSource;
            this.comboBox3.DisplayMember = "localityName";
            this.comboBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(15, 84);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 24);
            this.comboBox3.TabIndex = 7;
            this.comboBox3.ValueMember = "idLocality";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(12, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Choose locality";
            // 
            // r19BindingSource
            // 
            this.r19BindingSource.DataMember = "R_19";
            this.r19BindingSource.DataSource = this.r49BindingSource;
            // 
            // sLocalityTableAdapter
            // 
            this.sLocalityTableAdapter.ClearBeforeFill = true;
            // 
            // comboBox4
            // 
            this.comboBox4.DataSource = this.cStrtTypeBindingSource;
            this.comboBox4.DisplayMember = "typeName";
            this.comboBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(160, 84);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 24);
            this.comboBox4.TabIndex = 9;
            this.comboBox4.ValueMember = "idType";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(157, 64);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "Choose Street type";
            // 
            // cStrtTypeBindingSource
            // 
            this.cStrtTypeBindingSource.DataMember = "CStrtType";
            this.cStrtTypeBindingSource.DataSource = this.kursachDataSet;
            // 
            // cStrtTypeTableAdapter
            // 
            this.cStrtTypeTableAdapter.ClearBeforeFill = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(12, 121);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(118, 17);
            this.label5.TabIndex = 10;
            this.label5.Text = "Input street name";
            // 
            // txt_input
            // 
            this.txt_input.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txt_input.Location = new System.Drawing.Point(15, 153);
            this.txt_input.Name = "txt_input";
            this.txt_input.Size = new System.Drawing.Size(100, 23);
            this.txt_input.TabIndex = 11;
            // 
            // add_NewStreetForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(322, 269);
            this.Controls.Add(this.txt_input);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_Save);
            this.Name = "add_NewStreetForm";
            this.Text = "add_NewStreetForm";
            this.Load += new System.EventHandler(this.add_NewStreetForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sRegionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sCountryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r49BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r19BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cStrtTypeBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private kursachDataSet kursachDataSet;
        private System.Windows.Forms.BindingSource sRegionBindingSource;
        private kursachDataSetTableAdapters.SRegionTableAdapter sRegionTableAdapter;
        private System.Windows.Forms.BindingSource sCountryBindingSource;
        private kursachDataSetTableAdapters.SCountryTableAdapter sCountryTableAdapter;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.BindingSource r49BindingSource;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.BindingSource r19BindingSource;
        private kursachDataSetTableAdapters.SLocalityTableAdapter sLocalityTableAdapter;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.BindingSource cStrtTypeBindingSource;
        private kursachDataSetTableAdapters.CStrtTypeTableAdapter cStrtTypeTableAdapter;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_input;
    }
}