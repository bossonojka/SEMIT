﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class add_NewModel : Form
    {
        public add_NewModel()
        {
            InitializeComponent();
        }

        private void add_NewModel_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kursachDataSet.CManufacturer' table. You can move, or remove it, as needed.
            this.cManufacturerTableAdapter.Fill(this.kursachDataSet.CManufacturer);

        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            string conS = "Data Source=ADMIN;Initial Catalog=kursach;Integrated Security=True";
            try
            {
                using (SqlConnection con = new SqlConnection(conS))
                {
                    using (SqlCommand cmd = new SqlCommand("add_Model", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@idManufac", SqlDbType.Int).Value = int.Parse(comboBox1.SelectedValue.ToString());
                        cmd.Parameters.AddWithValue("@name", SqlDbType.VarChar).Value = txt_input1.Text.ToString();
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Data Error!", "Error!",
               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Close();
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
