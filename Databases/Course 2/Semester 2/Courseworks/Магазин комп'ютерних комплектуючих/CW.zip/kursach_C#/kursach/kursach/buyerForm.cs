﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class buyerForm : Form
    {
        public buyerForm()
        {
            InitializeComponent();
        }

        private void buyerForm_Load(object sender, EventArgs e)
        {
            
            this.view_AdressTableAdapter.Fill(this.kursachDataSet.view_Adress);
            
            this.view_GenderTableAdapter.Fill(this.kursachDataSet.view_Gender);
            
            this.rBuyerTableAdapter.Fill(this.kursachDataSet.RBuyer);

        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_refresh_Click(object sender, EventArgs e)
        {
            this.view_AdressTableAdapter.Fill(this.kursachDataSet.view_Adress);
            this.view_GenderTableAdapter.Fill(this.kursachDataSet.view_Gender);
            this.rBuyerTableAdapter.Fill(this.kursachDataSet.RBuyer);
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            foreach(DataGridViewRow row in rBuyerDataGridView.SelectedRows)
            {
                rBuyerDataGridView.Rows.Remove(row);
            }
        }

        private void btn_AddBuyer_Click(object sender, EventArgs e)
        {
            add_NewBuyerForm frm = new add_NewBuyerForm();
            frm.Show();
        }
    }
}
