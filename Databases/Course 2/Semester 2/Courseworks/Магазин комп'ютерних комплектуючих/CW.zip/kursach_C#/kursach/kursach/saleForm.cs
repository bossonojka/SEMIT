﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class saleForm : Form
    {
        public saleForm()
        {
            InitializeComponent();
        }

        private void jSaleBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.jSaleBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.kursachDataSet);

        }

        private void saleForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kursachDataSet.view_Adress' table. You can move, or remove it, as needed.
            this.view_AdressTableAdapter.Fill(this.kursachDataSet.view_Adress);
            // TODO: This line of code loads data into the 'kursachDataSet.view_Sale' table. You can move, or remove it, as needed.
            this.view_SaleTableAdapter.Fill(this.kursachDataSet.view_Sale);
            // TODO: This line of code loads data into the 'kursachDataSet.Dlvry' table. You can move, or remove it, as needed.
            this.dlvryTableAdapter.Fill(this.kursachDataSet.Dlvry);
            // TODO: This line of code loads data into the 'kursachDataSet.RSaleDetail' table. You can move, or remove it, as needed.
            this.rSaleDetailTableAdapter.Fill(this.kursachDataSet.RSaleDetail);
            // TODO: This line of code loads data into the 'kursachDataSet.JSale' table. You can move, or remove it, as needed.
            this.jSaleTableAdapter.Fill(this.kursachDataSet.JSale);

        }

        private void btn_deleteSale_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in jSaleDataGridView.SelectedRows)
            {
                jSaleDataGridView.Rows.Remove(row);
            }
        }

        private void btn_deleteSlsInfo_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in rSaleDetailDataGridView.SelectedRows)
            {
                rSaleDetailDataGridView.Rows.Remove(row);
            }
        }

        private void btn_deleteDlvr_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dlvryDataGridView.SelectedRows)
            {
                dlvryDataGridView.Rows.Remove(row);
            }
        }

        private void btn_refresh_Click(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kursachDataSet.view_Adress' table. You can move, or remove it, as needed.
            this.view_AdressTableAdapter.Fill(this.kursachDataSet.view_Adress);
            // TODO: This line of code loads data into the 'kursachDataSet.view_Sale' table. You can move, or remove it, as needed.
            this.view_SaleTableAdapter.Fill(this.kursachDataSet.view_Sale);
            // TODO: This line of code loads data into the 'kursachDataSet.Dlvry' table. You can move, or remove it, as needed.
            this.dlvryTableAdapter.Fill(this.kursachDataSet.Dlvry);
            // TODO: This line of code loads data into the 'kursachDataSet.RSaleDetail' table. You can move, or remove it, as needed.
            this.rSaleDetailTableAdapter.Fill(this.kursachDataSet.RSaleDetail);
            // TODO: This line of code loads data into the 'kursachDataSet.JSale' table. You can move, or remove it, as needed.
            this.jSaleTableAdapter.Fill(this.kursachDataSet.JSale);
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_SaleChek_Click(object sender, EventArgs e)
        {
            reportSaleCheckForm frm = new reportSaleCheckForm();
            if (jSaleDataGridView.SelectedCells.Count > 0)
            {
                frm.setContent(jSaleDataGridView.SelectedCells[0].Value.ToString());
            }
            frm.Show();
        }

        private void btn_AddSale_Click(object sender, EventArgs e)
        {
            add_NewSaleForm frm = new add_NewSaleForm();
            frm.Show();
        }

        private void btn_AddDlvr_Click(object sender, EventArgs e)
        {

        }

        private void btn_AddSaleInfo_Click(object sender, EventArgs e)
        {
            add_NewSaleInfoForm frm = new add_NewSaleInfoForm();
            frm.Show();
        }
    }
}
