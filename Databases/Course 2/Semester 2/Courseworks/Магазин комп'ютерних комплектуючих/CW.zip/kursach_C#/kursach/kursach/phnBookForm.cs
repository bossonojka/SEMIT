﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class phnBookForm : Form
    {
        public phnBookForm()
        {
            InitializeComponent();
        }

        private void phnBookForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kursachDataSet.view_Locality' table. You can move, or remove it, as needed.
            this.view_LocalityTableAdapter.Fill(this.kursachDataSet.view_Locality);
            // TODO: This line of code loads data into the 'kursachDataSet.LandlinePhone' table. You can move, or remove it, as needed.
            this.landlinePhoneTableAdapter.Fill(this.kursachDataSet.LandlinePhone);
            // TODO: This line of code loads data into the 'kursachDataSet.RPhone' table. You can move, or remove it, as needed.
            this.rPhoneTableAdapter.Fill(this.kursachDataSet.RPhone);
            // TODO: This line of code loads data into the 'kursachDataSet.MobilePhone' table. You can move, or remove it, as needed.
            this.mobilePhoneTableAdapter.Fill(this.kursachDataSet.MobilePhone);

        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kursachDataSet.view_Locality' table. You can move, or remove it, as needed.
            this.view_LocalityTableAdapter.Fill(this.kursachDataSet.view_Locality);
            // TODO: This line of code loads data into the 'kursachDataSet.LandlinePhone' table. You can move, or remove it, as needed.
            this.landlinePhoneTableAdapter.Fill(this.kursachDataSet.LandlinePhone);
            // TODO: This line of code loads data into the 'kursachDataSet.RPhone' table. You can move, or remove it, as needed.
            this.rPhoneTableAdapter.Fill(this.kursachDataSet.RPhone);
            // TODO: This line of code loads data into the 'kursachDataSet.MobilePhone' table. You can move, or remove it, as needed.
            this.mobilePhoneTableAdapter.Fill(this.kursachDataSet.MobilePhone);
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_NewMblPhn_Click(object sender, EventArgs e)
        {
            add_NewMblPhn frm = new add_NewMblPhn();
            frm.Show();
        }

        private void btn_DltMblPhn_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in mobilePhoneDataGridView.SelectedRows)
            {
                mobilePhoneDataGridView.Rows.Remove(row);
            }
        }

        private void btn_NewLcltPhn_Click(object sender, EventArgs e)
        {
            add_NewLnldPhn frm = new add_NewLnldPhn();
            frm.Show();
        }

        private void btn_DltLcltPhn_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in landlinePhoneDataGridView.SelectedRows)
            {
                landlinePhoneDataGridView.Rows.Remove(row);
            }
        }
    }
}
