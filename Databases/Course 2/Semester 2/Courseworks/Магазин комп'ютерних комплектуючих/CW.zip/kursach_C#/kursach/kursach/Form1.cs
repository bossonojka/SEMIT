﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_help_Click(object sender, EventArgs e)
        {

        }

        private void btn_provider_Click(object sender, EventArgs e)
        {
            providerForm frm = new providerForm();
            frm.Show();
        }

        private void btn_prdctn_Click(object sender, EventArgs e)
        {
            productionForm frm = new productionForm();
            frm.Show();
        }

        private void btn_buyer_Click(object sender, EventArgs e)
        {
            buyerForm frm = new buyerForm();
            frm.Show();
        }

        private void btn_staff_Click(object sender, EventArgs e)
        {
            staffForm frm = new staffForm();
            frm.Show();
        }

        private void btn_report_Click(object sender, EventArgs e)
        {
            reportForm frm = new reportForm();
            frm.Show();
        }

        private void btn_AddressInfo_Click(object sender, EventArgs e)
        {
            addressFrom frm = new addressFrom();
            frm.Show();
        }

        private void btn_Admin_Click(object sender, EventArgs e)
        {
            administartForm frm = new administartForm();
            frm.Show();
        }

        private void btn_sale_Click(object sender, EventArgs e)
        {
            saleForm frm = new saleForm();
            frm.Show();
        }

        private void btn_Storage_Click(object sender, EventArgs e)
        {
            storageForm frm = new storageForm();
            frm.Show();
        }

        private void btn_PhnBook_Click(object sender, EventArgs e)
        {
            phnBookForm frm = new phnBookForm();
                frm.Show();
        }
    }

}
