﻿namespace kursach
{
    partial class addressFrom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tab_Country = new System.Windows.Forms.TabPage();
            this.btn_deleteCntry = new System.Windows.Forms.Button();
            this.sCountryDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sCountryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kursachDataSet = new kursach.kursachDataSet();
            this.tab_Region = new System.Windows.Forms.TabPage();
            this.btn_deleteRgn = new System.Windows.Forms.Button();
            this.sRegionDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewCountryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sRegionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tab_Locality = new System.Windows.Forms.TabPage();
            this.btn_deleteLclty = new System.Windows.Forms.Button();
            this.sLocalityDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sLocalityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tab_Street = new System.Windows.Forms.TabPage();
            this.btn_deleteStrt = new System.Windows.Forms.Button();
            this.sStreetDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewLocalityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewStreetTypeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sStreetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tab_Address = new System.Windows.Forms.TabPage();
            this.btn_deleteAddrs = new System.Windows.Forms.Button();
            this.rAdressDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adress = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewAdressBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rAdressBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.viewStreetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sCountryTableAdapter = new kursach.kursachDataSetTableAdapters.SCountryTableAdapter();
            this.tableAdapterManager = new kursach.kursachDataSetTableAdapters.TableAdapterManager();
            this.rAdressTableAdapter = new kursach.kursachDataSetTableAdapters.RAdressTableAdapter();
            this.sLocalityTableAdapter = new kursach.kursachDataSetTableAdapters.SLocalityTableAdapter();
            this.sRegionTableAdapter = new kursach.kursachDataSetTableAdapters.SRegionTableAdapter();
            this.sStreetTableAdapter = new kursach.kursachDataSetTableAdapters.SStreetTableAdapter();
            this.view_CountryTableAdapter = new kursach.kursachDataSetTableAdapters.view_CountryTableAdapter();
            this.view_StreetTableAdapter = new kursach.kursachDataSetTableAdapters.view_StreetTableAdapter();
            this.view_StreetTypeTableAdapter = new kursach.kursachDataSetTableAdapters.view_StreetTypeTableAdapter();
            this.view_LocalityTableAdapter = new kursach.kursachDataSetTableAdapters.view_LocalityTableAdapter();
            this.view_AdressTableAdapter = new kursach.kursachDataSetTableAdapters.view_AdressTableAdapter();
            this.btn_AddCntry = new System.Windows.Forms.Button();
            this.btn_AddRgn = new System.Windows.Forms.Button();
            this.btn_AddLlty = new System.Windows.Forms.Button();
            this.btn_AddStrt = new System.Windows.Forms.Button();
            this.btn_AddAdress = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tab_Country.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sCountryDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sCountryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).BeginInit();
            this.tab_Region.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sRegionDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewCountryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sRegionBindingSource)).BeginInit();
            this.tab_Locality.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sLocalityDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sLocalityBindingSource)).BeginInit();
            this.tab_Street.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sStreetDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewLocalityBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewStreetTypeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sStreetBindingSource)).BeginInit();
            this.tab_Address.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rAdressDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewAdressBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rAdressBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewStreetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tab_Country);
            this.tabControl1.Controls.Add(this.tab_Region);
            this.tabControl1.Controls.Add(this.tab_Locality);
            this.tabControl1.Controls.Add(this.tab_Street);
            this.tabControl1.Controls.Add(this.tab_Address);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(745, 233);
            this.tabControl1.TabIndex = 0;
            // 
            // tab_Country
            // 
            this.tab_Country.AutoScroll = true;
            this.tab_Country.Controls.Add(this.btn_AddCntry);
            this.tab_Country.Controls.Add(this.btn_deleteCntry);
            this.tab_Country.Controls.Add(this.sCountryDataGridView);
            this.tab_Country.Location = new System.Drawing.Point(4, 22);
            this.tab_Country.Name = "tab_Country";
            this.tab_Country.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Country.Size = new System.Drawing.Size(737, 207);
            this.tab_Country.TabIndex = 0;
            this.tab_Country.Text = "Country";
            this.tab_Country.UseVisualStyleBackColor = true;
            // 
            // btn_deleteCntry
            // 
            this.btn_deleteCntry.Location = new System.Drawing.Point(631, 6);
            this.btn_deleteCntry.Name = "btn_deleteCntry";
            this.btn_deleteCntry.Size = new System.Drawing.Size(100, 35);
            this.btn_deleteCntry.TabIndex = 1;
            this.btn_deleteCntry.Text = "Delete";
            this.btn_deleteCntry.UseVisualStyleBackColor = true;
            this.btn_deleteCntry.Click += new System.EventHandler(this.btn_deleteCntry_Click);
            // 
            // sCountryDataGridView
            // 
            this.sCountryDataGridView.AutoGenerateColumns = false;
            this.sCountryDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sCountryDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.sCountryDataGridView.DataSource = this.sCountryBindingSource;
            this.sCountryDataGridView.Location = new System.Drawing.Point(3, 3);
            this.sCountryDataGridView.Name = "sCountryDataGridView";
            this.sCountryDataGridView.Size = new System.Drawing.Size(252, 201);
            this.sCountryDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "idCountry";
            this.dataGridViewTextBoxColumn1.HeaderText = "idCountry";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "countryName";
            this.dataGridViewTextBoxColumn2.HeaderText = "countryName";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // sCountryBindingSource
            // 
            this.sCountryBindingSource.DataMember = "SCountry";
            this.sCountryBindingSource.DataSource = this.kursachDataSet;
            // 
            // kursachDataSet
            // 
            this.kursachDataSet.DataSetName = "kursachDataSet";
            this.kursachDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tab_Region
            // 
            this.tab_Region.AutoScroll = true;
            this.tab_Region.Controls.Add(this.btn_AddRgn);
            this.tab_Region.Controls.Add(this.btn_deleteRgn);
            this.tab_Region.Controls.Add(this.sRegionDataGridView);
            this.tab_Region.Location = new System.Drawing.Point(4, 22);
            this.tab_Region.Name = "tab_Region";
            this.tab_Region.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Region.Size = new System.Drawing.Size(737, 207);
            this.tab_Region.TabIndex = 1;
            this.tab_Region.Text = "Region";
            this.tab_Region.UseVisualStyleBackColor = true;
            // 
            // btn_deleteRgn
            // 
            this.btn_deleteRgn.Location = new System.Drawing.Point(631, 6);
            this.btn_deleteRgn.Name = "btn_deleteRgn";
            this.btn_deleteRgn.Size = new System.Drawing.Size(100, 35);
            this.btn_deleteRgn.TabIndex = 1;
            this.btn_deleteRgn.Text = "Delete";
            this.btn_deleteRgn.UseVisualStyleBackColor = true;
            this.btn_deleteRgn.Click += new System.EventHandler(this.btn_deleteRgn_Click);
            // 
            // sRegionDataGridView
            // 
            this.sRegionDataGridView.AutoGenerateColumns = false;
            this.sRegionDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sRegionDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.sRegionDataGridView.DataSource = this.sRegionBindingSource;
            this.sRegionDataGridView.Location = new System.Drawing.Point(3, 3);
            this.sRegionDataGridView.Name = "sRegionDataGridView";
            this.sRegionDataGridView.Size = new System.Drawing.Size(356, 201);
            this.sRegionDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "idRegion";
            this.dataGridViewTextBoxColumn3.HeaderText = "idRegion";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "idCountry";
            this.dataGridViewTextBoxColumn4.DataSource = this.viewCountryBindingSource;
            this.dataGridViewTextBoxColumn4.DisplayMember = "countryName";
            this.dataGridViewTextBoxColumn4.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn4.HeaderText = "idCountry";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn4.ValueMember = "idCountry";
            // 
            // viewCountryBindingSource
            // 
            this.viewCountryBindingSource.DataMember = "view_Country";
            this.viewCountryBindingSource.DataSource = this.kursachDataSet;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "regionName";
            this.dataGridViewTextBoxColumn5.HeaderText = "regionName";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // sRegionBindingSource
            // 
            this.sRegionBindingSource.DataMember = "SRegion";
            this.sRegionBindingSource.DataSource = this.kursachDataSet;
            // 
            // tab_Locality
            // 
            this.tab_Locality.AutoScroll = true;
            this.tab_Locality.Controls.Add(this.btn_AddLlty);
            this.tab_Locality.Controls.Add(this.btn_deleteLclty);
            this.tab_Locality.Controls.Add(this.sLocalityDataGridView);
            this.tab_Locality.Location = new System.Drawing.Point(4, 22);
            this.tab_Locality.Name = "tab_Locality";
            this.tab_Locality.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Locality.Size = new System.Drawing.Size(737, 207);
            this.tab_Locality.TabIndex = 2;
            this.tab_Locality.Text = "Locality";
            this.tab_Locality.UseVisualStyleBackColor = true;
            // 
            // btn_deleteLclty
            // 
            this.btn_deleteLclty.Location = new System.Drawing.Point(631, 6);
            this.btn_deleteLclty.Name = "btn_deleteLclty";
            this.btn_deleteLclty.Size = new System.Drawing.Size(100, 35);
            this.btn_deleteLclty.TabIndex = 1;
            this.btn_deleteLclty.Text = "Delete";
            this.btn_deleteLclty.UseVisualStyleBackColor = true;
            this.btn_deleteLclty.Click += new System.EventHandler(this.btn_deleteLclty_Click);
            // 
            // sLocalityDataGridView
            // 
            this.sLocalityDataGridView.AutoGenerateColumns = false;
            this.sLocalityDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sLocalityDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.sLocalityDataGridView.DataSource = this.sLocalityBindingSource;
            this.sLocalityDataGridView.Location = new System.Drawing.Point(3, 3);
            this.sLocalityDataGridView.Name = "sLocalityDataGridView";
            this.sLocalityDataGridView.Size = new System.Drawing.Size(346, 201);
            this.sLocalityDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "idLocality";
            this.dataGridViewTextBoxColumn6.HeaderText = "idLocality";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "idRegion";
            this.dataGridViewTextBoxColumn7.HeaderText = "idRegion";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "localityName";
            this.dataGridViewTextBoxColumn8.HeaderText = "localityName";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // sLocalityBindingSource
            // 
            this.sLocalityBindingSource.DataMember = "SLocality";
            this.sLocalityBindingSource.DataSource = this.kursachDataSet;
            // 
            // tab_Street
            // 
            this.tab_Street.AutoScroll = true;
            this.tab_Street.Controls.Add(this.btn_AddStrt);
            this.tab_Street.Controls.Add(this.btn_deleteStrt);
            this.tab_Street.Controls.Add(this.sStreetDataGridView);
            this.tab_Street.Location = new System.Drawing.Point(4, 22);
            this.tab_Street.Name = "tab_Street";
            this.tab_Street.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Street.Size = new System.Drawing.Size(737, 207);
            this.tab_Street.TabIndex = 3;
            this.tab_Street.Text = "Street";
            this.tab_Street.UseVisualStyleBackColor = true;
            // 
            // btn_deleteStrt
            // 
            this.btn_deleteStrt.Location = new System.Drawing.Point(631, 6);
            this.btn_deleteStrt.Name = "btn_deleteStrt";
            this.btn_deleteStrt.Size = new System.Drawing.Size(100, 35);
            this.btn_deleteStrt.TabIndex = 1;
            this.btn_deleteStrt.Text = "Delete";
            this.btn_deleteStrt.UseVisualStyleBackColor = true;
            this.btn_deleteStrt.Click += new System.EventHandler(this.btn_deleteStrt_Click);
            // 
            // sStreetDataGridView
            // 
            this.sStreetDataGridView.AutoGenerateColumns = false;
            this.sStreetDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sStreetDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn11});
            this.sStreetDataGridView.DataSource = this.sStreetBindingSource;
            this.sStreetDataGridView.Location = new System.Drawing.Point(3, 3);
            this.sStreetDataGridView.Name = "sStreetDataGridView";
            this.sStreetDataGridView.Size = new System.Drawing.Size(445, 201);
            this.sStreetDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "idStreet";
            this.dataGridViewTextBoxColumn9.HeaderText = "idStreet";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "idLocality";
            this.dataGridViewTextBoxColumn10.DataSource = this.viewLocalityBindingSource;
            this.dataGridViewTextBoxColumn10.DisplayMember = "localityName";
            this.dataGridViewTextBoxColumn10.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn10.HeaderText = "idLocality";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn10.ValueMember = "idLocality";
            // 
            // viewLocalityBindingSource
            // 
            this.viewLocalityBindingSource.DataMember = "view_Locality";
            this.viewLocalityBindingSource.DataSource = this.kursachDataSet;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "streetName";
            this.dataGridViewTextBoxColumn12.HeaderText = "streetName";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "idType";
            this.dataGridViewTextBoxColumn11.DataSource = this.viewStreetTypeBindingSource;
            this.dataGridViewTextBoxColumn11.DisplayMember = "typeName";
            this.dataGridViewTextBoxColumn11.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn11.HeaderText = "idType";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn11.ValueMember = "idType";
            // 
            // viewStreetTypeBindingSource
            // 
            this.viewStreetTypeBindingSource.DataMember = "view_StreetType";
            this.viewStreetTypeBindingSource.DataSource = this.kursachDataSet;
            // 
            // sStreetBindingSource
            // 
            this.sStreetBindingSource.DataMember = "SStreet";
            this.sStreetBindingSource.DataSource = this.kursachDataSet;
            // 
            // tab_Address
            // 
            this.tab_Address.AutoScroll = true;
            this.tab_Address.Controls.Add(this.btn_AddAdress);
            this.tab_Address.Controls.Add(this.btn_deleteAddrs);
            this.tab_Address.Controls.Add(this.rAdressDataGridView);
            this.tab_Address.Location = new System.Drawing.Point(4, 22);
            this.tab_Address.Name = "tab_Address";
            this.tab_Address.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Address.Size = new System.Drawing.Size(737, 207);
            this.tab_Address.TabIndex = 4;
            this.tab_Address.Text = "Adress";
            this.tab_Address.UseVisualStyleBackColor = true;
            // 
            // btn_deleteAddrs
            // 
            this.btn_deleteAddrs.Location = new System.Drawing.Point(631, 6);
            this.btn_deleteAddrs.Name = "btn_deleteAddrs";
            this.btn_deleteAddrs.Size = new System.Drawing.Size(100, 35);
            this.btn_deleteAddrs.TabIndex = 1;
            this.btn_deleteAddrs.Text = "Delete";
            this.btn_deleteAddrs.UseVisualStyleBackColor = true;
            this.btn_deleteAddrs.Click += new System.EventHandler(this.btn_deleteAddrs_Click);
            // 
            // rAdressDataGridView
            // 
            this.rAdressDataGridView.AutoGenerateColumns = false;
            this.rAdressDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rAdressDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn13,
            this.adress,
            this.dataGridViewTextBoxColumn15});
            this.rAdressDataGridView.DataSource = this.rAdressBindingSource;
            this.rAdressDataGridView.Location = new System.Drawing.Point(3, 3);
            this.rAdressDataGridView.Name = "rAdressDataGridView";
            this.rAdressDataGridView.Size = new System.Drawing.Size(622, 201);
            this.rAdressDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "idAdress";
            this.dataGridViewTextBoxColumn13.HeaderText = "idAdress";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // adress
            // 
            this.adress.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.adress.DataPropertyName = "idAdress";
            this.adress.DataSource = this.viewAdressBindingSource;
            this.adress.DisplayMember = "Adress";
            this.adress.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.adress.HeaderText = "Adress";
            this.adress.Name = "adress";
            this.adress.ValueMember = "idAdress";
            this.adress.Width = 379;
            // 
            // viewAdressBindingSource
            // 
            this.viewAdressBindingSource.DataMember = "view_Adress";
            this.viewAdressBindingSource.DataSource = this.kursachDataSet;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "houseNmbr";
            this.dataGridViewTextBoxColumn15.HeaderText = "houseNmbr";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // rAdressBindingSource
            // 
            this.rAdressBindingSource.DataMember = "RAdress";
            this.rAdressBindingSource.DataSource = this.kursachDataSet;
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.Location = new System.Drawing.Point(13, 362);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(100, 35);
            this.btn_Refresh.TabIndex = 1;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = true;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Location = new System.Drawing.Point(658, 362);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(100, 35);
            this.btn_Exit.TabIndex = 2;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // viewStreetBindingSource
            // 
            this.viewStreetBindingSource.DataMember = "view_Street";
            this.viewStreetBindingSource.DataSource = this.kursachDataSet;
            // 
            // sCountryTableAdapter
            // 
            this.sCountryTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AllowableChrtrcsTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CGenderTableAdapter = null;
            this.tableAdapterManager.CharacteristicsTableAdapter = null;
            this.tableAdapterManager.CManufacturerTableAdapter = null;
            this.tableAdapterManager.COperatorNumberTableAdapter = null;
            this.tableAdapterManager.COperatorTableAdapter = null;
            this.tableAdapterManager.CRefundTypeTableAdapter = null;
            this.tableAdapterManager.CStrtTypeTableAdapter = null;
            this.tableAdapterManager.CUnitTableAdapter = null;
            this.tableAdapterManager.DlvryTableAdapter = null;
            this.tableAdapterManager.EntityTableAdapter = null;
            this.tableAdapterManager.IndividualTableAdapter = null;
            this.tableAdapterManager.JRefundTableAdapter = null;
            this.tableAdapterManager.JSaleTableAdapter = null;
            this.tableAdapterManager.LandlinePhoneTableAdapter = null;
            this.tableAdapterManager.MobilePhoneTableAdapter = null;
            this.tableAdapterManager.PrdctInstanceTableAdapter = null;
            this.tableAdapterManager.RAdressTableAdapter = this.rAdressTableAdapter;
            this.tableAdapterManager.RBuyerTableAdapter = null;
            this.tableAdapterManager.RCntcInfoTableAdapter = null;
            this.tableAdapterManager.RContractTableAdapter = null;
            this.tableAdapterManager.RPhoneTableAdapter = null;
            this.tableAdapterManager.RPrdctInfoTableAdapter = null;
            this.tableAdapterManager.RProviderTableAdapter = null;
            this.tableAdapterManager.RSaleDetailTableAdapter = null;
            this.tableAdapterManager.SCountryTableAdapter = this.sCountryTableAdapter;
            this.tableAdapterManager.SLocalityTableAdapter = this.sLocalityTableAdapter;
            this.tableAdapterManager.SModelTableAdapter = null;
            this.tableAdapterManager.SParameterTableAdapter = null;
            this.tableAdapterManager.SRegionTableAdapter = this.sRegionTableAdapter;
            this.tableAdapterManager.SStaffTableAdapter = null;
            this.tableAdapterManager.SStreetTableAdapter = this.sStreetTableAdapter;
            this.tableAdapterManager.StorageTableAdapter = null;
            this.tableAdapterManager.STrdGrpTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = kursach.kursachDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // rAdressTableAdapter
            // 
            this.rAdressTableAdapter.ClearBeforeFill = true;
            // 
            // sLocalityTableAdapter
            // 
            this.sLocalityTableAdapter.ClearBeforeFill = true;
            // 
            // sRegionTableAdapter
            // 
            this.sRegionTableAdapter.ClearBeforeFill = true;
            // 
            // sStreetTableAdapter
            // 
            this.sStreetTableAdapter.ClearBeforeFill = true;
            // 
            // view_CountryTableAdapter
            // 
            this.view_CountryTableAdapter.ClearBeforeFill = true;
            // 
            // view_StreetTableAdapter
            // 
            this.view_StreetTableAdapter.ClearBeforeFill = true;
            // 
            // view_StreetTypeTableAdapter
            // 
            this.view_StreetTypeTableAdapter.ClearBeforeFill = true;
            // 
            // view_LocalityTableAdapter
            // 
            this.view_LocalityTableAdapter.ClearBeforeFill = true;
            // 
            // view_AdressTableAdapter
            // 
            this.view_AdressTableAdapter.ClearBeforeFill = true;
            // 
            // btn_AddCntry
            // 
            this.btn_AddCntry.Location = new System.Drawing.Point(631, 47);
            this.btn_AddCntry.Name = "btn_AddCntry";
            this.btn_AddCntry.Size = new System.Drawing.Size(100, 35);
            this.btn_AddCntry.TabIndex = 2;
            this.btn_AddCntry.Text = "Add new";
            this.btn_AddCntry.UseVisualStyleBackColor = true;
            this.btn_AddCntry.Click += new System.EventHandler(this.btn_AddCntry_Click);
            // 
            // btn_AddRgn
            // 
            this.btn_AddRgn.Location = new System.Drawing.Point(631, 47);
            this.btn_AddRgn.Name = "btn_AddRgn";
            this.btn_AddRgn.Size = new System.Drawing.Size(100, 35);
            this.btn_AddRgn.TabIndex = 3;
            this.btn_AddRgn.Text = "Add new";
            this.btn_AddRgn.UseVisualStyleBackColor = true;
            this.btn_AddRgn.Click += new System.EventHandler(this.btn_AddRgn_Click);
            // 
            // btn_AddLlty
            // 
            this.btn_AddLlty.Location = new System.Drawing.Point(631, 47);
            this.btn_AddLlty.Name = "btn_AddLlty";
            this.btn_AddLlty.Size = new System.Drawing.Size(100, 35);
            this.btn_AddLlty.TabIndex = 3;
            this.btn_AddLlty.Text = "Add new";
            this.btn_AddLlty.UseVisualStyleBackColor = true;
            this.btn_AddLlty.Click += new System.EventHandler(this.btn_AddLlty_Click);
            // 
            // btn_AddStrt
            // 
            this.btn_AddStrt.Location = new System.Drawing.Point(631, 47);
            this.btn_AddStrt.Name = "btn_AddStrt";
            this.btn_AddStrt.Size = new System.Drawing.Size(100, 35);
            this.btn_AddStrt.TabIndex = 3;
            this.btn_AddStrt.Text = "Add new";
            this.btn_AddStrt.UseVisualStyleBackColor = true;
            this.btn_AddStrt.Click += new System.EventHandler(this.btn_AddStrt_Click);
            // 
            // btn_AddAdress
            // 
            this.btn_AddAdress.Location = new System.Drawing.Point(631, 47);
            this.btn_AddAdress.Name = "btn_AddAdress";
            this.btn_AddAdress.Size = new System.Drawing.Size(100, 35);
            this.btn_AddAdress.TabIndex = 3;
            this.btn_AddAdress.Text = "Add new";
            this.btn_AddAdress.UseVisualStyleBackColor = true;
            this.btn_AddAdress.Click += new System.EventHandler(this.btn_AddAdress_Click);
            // 
            // addressFrom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(770, 409);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.tabControl1);
            this.Name = "addressFrom";
            this.Text = "addressFrom";
            this.Load += new System.EventHandler(this.addressFrom_Load);
            this.tabControl1.ResumeLayout(false);
            this.tab_Country.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sCountryDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sCountryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).EndInit();
            this.tab_Region.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sRegionDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewCountryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sRegionBindingSource)).EndInit();
            this.tab_Locality.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sLocalityDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sLocalityBindingSource)).EndInit();
            this.tab_Street.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sStreetDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewLocalityBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewStreetTypeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sStreetBindingSource)).EndInit();
            this.tab_Address.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rAdressDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewAdressBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rAdressBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewStreetBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tab_Country;
        private System.Windows.Forms.TabPage tab_Region;
        private System.Windows.Forms.TabPage tab_Locality;
        private System.Windows.Forms.TabPage tab_Street;
        private kursachDataSet kursachDataSet;
        private System.Windows.Forms.BindingSource sCountryBindingSource;
        private kursachDataSetTableAdapters.SCountryTableAdapter sCountryTableAdapter;
        private kursachDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView sCountryDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private kursachDataSetTableAdapters.SRegionTableAdapter sRegionTableAdapter;
        private System.Windows.Forms.BindingSource sRegionBindingSource;
        private System.Windows.Forms.DataGridView sRegionDataGridView;
        private kursachDataSetTableAdapters.SLocalityTableAdapter sLocalityTableAdapter;
        private System.Windows.Forms.BindingSource sLocalityBindingSource;
        private System.Windows.Forms.DataGridView sLocalityDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private kursachDataSetTableAdapters.SStreetTableAdapter sStreetTableAdapter;
        private System.Windows.Forms.BindingSource sStreetBindingSource;
        private System.Windows.Forms.DataGridView sStreetDataGridView;
        private System.Windows.Forms.TabPage tab_Address;
        private kursachDataSetTableAdapters.RAdressTableAdapter rAdressTableAdapter;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.BindingSource rAdressBindingSource;
        private System.Windows.Forms.DataGridView rAdressDataGridView;
        private System.Windows.Forms.Button btn_deleteCntry;
        private System.Windows.Forms.Button btn_deleteRgn;
        private System.Windows.Forms.Button btn_deleteLclty;
        private System.Windows.Forms.Button btn_deleteStrt;
        private System.Windows.Forms.Button btn_deleteAddrs;
        private System.Windows.Forms.BindingSource viewCountryBindingSource;
        private kursachDataSetTableAdapters.view_CountryTableAdapter view_CountryTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.BindingSource viewStreetBindingSource;
        private kursachDataSetTableAdapters.view_StreetTableAdapter view_StreetTableAdapter;
        private System.Windows.Forms.BindingSource viewStreetTypeBindingSource;
        private kursachDataSetTableAdapters.view_StreetTypeTableAdapter view_StreetTypeTableAdapter;
        private System.Windows.Forms.BindingSource viewLocalityBindingSource;
        private kursachDataSetTableAdapters.view_LocalityTableAdapter view_LocalityTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.BindingSource viewAdressBindingSource;
        private kursachDataSetTableAdapters.view_AdressTableAdapter view_AdressTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewComboBoxColumn adress;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.Button btn_AddCntry;
        private System.Windows.Forms.Button btn_AddRgn;
        private System.Windows.Forms.Button btn_AddLlty;
        private System.Windows.Forms.Button btn_AddStrt;
        private System.Windows.Forms.Button btn_AddAdress;
    }
}