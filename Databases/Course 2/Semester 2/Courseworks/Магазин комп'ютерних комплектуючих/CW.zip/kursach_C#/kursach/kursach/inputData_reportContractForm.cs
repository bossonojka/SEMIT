﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class inputData_reportContractForm : Form
    {
        public inputData_reportContractForm()
        {
            InitializeComponent();
        }

        private void btn_exec_Click(object sender, EventArgs e)
        {
            if (int.Parse(this.txt_inputData.Text.ToString()) <= 0)
            {
                MessageBox.Show("Input data first");
            }
            else
            {
                reportContractInfoForm frm = new reportContractInfoForm();
                frm.setContent(txt_inputData.Text);
                frm.Show();
                this.Close();
            }
        }
    }
}
