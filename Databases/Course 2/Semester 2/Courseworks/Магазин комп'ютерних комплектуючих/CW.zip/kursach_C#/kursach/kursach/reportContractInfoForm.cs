﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class reportContractInfoForm : Form
    {
        public reportContractInfoForm()
        {
            InitializeComponent();
        }

        private void reportContractInfoForm_Load(object sender, EventArgs e)
        {
            int inputData = int.Parse(this.txt_inputData1.Text.ToString());    
            this.sp_contractInfoTableAdapter.Fill(this.kursachDataSet.sp_contractInfo, inputData);
            this.reportViewer1.RefreshReport();
        }

        public void setContent(string txt1)
        {
            this.txt_inputData1.Text = txt1;
        }
    }
}
