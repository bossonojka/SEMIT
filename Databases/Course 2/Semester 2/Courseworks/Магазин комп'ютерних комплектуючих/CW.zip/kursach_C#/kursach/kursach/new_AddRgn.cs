﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class new_AddRgn : Form
    {
        public new_AddRgn()
        {
            InitializeComponent();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            {
                string conS = "Data Source=ADMIN;Initial Catalog=kursach;Integrated Security=True";
                try
                {
                    using (SqlConnection con = new SqlConnection(conS))
                    {
                        using (SqlCommand cmd = new SqlCommand("add_Region", con))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@idContry", SqlDbType.VarChar).Value = int.Parse(comboBox1.SelectedValue.ToString());
                            cmd.Parameters.AddWithValue("@name", SqlDbType.VarChar).Value = txt_input.Text.ToString();   
                            con.Open();
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
                catch
                {
                    MessageBox.Show("Data Error!", "Error!",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                this.Close();
            }
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void new_AddRgn_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kursachDataSet.SCountry' table. You can move, or remove it, as needed.
            this.sCountryTableAdapter.Fill(this.kursachDataSet.SCountry);
            // TODO: This line of code loads data into the 'kursachDataSet.SCountry' table. You can move, or remove it, as needed.
            this.sCountryTableAdapter.Fill(this.kursachDataSet.SCountry);
            // TODO: This line of code loads data into the 'kursachDataSet.RContract' table. You can move, or remove it, as needed.

        }
    }
}
