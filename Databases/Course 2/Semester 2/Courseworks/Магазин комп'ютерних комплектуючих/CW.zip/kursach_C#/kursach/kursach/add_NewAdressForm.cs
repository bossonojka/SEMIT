﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class add_NewAdressForm : Form
    {
        public add_NewAdressForm()
        {
            InitializeComponent();
        }

        private void add_NewAdressForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kursachDataSet.SStreet' table. You can move, or remove it, as needed.
            this.sStreetTableAdapter.Fill(this.kursachDataSet.SStreet);
            // TODO: This line of code loads data into the 'kursachDataSet.SLocality' table. You can move, or remove it, as needed.
            this.sLocalityTableAdapter.Fill(this.kursachDataSet.SLocality);
            // TODO: This line of code loads data into the 'kursachDataSet.SRegion' table. You can move, or remove it, as needed.
            this.sRegionTableAdapter.Fill(this.kursachDataSet.SRegion);
            // TODO: This line of code loads data into the 'kursachDataSet.SCountry' table. You can move, or remove it, as needed.
            this.sCountryTableAdapter.Fill(this.kursachDataSet.SCountry);

        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            string conS = "Data Source=ADMIN;Initial Catalog=kursach;Integrated Security=True";
            try
            {
                using (SqlConnection con = new SqlConnection(conS))
                {
                    using (SqlCommand cmd = new SqlCommand("add_Adress", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@idStreet", SqlDbType.Int).Value = int.Parse(comboBox5.SelectedValue.ToString());                       
                        cmd.Parameters.AddWithValue("@houseNbr", SqlDbType.VarChar).Value = txt_input.Text.ToString();
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Data Error!", "Error!",
               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Close();
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
