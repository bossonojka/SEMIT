﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class reportSaleCheckForm : Form
    {
        public reportSaleCheckForm()
        {
            InitializeComponent();
        }

        private void reportSaleCheckForm_Load(object sender, EventArgs e)
        {
            int inputData = int.Parse(this.txt_inputData.Text.ToString());
            this.sp_SaleChekdTableAdapter.Fill(this.kursachDataSet.sp_SaleChekd, inputData);
            this.reportViewer1.RefreshReport();
        }

        public void setContent(string txt)
        {
            this.txt_inputData.Text = txt;

        }
    }
}
