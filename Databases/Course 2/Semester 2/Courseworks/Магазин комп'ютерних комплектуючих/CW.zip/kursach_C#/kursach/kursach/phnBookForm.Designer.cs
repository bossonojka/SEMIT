﻿namespace kursach
{
    partial class phnBookForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btn_DltMblPhn = new System.Windows.Forms.Button();
            this.btn_NewMblPhn = new System.Windows.Forms.Button();
            this.mobilePhoneDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.isaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rPhoneBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kursachDataSet = new kursach.kursachDataSet();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btn_DltLcltPhn = new System.Windows.Forms.Button();
            this.btn_NewLcltPhn = new System.Windows.Forms.Button();
            this.landlinePhoneDataGridView = new System.Windows.Forms.DataGridView();
            this.fKLandlinePhoneRPhoneBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mobilePhoneBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mobilePhoneTableAdapter = new kursach.kursachDataSetTableAdapters.MobilePhoneTableAdapter();
            this.tableAdapterManager = new kursach.kursachDataSetTableAdapters.TableAdapterManager();
            this.landlinePhoneTableAdapter = new kursach.kursachDataSetTableAdapters.LandlinePhoneTableAdapter();
            this.rPhoneTableAdapter = new kursach.kursachDataSetTableAdapters.RPhoneTableAdapter();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.rPhoneDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.landlinePhoneBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.viewLocalityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.view_LocalityTableAdapter = new kursach.kursachDataSetTableAdapters.view_LocalityTableAdapter();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mobilePhoneDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.isaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rPhoneBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.landlinePhoneDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKLandlinePhoneRPhoneBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mobilePhoneBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rPhoneDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.landlinePhoneBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewLocalityBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(13, 134);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(588, 199);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.Controls.Add(this.btn_DltMblPhn);
            this.tabPage1.Controls.Add(this.btn_NewMblPhn);
            this.tabPage1.Controls.Add(this.mobilePhoneDataGridView);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(580, 173);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Mobile Phone";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btn_DltMblPhn
            // 
            this.btn_DltMblPhn.Location = new System.Drawing.Point(474, 47);
            this.btn_DltMblPhn.Name = "btn_DltMblPhn";
            this.btn_DltMblPhn.Size = new System.Drawing.Size(100, 35);
            this.btn_DltMblPhn.TabIndex = 3;
            this.btn_DltMblPhn.Text = "Delete";
            this.btn_DltMblPhn.UseVisualStyleBackColor = true;
            this.btn_DltMblPhn.Click += new System.EventHandler(this.btn_DltMblPhn_Click);
            // 
            // btn_NewMblPhn
            // 
            this.btn_NewMblPhn.Location = new System.Drawing.Point(474, 6);
            this.btn_NewMblPhn.Name = "btn_NewMblPhn";
            this.btn_NewMblPhn.Size = new System.Drawing.Size(100, 35);
            this.btn_NewMblPhn.TabIndex = 2;
            this.btn_NewMblPhn.Text = "Add new";
            this.btn_NewMblPhn.UseVisualStyleBackColor = true;
            this.btn_NewMblPhn.Click += new System.EventHandler(this.btn_NewMblPhn_Click);
            // 
            // mobilePhoneDataGridView
            // 
            this.mobilePhoneDataGridView.AutoGenerateColumns = false;
            this.mobilePhoneDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.mobilePhoneDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.mobilePhoneDataGridView.DataSource = this.isaBindingSource;
            this.mobilePhoneDataGridView.Location = new System.Drawing.Point(0, 0);
            this.mobilePhoneDataGridView.Name = "mobilePhoneDataGridView";
            this.mobilePhoneDataGridView.Size = new System.Drawing.Size(245, 170);
            this.mobilePhoneDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "idPhone";
            this.dataGridViewTextBoxColumn1.HeaderText = "idPhone";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "idOperatorNmbr";
            this.dataGridViewTextBoxColumn2.HeaderText = "idOperatorNmbr";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // isaBindingSource
            // 
            this.isaBindingSource.DataMember = "is_a";
            this.isaBindingSource.DataSource = this.rPhoneBindingSource;
            // 
            // rPhoneBindingSource
            // 
            this.rPhoneBindingSource.DataMember = "RPhone";
            this.rPhoneBindingSource.DataSource = this.kursachDataSet;
            // 
            // kursachDataSet
            // 
            this.kursachDataSet.DataSetName = "kursachDataSet";
            this.kursachDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.Controls.Add(this.btn_DltLcltPhn);
            this.tabPage2.Controls.Add(this.btn_NewLcltPhn);
            this.tabPage2.Controls.Add(this.landlinePhoneDataGridView);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(580, 173);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Locality Phone";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btn_DltLcltPhn
            // 
            this.btn_DltLcltPhn.Location = new System.Drawing.Point(474, 47);
            this.btn_DltLcltPhn.Name = "btn_DltLcltPhn";
            this.btn_DltLcltPhn.Size = new System.Drawing.Size(100, 35);
            this.btn_DltLcltPhn.TabIndex = 5;
            this.btn_DltLcltPhn.Text = "Delete";
            this.btn_DltLcltPhn.UseVisualStyleBackColor = true;
            this.btn_DltLcltPhn.Click += new System.EventHandler(this.btn_DltLcltPhn_Click);
            // 
            // btn_NewLcltPhn
            // 
            this.btn_NewLcltPhn.Location = new System.Drawing.Point(474, 6);
            this.btn_NewLcltPhn.Name = "btn_NewLcltPhn";
            this.btn_NewLcltPhn.Size = new System.Drawing.Size(100, 35);
            this.btn_NewLcltPhn.TabIndex = 4;
            this.btn_NewLcltPhn.Text = "Add new";
            this.btn_NewLcltPhn.UseVisualStyleBackColor = true;
            this.btn_NewLcltPhn.Click += new System.EventHandler(this.btn_NewLcltPhn_Click);
            // 
            // landlinePhoneDataGridView
            // 
            this.landlinePhoneDataGridView.AutoGenerateColumns = false;
            this.landlinePhoneDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.landlinePhoneDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.landlinePhoneDataGridView.DataSource = this.fKLandlinePhoneRPhoneBindingSource;
            this.landlinePhoneDataGridView.Location = new System.Drawing.Point(0, 0);
            this.landlinePhoneDataGridView.Name = "landlinePhoneDataGridView";
            this.landlinePhoneDataGridView.Size = new System.Drawing.Size(345, 170);
            this.landlinePhoneDataGridView.TabIndex = 0;
            // 
            // fKLandlinePhoneRPhoneBindingSource
            // 
            this.fKLandlinePhoneRPhoneBindingSource.DataMember = "FK_LandlinePhone_RPhone";
            this.fKLandlinePhoneRPhoneBindingSource.DataSource = this.rPhoneBindingSource;
            // 
            // mobilePhoneBindingSource
            // 
            this.mobilePhoneBindingSource.DataMember = "MobilePhone";
            this.mobilePhoneBindingSource.DataSource = this.kursachDataSet;
            // 
            // mobilePhoneTableAdapter
            // 
            this.mobilePhoneTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AllowableChrtrcsTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CGenderTableAdapter = null;
            this.tableAdapterManager.CharacteristicsTableAdapter = null;
            this.tableAdapterManager.CManufacturerTableAdapter = null;
            this.tableAdapterManager.COperatorNumberTableAdapter = null;
            this.tableAdapterManager.COperatorTableAdapter = null;
            this.tableAdapterManager.CRefundTypeTableAdapter = null;
            this.tableAdapterManager.CStrtTypeTableAdapter = null;
            this.tableAdapterManager.CUnitTableAdapter = null;
            this.tableAdapterManager.DlvryTableAdapter = null;
            this.tableAdapterManager.EntityTableAdapter = null;
            this.tableAdapterManager.IndividualTableAdapter = null;
            this.tableAdapterManager.JRefundTableAdapter = null;
            this.tableAdapterManager.JSaleTableAdapter = null;
            this.tableAdapterManager.LandlinePhoneTableAdapter = this.landlinePhoneTableAdapter;
            this.tableAdapterManager.MobilePhoneTableAdapter = this.mobilePhoneTableAdapter;
            this.tableAdapterManager.PrdctInstanceTableAdapter = null;
            this.tableAdapterManager.RAdressTableAdapter = null;
            this.tableAdapterManager.RBuyerTableAdapter = null;
            this.tableAdapterManager.RCntcInfoTableAdapter = null;
            this.tableAdapterManager.RContractTableAdapter = null;
            this.tableAdapterManager.RPhoneTableAdapter = this.rPhoneTableAdapter;
            this.tableAdapterManager.RPrdctInfoTableAdapter = null;
            this.tableAdapterManager.RProviderTableAdapter = null;
            this.tableAdapterManager.RSaleDetailTableAdapter = null;
            this.tableAdapterManager.SCountryTableAdapter = null;
            this.tableAdapterManager.SLocalityTableAdapter = null;
            this.tableAdapterManager.SModelTableAdapter = null;
            this.tableAdapterManager.SParameterTableAdapter = null;
            this.tableAdapterManager.SRegionTableAdapter = null;
            this.tableAdapterManager.SStaffTableAdapter = null;
            this.tableAdapterManager.SStreetTableAdapter = null;
            this.tableAdapterManager.StorageTableAdapter = null;
            this.tableAdapterManager.STrdGrpTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = kursach.kursachDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // landlinePhoneTableAdapter
            // 
            this.landlinePhoneTableAdapter.ClearBeforeFill = true;
            // 
            // rPhoneTableAdapter
            // 
            this.rPhoneTableAdapter.ClearBeforeFill = true;
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.Location = new System.Drawing.Point(12, 339);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(100, 35);
            this.btn_Refresh.TabIndex = 1;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = true;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Location = new System.Drawing.Point(501, 339);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(100, 35);
            this.btn_Exit.TabIndex = 2;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // rPhoneDataGridView
            // 
            this.rPhoneDataGridView.AutoGenerateColumns = false;
            this.rPhoneDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rPhoneDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.rPhoneDataGridView.DataSource = this.rPhoneBindingSource;
            this.rPhoneDataGridView.Location = new System.Drawing.Point(17, 12);
            this.rPhoneDataGridView.Name = "rPhoneDataGridView";
            this.rPhoneDataGridView.Size = new System.Drawing.Size(584, 96);
            this.rPhoneDataGridView.TabIndex = 3;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "idPhone";
            this.dataGridViewTextBoxColumn3.HeaderText = "idPhone";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "phoneNmbr";
            this.dataGridViewTextBoxColumn4.HeaderText = "phoneNmbr";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // landlinePhoneBindingSource
            // 
            this.landlinePhoneBindingSource.DataMember = "LandlinePhone";
            this.landlinePhoneBindingSource.DataSource = this.kursachDataSet;
            // 
            // viewLocalityBindingSource
            // 
            this.viewLocalityBindingSource.DataMember = "view_Locality";
            this.viewLocalityBindingSource.DataSource = this.kursachDataSet;
            // 
            // view_LocalityTableAdapter
            // 
            this.view_LocalityTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "idPhone";
            this.dataGridViewTextBoxColumn5.HeaderText = "idPhone";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "idLocality";
            this.dataGridViewTextBoxColumn6.DataSource = this.viewLocalityBindingSource;
            this.dataGridViewTextBoxColumn6.DisplayMember = "localityName";
            this.dataGridViewTextBoxColumn6.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn6.HeaderText = "idLocality";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn6.ValueMember = "idLocality";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "localityPhoneCode";
            this.dataGridViewTextBoxColumn7.HeaderText = "localityPhoneCode";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // phnBookForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(621, 394);
            this.Controls.Add(this.rPhoneDataGridView);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.tabControl1);
            this.Name = "phnBookForm";
            this.Text = "phnBookForm";
            this.Load += new System.EventHandler(this.phnBookForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.mobilePhoneDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.isaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rPhoneBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.landlinePhoneDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKLandlinePhoneRPhoneBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mobilePhoneBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rPhoneDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.landlinePhoneBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewLocalityBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private kursachDataSet kursachDataSet;
        private System.Windows.Forms.BindingSource mobilePhoneBindingSource;
        private kursachDataSetTableAdapters.MobilePhoneTableAdapter mobilePhoneTableAdapter;
        private kursachDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView mobilePhoneDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private kursachDataSetTableAdapters.RPhoneTableAdapter rPhoneTableAdapter;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.BindingSource rPhoneBindingSource;
        private System.Windows.Forms.BindingSource isaBindingSource;
        private kursachDataSetTableAdapters.LandlinePhoneTableAdapter landlinePhoneTableAdapter;
        private System.Windows.Forms.DataGridView rPhoneDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.BindingSource landlinePhoneBindingSource;
        private System.Windows.Forms.DataGridView landlinePhoneDataGridView;
        private System.Windows.Forms.BindingSource fKLandlinePhoneRPhoneBindingSource;
        private System.Windows.Forms.Button btn_DltMblPhn;
        private System.Windows.Forms.Button btn_NewMblPhn;
        private System.Windows.Forms.Button btn_DltLcltPhn;
        private System.Windows.Forms.Button btn_NewLcltPhn;
        private System.Windows.Forms.BindingSource viewLocalityBindingSource;
        private kursachDataSetTableAdapters.view_LocalityTableAdapter view_LocalityTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
    }
}