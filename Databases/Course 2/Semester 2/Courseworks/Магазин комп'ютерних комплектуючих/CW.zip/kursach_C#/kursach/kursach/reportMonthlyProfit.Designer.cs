﻿namespace kursach
{
    partial class reportMonthlyProfit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource2 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.sp_soldPrdctBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kursachDataSet = new kursach.kursachDataSet();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.RSaleDetailBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.RSaleDetailTableAdapter = new kursach.kursachDataSetTableAdapters.RSaleDetailTableAdapter();
            this.sp_soldPrdctTableAdapter = new kursach.kursachDataSetTableAdapters.sp_soldPrdctTableAdapter();
            this.txt_inputData1 = new System.Windows.Forms.TextBox();
            this.txt_inputData2 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.sp_soldPrdctBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RSaleDetailBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // sp_soldPrdctBindingSource
            // 
            this.sp_soldPrdctBindingSource.DataMember = "sp_soldPrdct";
            this.sp_soldPrdctBindingSource.DataSource = this.kursachDataSet;
            // 
            // kursachDataSet
            // 
            this.kursachDataSet.DataSetName = "kursachDataSet";
            this.kursachDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource2.Name = "kursachDataSet";
            reportDataSource2.Value = this.sp_soldPrdctBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource2);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "kursach.report_monthlyProfit.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.ServerReport.BearerToken = null;
            this.reportViewer1.Size = new System.Drawing.Size(588, 428);
            this.reportViewer1.TabIndex = 0;
            // 
            // RSaleDetailBindingSource
            // 
            this.RSaleDetailBindingSource.DataMember = "RSaleDetail";
            this.RSaleDetailBindingSource.DataSource = this.kursachDataSet;
            // 
            // RSaleDetailTableAdapter
            // 
            this.RSaleDetailTableAdapter.ClearBeforeFill = true;
            // 
            // sp_soldPrdctTableAdapter
            // 
            this.sp_soldPrdctTableAdapter.ClearBeforeFill = true;
            // 
            // txt_inputData1
            // 
            this.txt_inputData1.Location = new System.Drawing.Point(67, 65);
            this.txt_inputData1.Name = "txt_inputData1";
            this.txt_inputData1.Size = new System.Drawing.Size(100, 20);
            this.txt_inputData1.TabIndex = 1;
            this.txt_inputData1.Visible = false;
            // 
            // txt_inputData2
            // 
            this.txt_inputData2.Location = new System.Drawing.Point(174, 64);
            this.txt_inputData2.Name = "txt_inputData2";
            this.txt_inputData2.Size = new System.Drawing.Size(100, 20);
            this.txt_inputData2.TabIndex = 2;
            this.txt_inputData2.Visible = false;
            // 
            // reportMonthlyProfit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(588, 428);
            this.Controls.Add(this.txt_inputData2);
            this.Controls.Add(this.txt_inputData1);
            this.Controls.Add(this.reportViewer1);
            this.Name = "reportMonthlyProfit";
            this.Text = "reportMonthlyProfit";
            this.Load += new System.EventHandler(this.reportMonthlyProfit_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sp_soldPrdctBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RSaleDetailBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource RSaleDetailBindingSource;
        private kursachDataSet kursachDataSet;
        private kursachDataSetTableAdapters.RSaleDetailTableAdapter RSaleDetailTableAdapter;
        private System.Windows.Forms.BindingSource sp_soldPrdctBindingSource;
        private kursachDataSetTableAdapters.sp_soldPrdctTableAdapter sp_soldPrdctTableAdapter;
        private System.Windows.Forms.TextBox txt_inputData1;
        private System.Windows.Forms.TextBox txt_inputData2;
    }
}