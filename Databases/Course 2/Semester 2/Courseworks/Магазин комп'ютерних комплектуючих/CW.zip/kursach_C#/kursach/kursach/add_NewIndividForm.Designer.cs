﻿namespace kursach
{
    partial class add_NewIndividForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txt_input3 = new System.Windows.Forms.TextBox();
            this.txt_input2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_input1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_input4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.kursachDataSet = new kursach.kursachDataSet();
            this.sCountryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sCountryTableAdapter = new kursach.kursachDataSetTableAdapters.SCountryTableAdapter();
            this.r49BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sRegionTableAdapter = new kursach.kursachDataSetTableAdapters.SRegionTableAdapter();
            this.r19BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sLocalityTableAdapter = new kursach.kursachDataSetTableAdapters.SLocalityTableAdapter();
            this.r20BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sStreetTableAdapter = new kursach.kursachDataSetTableAdapters.SStreetTableAdapter();
            this.r17BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rAdressTableAdapter = new kursach.kursachDataSetTableAdapters.RAdressTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sCountryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r49BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r19BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r20BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r17BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_input3
            // 
            this.txt_input3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txt_input3.Location = new System.Drawing.Point(141, 41);
            this.txt_input3.Name = "txt_input3";
            this.txt_input3.Size = new System.Drawing.Size(100, 23);
            this.txt_input3.TabIndex = 99;
            // 
            // txt_input2
            // 
            this.txt_input2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txt_input2.Location = new System.Drawing.Point(15, 108);
            this.txt_input2.Name = "txt_input2";
            this.txt_input2.Size = new System.Drawing.Size(100, 23);
            this.txt_input2.TabIndex = 97;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(12, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 17);
            this.label2.TabIndex = 96;
            this.label2.Text = "Input first name";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(336, 2);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(166, 24);
            this.label13.TabIndex = 95;
            this.label13.Text = "Adress information";
            // 
            // comboBox6
            // 
            this.comboBox6.DataSource = this.r17BindingSource;
            this.comboBox6.DisplayMember = "idAdress";
            this.comboBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(340, 177);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(121, 24);
            this.comboBox6.TabIndex = 94;
            this.comboBox6.ValueMember = "houseNmbr";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(337, 157);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(103, 17);
            this.label12.TabIndex = 93;
            this.label12.Text = "Choose locality";
            // 
            // comboBox5
            // 
            this.comboBox5.DataSource = this.r20BindingSource;
            this.comboBox5.DisplayMember = "streetName";
            this.comboBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(485, 122);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(121, 24);
            this.comboBox5.TabIndex = 92;
            this.comboBox5.ValueMember = "idStreet";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(482, 102);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 17);
            this.label8.TabIndex = 91;
            this.label8.Text = "Choose Name";
            // 
            // comboBox3
            // 
            this.comboBox3.DataSource = this.r19BindingSource;
            this.comboBox3.DisplayMember = "localityName";
            this.comboBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(340, 122);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 24);
            this.comboBox3.TabIndex = 90;
            this.comboBox3.ValueMember = "idLocality";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(337, 102);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 17);
            this.label9.TabIndex = 89;
            this.label9.Text = "Choose locality";
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.r49BindingSource;
            this.comboBox2.DisplayMember = "regionName";
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(485, 67);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 24);
            this.comboBox2.TabIndex = 88;
            this.comboBox2.ValueMember = "idRegion";
            // 
            // comboBox4
            // 
            this.comboBox4.DataSource = this.sCountryBindingSource;
            this.comboBox4.DisplayMember = "countryName";
            this.comboBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(340, 67);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 24);
            this.comboBox4.TabIndex = 87;
            this.comboBox4.ValueMember = "idCountry";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(337, 47);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(107, 17);
            this.label10.TabIndex = 86;
            this.label10.Text = "Choose country";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(482, 47);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(105, 17);
            this.label11.TabIndex = 85;
            this.label11.Text = "Choose Region";
            // 
            // txt_input1
            // 
            this.txt_input1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txt_input1.Location = new System.Drawing.Point(15, 41);
            this.txt_input1.Name = "txt_input1";
            this.txt_input1.Size = new System.Drawing.Size(100, 23);
            this.txt_input1.TabIndex = 84;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 17);
            this.label1.TabIndex = 83;
            this.label1.Text = "Input id";
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Cancel.Location = new System.Drawing.Point(506, 217);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(100, 35);
            this.btn_Cancel.TabIndex = 82;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // btn_Save
            // 
            this.btn_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Save.Location = new System.Drawing.Point(12, 217);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(100, 35);
            this.btn_Save.TabIndex = 81;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(138, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(150, 17);
            this.label3.TabIndex = 98;
            this.label3.Text = "Input doument number";
            // 
            // txt_input4
            // 
            this.txt_input4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txt_input4.Location = new System.Drawing.Point(141, 107);
            this.txt_input4.Name = "txt_input4";
            this.txt_input4.Size = new System.Drawing.Size(100, 23);
            this.txt_input4.TabIndex = 101;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(138, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 17);
            this.label4.TabIndex = 100;
            this.label4.Text = "Input last name";
            // 
            // kursachDataSet
            // 
            this.kursachDataSet.DataSetName = "kursachDataSet";
            this.kursachDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sCountryBindingSource
            // 
            this.sCountryBindingSource.DataMember = "SCountry";
            this.sCountryBindingSource.DataSource = this.kursachDataSet;
            // 
            // sCountryTableAdapter
            // 
            this.sCountryTableAdapter.ClearBeforeFill = true;
            // 
            // r49BindingSource
            // 
            this.r49BindingSource.DataMember = "R_49";
            this.r49BindingSource.DataSource = this.sCountryBindingSource;
            // 
            // sRegionTableAdapter
            // 
            this.sRegionTableAdapter.ClearBeforeFill = true;
            // 
            // r19BindingSource
            // 
            this.r19BindingSource.DataMember = "R_19";
            this.r19BindingSource.DataSource = this.r49BindingSource;
            // 
            // sLocalityTableAdapter
            // 
            this.sLocalityTableAdapter.ClearBeforeFill = true;
            // 
            // r20BindingSource
            // 
            this.r20BindingSource.DataMember = "R_20";
            this.r20BindingSource.DataSource = this.r19BindingSource;
            // 
            // sStreetTableAdapter
            // 
            this.sStreetTableAdapter.ClearBeforeFill = true;
            // 
            // r17BindingSource
            // 
            this.r17BindingSource.DataMember = "R_17";
            this.r17BindingSource.DataSource = this.r20BindingSource;
            // 
            // rAdressTableAdapter
            // 
            this.rAdressTableAdapter.ClearBeforeFill = true;
            // 
            // add_NewIndividForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(619, 263);
            this.Controls.Add(this.txt_input4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_input3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_input2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.comboBox6);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.comboBox5);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txt_input1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.btn_Save);
            this.Name = "add_NewIndividForm";
            this.Text = "add_NewIndividForm";
            this.Load += new System.EventHandler(this.add_NewIndividForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sCountryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r49BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r19BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r20BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r17BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_input3;
        private System.Windows.Forms.TextBox txt_input2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_input1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_input4;
        private System.Windows.Forms.Label label4;
        private kursachDataSet kursachDataSet;
        private System.Windows.Forms.BindingSource sCountryBindingSource;
        private kursachDataSetTableAdapters.SCountryTableAdapter sCountryTableAdapter;
        private System.Windows.Forms.BindingSource r49BindingSource;
        private kursachDataSetTableAdapters.SRegionTableAdapter sRegionTableAdapter;
        private System.Windows.Forms.BindingSource r19BindingSource;
        private kursachDataSetTableAdapters.SLocalityTableAdapter sLocalityTableAdapter;
        private System.Windows.Forms.BindingSource r20BindingSource;
        private kursachDataSetTableAdapters.SStreetTableAdapter sStreetTableAdapter;
        private System.Windows.Forms.BindingSource r17BindingSource;
        private kursachDataSetTableAdapters.RAdressTableAdapter rAdressTableAdapter;
    }
}