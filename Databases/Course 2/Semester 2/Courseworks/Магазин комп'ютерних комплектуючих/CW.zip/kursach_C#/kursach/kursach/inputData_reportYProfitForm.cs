﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class inputData_reportYProfitForm : Form
    {
        public inputData_reportYProfitForm()
        {
            InitializeComponent();
        }

        private void btn_Exct_Click(object sender, EventArgs e)
        {
            if (int.Parse(this.txt_inputYear.Text.ToString()) <= 0)
            {
                MessageBox.Show("Input data first");
            }
            else {
                reportYearProfit frm = new reportYearProfit();
                frm.setContent(txt_inputYear.Text);
                frm.Show();
                this.Close();
            }
        }
    }
}
