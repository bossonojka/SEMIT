﻿namespace kursach
{
    partial class administartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tab_AdminForm = new System.Windows.Forms.TabControl();
            this.tab_strtType = new System.Windows.Forms.TabPage();
            this.btn_AddSrtType = new System.Windows.Forms.Button();
            this.btn_deleteSrtrType = new System.Windows.Forms.Button();
            this.cStrtTypeDataGridView = new System.Windows.Forms.DataGridView();
            this.tab_Unit = new System.Windows.Forms.TabPage();
            this.btn_AddUnit = new System.Windows.Forms.Button();
            this.btn_deleteUnit = new System.Windows.Forms.Button();
            this.cUnitDataGridView = new System.Windows.Forms.DataGridView();
            this.tab_Gender = new System.Windows.Forms.TabPage();
            this.btn_AddGndr = new System.Windows.Forms.Button();
            this.btn_deleteGndr = new System.Windows.Forms.Button();
            this.cGenderDataGridView = new System.Windows.Forms.DataGridView();
            this.tab_RfndType = new System.Windows.Forms.TabPage();
            this.btn_AddRfndType = new System.Windows.Forms.Button();
            this.btn_deleteRfndType = new System.Windows.Forms.Button();
            this.cRefundTypeDataGridView = new System.Windows.Forms.DataGridView();
            this.tab_OprtrName = new System.Windows.Forms.TabPage();
            this.btn_AddOprtr = new System.Windows.Forms.Button();
            this.btn_DeleteOper = new System.Windows.Forms.Button();
            this.cOperatorDataGridView = new System.Windows.Forms.DataGridView();
            this.tab_AllblChrst = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_DeleteAllblChrcht = new System.Windows.Forms.Button();
            this.allowableChrtrcsDataGridView = new System.Windows.Forms.DataGridView();
            this.tab_OperNmbr = new System.Windows.Forms.TabPage();
            this.btn_NewOperNmbr = new System.Windows.Forms.Button();
            this.btn_DeleteOperNmbr = new System.Windows.Forms.Button();
            this.cOperatorNumberDataGridView = new System.Windows.Forms.DataGridView();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cStrtTypeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kursachDataSet = new kursach.kursachDataSet();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cUnitBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cGenderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cRefundTypeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cOperatorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.allowableChrtrcsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.viewCountryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cOperatorNumberBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cGenderTableAdapter = new kursach.kursachDataSetTableAdapters.CGenderTableAdapter();
            this.tableAdapterManager = new kursach.kursachDataSetTableAdapters.TableAdapterManager();
            this.cRefundTypeTableAdapter = new kursach.kursachDataSetTableAdapters.CRefundTypeTableAdapter();
            this.cStrtTypeTableAdapter = new kursach.kursachDataSetTableAdapters.CStrtTypeTableAdapter();
            this.cUnitTableAdapter = new kursach.kursachDataSetTableAdapters.CUnitTableAdapter();
            this.cOperatorTableAdapter = new kursach.kursachDataSetTableAdapters.COperatorTableAdapter();
            this.allowableChrtrcsTableAdapter = new kursach.kursachDataSetTableAdapters.AllowableChrtrcsTableAdapter();
            this.cOperatorNumberTableAdapter = new kursach.kursachDataSetTableAdapters.COperatorNumberTableAdapter();
            this.view_CountryTableAdapter = new kursach.kursachDataSetTableAdapters.view_CountryTableAdapter();
            this.viewOperatorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.view_OperatorTableAdapter = new kursach.kursachDataSetTableAdapters.view_OperatorTableAdapter();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tab_AdminForm.SuspendLayout();
            this.tab_strtType.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cStrtTypeDataGridView)).BeginInit();
            this.tab_Unit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cUnitDataGridView)).BeginInit();
            this.tab_Gender.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cGenderDataGridView)).BeginInit();
            this.tab_RfndType.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cRefundTypeDataGridView)).BeginInit();
            this.tab_OprtrName.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cOperatorDataGridView)).BeginInit();
            this.tab_AllblChrst.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.allowableChrtrcsDataGridView)).BeginInit();
            this.tab_OperNmbr.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cOperatorNumberDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cStrtTypeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUnitBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cGenderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cRefundTypeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cOperatorBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.allowableChrtrcsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewCountryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cOperatorNumberBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewOperatorBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tab_AdminForm
            // 
            this.tab_AdminForm.Controls.Add(this.tab_strtType);
            this.tab_AdminForm.Controls.Add(this.tab_Unit);
            this.tab_AdminForm.Controls.Add(this.tab_Gender);
            this.tab_AdminForm.Controls.Add(this.tab_RfndType);
            this.tab_AdminForm.Controls.Add(this.tab_OprtrName);
            this.tab_AdminForm.Controls.Add(this.tab_AllblChrst);
            this.tab_AdminForm.Controls.Add(this.tab_OperNmbr);
            this.tab_AdminForm.Location = new System.Drawing.Point(13, 13);
            this.tab_AdminForm.Name = "tab_AdminForm";
            this.tab_AdminForm.SelectedIndex = 0;
            this.tab_AdminForm.Size = new System.Drawing.Size(629, 241);
            this.tab_AdminForm.TabIndex = 0;
            // 
            // tab_strtType
            // 
            this.tab_strtType.AutoScroll = true;
            this.tab_strtType.Controls.Add(this.btn_AddSrtType);
            this.tab_strtType.Controls.Add(this.btn_deleteSrtrType);
            this.tab_strtType.Controls.Add(this.cStrtTypeDataGridView);
            this.tab_strtType.Location = new System.Drawing.Point(4, 22);
            this.tab_strtType.Name = "tab_strtType";
            this.tab_strtType.Padding = new System.Windows.Forms.Padding(3);
            this.tab_strtType.Size = new System.Drawing.Size(621, 215);
            this.tab_strtType.TabIndex = 0;
            this.tab_strtType.Text = "Street Type";
            this.tab_strtType.UseVisualStyleBackColor = true;
            // 
            // btn_AddSrtType
            // 
            this.btn_AddSrtType.Location = new System.Drawing.Point(515, 47);
            this.btn_AddSrtType.Name = "btn_AddSrtType";
            this.btn_AddSrtType.Size = new System.Drawing.Size(100, 35);
            this.btn_AddSrtType.TabIndex = 2;
            this.btn_AddSrtType.Text = "Add new";
            this.btn_AddSrtType.UseVisualStyleBackColor = true;
            this.btn_AddSrtType.Click += new System.EventHandler(this.btn_AddSrtType_Click);
            // 
            // btn_deleteSrtrType
            // 
            this.btn_deleteSrtrType.Location = new System.Drawing.Point(515, 6);
            this.btn_deleteSrtrType.Name = "btn_deleteSrtrType";
            this.btn_deleteSrtrType.Size = new System.Drawing.Size(100, 35);
            this.btn_deleteSrtrType.TabIndex = 1;
            this.btn_deleteSrtrType.Text = "Delete";
            this.btn_deleteSrtrType.UseVisualStyleBackColor = true;
            this.btn_deleteSrtrType.Click += new System.EventHandler(this.btn_deleteSrtrType_Click);
            // 
            // cStrtTypeDataGridView
            // 
            this.cStrtTypeDataGridView.AutoGenerateColumns = false;
            this.cStrtTypeDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cStrtTypeDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.cStrtTypeDataGridView.DataSource = this.cStrtTypeBindingSource;
            this.cStrtTypeDataGridView.Location = new System.Drawing.Point(3, 3);
            this.cStrtTypeDataGridView.Name = "cStrtTypeDataGridView";
            this.cStrtTypeDataGridView.Size = new System.Drawing.Size(284, 209);
            this.cStrtTypeDataGridView.TabIndex = 0;
            // 
            // tab_Unit
            // 
            this.tab_Unit.AutoScroll = true;
            this.tab_Unit.Controls.Add(this.btn_AddUnit);
            this.tab_Unit.Controls.Add(this.btn_deleteUnit);
            this.tab_Unit.Controls.Add(this.cUnitDataGridView);
            this.tab_Unit.Location = new System.Drawing.Point(4, 22);
            this.tab_Unit.Name = "tab_Unit";
            this.tab_Unit.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Unit.Size = new System.Drawing.Size(621, 215);
            this.tab_Unit.TabIndex = 1;
            this.tab_Unit.Text = "Unit";
            this.tab_Unit.UseVisualStyleBackColor = true;
            // 
            // btn_AddUnit
            // 
            this.btn_AddUnit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_AddUnit.Location = new System.Drawing.Point(515, 47);
            this.btn_AddUnit.Name = "btn_AddUnit";
            this.btn_AddUnit.Size = new System.Drawing.Size(100, 35);
            this.btn_AddUnit.TabIndex = 2;
            this.btn_AddUnit.TabStop = false;
            this.btn_AddUnit.Text = "Add new";
            this.btn_AddUnit.UseVisualStyleBackColor = true;
            this.btn_AddUnit.Click += new System.EventHandler(this.btn_AddUnit_Click);
            // 
            // btn_deleteUnit
            // 
            this.btn_deleteUnit.Location = new System.Drawing.Point(515, 6);
            this.btn_deleteUnit.Name = "btn_deleteUnit";
            this.btn_deleteUnit.Size = new System.Drawing.Size(100, 35);
            this.btn_deleteUnit.TabIndex = 1;
            this.btn_deleteUnit.Text = "Delete";
            this.btn_deleteUnit.UseVisualStyleBackColor = true;
            this.btn_deleteUnit.Click += new System.EventHandler(this.btn_deleteUnit_Click);
            // 
            // cUnitDataGridView
            // 
            this.cUnitDataGridView.AutoGenerateColumns = false;
            this.cUnitDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cUnitDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.cUnitDataGridView.DataSource = this.cUnitBindingSource;
            this.cUnitDataGridView.Location = new System.Drawing.Point(3, 3);
            this.cUnitDataGridView.Name = "cUnitDataGridView";
            this.cUnitDataGridView.Size = new System.Drawing.Size(285, 209);
            this.cUnitDataGridView.TabIndex = 0;
            // 
            // tab_Gender
            // 
            this.tab_Gender.AutoScroll = true;
            this.tab_Gender.Controls.Add(this.btn_AddGndr);
            this.tab_Gender.Controls.Add(this.btn_deleteGndr);
            this.tab_Gender.Controls.Add(this.cGenderDataGridView);
            this.tab_Gender.Location = new System.Drawing.Point(4, 22);
            this.tab_Gender.Name = "tab_Gender";
            this.tab_Gender.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Gender.Size = new System.Drawing.Size(621, 215);
            this.tab_Gender.TabIndex = 2;
            this.tab_Gender.Text = "Gender";
            this.tab_Gender.UseVisualStyleBackColor = true;
            // 
            // btn_AddGndr
            // 
            this.btn_AddGndr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_AddGndr.Location = new System.Drawing.Point(515, 47);
            this.btn_AddGndr.Name = "btn_AddGndr";
            this.btn_AddGndr.Size = new System.Drawing.Size(100, 35);
            this.btn_AddGndr.TabIndex = 3;
            this.btn_AddGndr.TabStop = false;
            this.btn_AddGndr.Text = "Add new";
            this.btn_AddGndr.UseVisualStyleBackColor = true;
            this.btn_AddGndr.Click += new System.EventHandler(this.btn_AddGndr_Click);
            // 
            // btn_deleteGndr
            // 
            this.btn_deleteGndr.Location = new System.Drawing.Point(515, 6);
            this.btn_deleteGndr.Name = "btn_deleteGndr";
            this.btn_deleteGndr.Size = new System.Drawing.Size(100, 35);
            this.btn_deleteGndr.TabIndex = 1;
            this.btn_deleteGndr.Text = "Delete";
            this.btn_deleteGndr.UseVisualStyleBackColor = true;
            this.btn_deleteGndr.Click += new System.EventHandler(this.btn_deleteGndr_Click);
            // 
            // cGenderDataGridView
            // 
            this.cGenderDataGridView.AutoGenerateColumns = false;
            this.cGenderDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cGenderDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.cGenderDataGridView.DataSource = this.cGenderBindingSource;
            this.cGenderDataGridView.Location = new System.Drawing.Point(3, 3);
            this.cGenderDataGridView.Name = "cGenderDataGridView";
            this.cGenderDataGridView.Size = new System.Drawing.Size(285, 209);
            this.cGenderDataGridView.TabIndex = 0;
            // 
            // tab_RfndType
            // 
            this.tab_RfndType.AutoScroll = true;
            this.tab_RfndType.Controls.Add(this.btn_AddRfndType);
            this.tab_RfndType.Controls.Add(this.btn_deleteRfndType);
            this.tab_RfndType.Controls.Add(this.cRefundTypeDataGridView);
            this.tab_RfndType.Location = new System.Drawing.Point(4, 22);
            this.tab_RfndType.Name = "tab_RfndType";
            this.tab_RfndType.Padding = new System.Windows.Forms.Padding(3);
            this.tab_RfndType.Size = new System.Drawing.Size(621, 215);
            this.tab_RfndType.TabIndex = 3;
            this.tab_RfndType.Text = "Refund Type";
            this.tab_RfndType.UseVisualStyleBackColor = true;
            // 
            // btn_AddRfndType
            // 
            this.btn_AddRfndType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_AddRfndType.Location = new System.Drawing.Point(515, 47);
            this.btn_AddRfndType.Name = "btn_AddRfndType";
            this.btn_AddRfndType.Size = new System.Drawing.Size(100, 35);
            this.btn_AddRfndType.TabIndex = 3;
            this.btn_AddRfndType.TabStop = false;
            this.btn_AddRfndType.Text = "Add new";
            this.btn_AddRfndType.UseVisualStyleBackColor = true;
            this.btn_AddRfndType.Click += new System.EventHandler(this.btn_AddRfndType_Click);
            // 
            // btn_deleteRfndType
            // 
            this.btn_deleteRfndType.Location = new System.Drawing.Point(515, 6);
            this.btn_deleteRfndType.Name = "btn_deleteRfndType";
            this.btn_deleteRfndType.Size = new System.Drawing.Size(100, 35);
            this.btn_deleteRfndType.TabIndex = 1;
            this.btn_deleteRfndType.Text = "Delete";
            this.btn_deleteRfndType.UseVisualStyleBackColor = true;
            this.btn_deleteRfndType.Click += new System.EventHandler(this.btn_deleteRfndType_Click);
            // 
            // cRefundTypeDataGridView
            // 
            this.cRefundTypeDataGridView.AutoGenerateColumns = false;
            this.cRefundTypeDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cRefundTypeDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.cRefundTypeDataGridView.DataSource = this.cRefundTypeBindingSource;
            this.cRefundTypeDataGridView.Location = new System.Drawing.Point(3, 3);
            this.cRefundTypeDataGridView.Name = "cRefundTypeDataGridView";
            this.cRefundTypeDataGridView.Size = new System.Drawing.Size(285, 209);
            this.cRefundTypeDataGridView.TabIndex = 0;
            // 
            // tab_OprtrName
            // 
            this.tab_OprtrName.AutoScroll = true;
            this.tab_OprtrName.Controls.Add(this.btn_AddOprtr);
            this.tab_OprtrName.Controls.Add(this.btn_DeleteOper);
            this.tab_OprtrName.Controls.Add(this.cOperatorDataGridView);
            this.tab_OprtrName.Location = new System.Drawing.Point(4, 22);
            this.tab_OprtrName.Name = "tab_OprtrName";
            this.tab_OprtrName.Padding = new System.Windows.Forms.Padding(3);
            this.tab_OprtrName.Size = new System.Drawing.Size(621, 215);
            this.tab_OprtrName.TabIndex = 4;
            this.tab_OprtrName.Text = "Operators";
            this.tab_OprtrName.UseVisualStyleBackColor = true;
            // 
            // btn_AddOprtr
            // 
            this.btn_AddOprtr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_AddOprtr.Location = new System.Drawing.Point(515, 47);
            this.btn_AddOprtr.Name = "btn_AddOprtr";
            this.btn_AddOprtr.Size = new System.Drawing.Size(100, 35);
            this.btn_AddOprtr.TabIndex = 3;
            this.btn_AddOprtr.TabStop = false;
            this.btn_AddOprtr.Text = "Add new";
            this.btn_AddOprtr.UseVisualStyleBackColor = true;
            this.btn_AddOprtr.Click += new System.EventHandler(this.btn_AddOprtr_Click);
            // 
            // btn_DeleteOper
            // 
            this.btn_DeleteOper.Location = new System.Drawing.Point(515, 6);
            this.btn_DeleteOper.Name = "btn_DeleteOper";
            this.btn_DeleteOper.Size = new System.Drawing.Size(100, 35);
            this.btn_DeleteOper.TabIndex = 2;
            this.btn_DeleteOper.Text = "Delete";
            this.btn_DeleteOper.UseVisualStyleBackColor = true;
            // 
            // cOperatorDataGridView
            // 
            this.cOperatorDataGridView.AutoGenerateColumns = false;
            this.cOperatorDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cOperatorDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10});
            this.cOperatorDataGridView.DataSource = this.cOperatorBindingSource;
            this.cOperatorDataGridView.Location = new System.Drawing.Point(3, 3);
            this.cOperatorDataGridView.Name = "cOperatorDataGridView";
            this.cOperatorDataGridView.Size = new System.Drawing.Size(285, 209);
            this.cOperatorDataGridView.TabIndex = 0;
            // 
            // tab_AllblChrst
            // 
            this.tab_AllblChrst.AutoScroll = true;
            this.tab_AllblChrst.Controls.Add(this.button1);
            this.tab_AllblChrst.Controls.Add(this.btn_DeleteAllblChrcht);
            this.tab_AllblChrst.Controls.Add(this.allowableChrtrcsDataGridView);
            this.tab_AllblChrst.Location = new System.Drawing.Point(4, 22);
            this.tab_AllblChrst.Name = "tab_AllblChrst";
            this.tab_AllblChrst.Padding = new System.Windows.Forms.Padding(3);
            this.tab_AllblChrst.Size = new System.Drawing.Size(621, 215);
            this.tab_AllblChrst.TabIndex = 5;
            this.tab_AllblChrst.Text = "Allowable Charachteristics";
            this.tab_AllblChrst.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(515, 47);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 35);
            this.button1.TabIndex = 3;
            this.button1.TabStop = false;
            this.button1.Text = "Refresh";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_DeleteAllblChrcht
            // 
            this.btn_DeleteAllblChrcht.Location = new System.Drawing.Point(515, 6);
            this.btn_DeleteAllblChrcht.Name = "btn_DeleteAllblChrcht";
            this.btn_DeleteAllblChrcht.Size = new System.Drawing.Size(100, 35);
            this.btn_DeleteAllblChrcht.TabIndex = 2;
            this.btn_DeleteAllblChrcht.Text = "Delete";
            this.btn_DeleteAllblChrcht.UseVisualStyleBackColor = true;
            // 
            // allowableChrtrcsDataGridView
            // 
            this.allowableChrtrcsDataGridView.AutoGenerateColumns = false;
            this.allowableChrtrcsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.allowableChrtrcsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            this.allowableChrtrcsDataGridView.DataSource = this.allowableChrtrcsBindingSource;
            this.allowableChrtrcsDataGridView.Location = new System.Drawing.Point(3, 3);
            this.allowableChrtrcsDataGridView.Name = "allowableChrtrcsDataGridView";
            this.allowableChrtrcsDataGridView.Size = new System.Drawing.Size(283, 209);
            this.allowableChrtrcsDataGridView.TabIndex = 0;
            // 
            // tab_OperNmbr
            // 
            this.tab_OperNmbr.AutoScroll = true;
            this.tab_OperNmbr.Controls.Add(this.btn_NewOperNmbr);
            this.tab_OperNmbr.Controls.Add(this.btn_DeleteOperNmbr);
            this.tab_OperNmbr.Controls.Add(this.cOperatorNumberDataGridView);
            this.tab_OperNmbr.Location = new System.Drawing.Point(4, 22);
            this.tab_OperNmbr.Name = "tab_OperNmbr";
            this.tab_OperNmbr.Padding = new System.Windows.Forms.Padding(3);
            this.tab_OperNmbr.Size = new System.Drawing.Size(621, 215);
            this.tab_OperNmbr.TabIndex = 6;
            this.tab_OperNmbr.Text = "Operator Number";
            this.tab_OperNmbr.UseVisualStyleBackColor = true;
            // 
            // btn_NewOperNmbr
            // 
            this.btn_NewOperNmbr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_NewOperNmbr.Location = new System.Drawing.Point(498, 47);
            this.btn_NewOperNmbr.Name = "btn_NewOperNmbr";
            this.btn_NewOperNmbr.Size = new System.Drawing.Size(100, 35);
            this.btn_NewOperNmbr.TabIndex = 5;
            this.btn_NewOperNmbr.TabStop = false;
            this.btn_NewOperNmbr.Text = "Add new";
            this.btn_NewOperNmbr.UseVisualStyleBackColor = true;
            this.btn_NewOperNmbr.Click += new System.EventHandler(this.btn_NewOperNmbr_Click);
            // 
            // btn_DeleteOperNmbr
            // 
            this.btn_DeleteOperNmbr.Location = new System.Drawing.Point(498, 6);
            this.btn_DeleteOperNmbr.Name = "btn_DeleteOperNmbr";
            this.btn_DeleteOperNmbr.Size = new System.Drawing.Size(100, 35);
            this.btn_DeleteOperNmbr.TabIndex = 4;
            this.btn_DeleteOperNmbr.Text = "Delete";
            this.btn_DeleteOperNmbr.UseVisualStyleBackColor = true;
            this.btn_DeleteOperNmbr.Click += new System.EventHandler(this.btn_DeleteOperNmbr_Click);
            // 
            // cOperatorNumberDataGridView
            // 
            this.cOperatorNumberDataGridView.AutoGenerateColumns = false;
            this.cOperatorNumberDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cOperatorNumberDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16});
            this.cOperatorNumberDataGridView.DataSource = this.cOperatorNumberBindingSource;
            this.cOperatorNumberDataGridView.Location = new System.Drawing.Point(0, 0);
            this.cOperatorNumberDataGridView.Name = "cOperatorNumberDataGridView";
            this.cOperatorNumberDataGridView.Size = new System.Drawing.Size(443, 215);
            this.cOperatorNumberDataGridView.TabIndex = 0;
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.Location = new System.Drawing.Point(17, 361);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(100, 35);
            this.btn_Refresh.TabIndex = 1;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = true;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Location = new System.Drawing.Point(542, 361);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(100, 35);
            this.btn_Exit.TabIndex = 2;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "idType";
            this.dataGridViewTextBoxColumn7.HeaderText = "idType";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "typeName";
            this.dataGridViewTextBoxColumn8.HeaderText = "typeName";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // cStrtTypeBindingSource
            // 
            this.cStrtTypeBindingSource.DataMember = "CStrtType";
            this.cStrtTypeBindingSource.DataSource = this.kursachDataSet;
            // 
            // kursachDataSet
            // 
            this.kursachDataSet.DataSetName = "kursachDataSet";
            this.kursachDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "idUnit";
            this.dataGridViewTextBoxColumn3.HeaderText = "idUnit";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "unitName";
            this.dataGridViewTextBoxColumn4.HeaderText = "unitName";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // cUnitBindingSource
            // 
            this.cUnitBindingSource.DataMember = "CUnit";
            this.cUnitBindingSource.DataSource = this.kursachDataSet;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "idGender";
            this.dataGridViewTextBoxColumn1.HeaderText = "idGender";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "genderName";
            this.dataGridViewTextBoxColumn2.HeaderText = "genderName";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // cGenderBindingSource
            // 
            this.cGenderBindingSource.DataMember = "CGender";
            this.cGenderBindingSource.DataSource = this.kursachDataSet;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "idRefundType";
            this.dataGridViewTextBoxColumn5.HeaderText = "idRefundType";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "refundName";
            this.dataGridViewTextBoxColumn6.HeaderText = "refundName";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // cRefundTypeBindingSource
            // 
            this.cRefundTypeBindingSource.DataMember = "CRefundType";
            this.cRefundTypeBindingSource.DataSource = this.kursachDataSet;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "idOperator";
            this.dataGridViewTextBoxColumn9.HeaderText = "idOperator";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "operatorName";
            this.dataGridViewTextBoxColumn10.HeaderText = "operatorName";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // cOperatorBindingSource
            // 
            this.cOperatorBindingSource.DataMember = "COperator";
            this.cOperatorBindingSource.DataSource = this.kursachDataSet;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "idTrdGrp";
            this.dataGridViewTextBoxColumn11.HeaderText = "idTrdGrp";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "idParameter";
            this.dataGridViewTextBoxColumn12.HeaderText = "idParameter";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // allowableChrtrcsBindingSource
            // 
            this.allowableChrtrcsBindingSource.DataMember = "AllowableChrtrcs";
            this.allowableChrtrcsBindingSource.DataSource = this.kursachDataSet;
            // 
            // viewCountryBindingSource
            // 
            this.viewCountryBindingSource.DataMember = "view_Country";
            this.viewCountryBindingSource.DataSource = this.kursachDataSet;
            // 
            // cOperatorNumberBindingSource
            // 
            this.cOperatorNumberBindingSource.DataMember = "COperatorNumber";
            this.cOperatorNumberBindingSource.DataSource = this.kursachDataSet;
            // 
            // cGenderTableAdapter
            // 
            this.cGenderTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AllowableChrtrcsTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CGenderTableAdapter = this.cGenderTableAdapter;
            this.tableAdapterManager.CharacteristicsTableAdapter = null;
            this.tableAdapterManager.CManufacturerTableAdapter = null;
            this.tableAdapterManager.COperatorNumberTableAdapter = null;
            this.tableAdapterManager.COperatorTableAdapter = null;
            this.tableAdapterManager.CRefundTypeTableAdapter = this.cRefundTypeTableAdapter;
            this.tableAdapterManager.CStrtTypeTableAdapter = this.cStrtTypeTableAdapter;
            this.tableAdapterManager.CUnitTableAdapter = this.cUnitTableAdapter;
            this.tableAdapterManager.DlvryTableAdapter = null;
            this.tableAdapterManager.EntityTableAdapter = null;
            this.tableAdapterManager.IndividualTableAdapter = null;
            this.tableAdapterManager.JRefundTableAdapter = null;
            this.tableAdapterManager.JSaleTableAdapter = null;
            this.tableAdapterManager.LandlinePhoneTableAdapter = null;
            this.tableAdapterManager.MobilePhoneTableAdapter = null;
            this.tableAdapterManager.PrdctInstanceTableAdapter = null;
            this.tableAdapterManager.RAdressTableAdapter = null;
            this.tableAdapterManager.RBuyerTableAdapter = null;
            this.tableAdapterManager.RCntcInfoTableAdapter = null;
            this.tableAdapterManager.RContractTableAdapter = null;
            this.tableAdapterManager.RPhoneTableAdapter = null;
            this.tableAdapterManager.RPrdctInfoTableAdapter = null;
            this.tableAdapterManager.RProviderTableAdapter = null;
            this.tableAdapterManager.RSaleDetailTableAdapter = null;
            this.tableAdapterManager.SCountryTableAdapter = null;
            this.tableAdapterManager.SLocalityTableAdapter = null;
            this.tableAdapterManager.SModelTableAdapter = null;
            this.tableAdapterManager.SParameterTableAdapter = null;
            this.tableAdapterManager.SRegionTableAdapter = null;
            this.tableAdapterManager.SStaffTableAdapter = null;
            this.tableAdapterManager.SStreetTableAdapter = null;
            this.tableAdapterManager.StorageTableAdapter = null;
            this.tableAdapterManager.STrdGrpTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = kursach.kursachDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // cRefundTypeTableAdapter
            // 
            this.cRefundTypeTableAdapter.ClearBeforeFill = true;
            // 
            // cStrtTypeTableAdapter
            // 
            this.cStrtTypeTableAdapter.ClearBeforeFill = true;
            // 
            // cUnitTableAdapter
            // 
            this.cUnitTableAdapter.ClearBeforeFill = true;
            // 
            // cOperatorTableAdapter
            // 
            this.cOperatorTableAdapter.ClearBeforeFill = true;
            // 
            // allowableChrtrcsTableAdapter
            // 
            this.allowableChrtrcsTableAdapter.ClearBeforeFill = true;
            // 
            // cOperatorNumberTableAdapter
            // 
            this.cOperatorNumberTableAdapter.ClearBeforeFill = true;
            // 
            // view_CountryTableAdapter
            // 
            this.view_CountryTableAdapter.ClearBeforeFill = true;
            // 
            // viewOperatorBindingSource
            // 
            this.viewOperatorBindingSource.DataMember = "view_Operator";
            this.viewOperatorBindingSource.DataSource = this.kursachDataSet;
            // 
            // view_OperatorTableAdapter
            // 
            this.view_OperatorTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "idOperatorNmbr";
            this.dataGridViewTextBoxColumn13.HeaderText = "idOperatorNmbr";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "idOperator";
            this.dataGridViewTextBoxColumn14.DataSource = this.viewOperatorBindingSource;
            this.dataGridViewTextBoxColumn14.DisplayMember = "operatorName";
            this.dataGridViewTextBoxColumn14.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn14.HeaderText = "idOperator";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn14.ValueMember = "idOperator";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "idCountry";
            this.dataGridViewTextBoxColumn15.DataSource = this.viewCountryBindingSource;
            this.dataGridViewTextBoxColumn15.DisplayMember = "countryName";
            this.dataGridViewTextBoxColumn15.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn15.HeaderText = "idCountry";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn15.ValueMember = "idCountry";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "operatorNumber";
            this.dataGridViewTextBoxColumn16.HeaderText = "operatorNumber";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // administartForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(654, 408);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.tab_AdminForm);
            this.Name = "administartForm";
            this.Text = "administartForm";
            this.Load += new System.EventHandler(this.administartForm_Load);
            this.tab_AdminForm.ResumeLayout(false);
            this.tab_strtType.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cStrtTypeDataGridView)).EndInit();
            this.tab_Unit.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cUnitDataGridView)).EndInit();
            this.tab_Gender.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cGenderDataGridView)).EndInit();
            this.tab_RfndType.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cRefundTypeDataGridView)).EndInit();
            this.tab_OprtrName.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cOperatorDataGridView)).EndInit();
            this.tab_AllblChrst.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.allowableChrtrcsDataGridView)).EndInit();
            this.tab_OperNmbr.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cOperatorNumberDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cStrtTypeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUnitBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cGenderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cRefundTypeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cOperatorBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.allowableChrtrcsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewCountryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cOperatorNumberBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewOperatorBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tab_AdminForm;
        private System.Windows.Forms.TabPage tab_strtType;
        private System.Windows.Forms.TabPage tab_Unit;
        private System.Windows.Forms.TabPage tab_Gender;
        private System.Windows.Forms.TabPage tab_RfndType;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Button btn_Exit;
        private kursachDataSet kursachDataSet;
        private System.Windows.Forms.BindingSource cGenderBindingSource;
        private kursachDataSetTableAdapters.CGenderTableAdapter cGenderTableAdapter;
        private kursachDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView cGenderDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private kursachDataSetTableAdapters.CUnitTableAdapter cUnitTableAdapter;
        private System.Windows.Forms.BindingSource cUnitBindingSource;
        private System.Windows.Forms.DataGridView cUnitDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private kursachDataSetTableAdapters.CRefundTypeTableAdapter cRefundTypeTableAdapter;
        private System.Windows.Forms.BindingSource cRefundTypeBindingSource;
        private System.Windows.Forms.DataGridView cRefundTypeDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private kursachDataSetTableAdapters.CStrtTypeTableAdapter cStrtTypeTableAdapter;
        private System.Windows.Forms.BindingSource cStrtTypeBindingSource;
        private System.Windows.Forms.DataGridView cStrtTypeDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.Button btn_deleteSrtrType;
        private System.Windows.Forms.Button btn_deleteUnit;
        private System.Windows.Forms.Button btn_deleteGndr;
        private System.Windows.Forms.Button btn_deleteRfndType;
        private System.Windows.Forms.TabPage tab_OprtrName;
        private System.Windows.Forms.BindingSource cOperatorBindingSource;
        private kursachDataSetTableAdapters.COperatorTableAdapter cOperatorTableAdapter;
        private System.Windows.Forms.DataGridView cOperatorDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.TabPage tab_AllblChrst;
        private System.Windows.Forms.BindingSource allowableChrtrcsBindingSource;
        private kursachDataSetTableAdapters.AllowableChrtrcsTableAdapter allowableChrtrcsTableAdapter;
        private System.Windows.Forms.DataGridView allowableChrtrcsDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.Button btn_DeleteOper;
        private System.Windows.Forms.Button btn_DeleteAllblChrcht;
        private System.Windows.Forms.Button btn_AddSrtType;
        private System.Windows.Forms.Button btn_AddUnit;
        private System.Windows.Forms.Button btn_AddGndr;
        private System.Windows.Forms.Button btn_AddRfndType;
        private System.Windows.Forms.Button btn_AddOprtr;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabPage tab_OperNmbr;
        private System.Windows.Forms.BindingSource cOperatorNumberBindingSource;
        private kursachDataSetTableAdapters.COperatorNumberTableAdapter cOperatorNumberTableAdapter;
        private System.Windows.Forms.DataGridView cOperatorNumberDataGridView;
        private System.Windows.Forms.BindingSource viewCountryBindingSource;
        private kursachDataSetTableAdapters.view_CountryTableAdapter view_CountryTableAdapter;
        private System.Windows.Forms.Button btn_NewOperNmbr;
        private System.Windows.Forms.Button btn_DeleteOperNmbr;
        private System.Windows.Forms.BindingSource viewOperatorBindingSource;
        private kursachDataSetTableAdapters.view_OperatorTableAdapter view_OperatorTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
    }
}