﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class inputData_reportMProfitForm : Form
    {
        public inputData_reportMProfitForm()
        {
            InitializeComponent();
        }

        private void btn_exec_Click(object sender, EventArgs e)
        {
            reportMonthlyProfit frm = new reportMonthlyProfit();
            frm.setContent(dateTimePicker1.Text, dateTimePicker2.Text);
            frm.Show();
            this.Close();
        }
    }
}
