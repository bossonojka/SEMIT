﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class add_NewEntityForm : Form
    {
        public add_NewEntityForm()
        {
            InitializeComponent();
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            string conS = "Data Source=ADMIN;Initial Catalog=kursach;Integrated Security=True";
            try
            {
                using (SqlConnection con = new SqlConnection(conS))
                {
                    using (SqlCommand cmd = new SqlCommand("add_Provider", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@id", SqlDbType.Int).Value = int.Parse(txt_input1.Text.ToString());
                        cmd.Parameters.AddWithValue("@idAdres", SqlDbType.Int).Value = int.Parse(comboBox6.SelectedValue.ToString());
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                    using (SqlCommand cmd = new SqlCommand("add_Entity", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@compName", SqlDbType.VarChar).Value = txt_input2.Text.ToString();
                        cmd.Parameters.AddWithValue("@taxNmbr", SqlDbType.VarChar).Value = txt_input3.Text.ToString();
                        cmd.Parameters.AddWithValue("@docVatNmbr", SqlDbType.VarChar).Value = txt_input4.Text.ToString();
                        cmd.Parameters.AddWithValue("@idProv", SqlDbType.Int).Value = int.Parse(txt_input1.Text.ToString());
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Data Error!", "Error!",
               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Close();
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void add_NewEntityForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kursachDataSet.RAdress' table. You can move, or remove it, as needed.
            this.rAdressTableAdapter.Fill(this.kursachDataSet.RAdress);
            // TODO: This line of code loads data into the 'kursachDataSet.SStreet' table. You can move, or remove it, as needed.
            this.sStreetTableAdapter.Fill(this.kursachDataSet.SStreet);
            // TODO: This line of code loads data into the 'kursachDataSet.SLocality' table. You can move, or remove it, as needed.
            this.sLocalityTableAdapter.Fill(this.kursachDataSet.SLocality);
            // TODO: This line of code loads data into the 'kursachDataSet.SRegion' table. You can move, or remove it, as needed.
            this.sRegionTableAdapter.Fill(this.kursachDataSet.SRegion);
            // TODO: This line of code loads data into the 'kursachDataSet.SCountry' table. You can move, or remove it, as needed.
            this.sCountryTableAdapter.Fill(this.kursachDataSet.SCountry);

        }
    }
}
