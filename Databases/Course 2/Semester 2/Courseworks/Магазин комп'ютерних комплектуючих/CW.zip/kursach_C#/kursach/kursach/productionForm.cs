﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class productionForm : Form
    {
        public productionForm()
        {
            InitializeComponent();
        }

        private void productionForm_Load(object sender, EventArgs e)
        {            
            this.view_ParameterTableAdapter.Fill(this.kursachDataSet.view_Parameter);            
            this.view_UnitTableAdapter.Fill(this.kursachDataSet.view_Unit);
            this.view_TrdGrpTableAdapter.Fill(this.kursachDataSet.view_TrdGrp);            
            this.view_ModelTableAdapter.Fill(this.kursachDataSet.view_Model);            
            this.view_ManufacturerTableAdapter.Fill(this.kursachDataSet.view_Manufacturer);            
            this.sParameterTableAdapter.Fill(this.kursachDataSet.SParameter);            
            this.characteristicsTableAdapter.Fill(this.kursachDataSet.Characteristics);            
            this.rPrdctInfoTableAdapter.Fill(this.kursachDataSet.RPrdctInfo);            
            this.cManufacturerTableAdapter.Fill(this.kursachDataSet.CManufacturer);            
            this.sModelTableAdapter.Fill(this.kursachDataSet.SModel);
            this.sTrdGrpTableAdapter.Fill(this.kursachDataSet.STrdGrp);            
            this.view_ModelTableAdapter.Fill(this.kursachDataSet.view_Model);            
            this.view_ManufacturerTableAdapter.Fill(this.kursachDataSet.view_Manufacturer);            
            this.cManufacturerTableAdapter.Fill(this.kursachDataSet.CManufacturer);            
            this.sParameterTableAdapter.Fill(this.kursachDataSet.SParameter);            
            this.characteristicsTableAdapter.Fill(this.kursachDataSet.Characteristics);            
            this.rPrdctInfoTableAdapter.Fill(this.kursachDataSet.RPrdctInfo);            
            this.sTrdGrpTableAdapter.Fill(this.kursachDataSet.STrdGrp);            
            this.sModelTableAdapter.Fill(this.kursachDataSet.SModel);
        }

        private void btn_refresh_Click(object sender, EventArgs e)
        {
            this.view_ParameterTableAdapter.Fill(this.kursachDataSet.view_Parameter);
            this.view_UnitTableAdapter.Fill(this.kursachDataSet.view_Unit);
            this.view_TrdGrpTableAdapter.Fill(this.kursachDataSet.view_TrdGrp);
            this.view_ModelTableAdapter.Fill(this.kursachDataSet.view_Model);
            this.view_ManufacturerTableAdapter.Fill(this.kursachDataSet.view_Manufacturer);
            this.sParameterTableAdapter.Fill(this.kursachDataSet.SParameter);
            this.characteristicsTableAdapter.Fill(this.kursachDataSet.Characteristics);
            this.rPrdctInfoTableAdapter.Fill(this.kursachDataSet.RPrdctInfo);
            this.cManufacturerTableAdapter.Fill(this.kursachDataSet.CManufacturer);
            this.sModelTableAdapter.Fill(this.kursachDataSet.SModel);
            this.sTrdGrpTableAdapter.Fill(this.kursachDataSet.STrdGrp);
            this.view_ModelTableAdapter.Fill(this.kursachDataSet.view_Model);
            this.view_ManufacturerTableAdapter.Fill(this.kursachDataSet.view_Manufacturer);
            this.cManufacturerTableAdapter.Fill(this.kursachDataSet.CManufacturer);
            this.sParameterTableAdapter.Fill(this.kursachDataSet.SParameter);
            this.characteristicsTableAdapter.Fill(this.kursachDataSet.Characteristics);
            this.rPrdctInfoTableAdapter.Fill(this.kursachDataSet.RPrdctInfo);
            this.sTrdGrpTableAdapter.Fill(this.kursachDataSet.STrdGrp);
            this.sModelTableAdapter.Fill(this.kursachDataSet.SModel);
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_deleteTRdGrp_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in sTrdGrpDataGridView.SelectedRows)
            {
                sTrdGrpDataGridView.Rows.Remove(row);
            }
        }

        private void btn_deleteModel_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in sModelDataGridView.SelectedRows)
            {
               sModelDataGridView.Rows.Remove(row);
            }
        }

        private void btn_deletePrdct_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in rPrdctInfoDataGridView.SelectedRows)
            {
                rPrdctInfoDataGridView.Rows.Remove(row);
            }
        }

        private void btn_deleteChrc_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in characteristicsDataGridView.SelectedRows)
            {
                characteristicsDataGridView.Rows.Remove(row);
            }
        }

        private void btn_deleteParam_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in sParameterDataGridView.SelectedRows)
            {
                sParameterDataGridView.Rows.Remove(row);
            }
        }

        private void btn_AddTrdGrp_Click(object sender, EventArgs e)
        {
            add_NewTrdGrp frm = new add_NewTrdGrp();
            frm.Show();
        }

        private void btn_AddModel_Click(object sender, EventArgs e)
        {
            add_NewModel frm = new add_NewModel();
            frm.Show();
        }

        private void btn_AddPrdct_Click(object sender, EventArgs e)
        {
            add_NewProductForm frm = new add_NewProductForm();
            frm.Show();
        }

        private void btn_AddManufact_Click(object sender, EventArgs e)
        {
            add_NewManufactForm frm = new add_NewManufactForm();
            frm.Show();
        }

        private void btn_AddCharcht_Click(object sender, EventArgs e)
        {
            add_NewCharachtForm frm = new add_NewCharachtForm();
            frm.Show();
        }

        private void btn_AddParam_Click(object sender, EventArgs e)
        {
            add_NewParamForm frm = new add_NewParamForm();
            frm.Show();
        }
    }
}
