﻿namespace kursach
{
    partial class inputData_reportContractForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl1 = new System.Windows.Forms.Label();
            this.txt_inputData = new System.Windows.Forms.TextBox();
            this.btn_exec = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbl1.Location = new System.Drawing.Point(12, 9);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(149, 25);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Input contract id";
            // 
            // txt_inputData
            // 
            this.txt_inputData.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txt_inputData.Location = new System.Drawing.Point(17, 46);
            this.txt_inputData.Name = "txt_inputData";
            this.txt_inputData.Size = new System.Drawing.Size(100, 30);
            this.txt_inputData.TabIndex = 1;
            // 
            // btn_exec
            // 
            this.btn_exec.Location = new System.Drawing.Point(249, 41);
            this.btn_exec.Name = "btn_exec";
            this.btn_exec.Size = new System.Drawing.Size(100, 35);
            this.btn_exec.TabIndex = 2;
            this.btn_exec.Text = "Execute";
            this.btn_exec.UseVisualStyleBackColor = true;
            this.btn_exec.Click += new System.EventHandler(this.btn_exec_Click);
            // 
            // inputData_reportContractForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(358, 83);
            this.Controls.Add(this.btn_exec);
            this.Controls.Add(this.txt_inputData);
            this.Controls.Add(this.lbl1);
            this.Name = "inputData_reportContractForm";
            this.Text = "inputData_reportContractForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.TextBox txt_inputData;
        private System.Windows.Forms.Button btn_exec;
    }
}