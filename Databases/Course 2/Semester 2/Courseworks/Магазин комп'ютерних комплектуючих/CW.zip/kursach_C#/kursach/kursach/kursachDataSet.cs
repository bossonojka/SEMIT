﻿namespace kursach
{


    partial class kursachDataSet
    {
        partial class sp_soldYearProfitDataTable
        {
        }
    }
}
