﻿namespace kursach
{
    partial class inputData_reportYProfitForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_inputYear = new System.Windows.Forms.TextBox();
            this.btn_Exct = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_inputYear
            // 
            this.txt_inputYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txt_inputYear.Location = new System.Drawing.Point(12, 38);
            this.txt_inputYear.Name = "txt_inputYear";
            this.txt_inputYear.Size = new System.Drawing.Size(160, 35);
            this.txt_inputYear.TabIndex = 0;
            // 
            // btn_Exct
            // 
            this.btn_Exct.Location = new System.Drawing.Point(282, 38);
            this.btn_Exct.Name = "btn_Exct";
            this.btn_Exct.Size = new System.Drawing.Size(100, 35);
            this.btn_Exct.TabIndex = 1;
            this.btn_Exct.Text = "Execute";
            this.btn_Exct.UseVisualStyleBackColor = true;
            this.btn_Exct.Click += new System.EventHandler(this.btn_Exct_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 29);
            this.label1.TabIndex = 2;
            this.label1.Text = "Input year";
            // 
            // inputData_reportYProfitForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(394, 92);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Exct);
            this.Controls.Add(this.txt_inputYear);
            this.Name = "inputData_reportYProfitForm";
            this.Text = "inputData_reportYProfitForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_inputYear;
        private System.Windows.Forms.Button btn_Exct;
        private System.Windows.Forms.Label label1;
    }
}