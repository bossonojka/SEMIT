﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class addressFrom : Form
    {
        public addressFrom()
        {
            InitializeComponent();
        }

        private void sCountryBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.sCountryBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.kursachDataSet);

        }

        private void addressFrom_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kursachDataSet.view_Adress' table. You can move, or remove it, as needed.
            this.view_AdressTableAdapter.Fill(this.kursachDataSet.view_Adress);
            // TODO: This line of code loads data into the 'kursachDataSet.view_Locality' table. You can move, or remove it, as needed.
            this.view_LocalityTableAdapter.Fill(this.kursachDataSet.view_Locality);
            // TODO: This line of code loads data into the 'kursachDataSet.view_StreetType' table. You can move, or remove it, as needed.
            this.view_StreetTypeTableAdapter.Fill(this.kursachDataSet.view_StreetType);
            // TODO: This line of code loads data into the 'kursachDataSet.view_Street' table. You can move, or remove it, as needed.
            this.view_StreetTableAdapter.Fill(this.kursachDataSet.view_Street);
            // TODO: This line of code loads data into the 'kursachDataSet.view_Country' table. You can move, or remove it, as needed.
            this.view_CountryTableAdapter.Fill(this.kursachDataSet.view_Country);
            // TODO: This line of code loads data into the 'kursachDataSet.RAdress' table. You can move, or remove it, as needed.
            this.rAdressTableAdapter.Fill(this.kursachDataSet.RAdress);
            // TODO: This line of code loads data into the 'kursachDataSet.SStreet' table. You can move, or remove it, as needed.
            this.sStreetTableAdapter.Fill(this.kursachDataSet.SStreet);
            // TODO: This line of code loads data into the 'kursachDataSet.SLocality' table. You can move, or remove it, as needed.
            this.sLocalityTableAdapter.Fill(this.kursachDataSet.SLocality);
            // TODO: This line of code loads data into the 'kursachDataSet.SRegion' table. You can move, or remove it, as needed.
            this.sRegionTableAdapter.Fill(this.kursachDataSet.SRegion);
            // TODO: This line of code loads data into the 'kursachDataSet.SCountry' table. You can move, or remove it, as needed.
            this.sCountryTableAdapter.Fill(this.kursachDataSet.SCountry);

        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kursachDataSet.view_Adress' table. You can move, or remove it, as needed.
            this.view_AdressTableAdapter.Fill(this.kursachDataSet.view_Adress);
            // TODO: This line of code loads data into the 'kursachDataSet.view_Locality' table. You can move, or remove it, as needed.
            this.view_LocalityTableAdapter.Fill(this.kursachDataSet.view_Locality);
            // TODO: This line of code loads data into the 'kursachDataSet.view_StreetType' table. You can move, or remove it, as needed.
            this.view_StreetTypeTableAdapter.Fill(this.kursachDataSet.view_StreetType);
            // TODO: This line of code loads data into the 'kursachDataSet.view_Street' table. You can move, or remove it, as needed.
            this.view_StreetTableAdapter.Fill(this.kursachDataSet.view_Street);
            // TODO: This line of code loads data into the 'kursachDataSet.view_Country' table. You can move, or remove it, as needed.
            this.view_CountryTableAdapter.Fill(this.kursachDataSet.view_Country);
            // TODO: This line of code loads data into the 'kursachDataSet.RAdress' table. You can move, or remove it, as needed.
            this.rAdressTableAdapter.Fill(this.kursachDataSet.RAdress);
            // TODO: This line of code loads data into the 'kursachDataSet.SStreet' table. You can move, or remove it, as needed.
            this.sStreetTableAdapter.Fill(this.kursachDataSet.SStreet);
            // TODO: This line of code loads data into the 'kursachDataSet.SLocality' table. You can move, or remove it, as needed.
            this.sLocalityTableAdapter.Fill(this.kursachDataSet.SLocality);
            // TODO: This line of code loads data into the 'kursachDataSet.SRegion' table. You can move, or remove it, as needed.
            this.sRegionTableAdapter.Fill(this.kursachDataSet.SRegion);
            // TODO: This line of code loads data into the 'kursachDataSet.SCountry' table. You can move, or remove it, as needed.
            this.sCountryTableAdapter.Fill(this.kursachDataSet.SCountry);
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_deleteCntry_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in sCountryDataGridView.SelectedRows)
            {
                sCountryDataGridView.Rows.Remove(row);
            }
        }

        private void btn_deleteRgn_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in sRegionDataGridView.SelectedRows)
            {
               sRegionDataGridView.Rows.Remove(row);
            }
        }

        private void btn_deleteLclty_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in sLocalityDataGridView.SelectedRows)
            {
                sLocalityDataGridView.Rows.Remove(row);
            }
        }

        private void btn_deleteStrt_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in sStreetDataGridView.SelectedRows)
            {
               sStreetDataGridView.Rows.Remove(row);
            }
        }

        private void btn_deleteAddrs_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in rAdressDataGridView.SelectedRows)
            {
                rAdressDataGridView.Rows.Remove(row);
            }
        }

        private void btn_AddCntry_Click(object sender, EventArgs e)
        {
            add_NewCntrForm frm = new add_NewCntrForm();
            frm.Show();
        }

        private void btn_AddRgn_Click(object sender, EventArgs e)
        {
            new_AddRgn frm = new new_AddRgn();
            frm.Show();
        }

        private void btn_AddLlty_Click(object sender, EventArgs e)
        {
            add_NewLcltForm frm = new add_NewLcltForm();
            frm.Show();
        }

        private void btn_AddStrt_Click(object sender, EventArgs e)
        {
            add_NewStreetForm frm = new add_NewStreetForm();
            frm.Show();
        }

        private void btn_AddAdress_Click(object sender, EventArgs e)
        {
            add_NewAdressForm frm = new add_NewAdressForm();
            frm.Show();
        }
    }
}
