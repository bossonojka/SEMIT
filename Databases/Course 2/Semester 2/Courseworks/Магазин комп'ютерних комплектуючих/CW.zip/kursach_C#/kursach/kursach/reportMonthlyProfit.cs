﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class reportMonthlyProfit : Form
    {
        public reportMonthlyProfit()
        {
            InitializeComponent();
        }

        private void reportMonthlyProfit_Load(object sender, EventArgs e)
        {
            DateTime fromDate = DateTime.Parse(this.txt_inputData1.Text.ToString());
            DateTime toDate = DateTime.Parse(this.txt_inputData2.Text.ToString());
            this.sp_soldPrdctTableAdapter.Fill(this.kursachDataSet.sp_soldPrdct, fromDate, toDate);            
            this.RSaleDetailTableAdapter.Fill(this.kursachDataSet.RSaleDetail);
            this.reportViewer1.RefreshReport();
        }

        public void setContent(string txt1, string txt2)
        {
            this.txt_inputData1.Text = txt1;
            this.txt_inputData2.Text = txt2;
        }
    }
}
