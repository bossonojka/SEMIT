﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class add_NewCharachtForm : Form
    {
        public add_NewCharachtForm()
        {
            InitializeComponent();
        }

        private void add_NewCharachtForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kursachDataSet.RPrdctInfo' table. You can move, or remove it, as needed.
            this.rPrdctInfoTableAdapter.Fill(this.kursachDataSet.RPrdctInfo);
            // TODO: This line of code loads data into the 'kursachDataSet.SParameter' table. You can move, or remove it, as needed.
            this.sParameterTableAdapter.Fill(this.kursachDataSet.SParameter);

        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            string conS = "Data Source=ADMIN;Initial Catalog=kursach;Integrated Security=True";
            try
            {
                using (SqlConnection con = new SqlConnection(conS))
                {
                    using (SqlCommand cmd = new SqlCommand("add_Chrctrcs", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@idProduct", SqlDbType.Int).Value = int.Parse(comboBox2.SelectedValue.ToString());
                        cmd.Parameters.AddWithValue("@idParameter", SqlDbType.Int).Value = int.Parse(comboBox1.SelectedValue.ToString());
                        cmd.Parameters.AddWithValue("@value", SqlDbType.VarChar).Value = txt_input1.Text.ToString();
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Data Error!", "Error!",
               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Close();
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
