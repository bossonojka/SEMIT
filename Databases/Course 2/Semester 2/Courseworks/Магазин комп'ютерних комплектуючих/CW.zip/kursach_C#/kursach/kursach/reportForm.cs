﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursach
{
    public partial class reportForm : Form
    {
        public reportForm()
        {
            InitializeComponent();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_reportProfit_Click(object sender, EventArgs e)
        {
            inputData_reportYProfitForm frm = new inputData_reportYProfitForm();
            frm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            inputData_reportMProfitForm frm = new inputData_reportMProfitForm();
            frm.Show();
        }

        private void btn_CntrctInfo_Click(object sender, EventArgs e)
        {
            inputData_reportContractForm frm = new inputData_reportContractForm();
            frm.Show();
        }
    }
}
