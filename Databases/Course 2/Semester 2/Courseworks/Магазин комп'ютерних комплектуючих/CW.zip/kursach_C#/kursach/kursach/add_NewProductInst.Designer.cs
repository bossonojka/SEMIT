﻿namespace kursach
{
    partial class add_NewProductInst
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.prdctInstanceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kursachDataSet = new kursach.kursachDataSet();
            this.prdctInstanceTableAdapter = new kursach.kursachDataSetTableAdapters.PrdctInstanceTableAdapter();
            this.txt_input2 = new System.Windows.Forms.TextBox();
            this.txt_input1 = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.rPrdctInfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rPrdctInfoTableAdapter = new kursach.kursachDataSetTableAdapters.RPrdctInfoTableAdapter();
            this.fKPrdctInstanceRPrdctInfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.r34BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.characteristicsTableAdapter = new kursach.kursachDataSetTableAdapters.CharacteristicsTableAdapter();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_input3 = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.prdctInstanceBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rPrdctInfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKPrdctInstanceRPrdctInfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r34BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_cancel
            // 
            this.btn_cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_cancel.Location = new System.Drawing.Point(161, 203);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(100, 35);
            this.btn_cancel.TabIndex = 22;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // btn_save
            // 
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_save.Location = new System.Drawing.Point(15, 203);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(100, 35);
            this.btn_save.TabIndex = 21;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 17);
            this.label1.TabIndex = 23;
            this.label1.Text = "Input contract id";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(158, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 17);
            this.label2.TabIndex = 24;
            this.label2.Text = "Input serial number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(12, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 17);
            this.label3.TabIndex = 25;
            this.label3.Text = "Input delivery price";
            // 
            // prdctInstanceBindingSource
            // 
            this.prdctInstanceBindingSource.DataMember = "PrdctInstance";
            this.prdctInstanceBindingSource.DataSource = this.kursachDataSet;
            // 
            // kursachDataSet
            // 
            this.kursachDataSet.DataSetName = "kursachDataSet";
            this.kursachDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // prdctInstanceTableAdapter
            // 
            this.prdctInstanceTableAdapter.ClearBeforeFill = true;
            // 
            // txt_input2
            // 
            this.txt_input2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txt_input2.Location = new System.Drawing.Point(15, 102);
            this.txt_input2.Name = "txt_input2";
            this.txt_input2.Size = new System.Drawing.Size(100, 23);
            this.txt_input2.TabIndex = 27;
            // 
            // txt_input1
            // 
            this.txt_input1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txt_input1.Location = new System.Drawing.Point(15, 34);
            this.txt_input1.Name = "txt_input1";
            this.txt_input1.Size = new System.Drawing.Size(100, 23);
            this.txt_input1.TabIndex = 28;
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.rPrdctInfoBindingSource;
            this.comboBox2.DisplayMember = "idProduct";
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(161, 35);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 29;
            this.comboBox2.ValueMember = "idProduct";
            // 
            // rPrdctInfoBindingSource
            // 
            this.rPrdctInfoBindingSource.DataMember = "RPrdctInfo";
            this.rPrdctInfoBindingSource.DataSource = this.kursachDataSet;
            // 
            // rPrdctInfoTableAdapter
            // 
            this.rPrdctInfoTableAdapter.ClearBeforeFill = true;
            // 
            // fKPrdctInstanceRPrdctInfoBindingSource
            // 
            this.fKPrdctInstanceRPrdctInfoBindingSource.DataMember = "FK_PrdctInstance_RPrdctInfo";
            this.fKPrdctInstanceRPrdctInfoBindingSource.DataSource = this.rPrdctInfoBindingSource;
            // 
            // r34BindingSource
            // 
            this.r34BindingSource.DataMember = "R_34";
            this.r34BindingSource.DataSource = this.rPrdctInfoBindingSource;
            // 
            // characteristicsTableAdapter
            // 
            this.characteristicsTableAdapter.ClearBeforeFill = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(158, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 17);
            this.label4.TabIndex = 30;
            this.label4.Text = "Choose product";
            // 
            // txt_input3
            // 
            this.txt_input3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txt_input3.Location = new System.Drawing.Point(161, 102);
            this.txt_input3.Name = "txt_input3";
            this.txt_input3.Size = new System.Drawing.Size(100, 23);
            this.txt_input3.TabIndex = 31;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(15, 164);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 32;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(12, 144);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 17);
            this.label5.TabIndex = 33;
            this.label5.Text = "Input delivery data";
            // 
            // add_NewProductInst
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(307, 250);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.txt_input3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.txt_input1);
            this.Controls.Add(this.txt_input2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_save);
            this.Name = "add_NewProductInst";
            this.Text = "add_NewProductInst";
            this.Load += new System.EventHandler(this.add_NewProductInst_Load);
            ((System.ComponentModel.ISupportInitialize)(this.prdctInstanceBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kursachDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rPrdctInfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKPrdctInstanceRPrdctInfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r34BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private kursachDataSet kursachDataSet;
        private System.Windows.Forms.BindingSource prdctInstanceBindingSource;
        private kursachDataSetTableAdapters.PrdctInstanceTableAdapter prdctInstanceTableAdapter;
        private System.Windows.Forms.TextBox txt_input2;
        private System.Windows.Forms.TextBox txt_input1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.BindingSource rPrdctInfoBindingSource;
        private kursachDataSetTableAdapters.RPrdctInfoTableAdapter rPrdctInfoTableAdapter;
        private System.Windows.Forms.BindingSource fKPrdctInstanceRPrdctInfoBindingSource;
        private System.Windows.Forms.BindingSource r34BindingSource;
        private kursachDataSetTableAdapters.CharacteristicsTableAdapter characteristicsTableAdapter;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_input3;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label5;
    }
}