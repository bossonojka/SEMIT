SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[add_ProviderInfo](@id int, @idAdress int)
AS
BEGIN	
	SET NOCOUNT ON;
		INSERT INTO [dbo].[RProvider]
		VALUES (@id, @idAdress)
END

