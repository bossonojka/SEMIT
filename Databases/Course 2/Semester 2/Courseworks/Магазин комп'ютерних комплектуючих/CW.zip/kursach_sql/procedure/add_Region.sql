SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[add_Region](@id int, @idContry int, @name text)
AS
BEGIN	
	SET NOCOUNT ON;
		INSERT INTO [dbo].[SRegion]
		VALUES (@id, @idContry, @name)
END
