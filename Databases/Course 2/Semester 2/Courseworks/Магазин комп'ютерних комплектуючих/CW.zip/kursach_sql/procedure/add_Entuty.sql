SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[add_Entity](@idProv int, @compName varchar(20), @taxNmbr text, @docVatNmbr text )
AS
BEGIN
	SET NOCOUNT ON;
		INSERT INTO [dbo].[Entity]
		VALUES (@compName, @taxNmbr, @docVatNmbr, @idProv)
END
GO
