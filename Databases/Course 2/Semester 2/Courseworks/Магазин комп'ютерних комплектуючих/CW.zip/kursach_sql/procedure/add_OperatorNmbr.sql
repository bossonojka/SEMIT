SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[add_OperatorNumb](@idOperNmbr int, @idOperator int, @idCntry int, @operNmbr smallint)
AS
BEGIN
	SET NOCOUNT ON;
		INSERT INTO [dbo].[COperatorNumber]
		VALUES (@idOperNmbr, @idOperator, @idCntry, @operNmbr)    
END
