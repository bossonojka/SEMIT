SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[add_Gender](@idGender int, @genderName varchar(20))
AS
BEGIN
	SET NOCOUNT ON;
		INSERT INTO [dbo].[CGender]
		VALUES(@idGender, @genderName)
END