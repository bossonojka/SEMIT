USE [kursach]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[update_Locality](@id int, @idRegion int, @name varchar(20))
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @check int
	SELECT @check=COUNT(idLocality) FROM SLocality WHERE localityName=RTRIM(@name) and idRegion = @idRegion
	IF(@check=0)
		BEGIN
		UPDATE SLocality SET localityName=@name, idRegion=@idRegion, idLocality=@id
		END
	ELSE ROLLBACK
END
GO
