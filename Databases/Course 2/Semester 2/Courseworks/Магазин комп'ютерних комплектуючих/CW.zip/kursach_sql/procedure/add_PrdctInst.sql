SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[add_PrdctInst](@id int, @serialNmbr int, @manufactDate datetime2(0))
AS
BEGIN
	SET NOCOUNT ON;
		INSERT INTO [dbo].[PrdctInstance]
		VALUES (@id, @serialNmbr, @manufactDate)
END

