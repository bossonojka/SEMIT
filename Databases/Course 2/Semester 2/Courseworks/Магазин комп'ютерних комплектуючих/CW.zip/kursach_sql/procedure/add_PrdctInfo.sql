SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[add_PrdctInfo](@id int, @idModel int, @idTrdGrp int , @warnty smallint)
AS
BEGIN
	SET NOCOUNT ON;
		INSERT INTO [dbo].[RPrdctInfo]
		VALUES (@id, @idModel, @idTrdGrp, @warnty)
END
