SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[add_Parameter](@id int, @idUnit int, @name text)
AS
BEGIN	
	SET NOCOUNT ON;
		INSERT INTO [dbo].[SParameter]
		VALUES (@id, @idUnit, @name)
END
