USE[kursach]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[update_Operator](@idOperator int, @name varchar(20))
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @check int
	SELECT @check=COUNT(idOperator) FROM COperator WHERE operatorName=RTRIM(@name)
	IF(@check=0)
		BEGIN
		UPDATE COperator SET operatorName=RTRIM(@name) WHERE idOperator=@idOperator
		END
	ELSE ROLLBACK
END
GO
