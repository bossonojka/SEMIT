USE [kursach]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[update_TrdGrp](@id int, @name varchar(20))
AS
BEGIN
	SET NOCOUNT ON;
	UPDATE STrdGrp SET trdGrpName=RTRIM(@name) WHERE idTrdGrp=@id
END
GO
