use[kursach]
go
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
alter procedure dbo.sp_SaleChekd(@var int)
as
begin
	set nocount on
	select JSale.idSale, JSale.saleDate, RSaleDetail.serialNumber, RSaleDetail.sellPrice,
				STrdGrp.trdGrpName, (RTRIM(CManufacturer.manufacturerName) +' '+ SModel.modelName) AS Model
	from JSale left outer join RSaleDetail ON JSale.idSale = RSaleDetail.idSale left outer join Storage
			on RSaleDetail.serialNumber = Storage.serialNumber left outer join PrdctInstance on Storage.serialNumber = PrdctInstance.serialNumber
				left outer join RPrdctInfo on PrdctInstance.idProduct = RPrdctInfo.idProduct left outer join STrdGrp on RPrdctInfo.idTrdGrp = STrdGrp.idTrdGrp
					left outer join SModel on RPrdctInfo.idModel = SModel.idModel  LEFT OUTER JOIN CManufacturer ON SModel.idManufactrer = CManufacturer.idManufactrer
	where (JSale.idSale = @var)
end