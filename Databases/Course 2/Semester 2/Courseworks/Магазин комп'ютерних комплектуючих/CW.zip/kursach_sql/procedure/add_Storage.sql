SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[add_Storage](@idContrat int, @serialNmbr int, @dlvryPrice int)
AS
BEGIN	
	SET NOCOUNT ON;
		INSERT INTO [dbo].[Storage]
		VALUES (@idContrat, @serialNmbr, @dlvryPrice)
END
