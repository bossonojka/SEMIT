SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[add_Adress](@id int, @idStreet int, @houseNbr text)
AS
BEGIN
	SET NOCOUNT ON;
		INSERT INTO [dbo].[RAdress]
		VALUES (@id, @idStreet, @houseNbr)
END

