USE [kursach]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[update_Unit](@id int, @name varchar(20))
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @check int
	SELECT @check=COUNT(idUnit) FROM CUnit WHERE unitName=RTRIM(@name)
	IF(@check=0)
		BEGIN
		UPDATE CUnit SET unitName=RTRIM(@name) WHERE idUnit=@id
		END
	ELSE ROLLBACK
END
GO
