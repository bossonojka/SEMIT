SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[add_Refund](@details text, @idRef int,  @idRefType int, @serialNmbr int)
AS
BEGIN
	SET NOCOUNT ON;
		INSERT INTO [dbo].[JRefund]
		VALUES(@details, @idRef, @idRefType, @serialNmbr)
END

