SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[add_TrdGrp](@id int, @name text)
AS
BEGIN	
	SET NOCOUNT ON;
		INSERT INTO [dbo].[STrdGrp]
		VALUES (@id, @name)
END
