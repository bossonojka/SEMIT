SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[add_Locality](@id int, @idRegion int, @name text)
AS
BEGIN
	SET NOCOUNT ON;
		INSERT INTO [dbo].[SLocality]
		VALUES (@id, @idRegion, @name)
END

