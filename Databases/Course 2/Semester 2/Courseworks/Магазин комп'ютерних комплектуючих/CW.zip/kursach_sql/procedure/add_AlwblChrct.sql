SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[add_AllowableChrtrsc] (@idTrdGrp int, @idParameter int)
AS
BEGIN	
	SET NOCOUNT ON;	
		INSERT INTO [dbo].[AllowableChrtrsc]
		VALUES (@idTrdGrp, @idParameter)
END
