SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[add_Manufact](@idManufact int, @manufactName varchar(20))
AS
BEGIN
	SET NOCOUNT ON;
		INSERT INTO [dbo].[CManufacturer]
		VALUES (@idManufact, @manufactName)
END

