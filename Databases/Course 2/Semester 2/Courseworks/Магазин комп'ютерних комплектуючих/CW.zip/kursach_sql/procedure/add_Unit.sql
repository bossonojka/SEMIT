SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[add_Unit](@id int, @name varchar(20))
AS
BEGIN
	SET NOCOUNT ON;
		INSERT INTO [dbo].[CUnit]
		VALUES(@id, @name)
END

