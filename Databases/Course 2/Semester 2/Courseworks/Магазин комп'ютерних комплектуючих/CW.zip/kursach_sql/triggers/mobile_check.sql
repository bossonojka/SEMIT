USE [kursach]
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER mobile_check
   ON  [dbo].[MobilePhone]
   AFTER INSERT,UPDATE not for replication
AS 
BEGIN
	SET NOCOUNT ON;
	DECLARE @var1 int
	DECLARE @check int
	SELECT @var1 = idPhone from inserted
	SELECT @check = count(LandlinePhone.idPhone) from LandlinePhone WHERE idPhone = @var1
	IF (@check>0)
	BEGIN
	ROLLBACK
	END
END