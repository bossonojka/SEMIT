USE [kursach]
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER not_null_date
   ON  RContract
   AFTER INSERT NOT FOR REPLICATION
AS 

BEGIN
SET NOCOUNT ON;

DECLARE @new_dgvr_date datetime
DECLARE @new_dgvr_nomer int
SELECT @new_dgvr_nomer = idContract, @new_dgvr_date = contractDate FROM inserted
	IF @new_dgvr_date IS NULL
		BEGIN
		UPDATE RContract SET contractDate=GETDATE() WHERE idContract = @new_dgvr_nomer
	END
END
