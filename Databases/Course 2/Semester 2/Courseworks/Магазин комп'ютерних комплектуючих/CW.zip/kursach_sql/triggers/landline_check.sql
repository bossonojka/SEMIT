USE [kursach]
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER landline_check
   ON  [dbo].[LandlinePhone]
   AFTER INSERT,UPDATE NOT FOR REPLICATION
AS 
BEGIN
	SET NOCOUNT ON;
	SET NOCOUNT ON;
	DECLARE @var1 int
	DECLARE @check int
	SELECT @var1 = idPhone from inserted
	SELECT @check = count(MobilePhone.idPhone) from MobilePhone WHERE idPhone = @var1
	IF (@check>0)
	BEGIN
	ROLLBACK
	END  

END
GO
