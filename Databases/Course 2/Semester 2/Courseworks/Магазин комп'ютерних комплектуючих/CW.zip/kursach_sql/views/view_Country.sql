use [kursach]
go
create view view_Country as
select *
from SCountry