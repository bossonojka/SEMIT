use [kursach]
go
create view view_Model as 
select SModel.idModel, (RTRIM(CManufacturer.manufacturerName) +' '+ SModel.modelName) AS Model
from SModel LEFT OUTER JOIN CManufacturer ON SModel.idManufactrer = CManufacturer.idManufactrer