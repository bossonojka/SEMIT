use [kursach]
go
create view view_Sale as
select JSale.idSale, (RTRIM (RBuyer.firstName) +' '+ RBuyer.secondName) AS Buyer, (RTRIM(SStaff.firstName) +
												' '+ SStaff.secondName) AS Seller
from JSale LEFT OUTER JOIN RBuyer ON JSale.idBuyer = RBuyer.idBuyer 
			LEFT OUTER JOIN SStaff ON JSale.idStaff = SStaff.idStaff