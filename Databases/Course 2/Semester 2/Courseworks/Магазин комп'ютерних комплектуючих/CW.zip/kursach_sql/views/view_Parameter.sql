use [kursach]
go
create view view_Parameter as
select SParameter.idParameter, SParameter.parameterName, CUnit.unitName
from SParameter LEFT OUTER JOIN CUnit ON SParameter.idUnit = CUnit.idUnit