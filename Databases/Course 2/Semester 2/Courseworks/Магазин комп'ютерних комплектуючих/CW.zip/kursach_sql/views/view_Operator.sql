use [kursach]
go
create view view_Operator as
select *
from COperator