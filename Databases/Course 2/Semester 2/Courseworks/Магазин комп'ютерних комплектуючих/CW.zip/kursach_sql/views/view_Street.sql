use [kursach]
go
create view view_Street as
select SStreet.idStreet, SStreet.streetName, CStrtType.typeName, SLocality.localityName
from SStreet LEFT OUTER JOIN CStrtType ON SStreet.idType = CStrtType.idType LEFT OUTER JOIN SLocality
				 ON SStreet.idLocality = SLocality.idLocality