use [kursach]
go
create view view_StreetType as
select *
from CStrtType