use [kursach]
go
create view view_Gender as
select *
from CGender