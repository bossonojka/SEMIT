use [kursach]
go
create view view_TrdGrp as
select * 
from STrdGrp