USE [kursach]
GO
CREATE VIEW view_Provider AS
SELECT RProvider.idProvider, ISNULL(Entity.companyName,RTRIM(Individual.firstName) +
							' '+ SUBSTRING(Individual.secondName, 1, 1)) AS _Provider
FROM RProvider LEFT OUTER JOIN Entity ON RProvider.idProvider = Entity.idProvider 
					LEFT OUTER JOIN Individual ON RProvider.idProvider = Individual.idProvider