use [kursach]
go
create view view_Locality as
select SLocality.idLocality, SLocality.localityName, SRegion.regionName
from SLocality LEFT OUTER JOIN SRegion ON SLocality.idRegion = SRegion.idRegion