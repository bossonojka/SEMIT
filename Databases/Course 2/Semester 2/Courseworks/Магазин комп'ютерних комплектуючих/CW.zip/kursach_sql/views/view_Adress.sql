use [kursach]
go
create view view_Adress as
select  RAdress.idAdress, RTRIM((SLocality.localityName)+', '+ (SStreet.streetName
									+' '+SUBSTRING(CStrtType.typeName,1, 3) +'.')) AS Adress,  RAdress.houseNmbr
from RAdress LEFT OUTER JOIN SStreet ON RAdress.idStreet = SStreet.idStreet
				 LEFT OUTER JOIN SLocality ON SLocality.idLocality = SStreet.idLocality
					LEFT OUTER JOIN CStrtType ON SStreet.idType = CStrtType.idType