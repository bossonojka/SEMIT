use	[kursach]
go
create view view_Unit as
select CUnit.idUnit, CUnit.unitName
from CUnit