﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class Pasport : Form
    {
        public Pasport()
        {
            InitializeComponent();
        }

        private void Form10_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Рекламные_агенты". При необходимости она может быть перемещена или удалена.
            this.рекламные_агентыTableAdapter.Fill(this.courseWorkBDDataSet.Рекламные_агенты);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.паспортные_данные_РА". При необходимости она может быть перемещена или удалена.
            this.паспортные_данные_РАTableAdapter.Fill(this.courseWorkBDDataSet.паспортные_данные_РА);

        }
    }
}
