﻿using CourseWork;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class AdreesDoovor : Form
    {
        public AdreesDoovor()
        {
            InitializeComponent();
            dataGridView1.DataError += new DataGridViewDataErrorEventHandler(DataGridView1_DataError);
           
        }

        public void DataGridView1_DataError(object sender, DataGridViewDataErrorEventArgs anError)
        {
            MessageBox.Show("Ошибка ввода!");
           
                anError.ThrowException = false;
           
            
        }

        private void Form17_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.View_4". При необходимости она может быть перемещена или удалена.
            this.view_4TableAdapter.Fill(this.courseWorkBDDataSet.View_4);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Адрес". При необходимости она может быть перемещена или удалена.
            this.адресTableAdapter.Fill(this.courseWorkBDDataSet.Адрес);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Договоры". При необходимости она может быть перемещена или удалена.
            this.договорыTableAdapter.Fill(this.courseWorkBDDataSet.Договоры);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Адрес_по_договорам". При необходимости она может быть перемещена или удалена.
            this.адрес_по_договорамTableAdapter.Fill(this.courseWorkBDDataSet.Адрес_по_договорам);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2;
        }

      

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Подтвердите действие", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                {
                    CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                    Адрес_по_договорам rm = new Адрес_по_договорам();

                    int dog;
                    Int32.TryParse(comboBox1.SelectedValue.ToString(), out dog);
                    rm.код_договора = dog;

                    int ad;
                    Int32.TryParse(comboBox1.SelectedValue.ToString(), out ad);
                    rm.код_адреса = ad;

                    int kol;
                    Int32.TryParse(textBox3.Text, out kol);
                    rm.количество = kol;

                    int price;
                    Int32.TryParse(textBox4.Text, out price);
                    rm.стоимость_грн = price;

                    context.Адрес_по_договорам.Add(rm);
                    context.SaveChanges();
                    this.адрес_по_договорамTableAdapter.Fill(this.courseWorkBDDataSet.Адрес_по_договорам);

                    tabControl1.SelectedTab = tabPage1;
                }
            }
            catch {
                Error frm = new Error();
                frm.Show();
            }
        }


      
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Вы действительно хотите удалить этот адрес по договорам?\nВсе связанные данные будут удалены", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                {
                    int index = dataGridView1.CurrentCell.RowIndex;

                    CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                    int p = int.Parse(dataGridView1.Rows[index].Cells["коддоговораDataGridViewTextBoxColumn"].Value.ToString());
                    
                    context.Адрес_по_договорам.Remove(context.Адрес_по_договорам.Find(p));
                    context.SaveChanges();
                    this.адрес_по_договорамTableAdapter.Fill(this.courseWorkBDDataSet.Адрес_по_договорам);
                    dataGridView1.Refresh();
                }
            }
            catch { }
        }
    }
}
