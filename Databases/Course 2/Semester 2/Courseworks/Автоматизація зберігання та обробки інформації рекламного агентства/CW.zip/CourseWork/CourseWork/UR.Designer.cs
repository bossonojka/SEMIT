﻿namespace CourseWork
{
    partial class UR
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.courseWorkBDDataSet = new CourseWork.CourseWorkBDDataSet();
            this.юридическийBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.юридическийTableAdapter = new CourseWork.CourseWorkBDDataSetTableAdapters.ЮридическийTableAdapter();
            this.юридическийBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.кодрекламодателяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.courseWorkBDDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.юридическийBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.юридическийBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодрекламодателяDataGridViewTextBoxColumn,
            this.названиеDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.юридическийBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(12, 12);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(254, 104);
            this.dataGridView2.TabIndex = 1;
            // 
            // courseWorkBDDataSet
            // 
            this.courseWorkBDDataSet.DataSetName = "CourseWorkBDDataSet";
            this.courseWorkBDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // юридическийBindingSource
            // 
            this.юридическийBindingSource.DataMember = "Юридический";
            this.юридическийBindingSource.DataSource = this.courseWorkBDDataSet;
            // 
            // юридическийTableAdapter
            // 
            this.юридическийTableAdapter.ClearBeforeFill = true;
            // 
            // юридическийBindingSource1
            // 
            this.юридическийBindingSource1.DataMember = "Юридический";
            this.юридическийBindingSource1.DataSource = this.courseWorkBDDataSet;
            // 
            // кодрекламодателяDataGridViewTextBoxColumn
            // 
            this.кодрекламодателяDataGridViewTextBoxColumn.DataPropertyName = "код_рекламодателя";
            this.кодрекламодателяDataGridViewTextBoxColumn.HeaderText = "код_рекламодателя";
            this.кодрекламодателяDataGridViewTextBoxColumn.Name = "кодрекламодателяDataGridViewTextBoxColumn";
            this.кодрекламодателяDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // названиеDataGridViewTextBoxColumn
            // 
            this.названиеDataGridViewTextBoxColumn.DataPropertyName = "название";
            this.названиеDataGridViewTextBoxColumn.HeaderText = "название";
            this.названиеDataGridViewTextBoxColumn.Name = "названиеDataGridViewTextBoxColumn";
            // 
            // Form11
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 125);
            this.Controls.Add(this.dataGridView2);
            this.Name = "Form11";
            this.Text = "Юридический";
            this.Load += new System.EventHandler(this.Form11_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.courseWorkBDDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.юридическийBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.юридическийBindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView2;
        private CourseWorkBDDataSet courseWorkBDDataSet;
        private System.Windows.Forms.BindingSource юридическийBindingSource;
        private CourseWorkBDDataSetTableAdapters.ЮридическийTableAdapter юридическийTableAdapter;
        private System.Windows.Forms.BindingSource юридическийBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодрекламодателяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеDataGridViewTextBoxColumn;
    }
}