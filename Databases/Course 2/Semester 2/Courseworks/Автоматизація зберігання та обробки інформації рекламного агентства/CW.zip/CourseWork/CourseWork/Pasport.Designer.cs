﻿namespace CourseWork
{
    partial class Pasport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.серияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерпаспортаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датавыдачипаспортаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кемвыданпаспортDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ппРАDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.рекламныеагентыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.courseWorkBDDataSet = new CourseWork.CourseWorkBDDataSet();
            this.паспортныеданныеРАBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.паспортные_данные_РАTableAdapter = new CourseWork.CourseWorkBDDataSetTableAdapters.паспортные_данные_РАTableAdapter();
            this.рекламные_агентыTableAdapter = new CourseWork.CourseWorkBDDataSetTableAdapters.Рекламные_агентыTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.рекламныеагентыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.courseWorkBDDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.паспортныеданныеРАBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.серияDataGridViewTextBoxColumn,
            this.номерпаспортаDataGridViewTextBoxColumn,
            this.датавыдачипаспортаDataGridViewTextBoxColumn,
            this.кемвыданпаспортDataGridViewTextBoxColumn,
            this.ппРАDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.паспортныеданныеРАBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(13, 13);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(555, 150);
            this.dataGridView1.TabIndex = 0;
            // 
            // серияDataGridViewTextBoxColumn
            // 
            this.серияDataGridViewTextBoxColumn.DataPropertyName = "серия";
            this.серияDataGridViewTextBoxColumn.HeaderText = "серия";
            this.серияDataGridViewTextBoxColumn.Name = "серияDataGridViewTextBoxColumn";
            // 
            // номерпаспортаDataGridViewTextBoxColumn
            // 
            this.номерпаспортаDataGridViewTextBoxColumn.DataPropertyName = "номер_паспорта";
            this.номерпаспортаDataGridViewTextBoxColumn.HeaderText = "номер_паспорта";
            this.номерпаспортаDataGridViewTextBoxColumn.Name = "номерпаспортаDataGridViewTextBoxColumn";
            // 
            // датавыдачипаспортаDataGridViewTextBoxColumn
            // 
            this.датавыдачипаспортаDataGridViewTextBoxColumn.DataPropertyName = "дата_выдачи_паспорта";
            this.датавыдачипаспортаDataGridViewTextBoxColumn.HeaderText = "дата_выдачи_паспорта";
            this.датавыдачипаспортаDataGridViewTextBoxColumn.Name = "датавыдачипаспортаDataGridViewTextBoxColumn";
            // 
            // кемвыданпаспортDataGridViewTextBoxColumn
            // 
            this.кемвыданпаспортDataGridViewTextBoxColumn.DataPropertyName = "кем_выдан_паспорт";
            this.кемвыданпаспортDataGridViewTextBoxColumn.HeaderText = "кем_выдан_паспорт";
            this.кемвыданпаспортDataGridViewTextBoxColumn.Name = "кемвыданпаспортDataGridViewTextBoxColumn";
            // 
            // ппРАDataGridViewTextBoxColumn
            // 
            this.ппРАDataGridViewTextBoxColumn.DataPropertyName = "№пп_РА";
            this.ппРАDataGridViewTextBoxColumn.DataSource = this.рекламныеагентыBindingSource;
            this.ппРАDataGridViewTextBoxColumn.DisplayMember = "фамилия";
            this.ппРАDataGridViewTextBoxColumn.HeaderText = "№пп_РА";
            this.ппРАDataGridViewTextBoxColumn.Name = "ппРАDataGridViewTextBoxColumn";
            this.ппРАDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ппРАDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ппРАDataGridViewTextBoxColumn.ValueMember = "№пп_РА";
            // 
            // рекламныеагентыBindingSource
            // 
            this.рекламныеагентыBindingSource.DataMember = "Рекламные_агенты";
            this.рекламныеагентыBindingSource.DataSource = this.courseWorkBDDataSet;
            // 
            // courseWorkBDDataSet
            // 
            this.courseWorkBDDataSet.DataSetName = "CourseWorkBDDataSet";
            this.courseWorkBDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // паспортныеданныеРАBindingSource
            // 
            this.паспортныеданныеРАBindingSource.DataMember = "паспортные_данные_РА";
            this.паспортныеданныеРАBindingSource.DataSource = this.courseWorkBDDataSet;
            // 
            // паспортные_данные_РАTableAdapter
            // 
            this.паспортные_данные_РАTableAdapter.ClearBeforeFill = true;
            // 
            // рекламные_агентыTableAdapter
            // 
            this.рекламные_агентыTableAdapter.ClearBeforeFill = true;
            // 
            // Pasport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(596, 246);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Pasport";
            this.Text = "Паспортные данные";
            this.Load += new System.EventHandler(this.Form10_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.рекламныеагентыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.courseWorkBDDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.паспортныеданныеРАBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CourseWorkBDDataSet courseWorkBDDataSet;
        private System.Windows.Forms.BindingSource паспортныеданныеРАBindingSource;
        private CourseWorkBDDataSetTableAdapters.паспортные_данные_РАTableAdapter паспортные_данные_РАTableAdapter;
        private System.Windows.Forms.BindingSource рекламныеагентыBindingSource;
        private CourseWorkBDDataSetTableAdapters.Рекламные_агентыTableAdapter рекламные_агентыTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn серияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерпаспортаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датавыдачипаспортаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кемвыданпаспортDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn ппРАDataGridViewTextBoxColumn;
    }
}