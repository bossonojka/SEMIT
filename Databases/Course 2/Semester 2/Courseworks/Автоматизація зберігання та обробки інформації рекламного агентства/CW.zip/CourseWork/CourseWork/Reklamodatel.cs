﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class Reklamodatel : Form
    {
        public Reklamodatel()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Физический". При необходимости она может быть перемещена или удалена.
            this.физическийTableAdapter.Fill(this.courseWorkBDDataSet.Физический);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Юридический". При необходимости она может быть перемещена или удалена.
            this.юридическийTableAdapter.Fill(this.courseWorkBDDataSet.Юридический);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Банк". При необходимости она может быть перемещена или удалена.
            this.банкTableAdapter.Fill(this.courseWorkBDDataSet.Банк);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.View_1". При необходимости она может быть перемещена или удалена.
            this.view_1TableAdapter.Fill(this.courseWorkBDDataSet.View_1);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Рекламодатель". При необходимости она может быть перемещена или удалена.
            this.рекламодательTableAdapter.Fill(this.courseWorkBDDataSet.Рекламодатель);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2;
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

       
        private void button9_Click(object sender, EventArgs e)
        {
            UR frm = new UR();
            frm.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            HarRekl frm = new HarRekl();
            frm.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            ZagalUrFiz frm = new ZagalUrFiz();
            frm.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {

                textBox7.Text = "";
                textBox8.Text = "";
                textBox9.Text = "";
                textBox10.Text = "";
                textBox11.Text = "";


                textBox7.Visible = true;
                textBox11.Visible = true;
                textBox10.Visible = true;
                textBox9.Visible = true;
                textBox8.Visible = false;

                label9.Visible = false;
                label13.Visible = true;
                label8.Visible = true;
                label12.Visible = true;
                label11.Visible = true;
            }

            if (comboBox1.SelectedIndex == 1)
            {

                textBox7.Text = "";
                textBox8.Text = "";
                textBox9.Text = "";
                textBox10.Text = "";
                textBox11.Text = "";


                textBox7.Visible = true;
                textBox11.Visible = false;
                textBox10.Visible = false;
                textBox9.Visible = false;
                textBox8.Visible = true;

                label9.Visible = true;
                label13.Visible = false;
                label8.Visible = true;
                label12.Visible = false;
                label11.Visible = false;

            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage3;
        }

        private void button3_Click_2(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

        private void button4_Click_2(object sender, EventArgs e)
        {
            if (MessageBox.Show("Подтвердите действие", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
               
                CourseWorkBDEntities11 s = new CourseWorkBDEntities11();
                Рекламодатель p = new Рекламодатель();
                if (comboBox1.SelectedIndex == 0)
                {
                    p.Физический = new Физический();
                    p.Физический.фамилия = textBox11.Text;
                    p.Физический.имя = textBox10.Text;
                    p.Физический.отчество = textBox9.Text;
                   
                    int kod;
                    Int32.TryParse(textBox7.Text, out kod);
                    p.код_рекламодателя = kod;

                    s.Рекламодатель.Add(p);
                    s.SaveChanges();
                    this.физическийTableAdapter.Fill(this.courseWorkBDDataSet.Физический);

                    tabControl1.SelectedTab = tabPage1;
                }
                if (comboBox1.SelectedIndex == 1)
                {
                    p.Юридический = new Юридический();
                    p.Юридический.название = textBox8.Text;
                    int kod;
                    Int32.TryParse(textBox7.Text, out kod);
                    p.код_рекламодателя = kod;

                    s.Рекламодатель.Add(p);
                    s.SaveChanges();
                    this.юридическийTableAdapter.Fill(this.courseWorkBDDataSet.Юридический);
                    tabControl1.SelectedTab = tabPage2;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы действительно хотите удалить этого рекламодателя?\nВсе связанные данные будут удалены", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
            {
                try
                {
                    CourseWorkBDEntities11 s = new CourseWorkBDEntities11();
                    if (tabControl1.SelectedTab == tabPage1)
                    {
                        int index1 = dataGridView1.CurrentCell.RowIndex;
                        int post_fiz = int.Parse(dataGridView1.Rows[index1].Cells["кодрекламодателяDataGridViewTextBoxColumn"].Value.ToString());
                        s.Физический.Remove(s.Физический.Find(post_fiz));
                        s.SaveChanges();
                        this.физическийTableAdapter.Fill(this.courseWorkBDDataSet.Физический);
                        dataGridView1.Refresh();



                    }
                    if (tabControl1.SelectedTab == tabPage2)
                    {
                        int index2 = dataGridView2.CurrentCell.RowIndex;
                        int post_yur = int.Parse(dataGridView2.Rows[index2].Cells["кодрекламодателяDataGridViewTextBoxColumn1"].Value.ToString());
                        s.Юридический.Remove(s.Юридический.Find(post_yur));
                        s.SaveChanges();
                        this.юридическийTableAdapter.Fill(this.courseWorkBDDataSet.Юридический);
                        dataGridView2.Refresh();
                    }
                }
                catch (Exception) { }
            }
        }
    }
    }
