﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class Adress : Form
    {
        public Adress()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {            
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Объект". При необходимости она может быть перемещена или удалена.
            this.объектTableAdapter.Fill(this.courseWorkBDDataSet.Объект);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Вид_места_размещения". При необходимости она может быть перемещена или удалена.
            this.вид_места_размещенияTableAdapter.Fill(this.courseWorkBDDataSet.Вид_места_размещения);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Адрес". При необходимости она может быть перемещена или удалена.
            this.адресTableAdapter.Fill(this.courseWorkBDDataSet.Адрес);
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Подтвердите действие", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                Адрес rm = new Адрес();

                int nomer;
                Int32.TryParse(textBox1.Text, out nomer);
                rm.код_адреса = nomer;

                int ob;
                Int32.TryParse(comboBox2.SelectedValue.ToString(), out ob);
                rm.код_объекта = ob;

                int vid;
                int.TryParse(comboBox1.SelectedValue.ToString(), out vid);
                rm.код_вида_размещения = vid;

                int et;
                Int32.TryParse(textBox2.Text, out et);
                rm.этаж = et;

                context.Адрес.Add(rm);
                context.SaveChanges();
                this.адресTableAdapter.Fill(courseWorkBDDataSet.Адрес);
                tabControl1.SelectedTab = tabPage1;
            }
        
    }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Вы действительно хотите удалить этот адрес?\nВсе связанные данные будут удалены", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                {
                    int index = dataGridView1.CurrentCell.RowIndex;
                    CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                    int numer = int.Parse(dataGridView1.Rows[index].Cells["кодадресаDataGridViewTextBoxColumn"].Value.ToString());
                    context.Адрес.Remove(context.Адрес.Find(numer));
                    context.SaveChanges();
                    this.адресTableAdapter.Fill(this.courseWorkBDDataSet.Адрес);
                    dataGridView1.Refresh();
                }
            }
            catch { }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Objekt frm = new Objekt();
            frm.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            HaraktAdress frm = new HaraktAdress();
            frm.Show();
        }
    }
}
