﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class Harakteristiki : Form
    {
        public Harakteristiki()
        {
            InitializeComponent();
        }

        private void Form15_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Единица_измерения". При необходимости она может быть перемещена или удалена.
            this.единица_измеренияTableAdapter.Fill(this.courseWorkBDDataSet.Единица_измерения);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Характеристики". При необходимости она может быть перемещена или удалена.
            this.характеристикиTableAdapter.Fill(this.courseWorkBDDataSet.Характеристики);

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Подтвердите действие", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                Характеристики rm = new Характеристики();


                int kod;
                Int32.TryParse(textBox1.Text, out kod);
                rm.код_характеристики = kod;

                rm.характеристика = textBox2.Text;

                int tip;
                Int32.TryParse(comboBox1.SelectedValue.ToString(), out tip);
                rm.код_единицы_измерения = tip;

                context.Характеристики.Add(rm);
                context.SaveChanges();
                this.характеристикиTableAdapter.Fill(this.courseWorkBDDataSet.Характеристики);
                tabControl1.SelectedTab = tabPage1;

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Вы действительно хотите удалить эту характеристику?\nВсе связанные данные будут удалены", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                {
                    int index = dataGridView1.CurrentCell.RowIndex;
                    CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                    int kod = int.Parse(dataGridView1.Rows[index].Cells["кодхарактеристикиDataGridViewTextBoxColumn"].Value.ToString());
                    context.Характеристики.Remove(context.Характеристики.Find(kod));
                    context.SaveChanges();
                    this.характеристикиTableAdapter.Fill(this.courseWorkBDDataSet.Характеристики);
                    dataGridView1.Refresh();
                }
            }
            catch { }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            CI frm = new CI();
            frm.Show();
        }
    }
}
