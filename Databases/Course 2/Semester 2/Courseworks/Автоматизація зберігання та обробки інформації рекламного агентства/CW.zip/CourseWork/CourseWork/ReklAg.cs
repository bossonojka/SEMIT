﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CourseWork;


namespace CourseWork
{
    public partial class ReklAg : Form
    {
        public ReklAg()
        {
            InitializeComponent();
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Пол_рекламного_агента". При необходимости она может быть перемещена или удалена.
            this.пол_рекламного_агентаTableAdapter.Fill(this.courseWorkBDDataSet.Пол_рекламного_агента);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Рекламные_агенты". При необходимости она может быть перемещена или удалена.
            this.рекламные_агентыTableAdapter.Fill(this.courseWorkBDDataSet.Рекламные_агенты);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Подтвердите действие", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                Рекламные_агенты rm = new Рекламные_агенты();


                int numer;
                Int32.TryParse(textBox1.Text, out numer);
                rm.C_пп_РА = numer;

                rm.фамилия = textBox2.Text;
                rm.имя = textBox3.Text;
                rm.отчество = textBox4.Text;
                rm.адрес_проживания = textBox5.Text;

                int pol;
                Int32.TryParse(comboBox1.SelectedValue.ToString(), out pol);
                rm.код_пола = pol;

                rm.день_рождение = dateTimePicker1.Value;
                rm.дата_начала_работы_в_агенстве = dateTimePicker2.Value;
               
                context.Рекламные_агенты.Add(rm);
                context.SaveChanges();
                this.рекламные_агентыTableAdapter.Fill(this.courseWorkBDDataSet.Рекламные_агенты);
                tabControl1.SelectedTab = tabPage1;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Вы действительно хотите удалить этого рекламного агента?\nВсе связанные данные будут удалены", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                {
                    int index = dataGridView1.CurrentCell.RowIndex;
                    CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                    int kod = int.Parse(dataGridView1.Rows[index].Cells["ппРАDataGridViewTextBoxColumn"].Value.ToString());
                    context.Рекламные_агенты.Remove(context.Рекламные_агенты.Find(kod));
                    context.SaveChanges();
                    this.рекламные_агентыTableAdapter.Fill(this.courseWorkBDDataSet.Рекламные_агенты);
                    dataGridView1.Refresh();
                }
            }
            catch { }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Pasport frm = new Pasport();
            frm.Show();
        }
    }
}
