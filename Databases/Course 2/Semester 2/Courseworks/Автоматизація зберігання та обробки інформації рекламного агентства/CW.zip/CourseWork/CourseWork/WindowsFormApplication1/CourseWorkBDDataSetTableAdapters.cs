﻿using CourseWork.CourseWorkBDDataSetTableAdapters;

namespace WindowsFormApplication1
{
    internal class CourseWorkBDDataSetTableAdapters
    {
        internal class sp_dgvr_sumTableAdapter : CourseWork.CourseWorkBDDataSetTableAdapters.sp_dgvr_sumTableAdapter
        {
        }
    }
}