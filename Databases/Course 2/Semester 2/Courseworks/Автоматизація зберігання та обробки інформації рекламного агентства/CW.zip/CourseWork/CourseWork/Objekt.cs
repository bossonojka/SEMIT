﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class Objekt : Form
    {
        public Objekt()
        {
            InitializeComponent();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Улица". При необходимости она может быть перемещена или удалена.
            this.улицаTableAdapter.Fill(this.courseWorkBDDataSet.Улица);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Тип_объекта". При необходимости она может быть перемещена или удалена.
            this.тип_объектаTableAdapter.Fill(this.courseWorkBDDataSet.Тип_объекта);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Объект". При необходимости она может быть перемещена или удалена.
            this.объектTableAdapter.Fill(this.courseWorkBDDataSet.Объект);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Вы действительно хотите удалить этот объект?\nВсе связанные данные будут удалены", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                {
                    int index = dataGridView1.CurrentCell.RowIndex;
                    CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                    int numer = int.Parse(dataGridView1.Rows[index].Cells["кодобъектаDataGridViewTextBoxColumn"].Value.ToString());
                    context.Объект.Remove(context.Объект.Find(numer));
                    context.SaveChanges();
                    this.объектTableAdapter.Fill(this.courseWorkBDDataSet.Объект);
                    dataGridView1.Refresh();
                }
            }
            catch { }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

        private void button4_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("Подтвердите действие", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                Объект rm = new Объект();


                int nomer;
                Int32.TryParse(textBox1.Text, out nomer);
                rm.код_объекта = nomer;

                int tip;
                Int32.TryParse(comboBox1.SelectedValue.ToString(), out tip);
                rm.код_типа_объекта = tip;

                int street;
                Int32.TryParse(comboBox2.SelectedValue.ToString(), out street);
                rm.код_улицы = street;

                rm.наименование = textBox2.Text;

                context.Объект.Add(rm);
                context.SaveChanges();
                this.объектTableAdapter.Fill(this.courseWorkBDDataSet.Объект);
                tabControl1.SelectedTab = tabPage1;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Street frm = new Street();
            frm.Show();
        }
    }
}
