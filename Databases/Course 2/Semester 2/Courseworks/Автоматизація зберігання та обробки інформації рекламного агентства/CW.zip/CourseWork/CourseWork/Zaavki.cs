﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class Zaavki : Form
    {
        public Zaavki()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet._Рекламный_материал_РМ_". При необходимости она может быть перемещена или удалена.
            this.рекламный_материал_РМ_TableAdapter.Fill(this.courseWorkBDDataSet._Рекламный_материал_РМ_);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Рекламные_агенты". При необходимости она может быть перемещена или удалена.
            this.рекламные_агентыTableAdapter.Fill(this.courseWorkBDDataSet.Рекламные_агенты);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.View_1". При необходимости она может быть перемещена или удалена.
            this.view_1TableAdapter.Fill(this.courseWorkBDDataSet.View_1);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Заявки_на_предоставление_РУ". При необходимости она может быть перемещена или удалена.
            this.заявки_на_предоставление_РУTableAdapter.Fill(this.courseWorkBDDataSet.Заявки_на_предоставление_РУ);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Подтвердите действие", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                Заявки_на_предоставление_РУ rm = new Заявки_на_предоставление_РУ();


                int nomer;
                Int32.TryParse(textBox1.Text, out nomer);
                rm.C_заявки = nomer;

                rm.дата_формирования_услуги = dateTimePicker1.Value;

              
                int kod;
                Int32.TryParse(comboBox1.SelectedValue.ToString(), out kod);
                rm.код_рекламодателя = kod;

                int RM;
                Int32.TryParse(comboBox2.SelectedValue.ToString(), out RM);
                rm.код_РМ = RM;

                int RA;
                Int32.TryParse(comboBox3.SelectedValue.ToString(), out RA);
                rm.C_пп_РА = RA;

                rm.дата_окончания_услуги = dateTimePicker2.Value;

                context.Заявки_на_предоставление_РУ.Add(rm);
                context.SaveChanges();
                this.заявки_на_предоставление_РУTableAdapter.Fill(this.courseWorkBDDataSet.Заявки_на_предоставление_РУ);
                tabControl1.SelectedTab = tabPage1;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Вы действительно хотите удалить эту заявку?\nВсе связанные данные будут удалены", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                {
                    int index = dataGridView1.CurrentCell.RowIndex;
                    CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                    int numer = int.Parse(dataGridView1.Rows[index].Cells["заявкиDataGridViewTextBoxColumn"].Value.ToString());
                    context.Заявки_на_предоставление_РУ.Remove(context.Заявки_на_предоставление_РУ.Find(numer));
                    context.SaveChanges();
                    this.заявки_на_предоставление_РУTableAdapter.Fill(this.courseWorkBDDataSet.Заявки_на_предоставление_РУ);
                    dataGridView1.Refresh();
                }
            }
            catch { }
        }
    }
}
