﻿namespace CourseWork
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.данныеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.рекламныеАгентыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.рекламодательToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.рекламодательToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.договорыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.адресаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.объектToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.улицаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.адресПоДоговорамToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.видМестаРазмещенияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.рекламныеАгентыToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.паспортныеДанныеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.характеристикиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.характеристикиПоВидуРекламногоМатериалаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.характеристикиАдресаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.дляВидаМестаРазмещенияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.владелецToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.договорыToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.данныеToolStripMenuItem,
            this.отчетToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(483, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // данныеToolStripMenuItem
            // 
            this.данныеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.рекламныеАгентыToolStripMenuItem,
            this.рекламодательToolStripMenuItem,
            this.рекламодательToolStripMenuItem1,
            this.договорыToolStripMenuItem,
            this.адресаToolStripMenuItem,
            this.рекламныеАгентыToolStripMenuItem1,
            this.характеристикиToolStripMenuItem,
            this.владелецToolStripMenuItem});
            this.данныеToolStripMenuItem.Name = "данныеToolStripMenuItem";
            this.данныеToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.данныеToolStripMenuItem.Text = "Данные";
            // 
            // рекламныеАгентыToolStripMenuItem
            // 
            this.рекламныеАгентыToolStripMenuItem.Name = "рекламныеАгентыToolStripMenuItem";
            this.рекламныеАгентыToolStripMenuItem.Size = new System.Drawing.Size(318, 22);
            this.рекламныеАгентыToolStripMenuItem.Text = "Рекламные материалы";
            this.рекламныеАгентыToolStripMenuItem.Click += new System.EventHandler(this.рекламныеАгентыToolStripMenuItem_Click);
            // 
            // рекламодательToolStripMenuItem
            // 
            this.рекламодательToolStripMenuItem.Name = "рекламодательToolStripMenuItem";
            this.рекламодательToolStripMenuItem.Size = new System.Drawing.Size(318, 22);
            this.рекламодательToolStripMenuItem.Text = "Заявки на предоставление рекламных услуг";
            this.рекламодательToolStripMenuItem.Click += new System.EventHandler(this.рекламодательToolStripMenuItem_Click);
            // 
            // рекламодательToolStripMenuItem1
            // 
            this.рекламодательToolStripMenuItem1.Name = "рекламодательToolStripMenuItem1";
            this.рекламодательToolStripMenuItem1.Size = new System.Drawing.Size(318, 22);
            this.рекламодательToolStripMenuItem1.Text = "Рекламодатель";
            this.рекламодательToolStripMenuItem1.Click += new System.EventHandler(this.рекламодательToolStripMenuItem1_Click);
            // 
            // договорыToolStripMenuItem
            // 
            this.договорыToolStripMenuItem.Name = "договорыToolStripMenuItem";
            this.договорыToolStripMenuItem.Size = new System.Drawing.Size(318, 22);
            this.договорыToolStripMenuItem.Text = "Договоры";
            this.договорыToolStripMenuItem.Click += new System.EventHandler(this.договорыToolStripMenuItem_Click);
            // 
            // адресаToolStripMenuItem
            // 
            this.адресаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.объектToolStripMenuItem,
            this.улицаToolStripMenuItem,
            this.адресПоДоговорамToolStripMenuItem,
            this.видМестаРазмещенияToolStripMenuItem});
            this.адресаToolStripMenuItem.Name = "адресаToolStripMenuItem";
            this.адресаToolStripMenuItem.Size = new System.Drawing.Size(318, 22);
            this.адресаToolStripMenuItem.Text = "Адреса";
            this.адресаToolStripMenuItem.Click += new System.EventHandler(this.адресаToolStripMenuItem_Click);
            // 
            // объектToolStripMenuItem
            // 
            this.объектToolStripMenuItem.Name = "объектToolStripMenuItem";
            this.объектToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.объектToolStripMenuItem.Text = "Объект";
            this.объектToolStripMenuItem.Click += new System.EventHandler(this.объектToolStripMenuItem_Click);
            // 
            // улицаToolStripMenuItem
            // 
            this.улицаToolStripMenuItem.Name = "улицаToolStripMenuItem";
            this.улицаToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.улицаToolStripMenuItem.Text = "Улица";
            this.улицаToolStripMenuItem.Click += new System.EventHandler(this.улицаToolStripMenuItem_Click);
            // 
            // адресПоДоговорамToolStripMenuItem
            // 
            this.адресПоДоговорамToolStripMenuItem.Name = "адресПоДоговорамToolStripMenuItem";
            this.адресПоДоговорамToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.адресПоДоговорамToolStripMenuItem.Text = "Адрес по договорам";
            this.адресПоДоговорамToolStripMenuItem.Click += new System.EventHandler(this.адресПоДоговорамToolStripMenuItem_Click);
            // 
            // видМестаРазмещенияToolStripMenuItem
            // 
            this.видМестаРазмещенияToolStripMenuItem.Name = "видМестаРазмещенияToolStripMenuItem";
            this.видМестаРазмещенияToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.видМестаРазмещенияToolStripMenuItem.Text = "Вид места размещения";
            this.видМестаРазмещенияToolStripMenuItem.Click += new System.EventHandler(this.видМестаРазмещенияToolStripMenuItem_Click);
            // 
            // рекламныеАгентыToolStripMenuItem1
            // 
            this.рекламныеАгентыToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.паспортныеДанныеToolStripMenuItem});
            this.рекламныеАгентыToolStripMenuItem1.Name = "рекламныеАгентыToolStripMenuItem1";
            this.рекламныеАгентыToolStripMenuItem1.Size = new System.Drawing.Size(318, 22);
            this.рекламныеАгентыToolStripMenuItem1.Text = "Рекламные агенты";
            this.рекламныеАгентыToolStripMenuItem1.Click += new System.EventHandler(this.рекламныеАгентыToolStripMenuItem1_Click);
            // 
            // паспортныеДанныеToolStripMenuItem
            // 
            this.паспортныеДанныеToolStripMenuItem.Name = "паспортныеДанныеToolStripMenuItem";
            this.паспортныеДанныеToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.паспортныеДанныеToolStripMenuItem.Text = "Паспортные данные";
            this.паспортныеДанныеToolStripMenuItem.Click += new System.EventHandler(this.паспортныеДанныеToolStripMenuItem_Click);
            // 
            // характеристикиToolStripMenuItem
            // 
            this.характеристикиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.характеристикиПоВидуРекламногоМатериалаToolStripMenuItem,
            this.характеристикиАдресаToolStripMenuItem,
            this.дляВидаМестаРазмещенияToolStripMenuItem});
            this.характеристикиToolStripMenuItem.Name = "характеристикиToolStripMenuItem";
            this.характеристикиToolStripMenuItem.Size = new System.Drawing.Size(318, 22);
            this.характеристикиToolStripMenuItem.Text = "Характеристики";
            this.характеристикиToolStripMenuItem.Click += new System.EventHandler(this.характеристикиToolStripMenuItem_Click);
            // 
            // характеристикиПоВидуРекламногоМатериалаToolStripMenuItem
            // 
            this.характеристикиПоВидуРекламногоМатериалаToolStripMenuItem.Name = "характеристикиПоВидуРекламногоМатериалаToolStripMenuItem";
            this.характеристикиПоВидуРекламногоМатериалаToolStripMenuItem.Size = new System.Drawing.Size(339, 22);
            this.характеристикиПоВидуРекламногоМатериалаToolStripMenuItem.Text = "Характеристики по виду рекламного материала";
            this.характеристикиПоВидуРекламногоМатериалаToolStripMenuItem.Click += new System.EventHandler(this.характеристикиПоВидуРекламногоМатериалаToolStripMenuItem_Click);
            // 
            // характеристикиАдресаToolStripMenuItem
            // 
            this.характеристикиАдресаToolStripMenuItem.Name = "характеристикиАдресаToolStripMenuItem";
            this.характеристикиАдресаToolStripMenuItem.Size = new System.Drawing.Size(339, 22);
            this.характеристикиАдресаToolStripMenuItem.Text = "Характеристики адреса";
            this.характеристикиАдресаToolStripMenuItem.Click += new System.EventHandler(this.характеристикиАдресаToolStripMenuItem_Click);
            // 
            // дляВидаМестаРазмещенияToolStripMenuItem
            // 
            this.дляВидаМестаРазмещенияToolStripMenuItem.Name = "дляВидаМестаРазмещенияToolStripMenuItem";
            this.дляВидаМестаРазмещенияToolStripMenuItem.Size = new System.Drawing.Size(339, 22);
            this.дляВидаМестаРазмещенияToolStripMenuItem.Text = "Для вида места размещения";
            this.дляВидаМестаРазмещенияToolStripMenuItem.Click += new System.EventHandler(this.дляВидаМестаРазмещенияToolStripMenuItem_Click);
            // 
            // владелецToolStripMenuItem
            // 
            this.владелецToolStripMenuItem.Name = "владелецToolStripMenuItem";
            this.владелецToolStripMenuItem.Size = new System.Drawing.Size(318, 22);
            this.владелецToolStripMenuItem.Text = "Владелец";
            this.владелецToolStripMenuItem.Click += new System.EventHandler(this.владелецToolStripMenuItem_Click);
            // 
            // отчетToolStripMenuItem
            // 
            this.отчетToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.договорыToolStripMenuItem1});
            this.отчетToolStripMenuItem.Name = "отчетToolStripMenuItem";
            this.отчетToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.отчетToolStripMenuItem.Text = "Отчет";
            // 
            // договорыToolStripMenuItem1
            // 
            this.договорыToolStripMenuItem1.Name = "договорыToolStripMenuItem1";
            this.договорыToolStripMenuItem1.Size = new System.Drawing.Size(130, 22);
            this.договорыToolStripMenuItem1.Text = "Договоры";
            this.договорыToolStripMenuItem1.Click += new System.EventHandler(this.договорыToolStripMenuItem1_Click);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(483, 365);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Рекламное агенство";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem данныеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem рекламныеАгентыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem рекламодательToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчетToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem рекламодательToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem договорыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem адресаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem объектToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem улицаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem рекламныеАгентыToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem паспортныеДанныеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem характеристикиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem владелецToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem адресПоДоговорамToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem договорыToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem характеристикиПоВидуРекламногоМатериалаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem характеристикиАдресаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem видМестаРазмещенияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem дляВидаМестаРазмещенияToolStripMenuItem;
    }
}