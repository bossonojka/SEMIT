﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class UR : Form
    {
        public UR()
        {
            InitializeComponent();
        }

        private void Form11_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Юридический". При необходимости она может быть перемещена или удалена.
            this.юридическийTableAdapter.Fill(this.courseWorkBDDataSet.Юридический);

        }
    }
}
