﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void рекламныеАгентыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReklMat frm = new ReklMat();
            frm.Show();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void рекламодательToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Zaavki frm = new Zaavki();
            frm.Show();
        }

        private void рекламодательToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Reklamodatel frm = new Reklamodatel();
            frm.Show();
        }

        private void договорыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Dogovoru frm = new Dogovoru();
            frm.Show();
        }

        private void адресаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Adress frm = new Adress();
            frm.Show();
        }

        private void объектToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Objekt frm = new Objekt();
            frm.Show();
        }

        private void улицаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Street frm = new Street();
            frm.Show();
        }

        private void рекламныеАгентыToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ReklAg frm = new ReklAg();
            frm.Show();
        }

        private void паспортныеДанныеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Pasport frm = new Pasport();
            frm.Show();
        }

        private void юридическийToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UR frm = new UR();
            frm.Show();
        }

        private void физическийToolStripMenuItem_Click(object sender, EventArgs e)
        {
            HarRekl frm = new HarRekl();
            frm.Show();
        }

        private void общийСписокToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ZagalUrFiz frm = new ZagalUrFiz();
            frm.Show();
        }

        private void характеристикиРазмещенияПоАдресуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            HaraktAdress frm = new HaraktAdress();
            frm.Show();
        }

        private void характеристикиРазмещенияПоАдресуToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            HaraktAdress frm = new HaraktAdress();
            frm.Show();
        }

        private void характеристикиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Harakteristiki frm = new Harakteristiki();
            frm.Show();
        }

        private void владелецToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Vladelezc frm = new Vladelezc();
            frm.Show();
        }

        private void адресПоДоговорамToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AdreesDoovor frm = new AdreesDoovor();
            frm.Show();
        }

        private void договорыToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form_Rep frm = new Form_Rep();
            frm.MdiParent = this;
            frm.Show();
        }

        private void характеристикиПоВидуРекламногоМатериалаToolStripMenuItem_Click(object sender, EventArgs e)
        {
           HarRekl frm = new HarRekl();
            frm.MdiParent = this;
            frm.Show();
        }

        private void характеристикиАдресаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            HaraktAdress frm = new HaraktAdress();
            frm.Show();
        }

        private void видМестаРазмещенияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Vid_mesta_razmeshenia frm = new Vid_mesta_razmeshenia();
            frm.Show();
        }

        private void дляВидаМестаРазмещенияToolStripMenuItem_Click(object sender, EventArgs e)
        {
           HarVidRazmeshenia frm = new HarVidRazmeshenia();
            frm.Show();
        }

       
    }
}
