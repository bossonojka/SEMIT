﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class CI : Form
    {
        public CI()
        {
            InitializeComponent();
        }

        private void CI_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Единица_измерения". При необходимости она может быть перемещена или удалена.
            this.единица_измеренияTableAdapter.Fill(this.courseWorkBDDataSet.Единица_измерения);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Подтвердите действие", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                Единица_измерения rm = new Единица_измерения();


                int kod;
                Int32.TryParse(textBox1.Text, out kod);
                rm.код_единицы_измерения = kod;

                rm.название_единицы_измерения = textBox2.Text;

                context.Единица_измерения.Add(rm);
                context.SaveChanges();
                this.единица_измеренияTableAdapter.Fill(this.courseWorkBDDataSet.Единица_измерения);
                tabControl1.SelectedTab = tabPage1;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Вы действительно хотите удалить эту единицу измерения?\nВсе связанные данные будут удалены", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                {
                    int index = dataGridView1.CurrentCell.RowIndex;
                    CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                    int kod = int.Parse(dataGridView1.Rows[index].Cells["кодединицыизмеренияDataGridViewTextBoxColumn"].Value.ToString());
                    context.Единица_измерения.Remove(context.Единица_измерения.Find(kod));
                    context.SaveChanges();
                    this.единица_измеренияTableAdapter.Fill(this.courseWorkBDDataSet.Единица_измерения);
                    dataGridView1.Refresh();
                }
            }
            catch { }
        }
    }
}
