﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CourseWork;

namespace CourseWork
{
    public partial class HarVidRazmeshenia : Form
    {
        public HarVidRazmeshenia()
        {
            InitializeComponent();
        }

        private void HarVidRazmeshenia_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Характеристики". При необходимости она может быть перемещена или удалена.
            this.характеристикиTableAdapter.Fill(this.courseWorkBDDataSet.Характеристики);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Вид_места_размещения". При необходимости она может быть перемещена или удалена.
            this.вид_места_размещенияTableAdapter.Fill(this.courseWorkBDDataSet.Вид_места_размещения);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Характеристики_для_вида_места_размещения". При необходимости она может быть перемещена или удалена.
            this.характеристики_для_вида_места_размещенияTableAdapter.Fill(this.courseWorkBDDataSet.Характеристики_для_вида_места_размещения);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Подтвердите действие", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                Характеристики_для_вида_места_размещения rm = new Характеристики_для_вида_места_размещения();

                int tip;
                Int32.TryParse(comboBox1.SelectedValue.ToString(), out tip);
                rm.код_вида_размещения = tip;

                int vid;
                Int32.TryParse(comboBox2.SelectedValue.ToString(), out vid);
                rm.код_характеристики = vid;

                context.Характеристики_для_вида_места_размещения.Add(rm);
                context.SaveChanges();
                this.характеристики_для_вида_места_размещенияTableAdapter.Fill(this.courseWorkBDDataSet.Характеристики_для_вида_места_размещения);
                tabControl1.SelectedTab = tabPage1;
            }
        }
    }
}
