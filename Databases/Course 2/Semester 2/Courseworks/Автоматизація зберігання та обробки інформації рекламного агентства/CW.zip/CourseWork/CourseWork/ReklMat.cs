﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CourseWork;


namespace CourseWork
{
    public partial class ReklMat : Form
    {
        public ReklMat()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Вид_РМ". При необходимости она может быть перемещена или удалена.
            this.вид_РМTableAdapter.Fill(this.courseWorkBDDataSet.Вид_РМ);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Тип_РУ". При необходимости она может быть перемещена или удалена.
            this.тип_РУTableAdapter.Fill(this.courseWorkBDDataSet.Тип_РУ);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet._Рекламный_материал_РМ_". При необходимости она может быть перемещена или удалена.
            this.рекламный_материал_РМ_TableAdapter.Fill(this.courseWorkBDDataSet._Рекламный_материал_РМ_);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Рекламные_агенты". При необходимости она может быть перемещена или удалена.
            this.рекламные_агентыTableAdapter.Fill(this.courseWorkBDDataSet.Рекламные_агенты);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Подтвердите действие", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                Рекламный_материал_РМ_ rm = new Рекламный_материал_РМ_();

              
                int kod;
                Int32.TryParse(textBox1.Text, out kod);
                rm.код_РМ = kod;

                rm.наименование = textBox2.Text;

                int tip;
                Int32.TryParse(comboBox1.SelectedValue.ToString(), out tip);
                rm.код_типа_РУ = tip;

                int vid;
                Int32.TryParse(comboBox2.SelectedValue.ToString(), out vid);
                rm.код_вида_РМ = vid;

                int prise;
                prise = Convert.ToInt32(textBox3.Text);
                rm.стоимость_за_единицу_грн = prise;




                context.Рекламный_материал_РМ_.Add(rm);
                context.SaveChanges();
                this.рекламный_материал_РМ_TableAdapter.Fill(this.courseWorkBDDataSet._Рекламный_материал_РМ_);
                tabControl1.SelectedTab = tabPage1;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Вы действительно хотите удалить этот материал?\nВсе связанные данные будут удалены", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                {
                    int index = dataGridView1.CurrentCell.RowIndex;
                    CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                    int kod = int.Parse(dataGridView1.Rows[index].Cells["кодРМDataGridViewTextBoxColumn"].Value.ToString());
                    context.Рекламный_материал_РМ_.Remove(context.Рекламный_материал_РМ_.Find(kod));
                    context.SaveChanges();
                    this.рекламный_материал_РМ_TableAdapter.Fill(this.courseWorkBDDataSet._Рекламный_материал_РМ_);
                    dataGridView1.Refresh();
                }
            }
            catch { }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }
    }
}
