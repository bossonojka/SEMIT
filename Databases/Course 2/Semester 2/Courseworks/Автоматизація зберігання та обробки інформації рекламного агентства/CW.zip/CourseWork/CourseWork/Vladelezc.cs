﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class Vladelezc : Form
    {
        public Vladelezc()
        {
            InitializeComponent();
        }

        private void Form16_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Юридический_в". При необходимости она может быть перемещена или удалена.
            this.юридический_вTableAdapter.Fill(this.courseWorkBDDataSet.Юридический_в);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Физический_в". При необходимости она может быть перемещена или удалена.
            this.физический_вTableAdapter.Fill(this.courseWorkBDDataSet.Физический_в);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Юридический". При необходимости она может быть перемещена или удалена.
            this.юридическийTableAdapter.Fill(this.courseWorkBDDataSet.Юридический);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.View_2". При необходимости она может быть перемещена или удалена.
            this.view_2TableAdapter.Fill(this.courseWorkBDDataSet.View_2);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Владелец". При необходимости она может быть перемещена или удалена.
            this.владелецTableAdapter.Fill(this.courseWorkBDDataSet.Владелец);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }


        private void comboBox1_SelectedValueChanged_1(object sender, EventArgs e)
        {
            
            if (comboBox1.SelectedIndex == 0)
            {

                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";


                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = false;

                label2.Visible = false;
                label3.Visible = true;
                label4.Visible = true;
                label5.Visible = true;
                label6.Visible = true;
            }

                if (comboBox1.SelectedIndex == 1)
                {

                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox4.Text = "";
                    textBox5.Text = "";

                    textBox1.Visible = false;
                    textBox2.Visible = false;
                    textBox3.Visible = false;
                    textBox4.Visible = true;
                    textBox5.Visible = true;

                    label2.Visible = true;
                    label3.Visible = false;
                    label4.Visible = false;
                    label5.Visible = false;
                    label6.Visible = true;

                }
            }

        private void button4_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("Подтвердите действие", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                label2.Visible = false;
                CourseWorkBDEntities11 s = new CourseWorkBDEntities11();
                Владелец p = new Владелец();
                if (comboBox1.SelectedIndex == 0)
                {
                    p.Физический_в = new Физический_в();
                    p.Физический_в.фамилия = textBox1.Text;
                    p.Физический_в.имя = textBox2.Text;
                    p.Физический_в.отчество = textBox3.Text;
                    int kod ;
                    Int32.TryParse(textBox4.Text, out kod);
                    p.код_владельца = kod;
                  
                    s.Владелец.Add(p);
                    s.SaveChanges();
                    this.физический_вTableAdapter.Fill(this.courseWorkBDDataSet.Физический_в);

                    tabControl1.SelectedTab = tabPage1;
                }
                if (comboBox1.SelectedIndex == 1)
                {
                    p.Юридический_в = new Юридический_в();
                    p.Юридический_в.название = textBox5.Text;
                    int kod;
                    int.TryParse(textBox4.Text, out kod);
                    p.код_владельца = kod;
                    
                    s.Владелец.Add(p);
                    s.SaveChanges();
                    this.юридический_вTableAdapter.Fill(this.courseWorkBDDataSet.Юридический_в);
                    tabControl1.SelectedTab = tabPage3;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы действительно хотите удалить этого владельца?\nВсе связанные данные будут удалены", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
            {
                try
                {
                    CourseWorkBDEntities11 s = new CourseWorkBDEntities11();
                    if (tabControl1.SelectedTab == tabPage1)
                    {
                        int index1 = dataGridView1.CurrentCell.RowIndex;
                        int post_fiz = int.Parse(dataGridView1.Rows[index1].Cells["кодвладельцаDataGridViewTextBoxColumn"].Value.ToString());
                        s.Физический_в.Remove(s.Физический_в.Find(post_fiz));
                        s.SaveChanges();
                        this.физический_вTableAdapter.Fill(this.courseWorkBDDataSet.Физический_в);
                        dataGridView1.Refresh();
                       
                    }
                    if (tabControl1.SelectedTab == tabPage3)
                    {
                        int index2 = dataGridView2.CurrentCell.RowIndex;
                        int post_yur = int.Parse(dataGridView2.Rows[index2].Cells["код_владельца"].Value.ToString());
                        s.Юридический_в.Remove(s.Юридический_в.Find(post_yur));
                        s.SaveChanges();
                        this.юридический_вTableAdapter.Fill(this.courseWorkBDDataSet.Юридический_в);
                        dataGridView2.Refresh();
                    }
                }
                catch (Exception) { }
            }
        }
    }

    }

