﻿namespace CourseWork
{
    partial class HarRekl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.кодхарактеристикиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.характеристикиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.courseWorkBDDataSet = new CourseWork.CourseWorkBDDataSet();
            this.кодРМDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.рекламныйматериалРМBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.значениеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.характеристикиповидуРМBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.физическийBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.физическийвBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.физический_вTableAdapter = new CourseWork.CourseWorkBDDataSetTableAdapters.Физический_вTableAdapter();
            this.физическийTableAdapter = new CourseWork.CourseWorkBDDataSetTableAdapters.ФизическийTableAdapter();
            this.рекламодательBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.рекламодательTableAdapter = new CourseWork.CourseWorkBDDataSetTableAdapters.РекламодательTableAdapter();
            this.характеристики_по_виду_РМTableAdapter = new CourseWork.CourseWorkBDDataSetTableAdapters.Характеристики_по_виду_РМTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.характеристикиTableAdapter = new CourseWork.CourseWorkBDDataSetTableAdapters.ХарактеристикиTableAdapter();
            this.рекламный_материал_РМ_TableAdapter = new CourseWork.CourseWorkBDDataSetTableAdapters.Рекламный_материал_РМ_TableAdapter();
            this.button4 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.характеристикиBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.courseWorkBDDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.рекламныйматериалРМBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.характеристикиповидуРМBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.физическийBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.физическийвBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.рекламодательBindingSource)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодхарактеристикиDataGridViewTextBoxColumn,
            this.кодРМDataGridViewTextBoxColumn,
            this.значениеDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.характеристикиповидуРМBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(6, 16);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(455, 117);
            this.dataGridView3.TabIndex = 1;
            // 
            // кодхарактеристикиDataGridViewTextBoxColumn
            // 
            this.кодхарактеристикиDataGridViewTextBoxColumn.DataPropertyName = "код_характеристики";
            this.кодхарактеристикиDataGridViewTextBoxColumn.DataSource = this.характеристикиBindingSource;
            this.кодхарактеристикиDataGridViewTextBoxColumn.DisplayMember = "характеристика";
            this.кодхарактеристикиDataGridViewTextBoxColumn.HeaderText = "код_характеристики";
            this.кодхарактеристикиDataGridViewTextBoxColumn.Name = "кодхарактеристикиDataGridViewTextBoxColumn";
            this.кодхарактеристикиDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.кодхарактеристикиDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.кодхарактеристикиDataGridViewTextBoxColumn.ValueMember = "код_характеристики";
            // 
            // характеристикиBindingSource
            // 
            this.характеристикиBindingSource.DataMember = "Характеристики";
            this.характеристикиBindingSource.DataSource = this.courseWorkBDDataSet;
            // 
            // courseWorkBDDataSet
            // 
            this.courseWorkBDDataSet.DataSetName = "CourseWorkBDDataSet";
            this.courseWorkBDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // кодРМDataGridViewTextBoxColumn
            // 
            this.кодРМDataGridViewTextBoxColumn.DataPropertyName = "код_РМ";
            this.кодРМDataGridViewTextBoxColumn.DataSource = this.рекламныйматериалРМBindingSource;
            this.кодРМDataGridViewTextBoxColumn.DisplayMember = "наименование";
            this.кодРМDataGridViewTextBoxColumn.HeaderText = "код_РМ";
            this.кодРМDataGridViewTextBoxColumn.Name = "кодРМDataGridViewTextBoxColumn";
            this.кодРМDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.кодРМDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.кодРМDataGridViewTextBoxColumn.ValueMember = "код_РМ";
            // 
            // рекламныйматериалРМBindingSource
            // 
            this.рекламныйматериалРМBindingSource.DataMember = "Рекламный_материал(РМ)";
            this.рекламныйматериалРМBindingSource.DataSource = this.courseWorkBDDataSet;
            // 
            // значениеDataGridViewTextBoxColumn
            // 
            this.значениеDataGridViewTextBoxColumn.DataPropertyName = "значение";
            this.значениеDataGridViewTextBoxColumn.HeaderText = "значение";
            this.значениеDataGridViewTextBoxColumn.Name = "значениеDataGridViewTextBoxColumn";
            // 
            // характеристикиповидуРМBindingSource
            // 
            this.характеристикиповидуРМBindingSource.DataMember = "Характеристики_по_виду_РМ";
            this.характеристикиповидуРМBindingSource.DataSource = this.courseWorkBDDataSet;
            // 
            // физическийBindingSource
            // 
            this.физическийBindingSource.DataMember = "Физический";
            this.физическийBindingSource.DataSource = this.courseWorkBDDataSet;
            // 
            // физическийвBindingSource
            // 
            this.физическийвBindingSource.DataMember = "Физический_в";
            this.физическийвBindingSource.DataSource = this.courseWorkBDDataSet;
            // 
            // физический_вTableAdapter
            // 
            this.физический_вTableAdapter.ClearBeforeFill = true;
            // 
            // физическийTableAdapter
            // 
            this.физическийTableAdapter.ClearBeforeFill = true;
            // 
            // рекламодательBindingSource
            // 
            this.рекламодательBindingSource.DataMember = "Рекламодатель";
            this.рекламодательBindingSource.DataSource = this.courseWorkBDDataSet;
            // 
            // рекламодательTableAdapter
            // 
            this.рекламодательTableAdapter.ClearBeforeFill = true;
            // 
            // характеристики_по_виду_РМTableAdapter
            // 
            this.характеристики_по_виду_РМTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(21, 155);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(212, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "Новая харкатеристика по виду";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(13, 13);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(475, 210);
            this.tabControl1.TabIndex = 5;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.dataGridView3);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(467, 184);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Характеристика";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.comboBox2);
            this.tabPage2.Controls.Add(this.comboBox1);
            this.tabPage2.Controls.Add(this.textBox3);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(467, 184);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Новая характеристика";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(348, 68);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 23;
            this.button3.Text = "Отмена";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(348, 23);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 22;
            this.button2.Text = "Сохранить";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.рекламныйматериалРМBindingSource;
            this.comboBox2.DisplayMember = "наименование";
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(120, 51);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 21;
            this.comboBox2.ValueMember = "код_РМ";
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.характеристикиBindingSource;
            this.comboBox1.DisplayMember = "характеристика";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(120, 22);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 20;
            this.comboBox1.ValueMember = "код_характеристики";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(120, 78);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 19;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 13);
            this.label5.TabIndex = 16;
            this.label5.Text = "Значения";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Материал";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Характеристика";
            // 
            // характеристикиTableAdapter
            // 
            this.характеристикиTableAdapter.ClearBeforeFill = true;
            // 
            // рекламный_материал_РМ_TableAdapter
            // 
            this.рекламный_материал_РМ_TableAdapter.ClearBeforeFill = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(263, 155);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(125, 23);
            this.button4.TabIndex = 4;
            this.button4.Text = "Удалить";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // HarRekl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 235);
            this.Controls.Add(this.tabControl1);
            this.Name = "HarRekl";
            this.Text = "Характеристики по виду РМ";
            this.Load += new System.EventHandler(this.Form12_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.характеристикиBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.courseWorkBDDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.рекламныйматериалРМBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.характеристикиповидуРМBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.физическийBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.физическийвBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.рекламодательBindingSource)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView3;
        private CourseWorkBDDataSet courseWorkBDDataSet;
        private System.Windows.Forms.BindingSource физическийвBindingSource;
        private CourseWorkBDDataSetTableAdapters.Физический_вTableAdapter физический_вTableAdapter;
        private System.Windows.Forms.BindingSource физическийBindingSource;
        private CourseWorkBDDataSetTableAdapters.ФизическийTableAdapter физическийTableAdapter;
        private System.Windows.Forms.BindingSource рекламодательBindingSource;
        private CourseWorkBDDataSetTableAdapters.РекламодательTableAdapter рекламодательTableAdapter;
        private System.Windows.Forms.BindingSource характеристикиповидуРМBindingSource;
        private CourseWorkBDDataSetTableAdapters.Характеристики_по_виду_РМTableAdapter характеристики_по_виду_РМTableAdapter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.BindingSource характеристикиBindingSource;
        private CourseWorkBDDataSetTableAdapters.ХарактеристикиTableAdapter характеристикиTableAdapter;
        private System.Windows.Forms.BindingSource рекламныйматериалРМBindingSource;
        private CourseWorkBDDataSetTableAdapters.Рекламный_материал_РМ_TableAdapter рекламный_материал_РМ_TableAdapter;
        private System.Windows.Forms.DataGridViewComboBoxColumn кодхарактеристикиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn кодРМDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn значениеDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button4;
    }
}