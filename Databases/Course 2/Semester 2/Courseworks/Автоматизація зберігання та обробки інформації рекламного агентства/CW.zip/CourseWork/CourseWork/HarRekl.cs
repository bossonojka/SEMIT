﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CourseWork;

namespace CourseWork
{
    public partial class HarRekl : Form
    {
        public HarRekl()
        {
            InitializeComponent();
        }

        private void Form12_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet._Рекламный_материал_РМ_". При необходимости она может быть перемещена или удалена.
            this.рекламный_материал_РМ_TableAdapter.Fill(this.courseWorkBDDataSet._Рекламный_материал_РМ_);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Характеристики". При необходимости она может быть перемещена или удалена.
            this.характеристикиTableAdapter.Fill(this.courseWorkBDDataSet.Характеристики);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Характеристики_по_виду_РМ". При необходимости она может быть перемещена или удалена.
            this.характеристики_по_виду_РМTableAdapter.Fill(this.courseWorkBDDataSet.Характеристики_по_виду_РМ);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Рекламодатель". При необходимости она может быть перемещена или удалена.
            this.рекламодательTableAdapter.Fill(this.courseWorkBDDataSet.Рекламодатель);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Физический". При необходимости она может быть перемещена или удалена.
            this.физическийTableAdapter.Fill(this.courseWorkBDDataSet.Физический);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Физический_в". При необходимости она может быть перемещена или удалена.
            this.физический_вTableAdapter.Fill(this.courseWorkBDDataSet.Физический_в);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Подтвердите действие", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                 Характеристики_по_виду_РМ rm = new Характеристики_по_виду_РМ();
               
                int tip;
                Int32.TryParse(comboBox1.SelectedValue.ToString(), out tip);
                rm.код_характеристики = tip;

                int vid;
                Int32.TryParse(comboBox2.SelectedValue.ToString(), out vid);
                rm.код_РМ = vid;

                int prise;
                Int32.TryParse(textBox3.Text, out prise);
                rm.значение = prise;

                context.Характеристики_по_виду_РМ.Add(rm);
                context.SaveChanges();
                this.характеристики_по_виду_РМTableAdapter.Fill(this.courseWorkBDDataSet.Характеристики_по_виду_РМ);
                tabControl1.SelectedTab = tabPage1;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Вы действительно хотите удалить эту характеристику?\nВсе связанные данные будут удалены", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                {
                    int index = dataGridView3.CurrentCell.RowIndex;
                    CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                    int kod = int.Parse(dataGridView3.Rows[index].Cells["кодхарактеристикиDataGridViewTextBoxColumn"].Value.ToString());
                    context.Характеристики_по_виду_РМ.Remove(context.Характеристики_по_виду_РМ.Find(kod));
                    context.SaveChanges();
                    this.характеристики_по_виду_РМTableAdapter.Fill(this.courseWorkBDDataSet.Характеристики_по_виду_РМ);
                    dataGridView3.Refresh();
                }
            }
            catch { }
        }
    }
}
