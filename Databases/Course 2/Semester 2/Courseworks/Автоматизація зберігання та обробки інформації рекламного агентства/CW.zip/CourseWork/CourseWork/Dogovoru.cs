﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class Dogovoru : Form
    {
        public Dogovoru()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Заявки_на_предоставление_РУ". При необходимости она может быть перемещена или удалена.
            this.заявки_на_предоставление_РУTableAdapter.Fill(this.courseWorkBDDataSet.Заявки_на_предоставление_РУ);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.View_2". При необходимости она может быть перемещена или удалена.
            this.view_2TableAdapter.Fill(this.courseWorkBDDataSet.View_2);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Заявки_на_предоставление_РУ". При необходимости она может быть перемещена или удалена.
            //this.заявки_на_предоставление_РУTableAdapter.Fill(this.courseWorkBDDataSet.Заявки_на_предоставление_РУ);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Договоры". При необходимости она может быть перемещена или удалена.
            this.договорыTableAdapter.Fill(this.courseWorkBDDataSet.Договоры);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Подтвердите действие", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                Договоры rm = new Договоры();


                int nomer;
                Int32.TryParse(textBox1.Text, out nomer);
                rm.код_договора = nomer;

                rm.дата_договора = dateTimePicker1.Value;
                rm.дата_начала = dateTimePicker2.Value;
                rm.дата_окончания = dateTimePicker3.Value;

                int kod;
                Int32.TryParse(comboBox2.SelectedValue.ToString(), out kod);
                rm.код_владельца = kod;

                int z;
                Int32.TryParse(comboBox1.SelectedValue.ToString(), out z);
                rm.C_заявки = z;

                context.Договоры.Add(rm);
                context.SaveChanges();
                this.договорыTableAdapter.Fill(this.courseWorkBDDataSet.Договоры);
                tabControl1.SelectedTab = tabPage1;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Вы действительно хотите удалить этот договор?\nВсе связанные данные будут удалены", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                {
                    int index = dataGridView1.CurrentCell.RowIndex;
                    CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                    int numer = int.Parse(dataGridView1.Rows[index].Cells["коддоговораDataGridViewTextBoxColumn"].Value.ToString());
                    context.Договоры.Remove(context.Договоры.Find(numer));
                    context.SaveChanges();
                    this.договорыTableAdapter.Fill(this.courseWorkBDDataSet.Договоры);
                    dataGridView1.Refresh();
                }
            }
            catch { }
        }
    }
}