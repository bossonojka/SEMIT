﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class Vid_mesta_razmeshenia : Form
    {
        public Vid_mesta_razmeshenia()
        {
            InitializeComponent();
        }

        private void Vid_mesta_razmeshenia_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Вид_места_размещения". При необходимости она может быть перемещена или удалена.
            this.вид_места_размещенияTableAdapter.Fill(this.courseWorkBDDataSet.Вид_места_размещения);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Подтвердите действие", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                Вид_места_размещения rm = new Вид_места_размещения();

                int tip;
                Int32.TryParse(textBox1.Text, out tip);
                rm.код_вида_размещения = tip;

                rm.наименование = textBox3.Text;

                context.Вид_места_размещения.Add(rm);
                context.SaveChanges();
                this.вид_места_размещенияTableAdapter.Fill(this.courseWorkBDDataSet.Вид_места_размещения);
                tabControl1.SelectedTab = tabPage1;
            }
        }
    }
}
