﻿namespace CourseWork
{
    partial class AdreesDoovor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.адресподоговорамBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.courseWorkBDDataSet = new CourseWork.CourseWorkBDDataSet();
            this.адрес_по_договорамTableAdapter = new CourseWork.CourseWorkBDDataSetTableAdapters.Адрес_по_договорамTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.коддоговораDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодадресаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.view4BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.количествоDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.стоимостьгрнDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.договорыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.адресBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.договорыTableAdapter = new CourseWork.CourseWorkBDDataSetTableAdapters.ДоговорыTableAdapter();
            this.адресTableAdapter = new CourseWork.CourseWorkBDDataSetTableAdapters.АдресTableAdapter();
            this.view_4TableAdapter = new CourseWork.CourseWorkBDDataSetTableAdapters.View_4TableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.адресподоговорамBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.courseWorkBDDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view4BindingSource)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.договорыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.адресBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // адресподоговорамBindingSource
            // 
            this.адресподоговорамBindingSource.DataMember = "Адрес_по_договорам";
            this.адресподоговорамBindingSource.DataSource = this.courseWorkBDDataSet;
            // 
            // courseWorkBDDataSet
            // 
            this.courseWorkBDDataSet.DataSetName = "CourseWorkBDDataSet";
            this.courseWorkBDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // адрес_по_договорамTableAdapter
            // 
            this.адрес_по_договорамTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.коддоговораDataGridViewTextBoxColumn,
            this.кодадресаDataGridViewTextBoxColumn,
            this.количествоDataGridViewTextBoxColumn,
            this.стоимостьгрнDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.адресподоговорамBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(9, 13);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(477, 163);
            this.dataGridView1.TabIndex = 1;
            // 
            // коддоговораDataGridViewTextBoxColumn
            // 
            this.коддоговораDataGridViewTextBoxColumn.DataPropertyName = "код_договора";
            this.коддоговораDataGridViewTextBoxColumn.HeaderText = "код_договора";
            this.коддоговораDataGridViewTextBoxColumn.Name = "коддоговораDataGridViewTextBoxColumn";
            this.коддоговораDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // кодадресаDataGridViewTextBoxColumn
            // 
            this.кодадресаDataGridViewTextBoxColumn.DataPropertyName = "код_адреса";
            this.кодадресаDataGridViewTextBoxColumn.DataSource = this.view4BindingSource;
            this.кодадресаDataGridViewTextBoxColumn.DisplayMember = "Адрес_для_размещения";
            this.кодадресаDataGridViewTextBoxColumn.HeaderText = "код_адреса";
            this.кодадресаDataGridViewTextBoxColumn.Name = "кодадресаDataGridViewTextBoxColumn";
            this.кодадресаDataGridViewTextBoxColumn.ReadOnly = true;
            this.кодадресаDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.кодадресаDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.кодадресаDataGridViewTextBoxColumn.ValueMember = "код_адреса";
            // 
            // view4BindingSource
            // 
            this.view4BindingSource.DataMember = "View_4";
            this.view4BindingSource.DataSource = this.courseWorkBDDataSet;
            // 
            // количествоDataGridViewTextBoxColumn
            // 
            this.количествоDataGridViewTextBoxColumn.DataPropertyName = "количество";
            this.количествоDataGridViewTextBoxColumn.HeaderText = "количество";
            this.количествоDataGridViewTextBoxColumn.Name = "количествоDataGridViewTextBoxColumn";
            this.количествоDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // стоимостьгрнDataGridViewTextBoxColumn
            // 
            this.стоимостьгрнDataGridViewTextBoxColumn.DataPropertyName = "стоимость_грн";
            this.стоимостьгрнDataGridViewTextBoxColumn.HeaderText = "стоимость_грн";
            this.стоимостьгрнDataGridViewTextBoxColumn.Name = "стоимостьгрнDataGridViewTextBoxColumn";
            this.стоимостьгрнDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(160, 187);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(113, 23);
            this.button4.TabIndex = 6;
            this.button4.Text = "Удалить";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(29, 187);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(-1, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(521, 268);
            this.tabControl1.TabIndex = 7;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(513, 242);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Адрес по договорам";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.comboBox2);
            this.tabPage2.Controls.Add(this.comboBox1);
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.textBox4);
            this.tabPage2.Controls.Add(this.textBox3);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(513, 242);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Добавить";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.view4BindingSource;
            this.comboBox2.DisplayMember = "Адрес_для_размещения";
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(109, 46);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 39;
            this.comboBox2.ValueMember = "код_адреса";
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.договорыBindingSource;
            this.comboBox1.DisplayMember = "код_договора";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(109, 18);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 38;
            this.comboBox1.ValueMember = "код_договора";
            // 
            // договорыBindingSource
            // 
            this.договорыBindingSource.DataMember = "Договоры";
            this.договорыBindingSource.DataSource = this.courseWorkBDDataSet;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(354, 81);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 37;
            this.button3.Text = "Отмена";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(354, 36);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 36;
            this.button2.Text = "Сохранить";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(109, 97);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 34;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(109, 71);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 33;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 13);
            this.label4.TabIndex = 29;
            this.label4.Text = "Стоимость";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 28;
            this.label3.Text = "Количество";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 27;
            this.label2.Text = "Адрес";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 26;
            this.label1.Text = "Договор";
            // 
            // адресBindingSource
            // 
            this.адресBindingSource.DataMember = "Адрес";
            this.адресBindingSource.DataSource = this.courseWorkBDDataSet;
            // 
            // договорыTableAdapter
            // 
            this.договорыTableAdapter.ClearBeforeFill = true;
            // 
            // адресTableAdapter
            // 
            this.адресTableAdapter.ClearBeforeFill = true;
            // 
            // view_4TableAdapter
            // 
            this.view_4TableAdapter.ClearBeforeFill = true;
            // 
            // AdreesDoovor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(522, 280);
            this.Controls.Add(this.tabControl1);
            this.Name = "AdreesDoovor";
            this.Text = "Адрес по договорам";
            this.Load += new System.EventHandler(this.Form17_Load);
            ((System.ComponentModel.ISupportInitialize)(this.адресподоговорамBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.courseWorkBDDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view4BindingSource)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.договорыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.адресBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private CourseWorkBDDataSet courseWorkBDDataSet;
        private System.Windows.Forms.BindingSource адресподоговорамBindingSource;
        private CourseWorkBDDataSetTableAdapters.Адрес_по_договорамTableAdapter адрес_по_договорамTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.BindingSource договорыBindingSource;
        private CourseWorkBDDataSetTableAdapters.ДоговорыTableAdapter договорыTableAdapter;
        private System.Windows.Forms.BindingSource адресBindingSource;
        private CourseWorkBDDataSetTableAdapters.АдресTableAdapter адресTableAdapter;
        private System.Windows.Forms.BindingSource view4BindingSource;
        private CourseWorkBDDataSetTableAdapters.View_4TableAdapter view_4TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn коддоговораDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn кодадресаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn стоимостьгрнDataGridViewTextBoxColumn;
    }
}