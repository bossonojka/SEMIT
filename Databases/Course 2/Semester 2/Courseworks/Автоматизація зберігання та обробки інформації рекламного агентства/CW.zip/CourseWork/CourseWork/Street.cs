﻿using CourseWork;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace CourseWork
{
    public partial class Street : Form
    {
        public Street()
        {
            InitializeComponent();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Тип_улицы". При необходимости она может быть перемещена или удалена.
            this.тип_улицыTableAdapter.Fill(this.courseWorkBDDataSet.Тип_улицы);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Улица". При необходимости она может быть перемещена или удалена.
            this.улицаTableAdapter.Fill(this.courseWorkBDDataSet.Улица);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Подтвердите действие", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                Улица rm = new Улица();

                int nomer;
                Int32.TryParse(textBox1.Text, out nomer);
                rm.код_улицы = nomer;

                int tip;
                Int32.TryParse(comboBox1.SelectedValue.ToString(), out tip);
                rm.код_типа_улицы = tip;

                rm.название = textBox2.Text;

                context.Улица.Add(rm);
                context.SaveChanges();
                this.улицаTableAdapter.Fill(this.courseWorkBDDataSet.Улица);
                tabControl1.SelectedTab = tabPage1;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Вы действительно хотите удалить эту улицу?\nВсе связанные данные будут удалены", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                {
                    int index = dataGridView1.CurrentCell.RowIndex;
                    CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                    int numer = int.Parse(dataGridView1.Rows[index].Cells["кодулицыDataGridViewTextBoxColumn"].Value.ToString());
                    context.Улица.Remove(context.Улица.Find(numer));
                    context.SaveChanges();
                    this.улицаTableAdapter.Fill(this.courseWorkBDDataSet.Улица);
                    dataGridView1.Refresh();
                }
            }
            catch { }
        }
    }
}
