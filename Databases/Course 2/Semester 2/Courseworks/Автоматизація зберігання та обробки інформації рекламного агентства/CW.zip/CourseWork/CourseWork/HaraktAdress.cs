﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class HaraktAdress : Form
    {
        public HaraktAdress()
        {
            InitializeComponent();
        }

        private void Form14_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.View_4". При необходимости она может быть перемещена или удалена.
            this.view_4TableAdapter.Fill(this.courseWorkBDDataSet.View_4);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Адрес". При необходимости она может быть перемещена или удалена.
            this.адресTableAdapter.Fill(this.courseWorkBDDataSet.Адрес);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Характеристики". При необходимости она может быть перемещена или удалена.
            this.характеристикиTableAdapter.Fill(this.courseWorkBDDataSet.Характеристики);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseWorkBDDataSet.Характеристики_Адрес". При необходимости она может быть перемещена или удалена.
            this.характеристики_АдресTableAdapter.Fill(this.courseWorkBDDataSet.Характеристики_Адрес);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Подтвердите действие", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                Характеристики_Адрес rm = new Характеристики_Адрес();

                int tip;
                Int32.TryParse(comboBox1.SelectedValue.ToString(), out tip);
                rm.код_характеристики = tip;

                int vid;
                Int32.TryParse(comboBox2.SelectedValue.ToString(), out vid);
                rm.код_адреса = vid;

                int prise;
                Int32.TryParse(textBox3.Text, out prise);
                rm.значение = prise;

                context.Характеристики_Адрес.Add(rm);
                context.SaveChanges();
                this.характеристики_АдресTableAdapter.Fill(this.courseWorkBDDataSet.Характеристики_Адрес);
                tabControl1.SelectedTab = tabPage1;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Вы действительно хотите удалить этот адрес и характеристику?\nВсе связанные данные будут удалены", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                {
                    int index = dataGridView1.CurrentCell.RowIndex;
                    CourseWorkBDEntities11 context = new CourseWorkBDEntities11();
                    int numer = int.Parse(dataGridView1.Rows[index].Cells["кодхарактеристикиDataGridViewTextBoxColumn"].Value.ToString());
                    context.Характеристики_Адрес.Remove(context.Характеристики_Адрес.Find(numer));
                    context.SaveChanges();
                    this.характеристики_АдресTableAdapter.Fill(this.courseWorkBDDataSet.Характеристики_Адрес);
                    dataGridView1.Refresh();
                }
            }
            catch { }
        }
    }
    }
    

