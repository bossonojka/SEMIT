﻿namespace CourseWork
{
    partial class ReklMat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.кодРМDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.наименованиеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодтипаРУDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.типРУBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.courseWorkBDDataSet = new CourseWork.CourseWorkBDDataSet();
            this.кодвидаРМDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.видРМBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.стоимостьзаединицугрнDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sSMATimeStampDataGridViewImageColumn = new System.Windows.Forms.DataGridViewImageColumn();
            this.рекламныйматериалРМBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.рекламныеагентыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.рекламные_агентыTableAdapter = new CourseWork.CourseWorkBDDataSetTableAdapters.Рекламные_агентыTableAdapter();
            this.рекламный_материал_РМ_TableAdapter = new CourseWork.CourseWorkBDDataSetTableAdapters.Рекламный_материал_РМ_TableAdapter();
            this.тип_РУTableAdapter = new CourseWork.CourseWorkBDDataSetTableAdapters.Тип_РУTableAdapter();
            this.типРУBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.вид_РМTableAdapter = new CourseWork.CourseWorkBDDataSetTableAdapters.Вид_РМTableAdapter();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типРУBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.courseWorkBDDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.видРМBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.рекламныйматериалРМBindingSource)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.рекламныеагентыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типРУBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(0, -1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(652, 246);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(644, 220);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Список материалов";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(193, 185);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(125, 23);
            this.button4.TabIndex = 2;
            this.button4.Text = "Удалить материал";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(9, 186);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(161, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Новый материал";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодРМDataGridViewTextBoxColumn,
            this.наименованиеDataGridViewTextBoxColumn,
            this.кодтипаРУDataGridViewTextBoxColumn,
            this.кодвидаРМDataGridViewTextBoxColumn,
            this.стоимостьзаединицугрнDataGridViewTextBoxColumn,
            this.sSMATimeStampDataGridViewImageColumn});
            this.dataGridView1.DataSource = this.рекламныйматериалРМBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(9, 7);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(544, 150);
            this.dataGridView1.TabIndex = 0;
            // 
            // кодРМDataGridViewTextBoxColumn
            // 
            this.кодРМDataGridViewTextBoxColumn.DataPropertyName = "код_РМ";
            this.кодРМDataGridViewTextBoxColumn.HeaderText = "код_РМ";
            this.кодРМDataGridViewTextBoxColumn.Name = "кодРМDataGridViewTextBoxColumn";
            // 
            // наименованиеDataGridViewTextBoxColumn
            // 
            this.наименованиеDataGridViewTextBoxColumn.DataPropertyName = "наименование";
            this.наименованиеDataGridViewTextBoxColumn.HeaderText = "наименование";
            this.наименованиеDataGridViewTextBoxColumn.Name = "наименованиеDataGridViewTextBoxColumn";
            // 
            // кодтипаРУDataGridViewTextBoxColumn
            // 
            this.кодтипаРУDataGridViewTextBoxColumn.DataPropertyName = "код_типа_РУ";
            this.кодтипаРУDataGridViewTextBoxColumn.DataSource = this.типРУBindingSource;
            this.кодтипаРУDataGridViewTextBoxColumn.DisplayMember = "наименование_РУ";
            this.кодтипаРУDataGridViewTextBoxColumn.HeaderText = "код_типа_РУ";
            this.кодтипаРУDataGridViewTextBoxColumn.Name = "кодтипаРУDataGridViewTextBoxColumn";
            this.кодтипаРУDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.кодтипаРУDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.кодтипаРУDataGridViewTextBoxColumn.ValueMember = "код_типа_РУ";
            // 
            // типРУBindingSource
            // 
            this.типРУBindingSource.DataMember = "Тип_РУ";
            this.типРУBindingSource.DataSource = this.courseWorkBDDataSet;
            // 
            // courseWorkBDDataSet
            // 
            this.courseWorkBDDataSet.DataSetName = "CourseWorkBDDataSet";
            this.courseWorkBDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // кодвидаРМDataGridViewTextBoxColumn
            // 
            this.кодвидаРМDataGridViewTextBoxColumn.DataPropertyName = "код_вида_РМ";
            this.кодвидаРМDataGridViewTextBoxColumn.DataSource = this.видРМBindingSource;
            this.кодвидаРМDataGridViewTextBoxColumn.DisplayMember = "наименование";
            this.кодвидаРМDataGridViewTextBoxColumn.HeaderText = "код_вида_РМ";
            this.кодвидаРМDataGridViewTextBoxColumn.Name = "кодвидаРМDataGridViewTextBoxColumn";
            this.кодвидаРМDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.кодвидаРМDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.кодвидаРМDataGridViewTextBoxColumn.ValueMember = "код_вида_РМ";
            // 
            // видРМBindingSource
            // 
            this.видРМBindingSource.DataMember = "Вид_РМ";
            this.видРМBindingSource.DataSource = this.courseWorkBDDataSet;
            // 
            // стоимостьзаединицугрнDataGridViewTextBoxColumn
            // 
            this.стоимостьзаединицугрнDataGridViewTextBoxColumn.DataPropertyName = "стоимость_за_единицу_грн";
            this.стоимостьзаединицугрнDataGridViewTextBoxColumn.HeaderText = "стоимость_за_единицу_грн";
            this.стоимостьзаединицугрнDataGridViewTextBoxColumn.Name = "стоимостьзаединицугрнDataGridViewTextBoxColumn";
            // 
            // sSMATimeStampDataGridViewImageColumn
            // 
            this.sSMATimeStampDataGridViewImageColumn.DataPropertyName = "SSMA_TimeStamp";
            this.sSMATimeStampDataGridViewImageColumn.HeaderText = "SSMA_TimeStamp";
            this.sSMATimeStampDataGridViewImageColumn.Name = "sSMATimeStampDataGridViewImageColumn";
            this.sSMATimeStampDataGridViewImageColumn.ReadOnly = true;
            // 
            // рекламныйматериалРМBindingSource
            // 
            this.рекламныйматериалРМBindingSource.DataMember = "Рекламный_материал(РМ)";
            this.рекламныйматериалРМBindingSource.DataSource = this.courseWorkBDDataSet;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.comboBox2);
            this.tabPage2.Controls.Add(this.comboBox1);
            this.tabPage2.Controls.Add(this.textBox3);
            this.tabPage2.Controls.Add(this.textBox2);
            this.tabPage2.Controls.Add(this.textBox1);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(644, 220);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Новый материал";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(371, 64);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 11;
            this.button3.Text = "Отмена";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(371, 19);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 10;
            this.button2.Text = "Сохранить";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.видРМBindingSource;
            this.comboBox2.DisplayMember = "наименование";
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(123, 104);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 9;
            this.comboBox2.ValueMember = "код_вида_РМ";
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.типРУBindingSource;
            this.comboBox1.DisplayMember = "наименование_РУ";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(123, 75);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 8;
            this.comboBox1.ValueMember = "код_типа_РУ";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(123, 131);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 7;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(123, 47);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 6;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(123, 19);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(26, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "стоимость";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(26, 102);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Вид материала";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Тип услуги";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Наименование";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Код";
            // 
            // рекламныеагентыBindingSource
            // 
            this.рекламныеагентыBindingSource.DataMember = "Рекламные_агенты";
            this.рекламныеагентыBindingSource.DataSource = this.courseWorkBDDataSet;
            // 
            // рекламные_агентыTableAdapter
            // 
            this.рекламные_агентыTableAdapter.ClearBeforeFill = true;
            // 
            // рекламный_материал_РМ_TableAdapter
            // 
            this.рекламный_материал_РМ_TableAdapter.ClearBeforeFill = true;
            // 
            // тип_РУTableAdapter
            // 
            this.тип_РУTableAdapter.ClearBeforeFill = true;
            // 
            // типРУBindingSource1
            // 
            this.типРУBindingSource1.DataMember = "Тип_РУ";
            this.типРУBindingSource1.DataSource = this.courseWorkBDDataSet;
            // 
            // вид_РМTableAdapter
            // 
            this.вид_РМTableAdapter.ClearBeforeFill = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(664, 294);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form2";
            this.Text = "Рекламные материалы";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типРУBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.courseWorkBDDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.видРМBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.рекламныйматериалРМBindingSource)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.рекламныеагентыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типРУBindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private CourseWorkBDDataSet courseWorkBDDataSet;
        private System.Windows.Forms.BindingSource рекламныеагентыBindingSource;
        private CourseWorkBDDataSetTableAdapters.Рекламные_агентыTableAdapter рекламные_агентыTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource рекламныйматериалРМBindingSource;
        private CourseWorkBDDataSetTableAdapters.Рекламный_материал_РМ_TableAdapter рекламный_материал_РМ_TableAdapter;
        private System.Windows.Forms.BindingSource типРУBindingSource;
        private CourseWorkBDDataSetTableAdapters.Тип_РУTableAdapter тип_РУTableAdapter;
        private System.Windows.Forms.BindingSource типРУBindingSource1;
        private System.Windows.Forms.BindingSource видРМBindingSource;
        private CourseWorkBDDataSetTableAdapters.Вид_РМTableAdapter вид_РМTableAdapter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодРМDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn наименованиеDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn кодтипаРУDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn кодвидаРМDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn стоимостьзаединицугрнDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewImageColumn sSMATimeStampDataGridViewImageColumn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button4;
    }
}