﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CourseWork
{
    public partial class Form_Rep : Form
    {
        public Form_Rep()
        {
            InitializeComponent();
        }
        CourseWorkBDDataSet work = new CourseWorkBDDataSet();
        CourseWorkBDDataSetTableAdapters.sp_dgvr_sumTableAdapter report = new CourseWorkBDDataSetTableAdapters.sp_dgvr_sumTableAdapter();

        private void Form_Rep_Load(object sender, EventArgs e)
        {
            report.Fill(work.sp_dgvr_sum);
            rep11.SetDataSource(work);
            crystalReportViewer1.Refresh();
            crystalReportViewer1.ReportSource = rep11;

        }
    }
}
