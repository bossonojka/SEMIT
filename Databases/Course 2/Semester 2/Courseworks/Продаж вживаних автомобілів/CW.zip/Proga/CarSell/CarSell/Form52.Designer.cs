﻿namespace CarSell
{
    partial class Form52
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button3 = new System.Windows.Forms.Button();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.клиент_покупательTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Клиент_покупательTableAdapter();
            this.carSellDataSet1 = new CarSell.CarSellDataSet();
            this.клиентпокупательBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fullKlNameBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fullKlNameTableAdapter = new CarSell.CarSellDataSetTableAdapters.FullKlNameTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентпокупательBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fullKlNameBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Gold;
            this.button3.Location = new System.Drawing.Point(89, 128);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(213, 28);
            this.button3.TabIndex = 50;
            this.button3.Text = "Добавить как клиента - покупателя";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // comboBox8
            // 
            this.comboBox8.DataSource = this.fullKlNameBindingSource;
            this.comboBox8.DisplayMember = "Клиент";
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.ItemHeight = 13;
            this.comboBox8.Location = new System.Drawing.Point(116, 42);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(256, 21);
            this.comboBox8.TabIndex = 49;
            this.comboBox8.ValueMember = "Код_клиента";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.Location = new System.Drawing.Point(22, 43);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(65, 20);
            this.label18.TabIndex = 48;
            this.label18.Text = "Клиент";
            // 
            // клиент_покупательTableAdapter1
            // 
            this.клиент_покупательTableAdapter1.ClearBeforeFill = true;
            // 
            // carSellDataSet1
            // 
            this.carSellDataSet1.DataSetName = "CarSellDataSet";
            this.carSellDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // клиентпокупательBindingSource
            // 
            this.клиентпокупательBindingSource.DataMember = "Клиент_покупатель";
            this.клиентпокупательBindingSource.DataSource = this.carSellDataSet1;
            // 
            // fullKlNameBindingSource
            // 
            this.fullKlNameBindingSource.DataMember = "FullKlName";
            this.fullKlNameBindingSource.DataSource = this.carSellDataSet1;
            // 
            // fullKlNameTableAdapter
            // 
            this.fullKlNameTableAdapter.ClearBeforeFill = true;
            // 
            // Form52
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(399, 318);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.comboBox8);
            this.Controls.Add(this.label18);
            this.Name = "Form52";
            this.Text = "Form52";
            this.Load += new System.EventHandler(this.Form52_Load);
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентпокупательBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fullKlNameBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.Label label18;
        private CarSellDataSetTableAdapters.Клиент_покупательTableAdapter клиент_покупательTableAdapter1;
        private CarSellDataSet carSellDataSet1;
        private System.Windows.Forms.BindingSource клиентпокупательBindingSource;
        private System.Windows.Forms.BindingSource fullKlNameBindingSource;
        private CarSellDataSetTableAdapters.FullKlNameTableAdapter fullKlNameTableAdapter;
    }
}