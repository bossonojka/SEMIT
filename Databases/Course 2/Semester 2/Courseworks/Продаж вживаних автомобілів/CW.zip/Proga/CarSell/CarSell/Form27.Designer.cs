﻿namespace CarSell
{
    partial class Form27
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDтелефонаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номероператораDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номертелефонаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mobilePhoneBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carSellDataSet = new CarSell.CarSellDataSet();
            this.телефонBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.номероператораBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.операторBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mobilePhoneTableAdapter = new CarSell.CarSellDataSetTableAdapters.MobilePhoneTableAdapter();
            this.телефонTableAdapter = new CarSell.CarSellDataSetTableAdapters.ТелефонTableAdapter();
            this.номер_оператораTableAdapter = new CarSell.CarSellDataSetTableAdapters.Номер_оператораTableAdapter();
            this.операторTableAdapter = new CarSell.CarSellDataSetTableAdapters.ОператорTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mobilePhoneBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.телефонBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.номероператораBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.операторBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.HighlightText;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDтелефонаDataGridViewTextBoxColumn,
            this.номероператораDataGridViewTextBoxColumn,
            this.названиеDataGridViewTextBoxColumn,
            this.номертелефонаDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.mobilePhoneBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(0, -1);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(555, 504);
            this.dataGridView1.TabIndex = 0;
            // 
            // iDтелефонаDataGridViewTextBoxColumn
            // 
            this.iDтелефонаDataGridViewTextBoxColumn.DataPropertyName = "ID_телефона";
            this.iDтелефонаDataGridViewTextBoxColumn.HeaderText = "ID_телефона";
            this.iDтелефонаDataGridViewTextBoxColumn.Name = "iDтелефонаDataGridViewTextBoxColumn";
            this.iDтелефонаDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // номероператораDataGridViewTextBoxColumn
            // 
            this.номероператораDataGridViewTextBoxColumn.DataPropertyName = "Номер_оператора";
            this.номероператораDataGridViewTextBoxColumn.HeaderText = "Номер_оператора";
            this.номероператораDataGridViewTextBoxColumn.Name = "номероператораDataGridViewTextBoxColumn";
            this.номероператораDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // названиеDataGridViewTextBoxColumn
            // 
            this.названиеDataGridViewTextBoxColumn.DataPropertyName = "Название";
            this.названиеDataGridViewTextBoxColumn.HeaderText = "Название";
            this.названиеDataGridViewTextBoxColumn.Name = "названиеDataGridViewTextBoxColumn";
            this.названиеDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // номертелефонаDataGridViewTextBoxColumn
            // 
            this.номертелефонаDataGridViewTextBoxColumn.DataPropertyName = "Номер_телефона";
            this.номертелефонаDataGridViewTextBoxColumn.HeaderText = "Номер_телефона";
            this.номертелефонаDataGridViewTextBoxColumn.Name = "номертелефонаDataGridViewTextBoxColumn";
            this.номертелефонаDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // mobilePhoneBindingSource
            // 
            this.mobilePhoneBindingSource.DataMember = "MobilePhone";
            this.mobilePhoneBindingSource.DataSource = this.carSellDataSet;
            // 
            // carSellDataSet
            // 
            this.carSellDataSet.DataSetName = "CarSellDataSet";
            this.carSellDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // телефонBindingSource
            // 
            this.телефонBindingSource.DataMember = "Телефон";
            this.телефонBindingSource.DataSource = this.carSellDataSet;
            // 
            // номероператораBindingSource
            // 
            this.номероператораBindingSource.DataMember = "Номер_оператора";
            this.номероператораBindingSource.DataSource = this.carSellDataSet;
            // 
            // операторBindingSource
            // 
            this.операторBindingSource.DataMember = "Оператор";
            this.операторBindingSource.DataSource = this.carSellDataSet;
            // 
            // mobilePhoneTableAdapter
            // 
            this.mobilePhoneTableAdapter.ClearBeforeFill = true;
            // 
            // телефонTableAdapter
            // 
            this.телефонTableAdapter.ClearBeforeFill = true;
            // 
            // номер_оператораTableAdapter
            // 
            this.номер_оператораTableAdapter.ClearBeforeFill = true;
            // 
            // операторTableAdapter
            // 
            this.операторTableAdapter.ClearBeforeFill = true;
            // 
            // Form27
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(556, 502);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form27";
            this.Text = "Form27";
            this.Load += new System.EventHandler(this.Form27_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mobilePhoneBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.телефонBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.номероператораBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.операторBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CarSellDataSet carSellDataSet;
        private System.Windows.Forms.BindingSource mobilePhoneBindingSource;
        private CarSellDataSetTableAdapters.MobilePhoneTableAdapter mobilePhoneTableAdapter;
        private System.Windows.Forms.BindingSource телефонBindingSource;
        private CarSellDataSetTableAdapters.ТелефонTableAdapter телефонTableAdapter;
        private System.Windows.Forms.BindingSource номероператораBindingSource;
        private CarSellDataSetTableAdapters.Номер_оператораTableAdapter номер_оператораTableAdapter;
        private System.Windows.Forms.BindingSource операторBindingSource;
        private CarSellDataSetTableAdapters.ОператорTableAdapter операторTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDтелефонаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номероператораDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номертелефонаDataGridViewTextBoxColumn;
    }
}