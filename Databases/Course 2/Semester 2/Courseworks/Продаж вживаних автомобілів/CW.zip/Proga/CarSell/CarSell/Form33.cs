﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSell
{
    public partial class Form33 : Form
    {
        public Form33()
        {
            InitializeComponent();
        }

        private void Form33_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.FullKlName' table. You can move, or remove it, as needed.
            this.fullKlNameTableAdapter.Fill(this.carSellDataSet.FullKlName);
            // TODO: This line of code loads data into the 'carSellDataSet.KlientPhone' table. You can move, or remove it, as needed.
            this.klientPhoneTableAdapter.Fill(this.carSellDataSet.KlientPhone);
            // TODO: This line of code loads data into the 'carSellDataSet.Клиент' table. You can move, or remove it, as needed.
            this.клиентTableAdapter.Fill(this.carSellDataSet.Клиент);
            // TODO: This line of code loads data into the 'carSellDataSet.SellKlient' table. You can move, or remove it, as needed.
            this.sellKlientTableAdapter.Fill(this.carSellDataSet.SellKlient);

        }
    }
}
