﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSell
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Модель_авто' table. You can move, or remove it, as needed.
            this.модель_автоTableAdapter.Fill(this.carSellDataSet.Модель_авто);
            // TODO: This line of code loads data into the 'carSellDataSet.CarBrand' table. You can move, or remove it, as needed.
            this.carBrandTableAdapter.Fill(this.carSellDataSet.CarBrand);
            // TODO: This line of code loads data into the 'carSellDataSet.Марка_авто' table. You can move, or remove it, as needed.
            this.марка_автоTableAdapter.Fill(this.carSellDataSet.Марка_авто);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form56 form56 = new Form56();
            form56.ShowDialog(this);
            this.марка_автоTableAdapter1.Fill(this.carSellDataSet1.Марка_авто);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.марка_автоTableAdapter.Update(this.carSellDataSet.Марка_авто);
        }
    }
}
