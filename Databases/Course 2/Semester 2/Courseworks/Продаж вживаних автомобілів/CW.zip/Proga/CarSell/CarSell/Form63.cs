﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;

namespace CarSell
{
    public partial class Form63 : Form
    {
        SqlConnection conn = null;
        public Form63()
        {
            InitializeComponent();
        }

        private void Form63_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Диапазон_цены' table. You can move, or remove it, as needed.
            this.диапазон_ценыTableAdapter.Fill(this.carSellDataSet.Диапазон_цены);
            // TODO: This line of code loads data into the 'carSellDataSet.Цвет' table. You can move, or remove it, as needed.
            this.цветTableAdapter.Fill(this.carSellDataSet.Цвет);
            // TODO: This line of code loads data into the 'carSellDataSet.Пробег' table. You can move, or remove it, as needed.
            this.пробегTableAdapter.Fill(this.carSellDataSet.Пробег);
            // TODO: This line of code loads data into the 'carSellDataSet.Мощность' table. You can move, or remove it, as needed.
            this.мощностьTableAdapter.Fill(this.carSellDataSet.Мощность);
            // TODO: This line of code loads data into the 'carSellDataSet.Объем_двигателя' table. You can move, or remove it, as needed.
            this.объем_двигателяTableAdapter.Fill(this.carSellDataSet.Объем_двигателя);
            // TODO: This line of code loads data into the 'carSellDataSet.Год_выпуска_до' table. You can move, or remove it, as needed.
            this.год_выпуска_доTableAdapter.Fill(this.carSellDataSet.Год_выпуска_до);
            // TODO: This line of code loads data into the 'carSellDataSet.Год_выпуска_от' table. You can move, or remove it, as needed.
            this.год_выпуска_отTableAdapter.Fill(this.carSellDataSet.Год_выпуска_от);
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_кузова' table. You can move, or remove it, as needed.
            this.тип_кузоваTableAdapter.Fill(this.carSellDataSet.Тип_кузова);
            // TODO: This line of code loads data into the 'carSellDataSet.Модель_авто' table. You can move, or remove it, as needed.
            this.модель_автоTableAdapter.Fill(this.carSellDataSet.Модель_авто);
            // TODO: This line of code loads data into the 'carSellDataSet.Марка_авто' table. You can move, or remove it, as needed.
            this.марка_автоTableAdapter.Fill(this.carSellDataSet.Марка_авто);
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_ТС' table. You can move, or remove it, as needed.
            this.тип_ТСTableAdapter.Fill(this.carSellDataSet.Тип_ТС);
            // TODO: This line of code loads data into the 'carSellDataSet.BuyKlient' table. You can move, or remove it, as needed.
            this.buyKlientTableAdapter.Fill(this.carSellDataSet.BuyKlient);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form53 form53 = new Form53();
            form53.ShowDialog(this);
            this.тип_ТСTableAdapter.Fill(this.carSellDataSet.Тип_ТС);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Form56 form56 = new Form56();
            form56.Show();
            this.марка_автоTableAdapter1.Fill(this.carSellDataSet.Марка_авто);
            this.модель_автоTableAdapter1.Fill(this.carSellDataSet.Модель_авто);
            this.lastBrandTableAdapter1.Fill(this.carSellDataSet.LastBrand);
            this.lastModelTableAdapter1.Fill(this.carSellDataSet.LastModel);
            this.марка_модельTableAdapter1.Fill(this.carSellDataSet.Марка_модель);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form54 form54 = new Form54();
            form54.ShowDialog(this);
            this.тип_кузоваTableAdapter.Fill(this.carSellDataSet.Тип_кузова);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form55 form55 = new Form55();
            form55.ShowDialog(this);
            this.год_выпуска_отTableAdapter.Fill(this.carSellDataSet.Год_выпуска_от);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form58 form58 = new Form58();
            form58.ShowDialog(this);
            this.год_выпуска_доTableAdapter.Fill(this.carSellDataSet.Год_выпуска_до);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Form59 form59 = new Form59();
            form59.ShowDialog(this);
            this.объем_двигателяTableAdapter.Fill(this.carSellDataSet.Объем_двигателя);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form60 form60 = new Form60();
            form60.ShowDialog(this);
            this.мощностьTableAdapter.Fill(this.carSellDataSet.Мощность);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Form61 form61 = new Form61();
            form61.ShowDialog(this);
            this.цветTableAdapter.Fill(this.carSellDataSet.Цвет);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Form62 form62 = new Form62();
            form62.ShowDialog(this);
            this.диапазон_ценыTableAdapter.Fill(this.carSellDataSet.Диапазон_цены);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection();
            conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";

            SqlCommand myComand = conn.CreateCommand();
            string Car = "INSERT into Заказ_клиента (Код_клиента_покупателя, Код_типа_ТС, Код_марки, Код_модели, Код_типа_кузова, Код_года_выпуска_от, Код_года_выпуска_до, " +
                "Код_диапазона_объема_двигателя, Код_диапазона_мощности, Код_диапазона_пробега, Код_цвета, Код_диапазона_цены) " +
                "values ('" + this.comboBox10.SelectedValue.ToString() + "','" + this.comboBox9.SelectedValue.ToString() + "','" + 
                this.comboBox11.SelectedValue.ToString() + "','" + this.comboBox12.SelectedValue.ToString() + "','" + 
                this.comboBox13.SelectedValue.ToString() + "','" + this.comboBox14.SelectedValue.ToString() + "','" + 
                this.comboBox15.SelectedValue.ToString() + "','" + this.comboBox16.SelectedValue.ToString() + "','" + 
                this.comboBox17.SelectedValue.ToString() + "','" + this.comboBox18.SelectedValue.ToString() + "','" + 
                this.comboBox19.SelectedValue.ToString() + "','" + this.comboBox20.SelectedValue.ToString() + "');";

            SqlCommand sqlCommand = new SqlCommand(Car, conn);
            SqlDataReader myReader;
            try
            {
                conn.Open();
                myReader = sqlCommand.ExecuteReader();
                MessageBox.Show("Изменения внесены", "Изменение записи");
                while (myReader.Read())
                {

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
