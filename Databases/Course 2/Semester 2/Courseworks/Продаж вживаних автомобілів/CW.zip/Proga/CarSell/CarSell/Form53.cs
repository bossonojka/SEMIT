﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;

namespace CarSell
{
    public partial class Form53 : Form
    {
        SqlConnection conn = null;
        public Form53()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string nameTpTC = Convert.ToString(this.textBox1.Text);


                conn = new SqlConnection();
                conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                conn.Open();
                SqlCommand myComand = conn.CreateCommand();
                myComand.CommandText = "INSERT into Тип_ТС (Тип_ТС) VALUES (@nameTpTC)";
                myComand.Parameters.Add("@nameTpTC", SqlDbType.NVarChar, 20);
                myComand.Parameters["@nameTpTC"].Value = nameTpTC;

                int UspeshnoeIzmenenie = myComand.ExecuteNonQuery();
                if (UspeshnoeIzmenenie != 0)
                {
                    MessageBox.Show("Изменения внесены", "Изменение записи");
                }
                else
                {
                    MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            this.тип_ТСTableAdapter1.Fill(this.carSellDataSet1.Тип_ТС);
            Form42 form42 = new Form42();
            
        }

        private void Form53_Load(object sender, EventArgs e)
        {

        }
    }
}
