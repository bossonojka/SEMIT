﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSell
{
    public partial class Form22 : Form
    {
        public Form22()
        {
            InitializeComponent();
        }

        private void Form22_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_строения' table. You can move, or remove it, as needed.
            this.тип_строенияTableAdapter.Fill(this.carSellDataSet.Тип_строения);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form48 form48 = new Form48();
            form48.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.тип_строенияTableAdapter.Update(this.carSellDataSet.Тип_строения);
        }
    }
}
