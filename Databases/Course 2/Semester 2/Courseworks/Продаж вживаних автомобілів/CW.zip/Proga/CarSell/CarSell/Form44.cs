﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSell
{
    public partial class Form44 : Form
    {
        public Form44()
        {
            InitializeComponent();
        }

        private void Form44_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.DgCountDl' table. You can move, or remove it, as needed.
            this.dgCountDlTableAdapter.Fill(this.carSellDataSet.DgCountDl);

        }
    }
}
