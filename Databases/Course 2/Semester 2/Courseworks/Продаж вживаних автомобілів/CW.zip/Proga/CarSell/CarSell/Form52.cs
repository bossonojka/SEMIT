﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;

namespace CarSell
{
    public partial class Form52 : Form
    {
        SqlConnection conn = null;
        public Form52()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int buyKl = int.Parse(this.comboBox8.SelectedValue.ToString());


                conn = new SqlConnection();
                conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                conn.Open();
                SqlCommand myComand = conn.CreateCommand();
                myComand.CommandText = "INSERT into Клиент_покупатель (Код_клиента_покупателя) VALUES (@buyKl)";
                myComand.Parameters.Add("@buyKl", SqlDbType.Int, 4);
                myComand.Parameters["@buyKl"].Value = buyKl;


                int UspeshnoeIzmenenie = myComand.ExecuteNonQuery();
                if (UspeshnoeIzmenenie != 0)
                {
                    MessageBox.Show("Изменения внесены", "Изменение записи");
                }
                else
                {
                    MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            this.клиент_покупательTableAdapter1.Fill(this.carSellDataSet1.Клиент_покупатель);
            Form41 form41 = new Form41();
            form41.Update();
        }

        private void Form52_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet1.FullKlName' table. You can move, or remove it, as needed.
            this.fullKlNameTableAdapter.Fill(this.carSellDataSet1.FullKlName);

        }
    }
}
