﻿namespace CarSell
{
    partial class Form36
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.кодзаказаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодклиентапокупателяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.клиентDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типТСDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.маркаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.модельDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типкузоваDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.годвыпускаотDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.годвыпускадоDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.диапазонобъемадвигателяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.диапазонмощностиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.диапазонпробегаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.цветDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.диапазонценыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.allOrderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carSellDataSet = new CarSell.CarSellDataSet();
            this.клиентпокупательBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fullKlNameBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.типТСBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.маркаавтоBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.модельавтоBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.типкузоваBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.годвыпускаотBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.годвыпускадоBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.объемдвигателяBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.мощностьBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.пробегBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.цветBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.диапазонценыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.klientPhoneBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.allOrderTableAdapter = new CarSell.CarSellDataSetTableAdapters.AllOrderTableAdapter();
            this.клиентBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.клиентTableAdapter = new CarSell.CarSellDataSetTableAdapters.КлиентTableAdapter();
            this.клиент_покупательTableAdapter = new CarSell.CarSellDataSetTableAdapters.Клиент_покупательTableAdapter();
            this.klientPhoneTableAdapter = new CarSell.CarSellDataSetTableAdapters.KlientPhoneTableAdapter();
            this.тип_ТСTableAdapter = new CarSell.CarSellDataSetTableAdapters.Тип_ТСTableAdapter();
            this.марка_автоTableAdapter = new CarSell.CarSellDataSetTableAdapters.Марка_автоTableAdapter();
            this.модель_автоTableAdapter = new CarSell.CarSellDataSetTableAdapters.Модель_автоTableAdapter();
            this.тип_кузоваTableAdapter = new CarSell.CarSellDataSetTableAdapters.Тип_кузоваTableAdapter();
            this.год_выпуска_отTableAdapter = new CarSell.CarSellDataSetTableAdapters.Год_выпуска_отTableAdapter();
            this.год_выпуска_доTableAdapter = new CarSell.CarSellDataSetTableAdapters.Год_выпуска_доTableAdapter();
            this.объем_двигателяTableAdapter = new CarSell.CarSellDataSetTableAdapters.Объем_двигателяTableAdapter();
            this.мощностьTableAdapter = new CarSell.CarSellDataSetTableAdapters.МощностьTableAdapter();
            this.пробегTableAdapter = new CarSell.CarSellDataSetTableAdapters.ПробегTableAdapter();
            this.цветTableAdapter = new CarSell.CarSellDataSetTableAdapters.ЦветTableAdapter();
            this.диапазон_ценыTableAdapter = new CarSell.CarSellDataSetTableAdapters.Диапазон_ценыTableAdapter();
            this.fullKlNameTableAdapter = new CarSell.CarSellDataSetTableAdapters.FullKlNameTableAdapter();
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.заказ_клиентаTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Заказ_клиентаTableAdapter();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.заказклиентаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.кодзаказаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодклиентапокупателяDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодтипаТСDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодмаркиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодмоделиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодтипакузоваDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодгодавыпускаотDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодгодавыпускадоDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.коддиапазонаобъемадвигателяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.коддиапазонамощностиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.коддиапазонапробегаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодцветаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.коддиапазонаценыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.allOrderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентпокупательBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fullKlNameBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типТСBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.маркаавтоBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.модельавтоBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типкузоваBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.годвыпускаотBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.годвыпускадоBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.объемдвигателяBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.мощностьBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.пробегBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.цветBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.диапазонценыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientPhoneBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.заказклиентаBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодзаказаDataGridViewTextBoxColumn,
            this.кодклиентапокупателяDataGridViewTextBoxColumn,
            this.клиентDataGridViewTextBoxColumn,
            this.типТСDataGridViewTextBoxColumn,
            this.маркаDataGridViewTextBoxColumn,
            this.модельDataGridViewTextBoxColumn,
            this.типкузоваDataGridViewTextBoxColumn,
            this.годвыпускаотDataGridViewTextBoxColumn,
            this.годвыпускадоDataGridViewTextBoxColumn,
            this.диапазонобъемадвигателяDataGridViewTextBoxColumn,
            this.диапазонмощностиDataGridViewTextBoxColumn,
            this.диапазонпробегаDataGridViewTextBoxColumn,
            this.цветDataGridViewTextBoxColumn,
            this.диапазонценыDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.allOrderBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(0, -1);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1346, 403);
            this.dataGridView1.TabIndex = 0;
            // 
            // кодзаказаDataGridViewTextBoxColumn
            // 
            this.кодзаказаDataGridViewTextBoxColumn.DataPropertyName = "Код_заказа";
            this.кодзаказаDataGridViewTextBoxColumn.HeaderText = "Код_заказа";
            this.кодзаказаDataGridViewTextBoxColumn.Name = "кодзаказаDataGridViewTextBoxColumn";
            // 
            // кодклиентапокупателяDataGridViewTextBoxColumn
            // 
            this.кодклиентапокупателяDataGridViewTextBoxColumn.DataPropertyName = "Код_клиента_покупателя";
            this.кодклиентапокупателяDataGridViewTextBoxColumn.FillWeight = 150F;
            this.кодклиентапокупателяDataGridViewTextBoxColumn.HeaderText = "Код_клиента_покупателя";
            this.кодклиентапокупателяDataGridViewTextBoxColumn.Name = "кодклиентапокупателяDataGridViewTextBoxColumn";
            this.кодклиентапокупателяDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.кодклиентапокупателяDataGridViewTextBoxColumn.Width = 150;
            // 
            // клиентDataGridViewTextBoxColumn
            // 
            this.клиентDataGridViewTextBoxColumn.DataPropertyName = "Клиент";
            this.клиентDataGridViewTextBoxColumn.FillWeight = 200F;
            this.клиентDataGridViewTextBoxColumn.HeaderText = "Клиент";
            this.клиентDataGridViewTextBoxColumn.Name = "клиентDataGridViewTextBoxColumn";
            this.клиентDataGridViewTextBoxColumn.ReadOnly = true;
            this.клиентDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.клиентDataGridViewTextBoxColumn.Width = 200;
            // 
            // типТСDataGridViewTextBoxColumn
            // 
            this.типТСDataGridViewTextBoxColumn.DataPropertyName = "Тип_ТС";
            this.типТСDataGridViewTextBoxColumn.HeaderText = "Тип_ТС";
            this.типТСDataGridViewTextBoxColumn.Name = "типТСDataGridViewTextBoxColumn";
            this.типТСDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // маркаDataGridViewTextBoxColumn
            // 
            this.маркаDataGridViewTextBoxColumn.DataPropertyName = "Марка";
            this.маркаDataGridViewTextBoxColumn.HeaderText = "Марка";
            this.маркаDataGridViewTextBoxColumn.Name = "маркаDataGridViewTextBoxColumn";
            this.маркаDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // модельDataGridViewTextBoxColumn
            // 
            this.модельDataGridViewTextBoxColumn.DataPropertyName = "Модель";
            this.модельDataGridViewTextBoxColumn.HeaderText = "Модель";
            this.модельDataGridViewTextBoxColumn.Name = "модельDataGridViewTextBoxColumn";
            this.модельDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // типкузоваDataGridViewTextBoxColumn
            // 
            this.типкузоваDataGridViewTextBoxColumn.DataPropertyName = "Тип_кузова";
            this.типкузоваDataGridViewTextBoxColumn.HeaderText = "Тип_кузова";
            this.типкузоваDataGridViewTextBoxColumn.Name = "типкузоваDataGridViewTextBoxColumn";
            this.типкузоваDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // годвыпускаотDataGridViewTextBoxColumn
            // 
            this.годвыпускаотDataGridViewTextBoxColumn.DataPropertyName = "Год_выпуска_от";
            this.годвыпускаотDataGridViewTextBoxColumn.HeaderText = "Год_выпуска_от";
            this.годвыпускаотDataGridViewTextBoxColumn.Name = "годвыпускаотDataGridViewTextBoxColumn";
            this.годвыпускаотDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // годвыпускадоDataGridViewTextBoxColumn
            // 
            this.годвыпускадоDataGridViewTextBoxColumn.DataPropertyName = "Год_выпуска_до";
            this.годвыпускадоDataGridViewTextBoxColumn.HeaderText = "Год_выпуска_до";
            this.годвыпускадоDataGridViewTextBoxColumn.Name = "годвыпускадоDataGridViewTextBoxColumn";
            this.годвыпускадоDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // диапазонобъемадвигателяDataGridViewTextBoxColumn
            // 
            this.диапазонобъемадвигателяDataGridViewTextBoxColumn.DataPropertyName = "Диапазон_объема_двигателя";
            this.диапазонобъемадвигателяDataGridViewTextBoxColumn.FillWeight = 150F;
            this.диапазонобъемадвигателяDataGridViewTextBoxColumn.HeaderText = "Диапазон_объема_двигателя";
            this.диапазонобъемадвигателяDataGridViewTextBoxColumn.Name = "диапазонобъемадвигателяDataGridViewTextBoxColumn";
            this.диапазонобъемадвигателяDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.диапазонобъемадвигателяDataGridViewTextBoxColumn.Width = 150;
            // 
            // диапазонмощностиDataGridViewTextBoxColumn
            // 
            this.диапазонмощностиDataGridViewTextBoxColumn.DataPropertyName = "Диапазон_мощности";
            this.диапазонмощностиDataGridViewTextBoxColumn.FillWeight = 130F;
            this.диапазонмощностиDataGridViewTextBoxColumn.HeaderText = "Диапазон_мощности";
            this.диапазонмощностиDataGridViewTextBoxColumn.Name = "диапазонмощностиDataGridViewTextBoxColumn";
            this.диапазонмощностиDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.диапазонмощностиDataGridViewTextBoxColumn.Width = 130;
            // 
            // диапазонпробегаDataGridViewTextBoxColumn
            // 
            this.диапазонпробегаDataGridViewTextBoxColumn.DataPropertyName = "Диапазон_пробега";
            this.диапазонпробегаDataGridViewTextBoxColumn.FillWeight = 130F;
            this.диапазонпробегаDataGridViewTextBoxColumn.HeaderText = "Диапазон_пробега";
            this.диапазонпробегаDataGridViewTextBoxColumn.Name = "диапазонпробегаDataGridViewTextBoxColumn";
            this.диапазонпробегаDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.диапазонпробегаDataGridViewTextBoxColumn.Width = 130;
            // 
            // цветDataGridViewTextBoxColumn
            // 
            this.цветDataGridViewTextBoxColumn.DataPropertyName = "Цвет";
            this.цветDataGridViewTextBoxColumn.HeaderText = "Цвет";
            this.цветDataGridViewTextBoxColumn.Name = "цветDataGridViewTextBoxColumn";
            this.цветDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // диапазонценыDataGridViewTextBoxColumn
            // 
            this.диапазонценыDataGridViewTextBoxColumn.DataPropertyName = "Диапазон_цены";
            this.диапазонценыDataGridViewTextBoxColumn.FillWeight = 110F;
            this.диапазонценыDataGridViewTextBoxColumn.HeaderText = "Диапазон_цены";
            this.диапазонценыDataGridViewTextBoxColumn.Name = "диапазонценыDataGridViewTextBoxColumn";
            this.диапазонценыDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.диапазонценыDataGridViewTextBoxColumn.Width = 110;
            // 
            // allOrderBindingSource
            // 
            this.allOrderBindingSource.DataMember = "AllOrder";
            this.allOrderBindingSource.DataSource = this.carSellDataSet;
            // 
            // carSellDataSet
            // 
            this.carSellDataSet.DataSetName = "CarSellDataSet";
            this.carSellDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // клиентпокупательBindingSource
            // 
            this.клиентпокупательBindingSource.DataMember = "Клиент_покупатель";
            this.клиентпокупательBindingSource.DataSource = this.carSellDataSet;
            // 
            // fullKlNameBindingSource
            // 
            this.fullKlNameBindingSource.DataMember = "FullKlName";
            this.fullKlNameBindingSource.DataSource = this.carSellDataSet;
            // 
            // типТСBindingSource
            // 
            this.типТСBindingSource.DataMember = "Тип_ТС";
            this.типТСBindingSource.DataSource = this.carSellDataSet;
            // 
            // маркаавтоBindingSource
            // 
            this.маркаавтоBindingSource.DataMember = "Марка_авто";
            this.маркаавтоBindingSource.DataSource = this.carSellDataSet;
            // 
            // модельавтоBindingSource
            // 
            this.модельавтоBindingSource.DataMember = "Модель_авто";
            this.модельавтоBindingSource.DataSource = this.carSellDataSet;
            // 
            // типкузоваBindingSource
            // 
            this.типкузоваBindingSource.DataMember = "Тип_кузова";
            this.типкузоваBindingSource.DataSource = this.carSellDataSet;
            // 
            // годвыпускаотBindingSource
            // 
            this.годвыпускаотBindingSource.DataMember = "Год_выпуска_от";
            this.годвыпускаотBindingSource.DataSource = this.carSellDataSet;
            // 
            // годвыпускадоBindingSource
            // 
            this.годвыпускадоBindingSource.DataMember = "Год_выпуска_до";
            this.годвыпускадоBindingSource.DataSource = this.carSellDataSet;
            // 
            // объемдвигателяBindingSource
            // 
            this.объемдвигателяBindingSource.DataMember = "Объем_двигателя";
            this.объемдвигателяBindingSource.DataSource = this.carSellDataSet;
            // 
            // мощностьBindingSource
            // 
            this.мощностьBindingSource.DataMember = "Мощность";
            this.мощностьBindingSource.DataSource = this.carSellDataSet;
            // 
            // пробегBindingSource
            // 
            this.пробегBindingSource.DataMember = "Пробег";
            this.пробегBindingSource.DataSource = this.carSellDataSet;
            // 
            // цветBindingSource
            // 
            this.цветBindingSource.DataMember = "Цвет";
            this.цветBindingSource.DataSource = this.carSellDataSet;
            // 
            // диапазонценыBindingSource
            // 
            this.диапазонценыBindingSource.DataMember = "Диапазон_цены";
            this.диапазонценыBindingSource.DataSource = this.carSellDataSet;
            // 
            // klientPhoneBindingSource
            // 
            this.klientPhoneBindingSource.DataMember = "KlientPhone";
            this.klientPhoneBindingSource.DataSource = this.carSellDataSet;
            // 
            // allOrderTableAdapter
            // 
            this.allOrderTableAdapter.ClearBeforeFill = true;
            // 
            // клиентBindingSource
            // 
            this.клиентBindingSource.DataMember = "Клиент";
            this.клиентBindingSource.DataSource = this.carSellDataSet;
            // 
            // клиентTableAdapter
            // 
            this.клиентTableAdapter.ClearBeforeFill = true;
            // 
            // клиент_покупательTableAdapter
            // 
            this.клиент_покупательTableAdapter.ClearBeforeFill = true;
            // 
            // klientPhoneTableAdapter
            // 
            this.klientPhoneTableAdapter.ClearBeforeFill = true;
            // 
            // тип_ТСTableAdapter
            // 
            this.тип_ТСTableAdapter.ClearBeforeFill = true;
            // 
            // марка_автоTableAdapter
            // 
            this.марка_автоTableAdapter.ClearBeforeFill = true;
            // 
            // модель_автоTableAdapter
            // 
            this.модель_автоTableAdapter.ClearBeforeFill = true;
            // 
            // тип_кузоваTableAdapter
            // 
            this.тип_кузоваTableAdapter.ClearBeforeFill = true;
            // 
            // год_выпуска_отTableAdapter
            // 
            this.год_выпуска_отTableAdapter.ClearBeforeFill = true;
            // 
            // год_выпуска_доTableAdapter
            // 
            this.год_выпуска_доTableAdapter.ClearBeforeFill = true;
            // 
            // объем_двигателяTableAdapter
            // 
            this.объем_двигателяTableAdapter.ClearBeforeFill = true;
            // 
            // мощностьTableAdapter
            // 
            this.мощностьTableAdapter.ClearBeforeFill = true;
            // 
            // пробегTableAdapter
            // 
            this.пробегTableAdapter.ClearBeforeFill = true;
            // 
            // цветTableAdapter
            // 
            this.цветTableAdapter.ClearBeforeFill = true;
            // 
            // диапазон_ценыTableAdapter
            // 
            this.диапазон_ценыTableAdapter.ClearBeforeFill = true;
            // 
            // fullKlNameTableAdapter
            // 
            this.fullKlNameTableAdapter.ClearBeforeFill = true;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Tomato;
            this.button4.Location = new System.Drawing.Point(883, 708);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(106, 29);
            this.button4.TabIndex = 6;
            this.button4.Text = "Удалить";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.OrangeRed;
            this.button1.Location = new System.Drawing.Point(509, 708);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 29);
            this.button1.TabIndex = 4;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // заказ_клиентаTableAdapter1
            // 
            this.заказ_клиентаTableAdapter1.ClearBeforeFill = true;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.RoyalBlue;
            this.button2.Location = new System.Drawing.Point(660, 708);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(168, 29);
            this.button2.TabIndex = 8;
            this.button2.Text = "Сохранить редактированное";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(553, 405);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(355, 24);
            this.label1.TabIndex = 9;
            this.label1.Text = "Редактировать только в нижнем окне";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодзаказаDataGridViewTextBoxColumn1,
            this.кодклиентапокупателяDataGridViewTextBoxColumn1,
            this.кодтипаТСDataGridViewTextBoxColumn,
            this.кодмаркиDataGridViewTextBoxColumn,
            this.кодмоделиDataGridViewTextBoxColumn,
            this.кодтипакузоваDataGridViewTextBoxColumn,
            this.кодгодавыпускаотDataGridViewTextBoxColumn,
            this.кодгодавыпускадоDataGridViewTextBoxColumn,
            this.коддиапазонаобъемадвигателяDataGridViewTextBoxColumn,
            this.коддиапазонамощностиDataGridViewTextBoxColumn,
            this.коддиапазонапробегаDataGridViewTextBoxColumn,
            this.кодцветаDataGridViewTextBoxColumn,
            this.коддиапазонаценыDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.заказклиентаBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(0, 428);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(1346, 274);
            this.dataGridView2.TabIndex = 10;
            // 
            // заказклиентаBindingSource
            // 
            this.заказклиентаBindingSource.DataMember = "Заказ_клиента";
            this.заказклиентаBindingSource.DataSource = this.carSellDataSet;
            // 
            // кодзаказаDataGridViewTextBoxColumn1
            // 
            this.кодзаказаDataGridViewTextBoxColumn1.DataPropertyName = "Код_заказа";
            this.кодзаказаDataGridViewTextBoxColumn1.HeaderText = "Код_заказа";
            this.кодзаказаDataGridViewTextBoxColumn1.Name = "кодзаказаDataGridViewTextBoxColumn1";
            this.кодзаказаDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // кодклиентапокупателяDataGridViewTextBoxColumn1
            // 
            this.кодклиентапокупателяDataGridViewTextBoxColumn1.DataPropertyName = "Код_клиента_покупателя";
            this.кодклиентапокупателяDataGridViewTextBoxColumn1.HeaderText = "Код_клиента_покупателя";
            this.кодклиентапокупателяDataGridViewTextBoxColumn1.Name = "кодклиентапокупателяDataGridViewTextBoxColumn1";
            // 
            // кодтипаТСDataGridViewTextBoxColumn
            // 
            this.кодтипаТСDataGridViewTextBoxColumn.DataPropertyName = "Код_типа_ТС";
            this.кодтипаТСDataGridViewTextBoxColumn.HeaderText = "Код_типа_ТС";
            this.кодтипаТСDataGridViewTextBoxColumn.Name = "кодтипаТСDataGridViewTextBoxColumn";
            // 
            // кодмаркиDataGridViewTextBoxColumn
            // 
            this.кодмаркиDataGridViewTextBoxColumn.DataPropertyName = "Код_марки";
            this.кодмаркиDataGridViewTextBoxColumn.HeaderText = "Код_марки";
            this.кодмаркиDataGridViewTextBoxColumn.Name = "кодмаркиDataGridViewTextBoxColumn";
            // 
            // кодмоделиDataGridViewTextBoxColumn
            // 
            this.кодмоделиDataGridViewTextBoxColumn.DataPropertyName = "Код_модели";
            this.кодмоделиDataGridViewTextBoxColumn.HeaderText = "Код_модели";
            this.кодмоделиDataGridViewTextBoxColumn.Name = "кодмоделиDataGridViewTextBoxColumn";
            // 
            // кодтипакузоваDataGridViewTextBoxColumn
            // 
            this.кодтипакузоваDataGridViewTextBoxColumn.DataPropertyName = "Код_типа_кузова";
            this.кодтипакузоваDataGridViewTextBoxColumn.HeaderText = "Код_типа_кузова";
            this.кодтипакузоваDataGridViewTextBoxColumn.Name = "кодтипакузоваDataGridViewTextBoxColumn";
            // 
            // кодгодавыпускаотDataGridViewTextBoxColumn
            // 
            this.кодгодавыпускаотDataGridViewTextBoxColumn.DataPropertyName = "Код_года_выпуска_от";
            this.кодгодавыпускаотDataGridViewTextBoxColumn.HeaderText = "Код_года_выпуска_от";
            this.кодгодавыпускаотDataGridViewTextBoxColumn.Name = "кодгодавыпускаотDataGridViewTextBoxColumn";
            // 
            // кодгодавыпускадоDataGridViewTextBoxColumn
            // 
            this.кодгодавыпускадоDataGridViewTextBoxColumn.DataPropertyName = "Код_года_выпуска_до";
            this.кодгодавыпускадоDataGridViewTextBoxColumn.HeaderText = "Код_года_выпуска_до";
            this.кодгодавыпускадоDataGridViewTextBoxColumn.Name = "кодгодавыпускадоDataGridViewTextBoxColumn";
            // 
            // коддиапазонаобъемадвигателяDataGridViewTextBoxColumn
            // 
            this.коддиапазонаобъемадвигателяDataGridViewTextBoxColumn.DataPropertyName = "Код_диапазона_объема_двигателя";
            this.коддиапазонаобъемадвигателяDataGridViewTextBoxColumn.HeaderText = "Код_диапазона_объема_двигателя";
            this.коддиапазонаобъемадвигателяDataGridViewTextBoxColumn.Name = "коддиапазонаобъемадвигателяDataGridViewTextBoxColumn";
            // 
            // коддиапазонамощностиDataGridViewTextBoxColumn
            // 
            this.коддиапазонамощностиDataGridViewTextBoxColumn.DataPropertyName = "Код_диапазона_мощности";
            this.коддиапазонамощностиDataGridViewTextBoxColumn.HeaderText = "Код_диапазона_мощности";
            this.коддиапазонамощностиDataGridViewTextBoxColumn.Name = "коддиапазонамощностиDataGridViewTextBoxColumn";
            // 
            // коддиапазонапробегаDataGridViewTextBoxColumn
            // 
            this.коддиапазонапробегаDataGridViewTextBoxColumn.DataPropertyName = "Код_диапазона_пробега";
            this.коддиапазонапробегаDataGridViewTextBoxColumn.HeaderText = "Код_диапазона_пробега";
            this.коддиапазонапробегаDataGridViewTextBoxColumn.Name = "коддиапазонапробегаDataGridViewTextBoxColumn";
            // 
            // кодцветаDataGridViewTextBoxColumn
            // 
            this.кодцветаDataGridViewTextBoxColumn.DataPropertyName = "Код_цвета";
            this.кодцветаDataGridViewTextBoxColumn.HeaderText = "Код_цвета";
            this.кодцветаDataGridViewTextBoxColumn.Name = "кодцветаDataGridViewTextBoxColumn";
            // 
            // коддиапазонаценыDataGridViewTextBoxColumn
            // 
            this.коддиапазонаценыDataGridViewTextBoxColumn.DataPropertyName = "Код_диапазона_цены";
            this.коддиапазонаценыDataGridViewTextBoxColumn.HeaderText = "Код_диапазона_цены";
            this.коддиапазонаценыDataGridViewTextBoxColumn.Name = "коддиапазонаценыDataGridViewTextBoxColumn";
            // 
            // Form36
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1346, 749);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form36";
            this.Text = "Form36";
            this.Load += new System.EventHandler(this.Form36_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.allOrderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентпокупательBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fullKlNameBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типТСBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.маркаавтоBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.модельавтоBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типкузоваBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.годвыпускаотBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.годвыпускадоBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.объемдвигателяBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.мощностьBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.пробегBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.цветBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.диапазонценыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientPhoneBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.заказклиентаBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CarSellDataSet carSellDataSet;
        private System.Windows.Forms.BindingSource allOrderBindingSource;
        private CarSellDataSetTableAdapters.AllOrderTableAdapter allOrderTableAdapter;
        private System.Windows.Forms.BindingSource клиентBindingSource;
        private CarSellDataSetTableAdapters.КлиентTableAdapter клиентTableAdapter;
        private System.Windows.Forms.BindingSource клиентпокупательBindingSource;
        private CarSellDataSetTableAdapters.Клиент_покупательTableAdapter клиент_покупательTableAdapter;
        private System.Windows.Forms.BindingSource klientPhoneBindingSource;
        private CarSellDataSetTableAdapters.KlientPhoneTableAdapter klientPhoneTableAdapter;
        private System.Windows.Forms.BindingSource типТСBindingSource;
        private CarSellDataSetTableAdapters.Тип_ТСTableAdapter тип_ТСTableAdapter;
        private System.Windows.Forms.BindingSource маркаавтоBindingSource;
        private CarSellDataSetTableAdapters.Марка_автоTableAdapter марка_автоTableAdapter;
        private System.Windows.Forms.BindingSource модельавтоBindingSource;
        private CarSellDataSetTableAdapters.Модель_автоTableAdapter модель_автоTableAdapter;
        private System.Windows.Forms.BindingSource типкузоваBindingSource;
        private CarSellDataSetTableAdapters.Тип_кузоваTableAdapter тип_кузоваTableAdapter;
        private System.Windows.Forms.BindingSource годвыпускаотBindingSource;
        private CarSellDataSetTableAdapters.Год_выпуска_отTableAdapter год_выпуска_отTableAdapter;
        private System.Windows.Forms.BindingSource годвыпускадоBindingSource;
        private CarSellDataSetTableAdapters.Год_выпуска_доTableAdapter год_выпуска_доTableAdapter;
        private System.Windows.Forms.BindingSource объемдвигателяBindingSource;
        private CarSellDataSetTableAdapters.Объем_двигателяTableAdapter объем_двигателяTableAdapter;
        private System.Windows.Forms.BindingSource мощностьBindingSource;
        private CarSellDataSetTableAdapters.МощностьTableAdapter мощностьTableAdapter;
        private System.Windows.Forms.BindingSource пробегBindingSource;
        private CarSellDataSetTableAdapters.ПробегTableAdapter пробегTableAdapter;
        private System.Windows.Forms.BindingSource цветBindingSource;
        private CarSellDataSetTableAdapters.ЦветTableAdapter цветTableAdapter;
        private System.Windows.Forms.BindingSource диапазонценыBindingSource;
        private CarSellDataSetTableAdapters.Диапазон_ценыTableAdapter диапазон_ценыTableAdapter;
        private System.Windows.Forms.BindingSource fullKlNameBindingSource;
        private CarSellDataSetTableAdapters.FullKlNameTableAdapter fullKlNameTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодзаказаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодклиентапокупателяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn клиентDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn типТСDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn маркаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn модельDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn типкузоваDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn годвыпускаотDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn годвыпускадоDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn диапазонобъемадвигателяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn диапазонмощностиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn диапазонпробегаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn цветDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn диапазонценыDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button1;
        private CarSellDataSetTableAdapters.Заказ_клиентаTableAdapter заказ_клиентаTableAdapter1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодзаказаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодклиентапокупателяDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодтипаТСDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодмаркиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодмоделиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодтипакузоваDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодгодавыпускаотDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодгодавыпускадоDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn коддиапазонаобъемадвигателяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn коддиапазонамощностиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn коддиапазонапробегаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодцветаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn коддиапазонаценыDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource заказклиентаBindingSource;
    }
}