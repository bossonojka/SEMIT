﻿namespace CarSell
{
    partial class Form41
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.carSellDataSet = new CarSell.CarSellDataSet();
            this.adressForNewKlBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.adressForNewKlTableAdapter = new CarSell.CarSellDataSetTableAdapters.AdressForNewKlTableAdapter();
            this.адресBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.типпомещенияBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.типстроенияBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.типулицыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.населенныйпунктBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.типНПBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.районBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.областьBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.диапазонценыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.цветBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.пробегBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.мощностьBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.объемдвигателяBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.годвыпускадоBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.годвыпускаотBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.типкузоваBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.модельавтоBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.маркаавтоBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.клиентпродавецBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.типТСBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.клиентпокупательBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.областьTableAdapter = new CarSell.CarSellDataSetTableAdapters.ОбластьTableAdapter();
            this.районTableAdapter = new CarSell.CarSellDataSetTableAdapters.РайонTableAdapter();
            this.тип_НПTableAdapter = new CarSell.CarSellDataSetTableAdapters.Тип_НПTableAdapter();
            this.населенный_пунктTableAdapter = new CarSell.CarSellDataSetTableAdapters.Населенный_пунктTableAdapter();
            this.тип_улицыTableAdapter = new CarSell.CarSellDataSetTableAdapters.Тип_улицыTableAdapter();
            this.тип_строенияTableAdapter = new CarSell.CarSellDataSetTableAdapters.Тип_строенияTableAdapter();
            this.тип_помещенияTableAdapter = new CarSell.CarSellDataSetTableAdapters.Тип_помещенияTableAdapter();
            this.адресTableAdapter = new CarSell.CarSellDataSetTableAdapters.АдресTableAdapter();
            this.клиент_продавецTableAdapter = new CarSell.CarSellDataSetTableAdapters.Клиент_продавецTableAdapter();
            this.тип_ТСTableAdapter = new CarSell.CarSellDataSetTableAdapters.Тип_ТСTableAdapter();
            this.марка_автоTableAdapter = new CarSell.CarSellDataSetTableAdapters.Марка_автоTableAdapter();
            this.маркаавтоBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.модель_автоTableAdapter = new CarSell.CarSellDataSetTableAdapters.Модель_автоTableAdapter();
            this.тип_кузоваTableAdapter = new CarSell.CarSellDataSetTableAdapters.Тип_кузоваTableAdapter();
            this.год_выпуска_отTableAdapter = new CarSell.CarSellDataSetTableAdapters.Год_выпуска_отTableAdapter();
            this.год_выпуска_доTableAdapter = new CarSell.CarSellDataSetTableAdapters.Год_выпуска_доTableAdapter();
            this.объем_двигателяTableAdapter = new CarSell.CarSellDataSetTableAdapters.Объем_двигателяTableAdapter();
            this.мощностьTableAdapter = new CarSell.CarSellDataSetTableAdapters.МощностьTableAdapter();
            this.пробегTableAdapter = new CarSell.CarSellDataSetTableAdapters.ПробегTableAdapter();
            this.цветTableAdapter = new CarSell.CarSellDataSetTableAdapters.ЦветTableAdapter();
            this.диапазон_ценыTableAdapter = new CarSell.CarSellDataSetTableAdapters.Диапазон_ценыTableAdapter();
            this.клиент_покупательTableAdapter = new CarSell.CarSellDataSetTableAdapters.Клиент_покупательTableAdapter();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.улицаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.улицаTableAdapter = new CarSell.CarSellDataSetTableAdapters.УлицаTableAdapter();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button18 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button19 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.comboBox13 = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.button25 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.comboBox14 = new System.Windows.Forms.ComboBox();
            this.comboBox15 = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.comboBox18 = new System.Windows.Forms.ComboBox();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.comboBox16 = new System.Windows.Forms.ComboBox();
            this.comboBox17 = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button11 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.shortAdressBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label18 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label14 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.видтелефонаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.телефонBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.fullKlNameBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.fullKlNameTableAdapter = new CarSell.CarSellDataSetTableAdapters.FullKlNameTableAdapter();
            this.телефонTableAdapter = new CarSell.CarSellDataSetTableAdapters.ТелефонTableAdapter();
            this.вид_телефонаTableAdapter = new CarSell.CarSellDataSetTableAdapters.Вид_телефонаTableAdapter();
            this.shortAdressTableAdapter = new CarSell.CarSellDataSetTableAdapters.ShortAdressTableAdapter();
            this.клиентTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.КлиентTableAdapter();
            this.телефон_клиентаTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Телефон_клиентаTableAdapter();
            this.клиент_продавецTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Клиент_продавецTableAdapter();
            this.клиент_покупательTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Клиент_покупательTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.adressForNewKlBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.адресBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типпомещенияBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типстроенияBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типулицыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.населенныйпунктBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типНПBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.районBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.областьBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.диапазонценыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.цветBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.пробегBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.мощностьBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.объемдвигателяBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.годвыпускадоBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.годвыпускаотBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типкузоваBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.модельавтоBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.маркаавтоBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентпродавецBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типТСBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентпокупательBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.маркаавтоBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.улицаBindingSource)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shortAdressBindingSource)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.видтелефонаBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.телефонBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fullKlNameBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // carSellDataSet
            // 
            this.carSellDataSet.DataSetName = "CarSellDataSet";
            this.carSellDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // adressForNewKlBindingSource
            // 
            this.adressForNewKlBindingSource.DataMember = "AdressForNewKl";
            this.adressForNewKlBindingSource.DataSource = this.carSellDataSet;
            // 
            // adressForNewKlTableAdapter
            // 
            this.adressForNewKlTableAdapter.ClearBeforeFill = true;
            // 
            // адресBindingSource
            // 
            this.адресBindingSource.DataMember = "Адрес";
            this.адресBindingSource.DataSource = this.carSellDataSet;
            // 
            // типпомещенияBindingSource
            // 
            this.типпомещенияBindingSource.DataMember = "Тип_помещения";
            this.типпомещенияBindingSource.DataSource = this.carSellDataSet;
            // 
            // типстроенияBindingSource
            // 
            this.типстроенияBindingSource.DataMember = "Тип_строения";
            this.типстроенияBindingSource.DataSource = this.carSellDataSet;
            // 
            // типулицыBindingSource
            // 
            this.типулицыBindingSource.DataMember = "Тип_улицы";
            this.типулицыBindingSource.DataSource = this.carSellDataSet;
            // 
            // населенныйпунктBindingSource
            // 
            this.населенныйпунктBindingSource.DataMember = "Населенный_пункт";
            this.населенныйпунктBindingSource.DataSource = this.carSellDataSet;
            // 
            // типНПBindingSource
            // 
            this.типНПBindingSource.DataMember = "Тип_НП";
            this.типНПBindingSource.DataSource = this.carSellDataSet;
            // 
            // районBindingSource
            // 
            this.районBindingSource.DataMember = "Район";
            this.районBindingSource.DataSource = this.carSellDataSet;
            // 
            // областьBindingSource
            // 
            this.областьBindingSource.DataMember = "Область";
            this.областьBindingSource.DataSource = this.carSellDataSet;
            // 
            // диапазонценыBindingSource
            // 
            this.диапазонценыBindingSource.DataMember = "Диапазон_цены";
            this.диапазонценыBindingSource.DataSource = this.carSellDataSet;
            // 
            // цветBindingSource
            // 
            this.цветBindingSource.DataMember = "Цвет";
            this.цветBindingSource.DataSource = this.carSellDataSet;
            // 
            // пробегBindingSource
            // 
            this.пробегBindingSource.DataMember = "Пробег";
            this.пробегBindingSource.DataSource = this.carSellDataSet;
            // 
            // мощностьBindingSource
            // 
            this.мощностьBindingSource.DataMember = "Мощность";
            this.мощностьBindingSource.DataSource = this.carSellDataSet;
            // 
            // объемдвигателяBindingSource
            // 
            this.объемдвигателяBindingSource.DataMember = "Объем_двигателя";
            this.объемдвигателяBindingSource.DataSource = this.carSellDataSet;
            // 
            // годвыпускадоBindingSource
            // 
            this.годвыпускадоBindingSource.DataMember = "Год_выпуска_до";
            this.годвыпускадоBindingSource.DataSource = this.carSellDataSet;
            // 
            // годвыпускаотBindingSource
            // 
            this.годвыпускаотBindingSource.DataMember = "Год_выпуска_от";
            this.годвыпускаотBindingSource.DataSource = this.carSellDataSet;
            // 
            // типкузоваBindingSource
            // 
            this.типкузоваBindingSource.DataMember = "Тип_кузова";
            this.типкузоваBindingSource.DataSource = this.carSellDataSet;
            // 
            // модельавтоBindingSource
            // 
            this.модельавтоBindingSource.DataMember = "Модель_авто";
            this.модельавтоBindingSource.DataSource = this.carSellDataSet;
            // 
            // маркаавтоBindingSource
            // 
            this.маркаавтоBindingSource.DataMember = "Марка_авто";
            this.маркаавтоBindingSource.DataSource = this.carSellDataSet;
            // 
            // клиентпродавецBindingSource
            // 
            this.клиентпродавецBindingSource.DataMember = "Клиент_продавец";
            this.клиентпродавецBindingSource.DataSource = this.carSellDataSet;
            // 
            // типТСBindingSource
            // 
            this.типТСBindingSource.DataMember = "Тип_ТС";
            this.типТСBindingSource.DataSource = this.carSellDataSet;
            // 
            // клиентпокупательBindingSource
            // 
            this.клиентпокупательBindingSource.DataMember = "Клиент_покупатель";
            this.клиентпокупательBindingSource.DataSource = this.carSellDataSet;
            // 
            // областьTableAdapter
            // 
            this.областьTableAdapter.ClearBeforeFill = true;
            // 
            // районTableAdapter
            // 
            this.районTableAdapter.ClearBeforeFill = true;
            // 
            // тип_НПTableAdapter
            // 
            this.тип_НПTableAdapter.ClearBeforeFill = true;
            // 
            // населенный_пунктTableAdapter
            // 
            this.населенный_пунктTableAdapter.ClearBeforeFill = true;
            // 
            // тип_улицыTableAdapter
            // 
            this.тип_улицыTableAdapter.ClearBeforeFill = true;
            // 
            // тип_строенияTableAdapter
            // 
            this.тип_строенияTableAdapter.ClearBeforeFill = true;
            // 
            // тип_помещенияTableAdapter
            // 
            this.тип_помещенияTableAdapter.ClearBeforeFill = true;
            // 
            // адресTableAdapter
            // 
            this.адресTableAdapter.ClearBeforeFill = true;
            // 
            // клиент_продавецTableAdapter
            // 
            this.клиент_продавецTableAdapter.ClearBeforeFill = true;
            // 
            // тип_ТСTableAdapter
            // 
            this.тип_ТСTableAdapter.ClearBeforeFill = true;
            // 
            // марка_автоTableAdapter
            // 
            this.марка_автоTableAdapter.ClearBeforeFill = true;
            // 
            // маркаавтоBindingSource1
            // 
            this.маркаавтоBindingSource1.DataMember = "Марка_авто";
            this.маркаавтоBindingSource1.DataSource = this.carSellDataSet;
            // 
            // модель_автоTableAdapter
            // 
            this.модель_автоTableAdapter.ClearBeforeFill = true;
            // 
            // тип_кузоваTableAdapter
            // 
            this.тип_кузоваTableAdapter.ClearBeforeFill = true;
            // 
            // год_выпуска_отTableAdapter
            // 
            this.год_выпуска_отTableAdapter.ClearBeforeFill = true;
            // 
            // год_выпуска_доTableAdapter
            // 
            this.год_выпуска_доTableAdapter.ClearBeforeFill = true;
            // 
            // объем_двигателяTableAdapter
            // 
            this.объем_двигателяTableAdapter.ClearBeforeFill = true;
            // 
            // мощностьTableAdapter
            // 
            this.мощностьTableAdapter.ClearBeforeFill = true;
            // 
            // пробегTableAdapter
            // 
            this.пробегTableAdapter.ClearBeforeFill = true;
            // 
            // цветTableAdapter
            // 
            this.цветTableAdapter.ClearBeforeFill = true;
            // 
            // диапазон_ценыTableAdapter
            // 
            this.диапазон_ценыTableAdapter.ClearBeforeFill = true;
            // 
            // клиент_покупательTableAdapter
            // 
            this.клиент_покупательTableAdapter.ClearBeforeFill = true;
            // 
            // улицаBindingSource
            // 
            this.улицаBindingSource.DataMember = "Улица";
            this.улицаBindingSource.DataSource = this.carSellDataSet;
            // 
            // улицаTableAdapter
            // 
            this.улицаTableAdapter.ClearBeforeFill = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.tabControl2);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(711, 492);
            this.tabPage3.TabIndex = 5;
            this.tabPage3.Text = "Адрес";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Location = new System.Drawing.Point(3, 21);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(702, 378);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.textBox1);
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Controls.Add(this.button18);
            this.tabPage4.Controls.Add(this.button14);
            this.tabPage4.Controls.Add(this.comboBox10);
            this.tabPage4.Controls.Add(this.label19);
            this.tabPage4.Controls.Add(this.label17);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(694, 352);
            this.tabPage4.TabIndex = 0;
            this.tabPage4.Text = "Район";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(113, 86);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(193, 20);
            this.textBox1.TabIndex = 34;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(279, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 24);
            this.label5.TabIndex = 33;
            this.label5.Text = "ИЛИ";
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.DodgerBlue;
            this.button18.Location = new System.Drawing.Point(236, 175);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(183, 28);
            this.button18.TabIndex = 31;
            this.button18.Text = "Сохранить";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button14.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button14.Location = new System.Drawing.Point(387, 15);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(160, 28);
            this.button14.TabIndex = 30;
            this.button14.Text = "Добавить новую область";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // comboBox10
            // 
            this.comboBox10.DataSource = this.областьBindingSource;
            this.comboBox10.DisplayMember = "Название_области";
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.ItemHeight = 13;
            this.comboBox10.Location = new System.Drawing.Point(113, 22);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(121, 21);
            this.comboBox10.TabIndex = 29;
            this.comboBox10.ValueMember = "Код_области";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.Location = new System.Drawing.Point(16, 23);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(75, 20);
            this.label19.TabIndex = 28;
            this.label19.Text = "Область";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(16, 86);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(55, 20);
            this.label17.TabIndex = 25;
            this.label17.Text = "Район";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.textBox2);
            this.tabPage6.Controls.Add(this.label6);
            this.tabPage6.Controls.Add(this.button19);
            this.tabPage6.Controls.Add(this.button15);
            this.tabPage6.Controls.Add(this.comboBox12);
            this.tabPage6.Controls.Add(this.comboBox13);
            this.tabPage6.Controls.Add(this.label20);
            this.tabPage6.Controls.Add(this.label21);
            this.tabPage6.Controls.Add(this.label22);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(694, 352);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "Населенный пункт";
            this.tabPage6.UseVisualStyleBackColor = true;
            this.tabPage6.Click += new System.EventHandler(this.tabPage6_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(175, 125);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(193, 20);
            this.textBox2.TabIndex = 40;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(350, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 24);
            this.label6.TabIndex = 38;
            this.label6.Text = "ИЛИ";
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.DodgerBlue;
            this.button19.Location = new System.Drawing.Point(241, 195);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(183, 28);
            this.button19.TabIndex = 36;
            this.button19.Text = "Сохранить";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button15.Location = new System.Drawing.Point(468, 20);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(160, 28);
            this.button15.TabIndex = 35;
            this.button15.Text = "Добавить новый тип НП";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // comboBox12
            // 
            this.comboBox12.DataSource = this.типНПBindingSource;
            this.comboBox12.DisplayMember = "Название_типа_НП";
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.ItemHeight = 13;
            this.comboBox12.Location = new System.Drawing.Point(103, 27);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(121, 21);
            this.comboBox12.TabIndex = 31;
            this.comboBox12.ValueMember = "Код_типа_НП";
            // 
            // comboBox13
            // 
            this.comboBox13.DataSource = this.районBindingSource;
            this.comboBox13.DisplayMember = "Назва_району";
            this.comboBox13.FormattingEnabled = true;
            this.comboBox13.ItemHeight = 13;
            this.comboBox13.Location = new System.Drawing.Point(103, 74);
            this.comboBox13.Name = "comboBox13";
            this.comboBox13.Size = new System.Drawing.Size(121, 21);
            this.comboBox13.TabIndex = 30;
            this.comboBox13.ValueMember = "Код_району";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.Location = new System.Drawing.Point(6, 125);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(150, 20);
            this.label20.TabIndex = 29;
            this.label20.Text = "Населенный пункт";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.Location = new System.Drawing.Point(6, 28);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(64, 20);
            this.label21.TabIndex = 28;
            this.label21.Text = "Тип НП";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.Location = new System.Drawing.Point(6, 75);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(55, 20);
            this.label22.TabIndex = 27;
            this.label22.Text = "Район";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.label8);
            this.tabPage7.Controls.Add(this.button25);
            this.tabPage7.Controls.Add(this.button20);
            this.tabPage7.Controls.Add(this.textBox11);
            this.tabPage7.Controls.Add(this.comboBox14);
            this.tabPage7.Controls.Add(this.comboBox15);
            this.tabPage7.Controls.Add(this.label23);
            this.tabPage7.Controls.Add(this.label24);
            this.tabPage7.Controls.Add(this.label25);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(694, 352);
            this.tabPage7.TabIndex = 2;
            this.tabPage7.Text = "Улица";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(351, 15);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 24);
            this.label8.TabIndex = 39;
            this.label8.Text = "ИЛИ";
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.DodgerBlue;
            this.button25.Location = new System.Drawing.Point(260, 200);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(183, 28);
            this.button25.TabIndex = 37;
            this.button25.Text = "Сохранить";
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button20.Location = new System.Drawing.Point(457, 11);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(160, 28);
            this.button20.TabIndex = 35;
            this.button20.Text = "Добавить новый тип улицы";
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(89, 132);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(174, 20);
            this.textBox11.TabIndex = 33;
            // 
            // comboBox14
            // 
            this.comboBox14.DataSource = this.типулицыBindingSource;
            this.comboBox14.DisplayMember = "Тип_улицы";
            this.comboBox14.FormattingEnabled = true;
            this.comboBox14.ItemHeight = 13;
            this.comboBox14.Location = new System.Drawing.Point(132, 18);
            this.comboBox14.Name = "comboBox14";
            this.comboBox14.Size = new System.Drawing.Size(121, 21);
            this.comboBox14.TabIndex = 32;
            this.comboBox14.ValueMember = "Код_типа_улицы";
            // 
            // comboBox15
            // 
            this.comboBox15.DataSource = this.населенныйпунктBindingSource;
            this.comboBox15.DisplayMember = "Название";
            this.comboBox15.FormattingEnabled = true;
            this.comboBox15.ItemHeight = 13;
            this.comboBox15.Location = new System.Drawing.Point(172, 76);
            this.comboBox15.Name = "comboBox15";
            this.comboBox15.Size = new System.Drawing.Size(144, 21);
            this.comboBox15.TabIndex = 31;
            this.comboBox15.ValueMember = "Код_НП";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label23.Location = new System.Drawing.Point(6, 132);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(56, 20);
            this.label23.TabIndex = 30;
            this.label23.Text = "Улица";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label24.Location = new System.Drawing.Point(6, 19);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(86, 20);
            this.label24.TabIndex = 29;
            this.label24.Text = "Тип улицы";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label25.Location = new System.Drawing.Point(6, 77);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(150, 20);
            this.label25.TabIndex = 28;
            this.label25.Text = "Населенный пункт";
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.label9);
            this.tabPage8.Controls.Add(this.label13);
            this.tabPage8.Controls.Add(this.comboBox18);
            this.tabPage8.Controls.Add(this.button22);
            this.tabPage8.Controls.Add(this.button23);
            this.tabPage8.Controls.Add(this.button24);
            this.tabPage8.Controls.Add(this.textBox12);
            this.tabPage8.Controls.Add(this.textBox13);
            this.tabPage8.Controls.Add(this.textBox14);
            this.tabPage8.Controls.Add(this.comboBox16);
            this.tabPage8.Controls.Add(this.comboBox17);
            this.tabPage8.Controls.Add(this.label26);
            this.tabPage8.Controls.Add(this.label27);
            this.tabPage8.Controls.Add(this.label28);
            this.tabPage8.Controls.Add(this.label29);
            this.tabPage8.Controls.Add(this.label30);
            this.tabPage8.Controls.Add(this.label31);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(694, 352);
            this.tabPage8.TabIndex = 3;
            this.tabPage8.Text = "Адрес";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(331, 55);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 24);
            this.label9.TabIndex = 48;
            this.label9.Text = "ИЛИ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(331, 141);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(48, 24);
            this.label13.TabIndex = 47;
            this.label13.Text = "ИЛИ";
            // 
            // comboBox18
            // 
            this.comboBox18.DataSource = this.улицаBindingSource;
            this.comboBox18.DisplayMember = "Название_улицы";
            this.comboBox18.FormattingEnabled = true;
            this.comboBox18.ItemHeight = 13;
            this.comboBox18.Location = new System.Drawing.Point(105, 15);
            this.comboBox18.Name = "comboBox18";
            this.comboBox18.Size = new System.Drawing.Size(121, 21);
            this.comboBox18.TabIndex = 46;
            this.comboBox18.ValueMember = "Код_улицы";
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.DodgerBlue;
            this.button22.Location = new System.Drawing.Point(246, 303);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(183, 28);
            this.button22.TabIndex = 45;
            this.button22.Text = "Сохранить";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button23.Location = new System.Drawing.Point(426, 137);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(183, 28);
            this.button23.TabIndex = 44;
            this.button23.Text = "Добавить новый тип помещения";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button24.Location = new System.Drawing.Point(426, 51);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(183, 28);
            this.button24.TabIndex = 43;
            this.button24.Text = "Добавить новый тип строения";
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(115, 233);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(121, 20);
            this.textBox12.TabIndex = 42;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(184, 192);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(121, 20);
            this.textBox13.TabIndex = 41;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(168, 104);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(121, 20);
            this.textBox14.TabIndex = 40;
            // 
            // comboBox16
            // 
            this.comboBox16.DataSource = this.типпомещенияBindingSource;
            this.comboBox16.DisplayMember = "Тип_помещения";
            this.comboBox16.FormattingEnabled = true;
            this.comboBox16.ItemHeight = 13;
            this.comboBox16.Location = new System.Drawing.Point(168, 144);
            this.comboBox16.Name = "comboBox16";
            this.comboBox16.Size = new System.Drawing.Size(121, 21);
            this.comboBox16.TabIndex = 38;
            this.comboBox16.ValueMember = "Код_типа_помещения";
            // 
            // comboBox17
            // 
            this.comboBox17.DataSource = this.типстроенияBindingSource;
            this.comboBox17.DisplayMember = "Тип_строения";
            this.comboBox17.FormattingEnabled = true;
            this.comboBox17.ItemHeight = 13;
            this.comboBox17.Location = new System.Drawing.Point(154, 58);
            this.comboBox17.Name = "comboBox17";
            this.comboBox17.Size = new System.Drawing.Size(121, 21);
            this.comboBox17.TabIndex = 37;
            this.comboBox17.ValueMember = "Код_типа_строения";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label26.Location = new System.Drawing.Point(18, 233);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(65, 20);
            this.label26.TabIndex = 36;
            this.label26.Text = "Индекс";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label27.Location = new System.Drawing.Point(18, 192);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(150, 20);
            this.label27.TabIndex = 35;
            this.label27.Text = "Номер помещения";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label28.Location = new System.Drawing.Point(18, 145);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(127, 20);
            this.label28.TabIndex = 34;
            this.label28.Text = "Тип помещения";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label29.Location = new System.Drawing.Point(18, 104);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(134, 20);
            this.label29.TabIndex = 33;
            this.label29.Text = "Номер строения";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label30.Location = new System.Drawing.Point(18, 59);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(111, 20);
            this.label30.TabIndex = 32;
            this.label30.Text = "Тип строения";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label31.Location = new System.Drawing.Point(18, 16);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(56, 20);
            this.label31.TabIndex = 31;
            this.label31.Text = "Улица";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(1, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(719, 518);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tabControl1_MouseClick);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button11);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.comboBox8);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.textBox9);
            this.tabPage1.Controls.Add(this.textBox8);
            this.tabPage1.Controls.Add(this.textBox7);
            this.tabPage1.Controls.Add(this.textBox6);
            this.tabPage1.Controls.Add(this.textBox5);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(711, 492);
            this.tabPage1.TabIndex = 6;
            this.tabPage1.Text = "Клиент";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click_1);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.DodgerBlue;
            this.button11.Location = new System.Drawing.Point(241, 251);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(183, 28);
            this.button11.TabIndex = 44;
            this.button11.Text = "Сохранить";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(160, 320);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(337, 24);
            this.label7.TabIndex = 48;
            this.label7.Text = "Затем, выбирите, кем будет Клиент";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(160, 215);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(369, 24);
            this.label4.TabIndex = 47;
            this.label4.Text = "Сначало, нажмите на кнопку Сохранить";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Gold;
            this.button3.Location = new System.Drawing.Point(32, 373);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(213, 28);
            this.button3.TabIndex = 46;
            this.button3.Text = "Добавить как клиента - продавца";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Gold;
            this.button2.Location = new System.Drawing.Point(423, 373);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(231, 28);
            this.button2.TabIndex = 45;
            this.button2.Text = "Добавить как клиента - покупателя";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // comboBox8
            // 
            this.comboBox8.DataSource = this.shortAdressBindingSource;
            this.comboBox8.DisplayMember = "Адрес и индекс";
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.ItemHeight = 13;
            this.comboBox8.Location = new System.Drawing.Point(121, 30);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(170, 21);
            this.comboBox8.TabIndex = 43;
            this.comboBox8.ValueMember = "Код_адриса";
            // 
            // shortAdressBindingSource
            // 
            this.shortAdressBindingSource.DataMember = "ShortAdress";
            this.shortAdressBindingSource.DataSource = this.carSellDataSet;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.Location = new System.Drawing.Point(17, 30);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(57, 20);
            this.label18.TabIndex = 42;
            this.label18.Text = "Адрес";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(519, 167);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(134, 20);
            this.textBox9.TabIndex = 41;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(516, 101);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(137, 20);
            this.textBox8.TabIndex = 40;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(468, 30);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(192, 20);
            this.textBox7.TabIndex = 39;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(63, 157);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(192, 20);
            this.textBox6.TabIndex = 38;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(99, 96);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(192, 20);
            this.textBox5.TabIndex = 37;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(376, 167);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(134, 20);
            this.label16.TabIndex = 36;
            this.label16.Text = "Номер паспорта";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(379, 99);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(131, 20);
            this.label15.TabIndex = 35;
            this.label15.Text = "Серия паспорта";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(379, 28);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(83, 20);
            this.label12.TabIndex = 34;
            this.label12.Text = "Отчество";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(17, 157);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(40, 20);
            this.label11.TabIndex = 33;
            this.label11.Text = "Имя";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(17, 96);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 20);
            this.label10.TabIndex = 32;
            this.label10.Text = "Фамилия";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.comboBox3);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.comboBox2);
            this.tabPage2.Controls.Add(this.comboBox1);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.button12);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(711, 492);
            this.tabPage2.TabIndex = 7;
            this.tabPage2.Text = "Телефон";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click_1);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(430, 116);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(48, 24);
            this.label14.TabIndex = 51;
            this.label14.Text = "ИЛИ";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Location = new System.Drawing.Point(526, 112);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(160, 28);
            this.button1.TabIndex = 49;
            this.button1.Text = "Добавить номер телефона";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox3
            // 
            this.comboBox3.DataSource = this.видтелефонаBindingSource;
            this.comboBox3.DisplayMember = "Название_вида";
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.ItemHeight = 13;
            this.comboBox3.Location = new System.Drawing.Point(193, 194);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(183, 21);
            this.comboBox3.TabIndex = 48;
            this.comboBox3.ValueMember = "Код_вида_телефона";
            // 
            // видтелефонаBindingSource
            // 
            this.видтелефонаBindingSource.DataMember = "Вид_телефона";
            this.видтелефонаBindingSource.DataSource = this.carSellDataSet;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(26, 195);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 20);
            this.label3.TabIndex = 47;
            this.label3.Text = "Вид телефона";
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.телефонBindingSource;
            this.comboBox2.DisplayMember = "Номер_телефона";
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.ItemHeight = 13;
            this.comboBox2.Location = new System.Drawing.Point(193, 119);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(183, 21);
            this.comboBox2.TabIndex = 46;
            this.comboBox2.ValueMember = "ID_телефона";
            // 
            // телефонBindingSource
            // 
            this.телефонBindingSource.DataMember = "Телефон";
            this.телефонBindingSource.DataSource = this.carSellDataSet;
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.fullKlNameBindingSource;
            this.comboBox1.DisplayMember = "Клиент";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.ItemHeight = 13;
            this.comboBox1.Location = new System.Drawing.Point(146, 47);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(230, 21);
            this.comboBox1.TabIndex = 45;
            this.comboBox1.ValueMember = "Код_клиента";
            // 
            // fullKlNameBindingSource
            // 
            this.fullKlNameBindingSource.DataMember = "FullKlName";
            this.fullKlNameBindingSource.DataSource = this.carSellDataSet;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(26, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 20);
            this.label2.TabIndex = 44;
            this.label2.Text = "Клиент";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(26, 120);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 20);
            this.label1.TabIndex = 43;
            this.label1.Text = "Номер телефона";
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.DodgerBlue;
            this.button12.Location = new System.Drawing.Point(266, 304);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(183, 28);
            this.button12.TabIndex = 35;
            this.button12.Text = "Сохранить";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // fullKlNameTableAdapter
            // 
            this.fullKlNameTableAdapter.ClearBeforeFill = true;
            // 
            // телефонTableAdapter
            // 
            this.телефонTableAdapter.ClearBeforeFill = true;
            // 
            // вид_телефонаTableAdapter
            // 
            this.вид_телефонаTableAdapter.ClearBeforeFill = true;
            // 
            // shortAdressTableAdapter
            // 
            this.shortAdressTableAdapter.ClearBeforeFill = true;
            // 
            // клиентTableAdapter1
            // 
            this.клиентTableAdapter1.ClearBeforeFill = true;
            // 
            // телефон_клиентаTableAdapter1
            // 
            this.телефон_клиентаTableAdapter1.ClearBeforeFill = true;
            // 
            // клиент_продавецTableAdapter1
            // 
            this.клиент_продавецTableAdapter1.ClearBeforeFill = true;
            // 
            // клиент_покупательTableAdapter1
            // 
            this.клиент_покупательTableAdapter1.ClearBeforeFill = true;
            // 
            // Form41
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(722, 519);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form41";
            this.Text = "Form41";
            this.Load += new System.EventHandler(this.Form41_Load);
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.adressForNewKlBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.адресBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типпомещенияBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типстроенияBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типулицыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.населенныйпунктBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типНПBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.районBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.областьBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.диапазонценыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.цветBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.пробегBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.мощностьBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.объемдвигателяBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.годвыпускадоBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.годвыпускаотBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типкузоваBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.модельавтоBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.маркаавтоBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентпродавецBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типТСBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентпокупательBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.маркаавтоBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.улицаBindingSource)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shortAdressBindingSource)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.видтелефонаBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.телефонBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fullKlNameBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private CarSellDataSet carSellDataSet;
        private System.Windows.Forms.BindingSource adressForNewKlBindingSource;
        private CarSellDataSetTableAdapters.AdressForNewKlTableAdapter adressForNewKlTableAdapter;
        private System.Windows.Forms.BindingSource областьBindingSource;
        private CarSellDataSetTableAdapters.ОбластьTableAdapter областьTableAdapter;
        private System.Windows.Forms.BindingSource районBindingSource;
        private CarSellDataSetTableAdapters.РайонTableAdapter районTableAdapter;
        private System.Windows.Forms.BindingSource типНПBindingSource;
        private CarSellDataSetTableAdapters.Тип_НПTableAdapter тип_НПTableAdapter;
        private System.Windows.Forms.BindingSource населенныйпунктBindingSource;
        private CarSellDataSetTableAdapters.Населенный_пунктTableAdapter населенный_пунктTableAdapter;
        private System.Windows.Forms.BindingSource типулицыBindingSource;
        private CarSellDataSetTableAdapters.Тип_улицыTableAdapter тип_улицыTableAdapter;
        private System.Windows.Forms.BindingSource типстроенияBindingSource;
        private CarSellDataSetTableAdapters.Тип_строенияTableAdapter тип_строенияTableAdapter;
        private System.Windows.Forms.BindingSource типпомещенияBindingSource;
        private CarSellDataSetTableAdapters.Тип_помещенияTableAdapter тип_помещенияTableAdapter;
        private System.Windows.Forms.BindingSource адресBindingSource;
        private CarSellDataSetTableAdapters.АдресTableAdapter адресTableAdapter;
        private System.Windows.Forms.BindingSource клиентпродавецBindingSource;
        private CarSellDataSetTableAdapters.Клиент_продавецTableAdapter клиент_продавецTableAdapter;
        private System.Windows.Forms.BindingSource типТСBindingSource;
        private CarSellDataSetTableAdapters.Тип_ТСTableAdapter тип_ТСTableAdapter;
        private System.Windows.Forms.BindingSource маркаавтоBindingSource;
        private CarSellDataSetTableAdapters.Марка_автоTableAdapter марка_автоTableAdapter;
        private System.Windows.Forms.BindingSource маркаавтоBindingSource1;
        private System.Windows.Forms.BindingSource модельавтоBindingSource;
        private CarSellDataSetTableAdapters.Модель_автоTableAdapter модель_автоTableAdapter;
        private System.Windows.Forms.BindingSource типкузоваBindingSource;
        private CarSellDataSetTableAdapters.Тип_кузоваTableAdapter тип_кузоваTableAdapter;
        private System.Windows.Forms.BindingSource годвыпускаотBindingSource;
        private CarSellDataSetTableAdapters.Год_выпуска_отTableAdapter год_выпуска_отTableAdapter;
        private System.Windows.Forms.BindingSource годвыпускадоBindingSource;
        private CarSellDataSetTableAdapters.Год_выпуска_доTableAdapter год_выпуска_доTableAdapter;
        private System.Windows.Forms.BindingSource объемдвигателяBindingSource;
        private CarSellDataSetTableAdapters.Объем_двигателяTableAdapter объем_двигателяTableAdapter;
        private System.Windows.Forms.BindingSource мощностьBindingSource;
        private CarSellDataSetTableAdapters.МощностьTableAdapter мощностьTableAdapter;
        private System.Windows.Forms.BindingSource пробегBindingSource;
        private CarSellDataSetTableAdapters.ПробегTableAdapter пробегTableAdapter;
        private System.Windows.Forms.BindingSource цветBindingSource;
        private CarSellDataSetTableAdapters.ЦветTableAdapter цветTableAdapter;
        private System.Windows.Forms.BindingSource диапазонценыBindingSource;
        private CarSellDataSetTableAdapters.Диапазон_ценыTableAdapter диапазон_ценыTableAdapter;
        private System.Windows.Forms.BindingSource клиентпокупательBindingSource;
        private CarSellDataSetTableAdapters.Клиент_покупательTableAdapter клиент_покупательTableAdapter;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.BindingSource улицаBindingSource;
        private CarSellDataSetTableAdapters.УлицаTableAdapter улицаTableAdapter;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.ComboBox comboBox13;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.ComboBox comboBox14;
        private System.Windows.Forms.ComboBox comboBox15;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.ComboBox comboBox18;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.ComboBox comboBox16;
        private System.Windows.Forms.ComboBox comboBox17;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.BindingSource fullKlNameBindingSource;
        private CarSellDataSetTableAdapters.FullKlNameTableAdapter fullKlNameTableAdapter;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.BindingSource телефонBindingSource;
        private CarSellDataSetTableAdapters.ТелефонTableAdapter телефонTableAdapter;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.BindingSource видтелефонаBindingSource;
        private CarSellDataSetTableAdapters.Вид_телефонаTableAdapter вид_телефонаTableAdapter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.BindingSource shortAdressBindingSource;
        private CarSellDataSetTableAdapters.ShortAdressTableAdapter shortAdressTableAdapter;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private CarSellDataSetTableAdapters.КлиентTableAdapter клиентTableAdapter1;
        private CarSellDataSetTableAdapters.Телефон_клиентаTableAdapter телефон_клиентаTableAdapter1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label7;
        private CarSellDataSetTableAdapters.Клиент_продавецTableAdapter клиент_продавецTableAdapter1;
        private CarSellDataSetTableAdapters.Клиент_покупательTableAdapter клиент_покупательTableAdapter1;
    }
}