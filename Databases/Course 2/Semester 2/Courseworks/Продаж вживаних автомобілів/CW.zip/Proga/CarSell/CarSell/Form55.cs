﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;

namespace CarSell
{
    public partial class Form55 : Form
    {
        SqlConnection conn = null;
        public Form55()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime graduationYear = Convert.ToDateTime(this.dateTimePicker1.Text);


                conn = new SqlConnection();
                conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                conn.Open();
                SqlCommand myComand = conn.CreateCommand();
                myComand.CommandText = "INSERT into Год_выпуска_от (Год_выпуска_от) VALUES (@graduationYear)";
                myComand.Parameters.Add("@graduationYear", SqlDbType.Date, 8);
                myComand.Parameters["@graduationYear"].Value = graduationYear;

                int UspeshnoeIzmenenie = myComand.ExecuteNonQuery();
                if (UspeshnoeIzmenenie != 0)
                {
                    MessageBox.Show("Изменения внесены", "Изменение записи");
                }
                else
                {
                    MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            this.год_выпуска_отTableAdapter1.Fill(this.carSellDataSet1.Год_выпуска_от);
            Form42 form42 = new Form42();
            form42.Update();
        }
    }
}
