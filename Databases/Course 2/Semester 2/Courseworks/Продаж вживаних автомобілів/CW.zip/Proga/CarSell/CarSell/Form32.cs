﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace CarSell
{
    public partial class Form32 : Form
    {
        SqlConnection conn = null;
        public Form32()
        {
            InitializeComponent();
        }

        private void Form32_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Адрес' table. You can move, or remove it, as needed.
            this.адресTableAdapter.Fill(this.carSellDataSet.Адрес);
            // TODO: This line of code loads data into the 'carSellDataSet.Клиент' table. You can move, or remove it, as needed.
            this.клиентTableAdapter.Fill(this.carSellDataSet.Клиент);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form42 form42 = new Form42();
            form42.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int codeKl = int.Parse(dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells["кодклиентаDataGridViewTextBoxColumn"].Value.ToString());
            DialogResult result = MessageBox.Show("Удалить клиента?", "Предупреждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            switch (result)
            {
                case DialogResult.Yes:
                    {
                        try
                        {
                            conn = new SqlConnection();
                            conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                            conn.Open();
                            SqlCommand myCommand = conn.CreateCommand();
                            myCommand.CommandText = "Delete from Клиент Where Код_клиента = @codeKl";
                            myCommand.Parameters.Add("@codeKl", SqlDbType.Int, 4);
                            myCommand.Parameters["@codeKl"].Value = codeKl;


                            int UspeshnoeIzmenenie = myCommand.ExecuteNonQuery();
                            if (UspeshnoeIzmenenie != 0)
                            {
                                MessageBox.Show("Изменения внесены", "Изменение записи");
                            }
                            else
                            {
                                MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                        finally
                        {
                            conn.Close();
                        }
                        this.клиентTableAdapter.Fill(this.carSellDataSet.Клиент);
                        break;
                    }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.клиентTableAdapter.Update(this.carSellDataSet.Клиент);
        }
    }
}
