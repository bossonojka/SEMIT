﻿namespace CarSell
{
    partial class Form46
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.button18 = new System.Windows.Forms.Button();
            this.тип_НПTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Тип_НПTableAdapter();
            this.carSellDataSet1 = new CarSell.CarSellDataSet();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(123, 35);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(193, 20);
            this.textBox1.TabIndex = 36;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(26, 35);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(64, 20);
            this.label17.TabIndex = 35;
            this.label17.Text = "Тип НП";
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.DodgerBlue;
            this.button18.Location = new System.Drawing.Point(85, 132);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(183, 28);
            this.button18.TabIndex = 37;
            this.button18.Text = "Сохранить";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // тип_НПTableAdapter1
            // 
            this.тип_НПTableAdapter1.ClearBeforeFill = true;
            // 
            // carSellDataSet1
            // 
            this.carSellDataSet1.DataSetName = "CarSellDataSet";
            this.carSellDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Form46
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(374, 450);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label17);
            this.Name = "Form46";
            this.Text = "Form46";
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button18;
        private CarSellDataSetTableAdapters.Тип_НПTableAdapter тип_НПTableAdapter1;
        private CarSellDataSet carSellDataSet1;
    }
}