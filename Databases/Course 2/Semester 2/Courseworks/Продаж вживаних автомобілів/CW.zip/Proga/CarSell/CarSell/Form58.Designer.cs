﻿namespace CarSell
{
    partial class Form58
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label19 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.carSellDataSet1 = new CarSell.CarSellDataSet();
            this.год_выпуска_доTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Год_выпуска_доTableAdapter();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.кодгодавыпускадоDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.годвыпускадоDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.годвыпускадоBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.годвыпускадоBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.Location = new System.Drawing.Point(111, 9);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(229, 20);
            this.label19.TabIndex = 39;
            this.label19.Text = "Дата снятия с производства";
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button1.Location = new System.Drawing.Point(157, 153);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 30);
            this.button1.TabIndex = 40;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // carSellDataSet1
            // 
            this.carSellDataSet1.DataSetName = "CarSellDataSet";
            this.carSellDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // год_выпуска_доTableAdapter1
            // 
            this.год_выпуска_доTableAdapter1.ClearBeforeFill = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(153, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 20);
            this.label1.TabIndex = 42;
            this.label1.Text = "Формат: Год-01-01";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодгодавыпускадоDataGridViewTextBoxColumn,
            this.годвыпускадоDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.годвыпускадоBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(-1, 189);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(437, 243);
            this.dataGridView1.TabIndex = 93;
            // 
            // кодгодавыпускадоDataGridViewTextBoxColumn
            // 
            this.кодгодавыпускадоDataGridViewTextBoxColumn.DataPropertyName = "Код_года_выпуска_до";
            this.кодгодавыпускадоDataGridViewTextBoxColumn.FillWeight = 200F;
            this.кодгодавыпускадоDataGridViewTextBoxColumn.HeaderText = "Код_года_выпуска_до";
            this.кодгодавыпускадоDataGridViewTextBoxColumn.Name = "кодгодавыпускадоDataGridViewTextBoxColumn";
            this.кодгодавыпускадоDataGridViewTextBoxColumn.ReadOnly = true;
            this.кодгодавыпускадоDataGridViewTextBoxColumn.Width = 200;
            // 
            // годвыпускадоDataGridViewTextBoxColumn
            // 
            this.годвыпускадоDataGridViewTextBoxColumn.DataPropertyName = "Год_выпуска_до";
            this.годвыпускадоDataGridViewTextBoxColumn.HeaderText = "Год_выпуска_до";
            this.годвыпускадоDataGridViewTextBoxColumn.Name = "годвыпускадоDataGridViewTextBoxColumn";
            // 
            // годвыпускадоBindingSource
            // 
            this.годвыпускадоBindingSource.DataMember = "Год_выпуска_до";
            this.годвыпускадоBindingSource.DataSource = this.carSellDataSet1;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(125, 94);
            this.dateTimePicker1.MinDate = new System.DateTime(2008, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 41;
            // 
            // Form58
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(435, 433);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.button1);
            this.Name = "Form58";
            this.Text = "Form58";
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.годвыпускадоBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button1;
        private CarSellDataSet carSellDataSet1;
        private CarSellDataSetTableAdapters.Год_выпуска_доTableAdapter год_выпуска_доTableAdapter1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодгодавыпускадоDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn годвыпускадоDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource годвыпускадоBindingSource;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}