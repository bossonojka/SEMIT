﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSell
{
    public partial class Form29 : Form
    {
        public Form29()
        {
            InitializeComponent();
        }

        private void Form29_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Вид_телефона' table. You can move, or remove it, as needed.
            this.вид_телефонаTableAdapter.Fill(this.carSellDataSet.Вид_телефона);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form69 form69 = new Form69();
            form69.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.вид_телефонаTableAdapter.Update(this.carSellDataSet.Вид_телефона);
        }
    }
}
