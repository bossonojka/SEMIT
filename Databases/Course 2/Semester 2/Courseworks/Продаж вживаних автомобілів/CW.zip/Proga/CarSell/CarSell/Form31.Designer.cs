﻿namespace CarSell
{
    partial class Form31
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.коддилераDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.дилерDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDтелефонаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиевидаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номертелефонаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dillersPhoneBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carSellDataSet = new CarSell.CarSellDataSet();
            this.дилерBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fullDlNameBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.телефондилераBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.видтелефонаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.телефонBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dillersPhoneTableAdapter = new CarSell.CarSellDataSetTableAdapters.DillersPhoneTableAdapter();
            this.дилерTableAdapter = new CarSell.CarSellDataSetTableAdapters.ДилерTableAdapter();
            this.телефон_дилераTableAdapter = new CarSell.CarSellDataSetTableAdapters.Телефон_дилераTableAdapter();
            this.вид_телефонаTableAdapter = new CarSell.CarSellDataSetTableAdapters.Вид_телефонаTableAdapter();
            this.телефонTableAdapter = new CarSell.CarSellDataSetTableAdapters.ТелефонTableAdapter();
            this.fullDlNameTableAdapter = new CarSell.CarSellDataSetTableAdapters.FullDlNameTableAdapter();
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.коддилераDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDтелефонаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодвидателефонаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dillersPhoneBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.дилерBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fullDlNameBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.телефондилераBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.видтелефонаBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.телефонBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.коддилераDataGridViewTextBoxColumn,
            this.дилерDataGridViewTextBoxColumn,
            this.iDтелефонаDataGridViewTextBoxColumn,
            this.названиевидаDataGridViewTextBoxColumn,
            this.номертелефонаDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.dillersPhoneBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(1, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(718, 175);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // коддилераDataGridViewTextBoxColumn
            // 
            this.коддилераDataGridViewTextBoxColumn.DataPropertyName = "Код_дилера";
            this.коддилераDataGridViewTextBoxColumn.HeaderText = "Код_дилера";
            this.коддилераDataGridViewTextBoxColumn.Name = "коддилераDataGridViewTextBoxColumn";
            this.коддилераDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // дилерDataGridViewTextBoxColumn
            // 
            this.дилерDataGridViewTextBoxColumn.DataPropertyName = "Дилер";
            this.дилерDataGridViewTextBoxColumn.HeaderText = "Дилер";
            this.дилерDataGridViewTextBoxColumn.Name = "дилерDataGridViewTextBoxColumn";
            this.дилерDataGridViewTextBoxColumn.ReadOnly = true;
            this.дилерDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // iDтелефонаDataGridViewTextBoxColumn
            // 
            this.iDтелефонаDataGridViewTextBoxColumn.DataPropertyName = "ID_телефона";
            this.iDтелефонаDataGridViewTextBoxColumn.HeaderText = "ID_телефона";
            this.iDтелефонаDataGridViewTextBoxColumn.Name = "iDтелефонаDataGridViewTextBoxColumn";
            this.iDтелефонаDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // названиевидаDataGridViewTextBoxColumn
            // 
            this.названиевидаDataGridViewTextBoxColumn.DataPropertyName = "Название_вида";
            this.названиевидаDataGridViewTextBoxColumn.HeaderText = "Название_вида";
            this.названиевидаDataGridViewTextBoxColumn.Name = "названиевидаDataGridViewTextBoxColumn";
            this.названиевидаDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // номертелефонаDataGridViewTextBoxColumn
            // 
            this.номертелефонаDataGridViewTextBoxColumn.DataPropertyName = "Номер_телефона";
            this.номертелефонаDataGridViewTextBoxColumn.HeaderText = "Номер_телефона";
            this.номертелефонаDataGridViewTextBoxColumn.Name = "номертелефонаDataGridViewTextBoxColumn";
            this.номертелефонаDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dillersPhoneBindingSource
            // 
            this.dillersPhoneBindingSource.DataMember = "DillersPhone";
            this.dillersPhoneBindingSource.DataSource = this.carSellDataSet;
            // 
            // carSellDataSet
            // 
            this.carSellDataSet.DataSetName = "CarSellDataSet";
            this.carSellDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // дилерBindingSource
            // 
            this.дилерBindingSource.DataMember = "Дилер";
            this.дилерBindingSource.DataSource = this.carSellDataSet;
            // 
            // fullDlNameBindingSource
            // 
            this.fullDlNameBindingSource.DataMember = "FullDlName";
            this.fullDlNameBindingSource.DataSource = this.carSellDataSet;
            // 
            // телефондилераBindingSource
            // 
            this.телефондилераBindingSource.DataMember = "Телефон_дилера";
            this.телефондилераBindingSource.DataSource = this.carSellDataSet;
            // 
            // видтелефонаBindingSource
            // 
            this.видтелефонаBindingSource.DataMember = "Вид_телефона";
            this.видтелефонаBindingSource.DataSource = this.carSellDataSet;
            // 
            // телефонBindingSource
            // 
            this.телефонBindingSource.DataMember = "Телефон";
            this.телефонBindingSource.DataSource = this.carSellDataSet;
            // 
            // dillersPhoneTableAdapter
            // 
            this.dillersPhoneTableAdapter.ClearBeforeFill = true;
            // 
            // дилерTableAdapter
            // 
            this.дилерTableAdapter.ClearBeforeFill = true;
            // 
            // телефон_дилераTableAdapter
            // 
            this.телефон_дилераTableAdapter.ClearBeforeFill = true;
            // 
            // вид_телефонаTableAdapter
            // 
            this.вид_телефонаTableAdapter.ClearBeforeFill = true;
            // 
            // телефонTableAdapter
            // 
            this.телефонTableAdapter.ClearBeforeFill = true;
            // 
            // fullDlNameTableAdapter
            // 
            this.fullDlNameTableAdapter.ClearBeforeFill = true;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Tomato;
            this.button4.Location = new System.Drawing.Point(488, 382);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(106, 29);
            this.button4.TabIndex = 6;
            this.button4.Text = "Удалить";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.OrangeRed;
            this.button1.Location = new System.Drawing.Point(128, 382);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 29);
            this.button1.TabIndex = 4;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.коддилераDataGridViewTextBoxColumn1,
            this.iDтелефонаDataGridViewTextBoxColumn1,
            this.кодвидателефонаDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.телефондилераBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(1, 208);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(718, 168);
            this.dataGridView2.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(124, 181);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(448, 24);
            this.label1.TabIndex = 9;
            this.label1.Text = "Редактировать и удалять только в нижнем окне";
            // 
            // коддилераDataGridViewTextBoxColumn1
            // 
            this.коддилераDataGridViewTextBoxColumn1.DataPropertyName = "Код_дилера";
            this.коддилераDataGridViewTextBoxColumn1.HeaderText = "Код_дилера";
            this.коддилераDataGridViewTextBoxColumn1.Name = "коддилераDataGridViewTextBoxColumn1";
            // 
            // iDтелефонаDataGridViewTextBoxColumn1
            // 
            this.iDтелефонаDataGridViewTextBoxColumn1.DataPropertyName = "ID_телефона";
            this.iDтелефонаDataGridViewTextBoxColumn1.HeaderText = "ID_телефона";
            this.iDтелефонаDataGridViewTextBoxColumn1.Name = "iDтелефонаDataGridViewTextBoxColumn1";
            // 
            // кодвидателефонаDataGridViewTextBoxColumn
            // 
            this.кодвидателефонаDataGridViewTextBoxColumn.DataPropertyName = "Код_вида_телефона";
            this.кодвидателефонаDataGridViewTextBoxColumn.FillWeight = 150F;
            this.кодвидателефонаDataGridViewTextBoxColumn.HeaderText = "Код_вида_телефона";
            this.кодвидателефонаDataGridViewTextBoxColumn.Name = "кодвидателефонаDataGridViewTextBoxColumn";
            this.кодвидателефонаDataGridViewTextBoxColumn.Width = 150;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.RoyalBlue;
            this.button2.Location = new System.Drawing.Point(282, 382);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(168, 29);
            this.button2.TabIndex = 10;
            this.button2.Text = "Сохранить редактированное";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // Form31
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(718, 423);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form31";
            this.Text = "Form31";
            this.Load += new System.EventHandler(this.Form31_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dillersPhoneBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.дилерBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fullDlNameBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.телефондилераBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.видтелефонаBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.телефонBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CarSellDataSet carSellDataSet;
        private System.Windows.Forms.BindingSource dillersPhoneBindingSource;
        private CarSellDataSetTableAdapters.DillersPhoneTableAdapter dillersPhoneTableAdapter;
        private System.Windows.Forms.BindingSource дилерBindingSource;
        private CarSellDataSetTableAdapters.ДилерTableAdapter дилерTableAdapter;
        private System.Windows.Forms.BindingSource телефондилераBindingSource;
        private CarSellDataSetTableAdapters.Телефон_дилераTableAdapter телефон_дилераTableAdapter;
        private System.Windows.Forms.BindingSource видтелефонаBindingSource;
        private CarSellDataSetTableAdapters.Вид_телефонаTableAdapter вид_телефонаTableAdapter;
        private System.Windows.Forms.BindingSource телефонBindingSource;
        private CarSellDataSetTableAdapters.ТелефонTableAdapter телефонTableAdapter;
        private System.Windows.Forms.BindingSource fullDlNameBindingSource;
        private CarSellDataSetTableAdapters.FullDlNameTableAdapter fullDlNameTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn коддилераDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn дилерDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDтелефонаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиевидаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номертелефонаDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn коддилераDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDтелефонаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодвидателефонаDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
    }
}