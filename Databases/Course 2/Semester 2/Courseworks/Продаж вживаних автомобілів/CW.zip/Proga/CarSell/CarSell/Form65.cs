﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;

namespace CarSell
{
    public partial class Form65 : Form
    {
        SqlConnection conn = null;
        public Form65()
        {
            InitializeComponent();
        }

        private void Form65_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.CarsHaventContracts' table. You can move, or remove it, as needed.
            this.carsHaventContractsTableAdapter.Fill(this.carSellDataSet.CarsHaventContracts);
            // TODO: This line of code loads data into the 'carSellDataSet.ShortCars' table. You can move, or remove it, as needed.
            this.shortCarsTableAdapter.Fill(this.carSellDataSet.ShortCars);
            // TODO: This line of code loads data into the 'carSellDataSet.SellKlCars' table. You can move, or remove it, as needed.
            this.sellKlCarsTableAdapter.Fill(this.carSellDataSet.SellKlCars);
            // TODO: This line of code loads data into the 'carSellDataSet.InfAbCar' table. You can move, or remove it, as needed.
            this.infAbCarTableAdapter.Fill(this.carSellDataSet.InfAbCar);
            // TODO: This line of code loads data into the 'carSellDataSet.Автомобиль' table. You can move, or remove it, as needed.
            this.автомобильTableAdapter.Fill(this.carSellDataSet.Автомобиль);
            // TODO: This line of code loads data into the 'carSellDataSet.AllOrder' table. You can move, or remove it, as needed.
            this.allOrderTableAdapter.Fill(this.carSellDataSet.AllOrder);
            // TODO: This line of code loads data into the 'carSellDataSet.Марка_модель' table. You can move, or remove it, as needed.
            this.марка_модельTableAdapter.Fill(this.carSellDataSet.Марка_модель);
            // TODO: This line of code loads data into the 'carSellDataSet.BuyKlient' table. You can move, or remove it, as needed.
            this.buyKlientTableAdapter.Fill(this.carSellDataSet.BuyKlient);
            // TODO: This line of code loads data into the 'carSellDataSet.SellKlient' table. You can move, or remove it, as needed.
            this.sellKlientTableAdapter.Fill(this.carSellDataSet.SellKlient);
            // TODO: This line of code loads data into the 'carSellDataSet.FullDlName' table. You can move, or remove it, as needed.
            this.fullDlNameTableAdapter.Fill(this.carSellDataSet.FullDlName);

        }

        private void carsBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection();
            conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";

            SqlCommand myComand = conn.CreateCommand();
            string Car = "INSERT into Договор (Код_дилера, Код_заказа, Код_клиента_продавца, Код_клиента_покупателя, " +
                "Код_автомобиля, Дата_заключения_договора, Цена_сделки, Размер_комиссионных) " +
                "values ('" + this.comboBox1.SelectedValue.ToString() + "','" + this.comboBox2.SelectedValue.ToString() +
                "','" + this.comboBox3.SelectedValue.ToString() + "','" + this.comboBox4.SelectedValue.ToString() + "','" + this.comboBox5.SelectedValue.ToString() + 
                "','" + this.dateTimePicker1.Text + "','" + this.textBox1.Text + "','" + this.textBox2.Text + "');";

            SqlCommand sqlCommand = new SqlCommand(Car, conn);
            SqlDataReader myReader;
            try
            {
                conn.Open();
                myReader = sqlCommand.ExecuteReader();
                MessageBox.Show("Изменения внесены", "Изменение записи");
                while (myReader.Read())
                {

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            this.carsHaventContractsTableAdapter.Fill(carSellDataSet.CarsHaventContracts);
            this.договорTableAdapter1.Fill(carSellDataSet.Договор);

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
