﻿namespace CarSell
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.данныеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оАвтомобиляхToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.инофрмацияОВсехАвтомобиляхToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.маркаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.модельToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.типТСToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.типКузоваToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.годВыпускаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.годСнятияСПроизводстваToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.объемДвигателяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.мощностьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.пробегToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.цветToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ценаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оАдресахToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.всеАдресаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.областьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.районToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.типНПToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.населенныйПунктToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.типУлицыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.улицаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.типСтроенияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.типПомещенияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оТелефонахToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.мобильныйОператорToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.номерОператораToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.телефонToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.мобильныйТелефонToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.стационарныйТелефонToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.видТелефонаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оДилерахToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.дилерыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.адерсДилераToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.телефонДилераToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.количествоДоговоровУКаждогоДилераToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оКлиентахToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.всеКлиентыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.клиентыПродавцыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.информацияОКлиентеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.автомобилиКлиентовПродавцовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.клиентыПокупателиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.информациОКлиентахToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.заказыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выполненыеЗаказыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.невыполненыеЗаказыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.адресКлиентовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.телефоныКлиентовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.новыйДилерToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.новыйКлиентToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сформироватьЗаказToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.дляКлиентаПродавцаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.дляКлиентаПокупателяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.договорToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.новыйДоговорToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.всеДоговораToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.carSellDataSet = new CarSell.CarSellDataSet();
            this.типТСBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.типкузоваBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.годвыпускаотBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.годвыпускадоBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.пробегBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.маркаавтоBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.модельавтоBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.объемдвигателяBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.мощностьBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.цветBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.диапазонценыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.заказклиентаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carSellDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.заказ_клиентаTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Заказ_клиентаTableAdapter();
            this.год_выпуска_доTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Год_выпуска_доTableAdapter();
            this.год_выпуска_отTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Год_выпуска_отTableAdapter();
            this.диапазон_ценыTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Диапазон_ценыTableAdapter();
            this.марка_автоTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Марка_автоTableAdapter();
            this.модель_автоTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Модель_автоTableAdapter();
            this.мощностьTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.МощностьTableAdapter();
            this.объем_двигателяTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Объем_двигателяTableAdapter();
            this.пробегTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.ПробегTableAdapter();
            this.тип_кузоваTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Тип_кузоваTableAdapter();
            this.тип_ТСTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Тип_ТСTableAdapter();
            this.цветTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.ЦветTableAdapter();
            this.brand_modelTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Brand_modelTableAdapter();
            this.operatorNumberTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.OperatorNumberTableAdapter();
            this.carsWhCodeAndNameBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carsHaventContractsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carsHaventContractsTableAdapter = new CarSell.CarSellDataSetTableAdapters.CarsHaventContractsTableAdapter();
            this.договорTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.ДоговорTableAdapter();
            this.infAbCarWOKlientsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.infAbCarWOKlientsTableAdapter = new CarSell.CarSellDataSetTableAdapters.InfAbCarWOKlientsTableAdapter();
            this.carsWhCodeAndNameTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.CarsWhCodeAndNameTableAdapter();
            this.оПродажахЗаФевральToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типТСBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типкузоваBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.годвыпускаотBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.годвыпускадоBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.пробегBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.маркаавтоBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.модельавтоBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.объемдвигателяBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.мощностьBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.цветBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.диапазонценыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.заказклиентаBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carsWhCodeAndNameBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carsHaventContractsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.infAbCarWOKlientsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.данныеToolStripMenuItem,
            this.новыйДилерToolStripMenuItem,
            this.новыйКлиентToolStripMenuItem,
            this.сформироватьЗаказToolStripMenuItem,
            this.договорToolStripMenuItem,
            this.отчетыToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(689, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // данныеToolStripMenuItem
            // 
            this.данныеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оАвтомобиляхToolStripMenuItem,
            this.оАдресахToolStripMenuItem,
            this.оТелефонахToolStripMenuItem,
            this.оДилерахToolStripMenuItem,
            this.оКлиентахToolStripMenuItem});
            this.данныеToolStripMenuItem.Name = "данныеToolStripMenuItem";
            this.данныеToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.данныеToolStripMenuItem.Text = "Данные";
            this.данныеToolStripMenuItem.Click += new System.EventHandler(this.данныеToolStripMenuItem_Click);
            // 
            // оАвтомобиляхToolStripMenuItem
            // 
            this.оАвтомобиляхToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.инофрмацияОВсехАвтомобиляхToolStripMenuItem,
            this.маркаToolStripMenuItem,
            this.модельToolStripMenuItem,
            this.типТСToolStripMenuItem,
            this.типКузоваToolStripMenuItem,
            this.годВыпускаToolStripMenuItem,
            this.годСнятияСПроизводстваToolStripMenuItem,
            this.объемДвигателяToolStripMenuItem,
            this.мощностьToolStripMenuItem,
            this.пробегToolStripMenuItem,
            this.цветToolStripMenuItem,
            this.ценаToolStripMenuItem});
            this.оАвтомобиляхToolStripMenuItem.Name = "оАвтомобиляхToolStripMenuItem";
            this.оАвтомобиляхToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.оАвтомобиляхToolStripMenuItem.Text = "О Автомобилях";
            this.оАвтомобиляхToolStripMenuItem.Click += new System.EventHandler(this.оАвтомобиляхToolStripMenuItem_Click);
            // 
            // инофрмацияОВсехАвтомобиляхToolStripMenuItem
            // 
            this.инофрмацияОВсехАвтомобиляхToolStripMenuItem.Name = "инофрмацияОВсехАвтомобиляхToolStripMenuItem";
            this.инофрмацияОВсехАвтомобиляхToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.инофрмацияОВсехАвтомобиляхToolStripMenuItem.Text = "Инофрмация о всех автомобилях";
            this.инофрмацияОВсехАвтомобиляхToolStripMenuItem.Click += new System.EventHandler(this.инофрмацияОВсехАвтомобиляхToolStripMenuItem_Click);
            // 
            // маркаToolStripMenuItem
            // 
            this.маркаToolStripMenuItem.Name = "маркаToolStripMenuItem";
            this.маркаToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.маркаToolStripMenuItem.Text = "Марка";
            this.маркаToolStripMenuItem.Click += new System.EventHandler(this.маркаToolStripMenuItem_Click);
            // 
            // модельToolStripMenuItem
            // 
            this.модельToolStripMenuItem.Name = "модельToolStripMenuItem";
            this.модельToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.модельToolStripMenuItem.Text = "Модель";
            this.модельToolStripMenuItem.Click += new System.EventHandler(this.модельToolStripMenuItem_Click);
            // 
            // типТСToolStripMenuItem
            // 
            this.типТСToolStripMenuItem.Name = "типТСToolStripMenuItem";
            this.типТСToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.типТСToolStripMenuItem.Text = "Тип ТС";
            this.типТСToolStripMenuItem.Click += new System.EventHandler(this.типТСToolStripMenuItem_Click);
            // 
            // типКузоваToolStripMenuItem
            // 
            this.типКузоваToolStripMenuItem.Name = "типКузоваToolStripMenuItem";
            this.типКузоваToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.типКузоваToolStripMenuItem.Text = "Тип кузова";
            this.типКузоваToolStripMenuItem.Click += new System.EventHandler(this.типКузоваToolStripMenuItem_Click);
            // 
            // годВыпускаToolStripMenuItem
            // 
            this.годВыпускаToolStripMenuItem.Name = "годВыпускаToolStripMenuItem";
            this.годВыпускаToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.годВыпускаToolStripMenuItem.Text = "Год выпуска";
            this.годВыпускаToolStripMenuItem.Click += new System.EventHandler(this.годВыпускаToolStripMenuItem_Click);
            // 
            // годСнятияСПроизводстваToolStripMenuItem
            // 
            this.годСнятияСПроизводстваToolStripMenuItem.Name = "годСнятияСПроизводстваToolStripMenuItem";
            this.годСнятияСПроизводстваToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.годСнятияСПроизводстваToolStripMenuItem.Text = "Год снятия с производства";
            this.годСнятияСПроизводстваToolStripMenuItem.Click += new System.EventHandler(this.годСнятияСПроизводстваToolStripMenuItem_Click);
            // 
            // объемДвигателяToolStripMenuItem
            // 
            this.объемДвигателяToolStripMenuItem.Name = "объемДвигателяToolStripMenuItem";
            this.объемДвигателяToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.объемДвигателяToolStripMenuItem.Text = "Объем двигателя";
            this.объемДвигателяToolStripMenuItem.Click += new System.EventHandler(this.объемДвигателяToolStripMenuItem_Click);
            // 
            // мощностьToolStripMenuItem
            // 
            this.мощностьToolStripMenuItem.Name = "мощностьToolStripMenuItem";
            this.мощностьToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.мощностьToolStripMenuItem.Text = "Мощность";
            this.мощностьToolStripMenuItem.Click += new System.EventHandler(this.мощностьToolStripMenuItem_Click);
            // 
            // пробегToolStripMenuItem
            // 
            this.пробегToolStripMenuItem.Name = "пробегToolStripMenuItem";
            this.пробегToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.пробегToolStripMenuItem.Text = "Пробег";
            this.пробегToolStripMenuItem.Click += new System.EventHandler(this.пробегToolStripMenuItem_Click);
            // 
            // цветToolStripMenuItem
            // 
            this.цветToolStripMenuItem.Name = "цветToolStripMenuItem";
            this.цветToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.цветToolStripMenuItem.Text = "Цвет";
            this.цветToolStripMenuItem.Click += new System.EventHandler(this.цветToolStripMenuItem_Click);
            // 
            // ценаToolStripMenuItem
            // 
            this.ценаToolStripMenuItem.Name = "ценаToolStripMenuItem";
            this.ценаToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.ценаToolStripMenuItem.Text = "Цена";
            this.ценаToolStripMenuItem.Click += new System.EventHandler(this.ценаToolStripMenuItem_Click);
            // 
            // оАдресахToolStripMenuItem
            // 
            this.оАдресахToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.всеАдресаToolStripMenuItem,
            this.областьToolStripMenuItem,
            this.районToolStripMenuItem,
            this.типНПToolStripMenuItem,
            this.населенныйПунктToolStripMenuItem,
            this.типУлицыToolStripMenuItem,
            this.улицаToolStripMenuItem,
            this.типСтроенияToolStripMenuItem,
            this.типПомещенияToolStripMenuItem});
            this.оАдресахToolStripMenuItem.Name = "оАдресахToolStripMenuItem";
            this.оАдресахToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.оАдресахToolStripMenuItem.Text = "О Адресах";
            // 
            // всеАдресаToolStripMenuItem
            // 
            this.всеАдресаToolStripMenuItem.Name = "всеАдресаToolStripMenuItem";
            this.всеАдресаToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.всеАдресаToolStripMenuItem.Text = "Все адреса";
            this.всеАдресаToolStripMenuItem.Click += new System.EventHandler(this.всеАдресаToolStripMenuItem_Click);
            // 
            // областьToolStripMenuItem
            // 
            this.областьToolStripMenuItem.Name = "областьToolStripMenuItem";
            this.областьToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.областьToolStripMenuItem.Text = "Область";
            this.областьToolStripMenuItem.Click += new System.EventHandler(this.областьToolStripMenuItem_Click);
            // 
            // районToolStripMenuItem
            // 
            this.районToolStripMenuItem.Name = "районToolStripMenuItem";
            this.районToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.районToolStripMenuItem.Text = "Район";
            this.районToolStripMenuItem.Click += new System.EventHandler(this.районToolStripMenuItem_Click);
            // 
            // типНПToolStripMenuItem
            // 
            this.типНПToolStripMenuItem.Name = "типНПToolStripMenuItem";
            this.типНПToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.типНПToolStripMenuItem.Text = "Тип НП";
            this.типНПToolStripMenuItem.Click += new System.EventHandler(this.типНПToolStripMenuItem_Click);
            // 
            // населенныйПунктToolStripMenuItem
            // 
            this.населенныйПунктToolStripMenuItem.Name = "населенныйПунктToolStripMenuItem";
            this.населенныйПунктToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.населенныйПунктToolStripMenuItem.Text = "Населенный пункт";
            this.населенныйПунктToolStripMenuItem.Click += new System.EventHandler(this.населенныйПунктToolStripMenuItem_Click);
            // 
            // типУлицыToolStripMenuItem
            // 
            this.типУлицыToolStripMenuItem.Name = "типУлицыToolStripMenuItem";
            this.типУлицыToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.типУлицыToolStripMenuItem.Text = "Тип улицы";
            this.типУлицыToolStripMenuItem.Click += new System.EventHandler(this.типУлицыToolStripMenuItem_Click);
            // 
            // улицаToolStripMenuItem
            // 
            this.улицаToolStripMenuItem.Name = "улицаToolStripMenuItem";
            this.улицаToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.улицаToolStripMenuItem.Text = "Улица";
            this.улицаToolStripMenuItem.Click += new System.EventHandler(this.улицаToolStripMenuItem_Click);
            // 
            // типСтроенияToolStripMenuItem
            // 
            this.типСтроенияToolStripMenuItem.Name = "типСтроенияToolStripMenuItem";
            this.типСтроенияToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.типСтроенияToolStripMenuItem.Text = "Тип строения";
            this.типСтроенияToolStripMenuItem.Click += new System.EventHandler(this.типСтроенияToolStripMenuItem_Click);
            // 
            // типПомещенияToolStripMenuItem
            // 
            this.типПомещенияToolStripMenuItem.Name = "типПомещенияToolStripMenuItem";
            this.типПомещенияToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.типПомещенияToolStripMenuItem.Text = "Тип помещения";
            this.типПомещенияToolStripMenuItem.Click += new System.EventHandler(this.типПомещенияToolStripMenuItem_Click);
            // 
            // оТелефонахToolStripMenuItem
            // 
            this.оТелефонахToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.мобильныйОператорToolStripMenuItem,
            this.номерОператораToolStripMenuItem,
            this.телефонToolStripMenuItem,
            this.мобильныйТелефонToolStripMenuItem,
            this.стационарныйТелефонToolStripMenuItem,
            this.видТелефонаToolStripMenuItem});
            this.оТелефонахToolStripMenuItem.Name = "оТелефонахToolStripMenuItem";
            this.оТелефонахToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.оТелефонахToolStripMenuItem.Text = "О Телефонах";
            // 
            // мобильныйОператорToolStripMenuItem
            // 
            this.мобильныйОператорToolStripMenuItem.Name = "мобильныйОператорToolStripMenuItem";
            this.мобильныйОператорToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.мобильныйОператорToolStripMenuItem.Text = "Мобильный оператор";
            this.мобильныйОператорToolStripMenuItem.Click += new System.EventHandler(this.мобильныйОператорToolStripMenuItem_Click);
            // 
            // номерОператораToolStripMenuItem
            // 
            this.номерОператораToolStripMenuItem.Name = "номерОператораToolStripMenuItem";
            this.номерОператораToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.номерОператораToolStripMenuItem.Text = "Номер оператора";
            this.номерОператораToolStripMenuItem.Click += new System.EventHandler(this.номерОператораToolStripMenuItem_Click);
            // 
            // телефонToolStripMenuItem
            // 
            this.телефонToolStripMenuItem.Name = "телефонToolStripMenuItem";
            this.телефонToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.телефонToolStripMenuItem.Text = "Телефон";
            this.телефонToolStripMenuItem.Click += new System.EventHandler(this.телефонToolStripMenuItem_Click);
            // 
            // мобильныйТелефонToolStripMenuItem
            // 
            this.мобильныйТелефонToolStripMenuItem.Name = "мобильныйТелефонToolStripMenuItem";
            this.мобильныйТелефонToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.мобильныйТелефонToolStripMenuItem.Text = "Мобильный телефон";
            this.мобильныйТелефонToolStripMenuItem.Click += new System.EventHandler(this.мобильныйТелефонToolStripMenuItem_Click);
            // 
            // стационарныйТелефонToolStripMenuItem
            // 
            this.стационарныйТелефонToolStripMenuItem.Name = "стационарныйТелефонToolStripMenuItem";
            this.стационарныйТелефонToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.стационарныйТелефонToolStripMenuItem.Text = "Стационарный телефон";
            this.стационарныйТелефонToolStripMenuItem.Click += new System.EventHandler(this.стационарныйТелефонToolStripMenuItem_Click);
            // 
            // видТелефонаToolStripMenuItem
            // 
            this.видТелефонаToolStripMenuItem.Name = "видТелефонаToolStripMenuItem";
            this.видТелефонаToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.видТелефонаToolStripMenuItem.Text = "Вид телефона";
            this.видТелефонаToolStripMenuItem.Click += new System.EventHandler(this.видТелефонаToolStripMenuItem_Click);
            // 
            // оДилерахToolStripMenuItem
            // 
            this.оДилерахToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.дилерыToolStripMenuItem,
            this.адерсДилераToolStripMenuItem,
            this.телефонДилераToolStripMenuItem,
            this.количествоДоговоровУКаждогоДилераToolStripMenuItem});
            this.оДилерахToolStripMenuItem.Name = "оДилерахToolStripMenuItem";
            this.оДилерахToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.оДилерахToolStripMenuItem.Text = "О Дилерах";
            // 
            // дилерыToolStripMenuItem
            // 
            this.дилерыToolStripMenuItem.Name = "дилерыToolStripMenuItem";
            this.дилерыToolStripMenuItem.Size = new System.Drawing.Size(300, 22);
            this.дилерыToolStripMenuItem.Text = "Дилеры";
            this.дилерыToolStripMenuItem.Click += new System.EventHandler(this.дилерыToolStripMenuItem_Click);
            // 
            // адерсДилераToolStripMenuItem
            // 
            this.адерсДилераToolStripMenuItem.Name = "адерсДилераToolStripMenuItem";
            this.адерсДилераToolStripMenuItem.Size = new System.Drawing.Size(300, 22);
            this.адерсДилераToolStripMenuItem.Text = "Адерс дилера";
            this.адерсДилераToolStripMenuItem.Click += new System.EventHandler(this.адерсДилераToolStripMenuItem_Click);
            // 
            // телефонДилераToolStripMenuItem
            // 
            this.телефонДилераToolStripMenuItem.Name = "телефонДилераToolStripMenuItem";
            this.телефонДилераToolStripMenuItem.Size = new System.Drawing.Size(300, 22);
            this.телефонДилераToolStripMenuItem.Text = "Телефон дилера";
            this.телефонДилераToolStripMenuItem.Click += new System.EventHandler(this.телефонДилераToolStripMenuItem_Click);
            // 
            // количествоДоговоровУКаждогоДилераToolStripMenuItem
            // 
            this.количествоДоговоровУКаждогоДилераToolStripMenuItem.Name = "количествоДоговоровУКаждогоДилераToolStripMenuItem";
            this.количествоДоговоровУКаждогоДилераToolStripMenuItem.Size = new System.Drawing.Size(300, 22);
            this.количествоДоговоровУКаждогоДилераToolStripMenuItem.Text = "Количество договоров у каждого дилера";
            this.количествоДоговоровУКаждогоДилераToolStripMenuItem.Click += new System.EventHandler(this.количествоДоговоровУКаждогоДилераToolStripMenuItem_Click);
            // 
            // оКлиентахToolStripMenuItem
            // 
            this.оКлиентахToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.всеКлиентыToolStripMenuItem,
            this.клиентыПродавцыToolStripMenuItem,
            this.клиентыПокупателиToolStripMenuItem,
            this.адресКлиентовToolStripMenuItem,
            this.телефоныКлиентовToolStripMenuItem});
            this.оКлиентахToolStripMenuItem.Name = "оКлиентахToolStripMenuItem";
            this.оКлиентахToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.оКлиентахToolStripMenuItem.Text = "О Клиентах";
            // 
            // всеКлиентыToolStripMenuItem
            // 
            this.всеКлиентыToolStripMenuItem.Name = "всеКлиентыToolStripMenuItem";
            this.всеКлиентыToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.всеКлиентыToolStripMenuItem.Text = "Все клиенты";
            this.всеКлиентыToolStripMenuItem.Click += new System.EventHandler(this.всеКлиентыToolStripMenuItem_Click);
            // 
            // клиентыПродавцыToolStripMenuItem
            // 
            this.клиентыПродавцыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.информацияОКлиентеToolStripMenuItem,
            this.автомобилиКлиентовПродавцовToolStripMenuItem});
            this.клиентыПродавцыToolStripMenuItem.Name = "клиентыПродавцыToolStripMenuItem";
            this.клиентыПродавцыToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.клиентыПродавцыToolStripMenuItem.Text = "Клиенты - продавцы";
            this.клиентыПродавцыToolStripMenuItem.Click += new System.EventHandler(this.клиентыПродавцыToolStripMenuItem_Click);
            // 
            // информацияОКлиентеToolStripMenuItem
            // 
            this.информацияОКлиентеToolStripMenuItem.Name = "информацияОКлиентеToolStripMenuItem";
            this.информацияОКлиентеToolStripMenuItem.Size = new System.Drawing.Size(268, 22);
            this.информацияОКлиентеToolStripMenuItem.Text = "Информация о клиенте";
            this.информацияОКлиентеToolStripMenuItem.Click += new System.EventHandler(this.информацияОКлиентеToolStripMenuItem_Click);
            // 
            // автомобилиКлиентовПродавцовToolStripMenuItem
            // 
            this.автомобилиКлиентовПродавцовToolStripMenuItem.Name = "автомобилиКлиентовПродавцовToolStripMenuItem";
            this.автомобилиКлиентовПродавцовToolStripMenuItem.Size = new System.Drawing.Size(268, 22);
            this.автомобилиКлиентовПродавцовToolStripMenuItem.Text = "Автомобили клиентов - продавцов";
            this.автомобилиКлиентовПродавцовToolStripMenuItem.Click += new System.EventHandler(this.автомобилиКлиентовПродавцовToolStripMenuItem_Click);
            // 
            // клиентыПокупателиToolStripMenuItem
            // 
            this.клиентыПокупателиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.информациОКлиентахToolStripMenuItem,
            this.заказыToolStripMenuItem,
            this.выполненыеЗаказыToolStripMenuItem,
            this.невыполненыеЗаказыToolStripMenuItem});
            this.клиентыПокупателиToolStripMenuItem.Name = "клиентыПокупателиToolStripMenuItem";
            this.клиентыПокупателиToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.клиентыПокупателиToolStripMenuItem.Text = "Клиенты - покупатели";
            // 
            // информациОКлиентахToolStripMenuItem
            // 
            this.информациОКлиентахToolStripMenuItem.Name = "информациОКлиентахToolStripMenuItem";
            this.информациОКлиентахToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.информациОКлиентахToolStripMenuItem.Text = "Информаци о клиентах";
            this.информациОКлиентахToolStripMenuItem.Click += new System.EventHandler(this.информациОКлиентахToolStripMenuItem_Click);
            // 
            // заказыToolStripMenuItem
            // 
            this.заказыToolStripMenuItem.Name = "заказыToolStripMenuItem";
            this.заказыToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.заказыToolStripMenuItem.Text = "Заказы клиентов";
            this.заказыToolStripMenuItem.Click += new System.EventHandler(this.заказыToolStripMenuItem_Click);
            // 
            // выполненыеЗаказыToolStripMenuItem
            // 
            this.выполненыеЗаказыToolStripMenuItem.Name = "выполненыеЗаказыToolStripMenuItem";
            this.выполненыеЗаказыToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.выполненыеЗаказыToolStripMenuItem.Text = "Выполненые заказы";
            this.выполненыеЗаказыToolStripMenuItem.Click += new System.EventHandler(this.выполненыеЗаказыToolStripMenuItem_Click);
            // 
            // невыполненыеЗаказыToolStripMenuItem
            // 
            this.невыполненыеЗаказыToolStripMenuItem.Name = "невыполненыеЗаказыToolStripMenuItem";
            this.невыполненыеЗаказыToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.невыполненыеЗаказыToolStripMenuItem.Text = "Невыполненые заказы";
            this.невыполненыеЗаказыToolStripMenuItem.Click += new System.EventHandler(this.невыполненыеЗаказыToolStripMenuItem_Click);
            // 
            // адресКлиентовToolStripMenuItem
            // 
            this.адресКлиентовToolStripMenuItem.Name = "адресКлиентовToolStripMenuItem";
            this.адресКлиентовToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.адресКлиентовToolStripMenuItem.Text = "Адрес клиентов";
            this.адресКлиентовToolStripMenuItem.Click += new System.EventHandler(this.адресКлиентовToolStripMenuItem_Click);
            // 
            // телефоныКлиентовToolStripMenuItem
            // 
            this.телефоныКлиентовToolStripMenuItem.Name = "телефоныКлиентовToolStripMenuItem";
            this.телефоныКлиентовToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.телефоныКлиентовToolStripMenuItem.Text = "Телефоны клиентов";
            this.телефоныКлиентовToolStripMenuItem.Click += new System.EventHandler(this.телефоныКлиентовToolStripMenuItem_Click);
            // 
            // новыйДилерToolStripMenuItem
            // 
            this.новыйДилерToolStripMenuItem.Name = "новыйДилерToolStripMenuItem";
            this.новыйДилерToolStripMenuItem.Size = new System.Drawing.Size(93, 20);
            this.новыйДилерToolStripMenuItem.Text = "Новый дилер";
            this.новыйДилерToolStripMenuItem.Click += new System.EventHandler(this.новыйДилерToolStripMenuItem_Click);
            // 
            // новыйКлиентToolStripMenuItem
            // 
            this.новыйКлиентToolStripMenuItem.Name = "новыйКлиентToolStripMenuItem";
            this.новыйКлиентToolStripMenuItem.Size = new System.Drawing.Size(98, 20);
            this.новыйКлиентToolStripMenuItem.Text = "Новый клиент";
            this.новыйКлиентToolStripMenuItem.Click += new System.EventHandler(this.новыйКлиентToolStripMenuItem_Click);
            // 
            // сформироватьЗаказToolStripMenuItem
            // 
            this.сформироватьЗаказToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.дляКлиентаПродавцаToolStripMenuItem,
            this.дляКлиентаПокупателяToolStripMenuItem});
            this.сформироватьЗаказToolStripMenuItem.Name = "сформироватьЗаказToolStripMenuItem";
            this.сформироватьЗаказToolStripMenuItem.Size = new System.Drawing.Size(156, 20);
            this.сформироватьЗаказToolStripMenuItem.Text = "Сформировать заказ для";
            this.сформироватьЗаказToolStripMenuItem.Click += new System.EventHandler(this.сформироватьЗаказToolStripMenuItem_Click);
            // 
            // дляКлиентаПродавцаToolStripMenuItem
            // 
            this.дляКлиентаПродавцаToolStripMenuItem.Name = "дляКлиентаПродавцаToolStripMenuItem";
            this.дляКлиентаПродавцаToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.дляКлиентаПродавцаToolStripMenuItem.Text = " Клиента - продавца";
            this.дляКлиентаПродавцаToolStripMenuItem.Click += new System.EventHandler(this.дляКлиентаПродавцаToolStripMenuItem_Click);
            // 
            // дляКлиентаПокупателяToolStripMenuItem
            // 
            this.дляКлиентаПокупателяToolStripMenuItem.Name = "дляКлиентаПокупателяToolStripMenuItem";
            this.дляКлиентаПокупателяToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.дляКлиентаПокупателяToolStripMenuItem.Text = "Клиента - покупателя";
            this.дляКлиентаПокупателяToolStripMenuItem.Click += new System.EventHandler(this.дляКлиентаПокупателяToolStripMenuItem_Click);
            // 
            // договорToolStripMenuItem
            // 
            this.договорToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.новыйДоговорToolStripMenuItem,
            this.всеДоговораToolStripMenuItem});
            this.договорToolStripMenuItem.Name = "договорToolStripMenuItem";
            this.договорToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.договорToolStripMenuItem.Text = "Договор";
            // 
            // новыйДоговорToolStripMenuItem
            // 
            this.новыйДоговорToolStripMenuItem.Name = "новыйДоговорToolStripMenuItem";
            this.новыйДоговорToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.новыйДоговорToolStripMenuItem.Text = "Новый договор";
            this.новыйДоговорToolStripMenuItem.Click += new System.EventHandler(this.новыйДоговорToolStripMenuItem_Click);
            // 
            // всеДоговораToolStripMenuItem
            // 
            this.всеДоговораToolStripMenuItem.Name = "всеДоговораToolStripMenuItem";
            this.всеДоговораToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.всеДоговораToolStripMenuItem.Text = "Все договора";
            this.всеДоговораToolStripMenuItem.Click += new System.EventHandler(this.всеДоговораToolStripMenuItem_Click);
            // 
            // отчетыToolStripMenuItem
            // 
            this.отчетыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПродажахЗаФевральToolStripMenuItem});
            this.отчетыToolStripMenuItem.Name = "отчетыToolStripMenuItem";
            this.отчетыToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.отчетыToolStripMenuItem.Text = "Отчеты";
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // carSellDataSet
            // 
            this.carSellDataSet.DataSetName = "CarSellDataSet";
            this.carSellDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // типТСBindingSource
            // 
            this.типТСBindingSource.DataMember = "Тип_ТС";
            this.типТСBindingSource.DataSource = this.carSellDataSet;
            // 
            // типкузоваBindingSource
            // 
            this.типкузоваBindingSource.DataMember = "Тип_кузова";
            this.типкузоваBindingSource.DataSource = this.carSellDataSet;
            // 
            // годвыпускаотBindingSource
            // 
            this.годвыпускаотBindingSource.DataMember = "Год_выпуска_от";
            this.годвыпускаотBindingSource.DataSource = this.carSellDataSet;
            // 
            // годвыпускадоBindingSource
            // 
            this.годвыпускадоBindingSource.DataMember = "Год_выпуска_до";
            this.годвыпускадоBindingSource.DataSource = this.carSellDataSet;
            // 
            // пробегBindingSource
            // 
            this.пробегBindingSource.DataMember = "Пробег";
            this.пробегBindingSource.DataSource = this.carSellDataSet;
            // 
            // маркаавтоBindingSource
            // 
            this.маркаавтоBindingSource.DataMember = "Марка_авто";
            this.маркаавтоBindingSource.DataSource = this.carSellDataSet;
            // 
            // модельавтоBindingSource
            // 
            this.модельавтоBindingSource.DataMember = "Модель_авто";
            this.модельавтоBindingSource.DataSource = this.carSellDataSet;
            // 
            // объемдвигателяBindingSource
            // 
            this.объемдвигателяBindingSource.DataMember = "Объем_двигателя";
            this.объемдвигателяBindingSource.DataSource = this.carSellDataSet;
            // 
            // мощностьBindingSource
            // 
            this.мощностьBindingSource.DataMember = "Мощность";
            this.мощностьBindingSource.DataSource = this.carSellDataSet;
            // 
            // цветBindingSource
            // 
            this.цветBindingSource.DataMember = "Цвет";
            this.цветBindingSource.DataSource = this.carSellDataSet;
            // 
            // диапазонценыBindingSource
            // 
            this.диапазонценыBindingSource.DataMember = "Диапазон_цены";
            this.диапазонценыBindingSource.DataSource = this.carSellDataSet;
            // 
            // заказклиентаBindingSource
            // 
            this.заказклиентаBindingSource.DataMember = "Заказ_клиента";
            this.заказклиентаBindingSource.DataSource = this.carSellDataSet;
            // 
            // carSellDataSetBindingSource
            // 
            this.carSellDataSetBindingSource.DataSource = this.carSellDataSet;
            this.carSellDataSetBindingSource.Position = 0;
            // 
            // заказ_клиентаTableAdapter1
            // 
            this.заказ_клиентаTableAdapter1.ClearBeforeFill = true;
            // 
            // год_выпуска_доTableAdapter1
            // 
            this.год_выпуска_доTableAdapter1.ClearBeforeFill = true;
            // 
            // год_выпуска_отTableAdapter1
            // 
            this.год_выпуска_отTableAdapter1.ClearBeforeFill = true;
            // 
            // диапазон_ценыTableAdapter1
            // 
            this.диапазон_ценыTableAdapter1.ClearBeforeFill = true;
            // 
            // марка_автоTableAdapter1
            // 
            this.марка_автоTableAdapter1.ClearBeforeFill = true;
            // 
            // модель_автоTableAdapter1
            // 
            this.модель_автоTableAdapter1.ClearBeforeFill = true;
            // 
            // мощностьTableAdapter1
            // 
            this.мощностьTableAdapter1.ClearBeforeFill = true;
            // 
            // объем_двигателяTableAdapter1
            // 
            this.объем_двигателяTableAdapter1.ClearBeforeFill = true;
            // 
            // пробегTableAdapter1
            // 
            this.пробегTableAdapter1.ClearBeforeFill = true;
            // 
            // тип_кузоваTableAdapter1
            // 
            this.тип_кузоваTableAdapter1.ClearBeforeFill = true;
            // 
            // тип_ТСTableAdapter1
            // 
            this.тип_ТСTableAdapter1.ClearBeforeFill = true;
            // 
            // цветTableAdapter1
            // 
            this.цветTableAdapter1.ClearBeforeFill = true;
            // 
            // brand_modelTableAdapter1
            // 
            this.brand_modelTableAdapter1.ClearBeforeFill = true;
            // 
            // operatorNumberTableAdapter1
            // 
            this.operatorNumberTableAdapter1.ClearBeforeFill = true;
            // 
            // carsWhCodeAndNameBindingSource
            // 
            this.carsWhCodeAndNameBindingSource.DataMember = "CarsWhCodeAndName";
            this.carsWhCodeAndNameBindingSource.DataSource = this.carSellDataSet;
            // 
            // carsHaventContractsBindingSource
            // 
            this.carsHaventContractsBindingSource.DataMember = "CarsHaventContracts";
            this.carsHaventContractsBindingSource.DataSource = this.carSellDataSet;
            // 
            // carsHaventContractsTableAdapter
            // 
            this.carsHaventContractsTableAdapter.ClearBeforeFill = true;
            // 
            // договорTableAdapter1
            // 
            this.договорTableAdapter1.ClearBeforeFill = true;
            // 
            // infAbCarWOKlientsBindingSource
            // 
            this.infAbCarWOKlientsBindingSource.DataMember = "InfAbCarWOKlients";
            this.infAbCarWOKlientsBindingSource.DataSource = this.carSellDataSet;
            // 
            // infAbCarWOKlientsTableAdapter
            // 
            this.infAbCarWOKlientsTableAdapter.ClearBeforeFill = true;
            // 
            // carsWhCodeAndNameTableAdapter1
            // 
            this.carsWhCodeAndNameTableAdapter1.ClearBeforeFill = true;
            // 
            // оПродажахЗаФевральToolStripMenuItem
            // 
            this.оПродажахЗаФевральToolStripMenuItem.Name = "оПродажахЗаФевральToolStripMenuItem";
            this.оПродажахЗаФевральToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.оПродажахЗаФевральToolStripMenuItem.Text = "О продажах за февраль";
            this.оПродажахЗаФевральToolStripMenuItem.Click += new System.EventHandler(this.оПродажахЗаФевральToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(692, 435);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(689, 463);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Car Sell";
            this.TransparencyKey = System.Drawing.Color.White;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типТСBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типкузоваBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.годвыпускаотBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.годвыпускадоBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.пробегBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.маркаавтоBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.модельавтоBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.объемдвигателяBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.мощностьBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.цветBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.диапазонценыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.заказклиентаBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carsWhCodeAndNameBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carsHaventContractsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.infAbCarWOKlientsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem данныеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оАвтомобиляхToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem маркаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem модельToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem типТСToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem типКузоваToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem годВыпускаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem годСнятияСПроизводстваToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem объемДвигателяToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem мощностьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem пробегToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem цветToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ценаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem инофрмацияОВсехАвтомобиляхToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оДилерахToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem дилерыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem адерсДилераToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оАдресахToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem областьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem всеАдресаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem районToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem типНПToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem населенныйПунктToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem типУлицыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem улицаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem типСтроенияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem типПомещенияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оТелефонахToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem мобильныйОператорToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem номерОператораToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem телефонToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem мобильныйТелефонToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem стационарныйТелефонToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem видТелефонаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem телефонДилераToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem количествоДоговоровУКаждогоДилераToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оКлиентахToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem всеКлиентыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem клиентыПродавцыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem клиентыПокупателиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem заказыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выполненыеЗаказыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem невыполненыеЗаказыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem адресКлиентовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem телефоныКлиентовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сформироватьЗаказToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem дляКлиентаПродавцаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem дляКлиентаПокупателяToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчетыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem новыйКлиентToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem автомобилиКлиентовПродавцовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem информацияОКлиентеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem информациОКлиентахToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem договорToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem новыйДоговорToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem всеДоговораToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem новыйДилерToolStripMenuItem;
        private CarSellDataSet carSellDataSet;
        private System.Windows.Forms.BindingSource типТСBindingSource;
        private System.Windows.Forms.BindingSource типкузоваBindingSource;
        private System.Windows.Forms.BindingSource годвыпускаотBindingSource;
        private System.Windows.Forms.BindingSource годвыпускадоBindingSource;
        private System.Windows.Forms.BindingSource пробегBindingSource;
        private System.Windows.Forms.BindingSource маркаавтоBindingSource;
        private System.Windows.Forms.BindingSource модельавтоBindingSource;
        private System.Windows.Forms.BindingSource объемдвигателяBindingSource;
        private System.Windows.Forms.BindingSource мощностьBindingSource;
        private System.Windows.Forms.BindingSource цветBindingSource;
        private System.Windows.Forms.BindingSource диапазонценыBindingSource;
        private System.Windows.Forms.BindingSource заказклиентаBindingSource;
        private System.Windows.Forms.BindingSource carSellDataSetBindingSource;
        private CarSellDataSetTableAdapters.Заказ_клиентаTableAdapter заказ_клиентаTableAdapter1;
        private CarSellDataSetTableAdapters.Год_выпуска_доTableAdapter год_выпуска_доTableAdapter1;
        private CarSellDataSetTableAdapters.Год_выпуска_отTableAdapter год_выпуска_отTableAdapter1;
        private CarSellDataSetTableAdapters.Диапазон_ценыTableAdapter диапазон_ценыTableAdapter1;
        private CarSellDataSetTableAdapters.Марка_автоTableAdapter марка_автоTableAdapter1;
        private CarSellDataSetTableAdapters.Модель_автоTableAdapter модель_автоTableAdapter1;
        private CarSellDataSetTableAdapters.МощностьTableAdapter мощностьTableAdapter1;
        private CarSellDataSetTableAdapters.Объем_двигателяTableAdapter объем_двигателяTableAdapter1;
        private CarSellDataSetTableAdapters.ПробегTableAdapter пробегTableAdapter1;
        private CarSellDataSetTableAdapters.Тип_кузоваTableAdapter тип_кузоваTableAdapter1;
        private CarSellDataSetTableAdapters.Тип_ТСTableAdapter тип_ТСTableAdapter1;
        private CarSellDataSetTableAdapters.ЦветTableAdapter цветTableAdapter1;
        private CarSellDataSetTableAdapters.Brand_modelTableAdapter brand_modelTableAdapter1;
        private CarSellDataSetTableAdapters.OperatorNumberTableAdapter operatorNumberTableAdapter1;
        private System.Windows.Forms.BindingSource carsHaventContractsBindingSource;
        private CarSellDataSetTableAdapters.CarsHaventContractsTableAdapter carsHaventContractsTableAdapter;
        private CarSellDataSetTableAdapters.ДоговорTableAdapter договорTableAdapter1;
        private System.Windows.Forms.BindingSource infAbCarWOKlientsBindingSource;
        private CarSellDataSetTableAdapters.InfAbCarWOKlientsTableAdapter infAbCarWOKlientsTableAdapter;
        private System.Windows.Forms.BindingSource carsWhCodeAndNameBindingSource;
        private CarSellDataSetTableAdapters.CarsWhCodeAndNameTableAdapter carsWhCodeAndNameTableAdapter1;
        private System.Windows.Forms.ToolStripMenuItem оПродажахЗаФевральToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

