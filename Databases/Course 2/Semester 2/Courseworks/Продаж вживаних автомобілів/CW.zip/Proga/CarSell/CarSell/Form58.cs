﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;

namespace CarSell
{
    public partial class Form58 : Form
    {
        SqlConnection conn = null;
        public Form58()
        {
            InitializeComponent();
        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime withdrawalYear = Convert.ToDateTime(this.dateTimePicker1.Text);
                //string withdrawalYear = Convert.ToString(this.textBox1.Text);

                conn = new SqlConnection();
                conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                conn.Open();
                SqlCommand myComand = conn.CreateCommand();
                myComand.CommandText = "INSERT into Год_выпуска_до (Год_выпуска_до) VALUES (@withdrawalYear)";
                myComand.Parameters.Add("@withdrawalYear", SqlDbType.Date, 8);
                myComand.Parameters["@withdrawalYear"].Value = withdrawalYear;

                int UspeshnoeIzmenenie = myComand.ExecuteNonQuery();
                if (UspeshnoeIzmenenie != 0)
                {
                    MessageBox.Show("Изменения внесены", "Изменение записи");
                }
                else
                {
                    MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            this.год_выпуска_доTableAdapter1.Fill(this.carSellDataSet1.Год_выпуска_до);
            Form42 form42 = new Form42();
            form42.Update();
        }
    }
}
