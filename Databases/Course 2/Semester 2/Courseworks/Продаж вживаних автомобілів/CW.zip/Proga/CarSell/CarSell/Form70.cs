﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSell
{
    public partial class Form70 : Form
    {
        public Form70()
        {
            InitializeComponent();
        }
        CarSellDataSet dsCarSell = new CarSellDataSet();
        CarSellDataSetTableAdapters.Otch1TableAdapter daДоговоры =
            new CarSell.CarSellDataSetTableAdapters.Otch1TableAdapter();


        private void Form70_Load(object sender, EventArgs e)
        {
            Form70_Договоры_Fill();
            this.crystalReport11.SetDataSource(dsCarSell);
            this.crystalReportViewer1.Refresh();
            this.crystalReportViewer1.ReportSource = this.crystalReport11;
        }

        public void Form70_Договоры_Fill()
        {
            daДоговоры.Fill(dsCarSell.Otch1);
        }
    }
}
