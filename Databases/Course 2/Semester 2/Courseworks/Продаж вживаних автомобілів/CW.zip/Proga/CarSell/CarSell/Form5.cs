﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;


namespace CarSell
{
    public partial class Form5 : Form
    {
        SqlConnection conn = null;
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_кузова' table. You can move, or remove it, as needed.
            this.тип_кузоваTableAdapter.Fill(this.carSellDataSet.Тип_кузова);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form54 form54 = new Form54();
            form54.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            int codeTpBody = int.Parse(dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells["кодтипакузоваDataGridViewTextBoxColumn"].Value.ToString());
            DialogResult result = MessageBox.Show("Удалить тип кузова?", "Предупреждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            switch (result)
            {
                case DialogResult.Yes:
                    {
                        try
                        {
                            conn = new SqlConnection();
                            conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                            conn.Open();
                            SqlCommand myCommand = conn.CreateCommand();
                            myCommand.CommandText = "Delete from Тип_кузова Where Код_типа_кузова = @codeTpBody";
                            myCommand.Parameters.Add("@codeTpBody", SqlDbType.Int, 4);
                            myCommand.Parameters["@codeTpBody"].Value = codeTpBody;


                            int UspeshnoeIzmenenie = myCommand.ExecuteNonQuery();
                            if (UspeshnoeIzmenenie != 0)
                            {
                                MessageBox.Show("Изменения внесены", "Изменение записи");
                            }
                            else
                            {
                                MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                        finally
                        {
                            conn.Close();
                        }
                        this.тип_кузоваTableAdapter.Fill(this.carSellDataSet.Тип_кузова);
                        break;
                    }
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.тип_кузоваTableAdapter.Update(this.carSellDataSet.Тип_кузова);
        }
    }
}
