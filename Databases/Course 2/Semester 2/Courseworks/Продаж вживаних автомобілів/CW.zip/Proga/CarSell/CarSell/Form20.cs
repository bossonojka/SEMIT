﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSell
{
    public partial class Form20 : Form
    {
        public Form20()
        {
            InitializeComponent();
        }

        private void Form20_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_улицы' table. You can move, or remove it, as needed.
            this.тип_улицыTableAdapter.Fill(this.carSellDataSet.Тип_улицы);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form47 form47 = new Form47();
            form47.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.тип_улицыTableAdapter.Update(this.carSellDataSet.Тип_улицы);
        }
    }
}
