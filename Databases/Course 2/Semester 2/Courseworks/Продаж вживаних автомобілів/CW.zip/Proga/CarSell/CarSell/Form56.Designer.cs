﻿namespace CarSell
{
    partial class Form56
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.carSellDataSet1 = new CarSell.CarSellDataSet();
            this.марка_автоTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Марка_автоTableAdapter();
            this.марка_модельTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Марка_модельTableAdapter();
            this.модель_автоTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Модель_автоTableAdapter();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.brandmodelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.маркаавтоBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.модельавтоBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.brand_modelTableAdapter = new CarSell.CarSellDataSetTableAdapters.Brand_modelTableAdapter();
            this.carBrandBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carBrandTableAdapter = new CarSell.CarSellDataSetTableAdapters.CarBrandTableAdapter();
            this.lastBrandBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lastBrandTableAdapter = new CarSell.CarSellDataSetTableAdapters.LastBrandTableAdapter();
            this.lastModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lastModelTableAdapter = new CarSell.CarSellDataSetTableAdapters.LastModelTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.brandmodelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.маркаавтоBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.модельавтоBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carBrandBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lastBrandBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lastModelBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.Location = new System.Drawing.Point(147, 69);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(57, 20);
            this.label19.TabIndex = 37;
            this.label19.Text = "Марка";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(78, 94);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(220, 20);
            this.textBox1.TabIndex = 38;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(590, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 20);
            this.label1.TabIndex = 39;
            this.label1.Text = "Модель";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(514, 92);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(220, 20);
            this.textBox2.TabIndex = 40;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button1.Location = new System.Drawing.Point(326, 132);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 30);
            this.button1.TabIndex = 41;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // carSellDataSet1
            // 
            this.carSellDataSet1.DataSetName = "CarSellDataSet";
            this.carSellDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // марка_автоTableAdapter1
            // 
            this.марка_автоTableAdapter1.ClearBeforeFill = true;
            // 
            // марка_модельTableAdapter1
            // 
            this.марка_модельTableAdapter1.ClearBeforeFill = true;
            // 
            // модель_автоTableAdapter1
            // 
            this.модель_автоTableAdapter1.ClearBeforeFill = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(74, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(660, 24);
            this.label2.TabIndex = 42;
            this.label2.Text = "Сначало, нужно сохранить марку и модель автомобиля по отдельности";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(147, 225);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(516, 24);
            this.label3.TabIndex = 43;
            this.label3.Text = "Затем, выбрать новые марку и модель и связать их!!!!!!!";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(147, 277);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 20);
            this.label4.TabIndex = 44;
            this.label4.Text = "Марка";
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.lastBrandBindingSource;
            this.comboBox1.DisplayMember = "Марка";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(78, 312);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(220, 21);
            this.comboBox1.TabIndex = 45;
            this.comboBox1.ValueMember = "Код_марки";
            // 
            // brandmodelBindingSource
            // 
            this.brandmodelBindingSource.DataMember = "Brand_model";
            this.brandmodelBindingSource.DataSource = this.carSellDataSet1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(590, 277);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 20);
            this.label5.TabIndex = 46;
            this.label5.Text = "Модель";
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.lastModelBindingSource;
            this.comboBox2.DisplayMember = "Модель";
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(514, 312);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(220, 21);
            this.comboBox2.TabIndex = 47;
            this.comboBox2.ValueMember = "Код_модели";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.OrangeRed;
            this.button2.Location = new System.Drawing.Point(326, 366);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(150, 30);
            this.button2.TabIndex = 48;
            this.button2.Text = "Связать";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // маркаавтоBindingSource
            // 
            this.маркаавтоBindingSource.DataMember = "Марка_авто";
            this.маркаавтоBindingSource.DataSource = this.carSellDataSet1;
            // 
            // модельавтоBindingSource
            // 
            this.модельавтоBindingSource.DataMember = "Модель_авто";
            this.модельавтоBindingSource.DataSource = this.carSellDataSet1;
            // 
            // brand_modelTableAdapter
            // 
            this.brand_modelTableAdapter.ClearBeforeFill = true;
            // 
            // carBrandBindingSource
            // 
            this.carBrandBindingSource.DataMember = "CarBrand";
            this.carBrandBindingSource.DataSource = this.carSellDataSet1;
            // 
            // carBrandTableAdapter
            // 
            this.carBrandTableAdapter.ClearBeforeFill = true;
            // 
            // lastBrandBindingSource
            // 
            this.lastBrandBindingSource.DataMember = "LastBrand";
            this.lastBrandBindingSource.DataSource = this.carSellDataSet1;
            // 
            // lastBrandTableAdapter
            // 
            this.lastBrandTableAdapter.ClearBeforeFill = true;
            // 
            // lastModelBindingSource
            // 
            this.lastModelBindingSource.DataMember = "LastModel";
            this.lastModelBindingSource.DataSource = this.carSellDataSet1;
            // 
            // lastModelTableAdapter
            // 
            this.lastModelTableAdapter.ClearBeforeFill = true;
            // 
            // Form56
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.textBox1);
            this.Name = "Form56";
            this.Text = "Form56";
            this.Load += new System.EventHandler(this.Form56_Load);
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.brandmodelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.маркаавтоBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.модельавтоBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carBrandBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lastBrandBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lastModelBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button1;
        private CarSellDataSet carSellDataSet1;
        private CarSellDataSetTableAdapters.Марка_автоTableAdapter марка_автоTableAdapter1;
        private CarSellDataSetTableAdapters.Марка_модельTableAdapter марка_модельTableAdapter1;
        private CarSellDataSetTableAdapters.Модель_автоTableAdapter модель_автоTableAdapter1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.BindingSource маркаавтоBindingSource;
        private System.Windows.Forms.BindingSource модельавтоBindingSource;
        private System.Windows.Forms.BindingSource brandmodelBindingSource;
        private CarSellDataSetTableAdapters.Brand_modelTableAdapter brand_modelTableAdapter;
        private System.Windows.Forms.BindingSource carBrandBindingSource;
        private CarSellDataSetTableAdapters.CarBrandTableAdapter carBrandTableAdapter;
        private System.Windows.Forms.BindingSource lastBrandBindingSource;
        private CarSellDataSetTableAdapters.LastBrandTableAdapter lastBrandTableAdapter;
        private System.Windows.Forms.BindingSource lastModelBindingSource;
        private CarSellDataSetTableAdapters.LastModelTableAdapter lastModelTableAdapter;
    }
}