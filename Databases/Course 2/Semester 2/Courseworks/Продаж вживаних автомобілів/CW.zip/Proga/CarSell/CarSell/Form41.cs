﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;

namespace CarSell
{
    public partial class Form41 : Form
    {
        SqlConnection conn = null;
        public Form41()
        {
            InitializeComponent();
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void Form41_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.ShortAdress' table. You can move, or remove it, as needed.
            this.shortAdressTableAdapter.Fill(this.carSellDataSet.ShortAdress);
            // TODO: This line of code loads data into the 'carSellDataSet.Вид_телефона' table. You can move, or remove it, as needed.
            this.вид_телефонаTableAdapter.Fill(this.carSellDataSet.Вид_телефона);
            // TODO: This line of code loads data into the 'carSellDataSet.Телефон' table. You can move, or remove it, as needed.
            this.телефонTableAdapter.Fill(this.carSellDataSet.Телефон);
            // TODO: This line of code loads data into the 'carSellDataSet.FullKlName' table. You can move, or remove it, as needed.
            this.fullKlNameTableAdapter.Fill(this.carSellDataSet.FullKlName);
            // TODO: This line of code loads data into the 'carSellDataSet.Улица' table. You can move, or remove it, as needed.
            this.улицаTableAdapter.Fill(this.carSellDataSet.Улица);
            // TODO: This line of code loads data into the 'carSellDataSet.Клиент_покупатель' table. You can move, or remove it, as needed.
            this.клиент_покупательTableAdapter.Fill(this.carSellDataSet.Клиент_покупатель);
            // TODO: This line of code loads data into the 'carSellDataSet.Диапазон_цены' table. You can move, or remove it, as needed.
            this.диапазон_ценыTableAdapter.Fill(this.carSellDataSet.Диапазон_цены);
            // TODO: This line of code loads data into the 'carSellDataSet.Цвет' table. You can move, or remove it, as needed.
            this.цветTableAdapter.Fill(this.carSellDataSet.Цвет);
            // TODO: This line of code loads data into the 'carSellDataSet.Пробег' table. You can move, or remove it, as needed.
            this.пробегTableAdapter.Fill(this.carSellDataSet.Пробег);
            // TODO: This line of code loads data into the 'carSellDataSet.Мощность' table. You can move, or remove it, as needed.
            this.мощностьTableAdapter.Fill(this.carSellDataSet.Мощность);
            // TODO: This line of code loads data into the 'carSellDataSet.Объем_двигателя' table. You can move, or remove it, as needed.
            this.объем_двигателяTableAdapter.Fill(this.carSellDataSet.Объем_двигателя);
            // TODO: This line of code loads data into the 'carSellDataSet.Год_выпуска_до' table. You can move, or remove it, as needed.
            this.год_выпуска_доTableAdapter.Fill(this.carSellDataSet.Год_выпуска_до);
            // TODO: This line of code loads data into the 'carSellDataSet.Год_выпуска_от' table. You can move, or remove it, as needed.
            this.год_выпуска_отTableAdapter.Fill(this.carSellDataSet.Год_выпуска_от);
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_кузова' table. You can move, or remove it, as needed.
            this.тип_кузоваTableAdapter.Fill(this.carSellDataSet.Тип_кузова);
            // TODO: This line of code loads data into the 'carSellDataSet.Модель_авто' table. You can move, or remove it, as needed.
            this.модель_автоTableAdapter.Fill(this.carSellDataSet.Модель_авто);
            // TODO: This line of code loads data into the 'carSellDataSet.Марка_авто' table. You can move, or remove it, as needed.
            this.марка_автоTableAdapter.Fill(this.carSellDataSet.Марка_авто);
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_ТС' table. You can move, or remove it, as needed.
            this.тип_ТСTableAdapter.Fill(this.carSellDataSet.Тип_ТС);
            // TODO: This line of code loads data into the 'carSellDataSet.Клиент_продавец' table. You can move, or remove it, as needed.
            this.клиент_продавецTableAdapter.Fill(this.carSellDataSet.Клиент_продавец);
            // TODO: This line of code loads data into the 'carSellDataSet.Адрес' table. You can move, or remove it, as needed.
            this.адресTableAdapter.Fill(this.carSellDataSet.Адрес);
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_помещения' table. You can move, or remove it, as needed.
            this.тип_помещенияTableAdapter.Fill(this.carSellDataSet.Тип_помещения);
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_строения' table. You can move, or remove it, as needed.
            this.тип_строенияTableAdapter.Fill(this.carSellDataSet.Тип_строения);
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_улицы' table. You can move, or remove it, as needed.
            this.тип_улицыTableAdapter.Fill(this.carSellDataSet.Тип_улицы);
            // TODO: This line of code loads data into the 'carSellDataSet.Населенный_пункт' table. You can move, or remove it, as needed.
            this.населенный_пунктTableAdapter.Fill(this.carSellDataSet.Населенный_пункт);
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_НП' table. You can move, or remove it, as needed.
            this.тип_НПTableAdapter.Fill(this.carSellDataSet.Тип_НП);
            // TODO: This line of code loads data into the 'carSellDataSet.Район' table. You can move, or remove it, as needed.
            this.районTableAdapter.Fill(this.carSellDataSet.Район);
            // TODO: This line of code loads data into the 'carSellDataSet.Область' table. You can move, or remove it, as needed.
            this.областьTableAdapter.Fill(this.carSellDataSet.Область);
            // TODO: This line of code loads data into the 'carSellDataSet.AdressForNewKl' table. You can move, or remove it, as needed.
            this.adressForNewKlTableAdapter.Fill(this.carSellDataSet.AdressForNewKl);

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void label42_Click(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {

            Form45 form45 = new Form45();
            form45.ShowDialog(this);
            this.областьTableAdapter.Fill(this.carSellDataSet.Область);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            try
            {
                int codeObl = int.Parse(this.comboBox10.SelectedValue.ToString());
                string nameRay = Convert.ToString(this.textBox1.Text);


                conn = new SqlConnection();
                conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                conn.Open();
                SqlCommand myComand = conn.CreateCommand();
                myComand.CommandText = "INSERT into Район (Код_области, Назва_району) VALUES (@codeObl, @nameRay)";
                myComand.Parameters.Add("@codeObl", SqlDbType.Int, 4);
                myComand.Parameters["@codeObl"].Value = codeObl;
                myComand.Parameters.Add("@nameRay", SqlDbType.NVarChar, 255);
                myComand.Parameters["@nameRay"].Value = nameRay;

                int UspeshnoeIzmenenie = myComand.ExecuteNonQuery();
                if (UspeshnoeIzmenenie != 0)
                {
                    MessageBox.Show("Изменения внесены", "Изменение записи");
                }
                else
                {
                    MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            this.районTableAdapter.Fill(this.carSellDataSet.Район);
            Form41 form41 = new Form41();
            form41.Update();
            

        }

        private void button15_Click(object sender, EventArgs e)
        {
            Form46 form46 = new Form46();
            form46.ShowDialog(this);
            this.тип_НПTableAdapter.Fill(this.carSellDataSet.Тип_НП);
        }

        private void button19_Click(object sender, EventArgs e)
        {
            try
            {
                int codeTpNP = int.Parse(this.comboBox12.SelectedValue.ToString());
                int codeRay = int.Parse(this.comboBox13.SelectedValue.ToString());
                string nameNP = Convert.ToString(this.textBox2.Text);

                conn = new SqlConnection();
                conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                conn.Open();
                SqlCommand myComand = conn.CreateCommand();
                myComand.CommandText = "INSERT into Населенный_пункт (Код_типа_НП, Код_району, Название) VALUES (@codeTpNP, @codeRay, @nameNP)";
                myComand.Parameters.Add("@codeTpNP", SqlDbType.Int, 4);
                myComand.Parameters["@codeTpNP"].Value = codeTpNP;
                myComand.Parameters.Add("@codeRay", SqlDbType.Int, 4);
                myComand.Parameters["@codeRay"].Value = codeRay;
                myComand.Parameters.Add("@nameNP", SqlDbType.NVarChar, 20);
                myComand.Parameters["@nameNP"].Value = nameNP;

                int UspeshnoeIzmenenie = myComand.ExecuteNonQuery();
                if (UspeshnoeIzmenenie != 0)
                {
                    MessageBox.Show("Изменения внесены", "Изменение записи");
                }
                else
                {
                    MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            this.населенный_пунктTableAdapter.Fill(this.carSellDataSet.Населенный_пункт);
            Form41 form41 = new Form41();
            form41.Update();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            Form47 form47 = new Form47();
            form47.ShowDialog(this);
            this.тип_улицыTableAdapter.Fill(this.carSellDataSet.Тип_улицы);
        }

        private void button25_Click(object sender, EventArgs e)
        {
            try
            {
                int codeTpStr = int.Parse(this.comboBox14.SelectedValue.ToString());
                int codeNP = int.Parse(this.comboBox15.SelectedValue.ToString());
                string nameStr = Convert.ToString(this.textBox11.Text);

                conn = new SqlConnection();
                conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                conn.Open();
                SqlCommand myComand = conn.CreateCommand();
                myComand.CommandText = "INSERT into Улица (Код_типа_улицы, Код_НП, Название_улицы) VALUES (@codeTpStr, @codeNP, @nameStr)";
                myComand.Parameters.Add("@codeTpStr", SqlDbType.Int, 4);
                myComand.Parameters["@codeTpStr"].Value = codeTpStr;
                myComand.Parameters.Add("@codeNP", SqlDbType.Int, 4);
                myComand.Parameters["@codeNP"].Value = codeNP;
                myComand.Parameters.Add("@nameStr", SqlDbType.NVarChar, 20);
                myComand.Parameters["@nameStr"].Value = nameStr;

                int UspeshnoeIzmenenie = myComand.ExecuteNonQuery();
                if (UspeshnoeIzmenenie != 0)
                {
                    MessageBox.Show("Изменения внесены", "Изменение записи");
                }
                else
                {
                    MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            this.улицаTableAdapter.Fill(this.carSellDataSet.Улица);
            Form41 form41 = new Form41();
            form41.Update();
            tabPage1.Update(); 
        }

        private void button24_Click(object sender, EventArgs e)
        {
            Form48 form48 = new Form48();
            form48.ShowDialog(this);
            this.тип_строенияTableAdapter.Fill(this.carSellDataSet.Тип_строения);
        }

        private void button23_Click(object sender, EventArgs e)
        {
            Form49 form49 = new Form49();
            form49.ShowDialog(this);
            this.тип_помещенияTableAdapter.Fill(this.carSellDataSet.Тип_помещения);
        }

        private void button22_Click(object sender, EventArgs e)
        {
            try
            {
                int codeStr = int.Parse(this.comboBox18.SelectedValue.ToString());
                int codeTpBuild = int.Parse(this.comboBox17.SelectedValue.ToString());
                string numberBuild = Convert.ToString(this.textBox14.Text);
                int codeTpRoom = int.Parse(this.comboBox16.SelectedValue.ToString());
                string numberRoom = Convert.ToString(this.textBox13.Text);
                string index = Convert.ToString(this.textBox12.Text);

                conn = new SqlConnection();
                conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                conn.Open();
                SqlCommand myComand = conn.CreateCommand();
                myComand.CommandText = "INSERT into Адрес (Код_улицы, Код_типа_строения, Код_типа_помещения, Номер_строения, Номер_помещения, Индекс) " +
                    "VALUES (@codeStr, @codeTpBuild, @codeTpRoom, @numberBuild, @numberRoom, @index)";

                myComand.Parameters.Add("@codeStr", SqlDbType.Int, 4);
                myComand.Parameters["@codeStr"].Value = codeStr;

                myComand.Parameters.Add("@codeTpBuild", SqlDbType.Int, 4);
                myComand.Parameters["@codeTpBuild"].Value = codeTpBuild;

                myComand.Parameters.Add("@codeTpRoom", SqlDbType.Int, 4);
                myComand.Parameters["@codeTpRoom"].Value = codeTpRoom;

                myComand.Parameters.Add("@numberBuild", SqlDbType.NVarChar, 255);
                myComand.Parameters["@numberBuild"].Value = numberBuild;

                myComand.Parameters.Add("@numberRoom", SqlDbType.NVarChar, 255);
                myComand.Parameters["@numberRoom"].Value = numberRoom;

                myComand.Parameters.Add("@index", SqlDbType.NVarChar, 20);
                myComand.Parameters["@index"].Value = index;


                int UspeshnoeIzmenenie = myComand.ExecuteNonQuery();
                if (UspeshnoeIzmenenie != 0)
                {
                    MessageBox.Show("Изменения внесены", "Изменение записи");
                }
                else
                {
                    MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            this.адресTableAdapter.Fill(this.carSellDataSet.Адрес);
            this.shortAdressTableAdapter.Fill(this.carSellDataSet.ShortAdress);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            try
            {
                int codeAdress = int.Parse(this.comboBox8.SelectedValue.ToString());
                string lastName = Convert.ToString(this.textBox5.Text);
                string name = Convert.ToString(this.textBox6.Text);
                string surName = Convert.ToString(this.textBox7.Text);
                string serPassp = Convert.ToString(this.textBox8.Text);
                string numbPassp = Convert.ToString(this.textBox9.Text);

                conn = new SqlConnection();
                conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                conn.Open();
                SqlCommand myComand = conn.CreateCommand();
                myComand.CommandText = "INSERT into Клиент (Код_адриса, Фамилия, Имя, Отчество, Серия_паспорта, Номер_паспорта) " +
                    "VALUES (@codeAdress, @lastName, @name, @surName, @serPassp, @numbPassp)";

                myComand.Parameters.Add("@codeAdress", SqlDbType.Int, 4);
                myComand.Parameters["@codeAdress"].Value = codeAdress;

                myComand.Parameters.Add("@lastName", SqlDbType.NVarChar, 20);
                myComand.Parameters["@lastName"].Value = lastName;

                myComand.Parameters.Add("@name", SqlDbType.NVarChar, 20);
                myComand.Parameters["@name"].Value = name;

                myComand.Parameters.Add("@surName", SqlDbType.NVarChar, 20);
                myComand.Parameters["@surName"].Value = surName;

                myComand.Parameters.Add("@serPassp", SqlDbType.NVarChar, 20);
                myComand.Parameters["@serPassp"].Value = serPassp;

                myComand.Parameters.Add("@numbPassp", SqlDbType.NVarChar, 20);
                myComand.Parameters["@numbPassp"].Value = numbPassp;


                int UspeshnoeIzmenenie = myComand.ExecuteNonQuery();
                if (UspeshnoeIzmenenie != 0)
                {
                    MessageBox.Show("Изменения внесены", "Изменение записи");
                }
                else
                {
                    MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            this.клиентTableAdapter1.Fill(this.carSellDataSet.Клиент);
            this.адресTableAdapter.Fill(this.carSellDataSet.Адрес);
            this.fullKlNameTableAdapter.Fill(this.carSellDataSet.FullKlName);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form50 form50 = new Form50();
            form50.ShowDialog(this);
            this.телефон_клиентаTableAdapter1.Fill(this.carSellDataSet.Телефон_клиента);
            this.телефонTableAdapter.Fill(this.carSellDataSet.Телефон);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            try
            {
                int codeKl = int.Parse(this.comboBox1.SelectedValue.ToString());
                int telNumber = int.Parse(this.comboBox2.SelectedValue.ToString());
                int telKind = int.Parse(this.comboBox3.SelectedValue.ToString());

                conn = new SqlConnection();
                conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                conn.Open();
                SqlCommand myComand = conn.CreateCommand();
                myComand.CommandText = "INSERT into Телефон_клиента (Код_клиента, ID_телефона, Код_вида_телефона) " +
                    "VALUES (@codeKl, @telNumber, @telKind)";

                myComand.Parameters.Add("@codeKl", SqlDbType.Int, 4);
                myComand.Parameters["@codeKl"].Value = codeKl;

                myComand.Parameters.Add("@telNumber", SqlDbType.Int, 4);
                myComand.Parameters["@telNumber"].Value = telNumber;

                myComand.Parameters.Add("@telKind", SqlDbType.Int, 4);
                myComand.Parameters["@telKind"].Value = telKind;

                
                int UspeshnoeIzmenenie = myComand.ExecuteNonQuery();
                if (UspeshnoeIzmenenie != 0)
                {
                    MessageBox.Show("Изменения внесены", "Изменение записи");
                }
                else
                {
                    MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            this.телефон_клиентаTableAdapter1.Fill(this.carSellDataSet.Телефон_клиента);
            Form41 form41 = new Form41();
            form41.Update();
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form51 form51 = new Form51();
            form51.ShowDialog(this);
            this.клиент_продавецTableAdapter1.Fill(this.carSellDataSet.Клиент_продавец);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form52 form52 = new Form52();
            form52.ShowDialog(this);
            this.клиент_покупательTableAdapter1.Fill(this.carSellDataSet.Клиент_покупатель);
        }

        private void tabPage6_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void tabControl1_MouseClick(object sender, MouseEventArgs e)
        {
            this.shortAdressTableAdapter.Fill(this.carSellDataSet.ShortAdress);
        }

        private void tabPage1_Click_1(object sender, EventArgs e)
        {
            this.shortAdressTableAdapter.Fill(this.carSellDataSet.ShortAdress);
        }

        private void tabPage2_Click_1(object sender, EventArgs e)
        {
            this.fullKlNameTableAdapter.Fill(this.carSellDataSet.FullKlName);
        }
    }
}

