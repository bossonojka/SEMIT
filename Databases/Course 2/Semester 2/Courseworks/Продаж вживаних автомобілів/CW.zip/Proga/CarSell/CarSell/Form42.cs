﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;

namespace CarSell
{
    public partial class Form42 : Form
    {
        SqlConnection conn = null;
        public Form42()
        {
            InitializeComponent();
        }

        private void Form55_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.FullKlName' table. You can move, or remove it, as needed.
            this.fullKlNameTableAdapter1.Fill(this.carSellDataSet.FullKlName);
            // TODO: This line of code loads data into the 'carSellDataSet.CarBrand' table. You can move, or remove it, as needed.
            this.carBrandTableAdapter1.Fill(this.carSellDataSet.CarBrand);
            // TODO: This line of code loads data into the 'carSellDataSet.Диапазон_цены' table. You can move, or remove it, as needed.
            this.диапазон_ценыTableAdapter1.Fill(this.carSellDataSet.Диапазон_цены);
            // TODO: This line of code loads data into the 'carSellDataSet.Цвет' table. You can move, or remove it, as needed.
            this.цветTableAdapter1.Fill(this.carSellDataSet.Цвет);
            // TODO: This line of code loads data into the 'carSellDataSet.Пробег' table. You can move, or remove it, as needed.
            this.пробегTableAdapter1.Fill(this.carSellDataSet.Пробег);
            // TODO: This line of code loads data into the 'carSellDataSet.Мощность' table. You can move, or remove it, as needed.
            this.мощностьTableAdapter1.Fill(this.carSellDataSet.Мощность);
            // TODO: This line of code loads data into the 'carSellDataSet.Объем_двигателя' table. You can move, or remove it, as needed.
            this.объем_двигателяTableAdapter1.Fill(this.carSellDataSet.Объем_двигателя);
            // TODO: This line of code loads data into the 'carSellDataSet.Год_выпуска_до' table. You can move, or remove it, as needed.
            this.год_выпуска_доTableAdapter1.Fill(this.carSellDataSet.Год_выпуска_до);
            comboBox15.SelectedIndex = -1;
            // TODO: This line of code loads data into the 'carSellDataSet.Год_выпуска_от' table. You can move, or remove it, as needed.
            this.год_выпуска_отTableAdapter1.Fill(this.carSellDataSet.Год_выпуска_от);
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_кузова' table. You can move, or remove it, as needed.
            this.тип_кузоваTableAdapter1.Fill(this.carSellDataSet.Тип_кузова);
            // TODO: This line of code loads data into the 'carSellDataSet.Модель_авто' table. You can move, or remove it, as needed.
            this.модель_автоTableAdapter1.Fill(this.carSellDataSet.Модель_авто);
            // TODO: This line of code loads data into the 'carSellDataSet.Марка_авто' table. You can move, or remove it, as needed.
            this.марка_автоTableAdapter1.Fill(this.carSellDataSet.Марка_авто);
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_ТС' table. You can move, or remove it, as needed.
            this.тип_ТСTableAdapter1.Fill(this.carSellDataSet.Тип_ТС);
            // TODO: This line of code loads data into the 'carSellDataSet.SellKlient' table. You can move, or remove it, as needed.
            this.sellKlientTableAdapter1.Fill(this.carSellDataSet.SellKlient);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form53 form53 = new Form53();
            form53.ShowDialog(this);
            this.тип_ТСTableAdapter1.Fill(this.carSellDataSet.Тип_ТС);
        }

        

        private void button13_Click(object sender, EventArgs e)
        {
            Form56 form56 = new Form56();
            form56.ShowDialog(this);
            this.марка_автоTableAdapter1.Fill(this.carSellDataSet.Марка_авто);
            this.модель_автоTableAdapter1.Fill(this.carSellDataSet.Модель_авто);
            this.lastBrandTableAdapter1.Fill(this.carSellDataSet.LastBrand);
            this.lastModelTableAdapter1.Fill(this.carSellDataSet.LastModel);
            this.марка_модельTableAdapter1.Fill(this.carSellDataSet.Марка_модель);

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form54 form54 = new Form54();
            form54.ShowDialog(this);
            this.тип_кузоваTableAdapter1.Fill(this.carSellDataSet.Тип_кузова);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form55 form55 = new Form55();
            form55.ShowDialog(this);
            this.год_выпуска_отTableAdapter1.Fill(this.carSellDataSet.Год_выпуска_от);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form58 form58 = new Form58();
            form58.ShowDialog(this);
            this.год_выпуска_доTableAdapter1.Fill(this.carSellDataSet.Год_выпуска_до);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Form59 form59 = new Form59();
            form59.ShowDialog(this);
            this.объем_двигателяTableAdapter1.Fill(this.carSellDataSet.Объем_двигателя);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form60 form60 = new Form60();
            form60.ShowDialog(this);
            this.мощностьTableAdapter1.Fill(this.carSellDataSet.Мощность);
        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            Form61 form61 = new Form61();
            form61.ShowDialog(this);
            this.цветTableAdapter1.Fill(this.carSellDataSet.Цвет);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Form62 form62 = new Form62();
            form62.ShowDialog(this);
            this.диапазон_ценыTableAdapter1.Fill(this.carSellDataSet.Диапазон_цены);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            /*try
            {
                int codeKl = int.Parse(this.comboBox10.SelectedValue.ToString());
                int typeTC = int.Parse(this.comboBox9.SelectedValue.ToString());
                int brand = int.Parse(this.comboBox11.SelectedValue.ToString());
                int model = int.Parse(this.comboBox12.SelectedValue.ToString());
                int typeBody = int.Parse(this.comboBox13.SelectedValue.ToString());
                int graduationYear = int.Parse(this.comboBox14.SelectedValue.ToString());
                int withdrawalYear = int.Parse(this.comboBox15.SelectedValue.ToString());
                int capacity = int.Parse(this.comboBox16.SelectedValue.ToString());
                int power = int.Parse(this.comboBox17.SelectedValue.ToString());
                int mileage = int.Parse(this.comboBox18.SelectedValue.ToString());
                int color = int.Parse(this.comboBox19.SelectedValue.ToString());
                int price = int.Parse(this.comboBox20.SelectedValue.ToString());
                string vinCode = Convert.ToString(this.textBox1.Text);


                conn = new SqlConnection();
                conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                conn.Open();
                SqlCommand myComand = conn.CreateCommand();
                myComand.CommandText = "INSERT into Автомобиль (Код_клиента_продавца, Код_типа_ТС, Код_марки, Код_модели, Код_типа_кузова, Код_года_выпуска_от, Код_года_выпуска_до, Код_диапазона_объема_двигателя, Код_диапазона_мощности, Код_диапазона_пробега, Код_цвета, Код_диапазона_цены, VIN_код_кузова) " +
                    "VALUES (@codeKl, @typeTC, @brand, @model, @typeBody, @graduationYear, @withdrawalYear, @capacity, @power, @color, @price, @vinCode)";

                myComand.Parameters.Add("@codeKl", SqlDbType.Int, 8);
                myComand.Parameters["@codeKl"].Value = codeKl;

                myComand.Parameters.Add("@typeTC", SqlDbType.Int, 4);
                myComand.Parameters["@typeTC"].Value = typeTC;

                myComand.Parameters.Add("@brand", SqlDbType.Int, 4);
                myComand.Parameters["@brand"].Value = brand;

                myComand.Parameters.Add("@model", SqlDbType.Int, 4);
                myComand.Parameters["@model"].Value = model;

                myComand.Parameters.Add("@typeBody", SqlDbType.Int, 4);
                myComand.Parameters["@typeBody"].Value = typeBody;

                myComand.Parameters.Add("@graduationYear", SqlDbType.Int, 4);
                myComand.Parameters["@graduationYear"].Value = graduationYear;

                myComand.Parameters.Add("@withdrawalYear", SqlDbType.Int, 4);
                myComand.Parameters["@withdrawalYear"].Value = withdrawalYear;

                myComand.Parameters.Add("@capacity", SqlDbType.Int, 4);
                myComand.Parameters["@capacity"].Value = capacity;

                myComand.Parameters.Add("@power", SqlDbType.Int, 4);
                myComand.Parameters["@power"].Value = power;

                myComand.Parameters.Add("@mileage", SqlDbType.Int, 4);
                myComand.Parameters["@mileage"].Value = mileage;

                myComand.Parameters.Add("@color", SqlDbType.Int, 4);
                myComand.Parameters["@color"].Value = color;

                myComand.Parameters.Add("@price", SqlDbType.Int, 4);
                myComand.Parameters["@price"].Value = price;

                myComand.Parameters.Add("@vinCode", SqlDbType.NVarChar, 20);
                myComand.Parameters["@vinCode"].Value = vinCode;


                int UspeshnoeIzmenenie = myComand.ExecuteNonQuery();
                if (UspeshnoeIzmenenie != 0)
                {
                    MessageBox.Show("Изменения внесены", "Изменение записи");
                }
                else
                {
                    MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            this.автомобильTableAdapter1.Fill(this.carSellDataSet.Автомобиль);
            Form42 form42 = new Form42();
            form42.Update();*/




            conn = new SqlConnection();
            conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
            
            SqlCommand myComand = conn.CreateCommand();
            string Car = "INSERT into Автомобиль (Код_клиента_продавца, Код_типа_ТС, Код_марки, Код_модели, Код_типа_кузова, Код_года_выпуска_от, Код_года_выпуска_до, " +
                "Код_диапазона_объема_двигателя, Код_диапазона_мощности, Код_диапазона_пробега, Код_цвета, Код_диапазона_цены, VIN_код_кузова) " +
                "values ('" + this.comboBox10.SelectedValue.ToString() + "','" + this.comboBox9.SelectedValue.ToString() + "','" + 
                this.comboBox11.SelectedValue.ToString() + "','" + this.comboBox12.SelectedValue.ToString() + "','" + this.comboBox13.SelectedValue.ToString() + 
                "','" + this.comboBox14.SelectedValue.ToString() + "','" + this.comboBox15.SelectedValue.ToString()  + "','" + this.comboBox16.SelectedValue.ToString() + 
                "','" + this.comboBox17.SelectedValue.ToString() + "','" + this.comboBox18.SelectedValue.ToString() + "','" + this.comboBox19.SelectedValue.ToString() + 
                "','" + this.comboBox20.SelectedValue.ToString() + "','" + this.textBox1.Text + "');";
            
            SqlCommand sqlCommand = new SqlCommand(Car, conn);
            SqlDataReader myReader;
            try
            {
                conn.Open();
                myReader = sqlCommand.ExecuteReader();
                MessageBox.Show("Изменения внесены", "Изменение записи");
                while(myReader.Read())
                {

                }

            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            this.автомобильTableAdapter1.Update(this.carSellDataSet.Автомобиль);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void comboBox15_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
