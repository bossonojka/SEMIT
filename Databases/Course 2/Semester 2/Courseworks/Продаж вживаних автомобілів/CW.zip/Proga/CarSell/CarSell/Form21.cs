﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSell
{
    public partial class Form21 : Form
    {
        public Form21()
        {
            InitializeComponent();
        }

        private void Form21_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Улица' table. You can move, or remove it, as needed.
            this.улицаTableAdapter.Fill(this.carSellDataSet.Улица);
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_улицы' table. You can move, or remove it, as needed.
            this.тип_улицыTableAdapter.Fill(this.carSellDataSet.Тип_улицы);
            // TODO: This line of code loads data into the 'carSellDataSet.Населенный_пункт' table. You can move, or remove it, as needed.
            this.населенный_пунктTableAdapter.Fill(this.carSellDataSet.Населенный_пункт);
            // TODO: This line of code loads data into the 'carSellDataSet.Street' table. You can move, or remove it, as needed.
            this.streetTableAdapter.Fill(this.carSellDataSet.Street);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form41 form41 = new Form41();
            form41.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.улицаTableAdapter.Update(this.carSellDataSet.Улица);
        }
    }
}
