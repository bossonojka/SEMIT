﻿namespace CarSell
{
    partial class Form34
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.кодклиентапродавцаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.клиентПродавецDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодавтомобиляDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.маркаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.модельDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.диапазонценыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sellKlCarsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carSellDataSet = new CarSell.CarSellDataSet();
            this.клиентBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fullKlNameBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.автомобильBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.маркаавтоBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.модельавтоBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.диапазонценыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.klientPhoneBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sellKlCarsTableAdapter = new CarSell.CarSellDataSetTableAdapters.SellKlCarsTableAdapter();
            this.клиентTableAdapter = new CarSell.CarSellDataSetTableAdapters.КлиентTableAdapter();
            this.klientAdressBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.klientAdressTableAdapter = new CarSell.CarSellDataSetTableAdapters.KlientAdressTableAdapter();
            this.klientPhoneTableAdapter = new CarSell.CarSellDataSetTableAdapters.KlientPhoneTableAdapter();
            this.автомобильTableAdapter = new CarSell.CarSellDataSetTableAdapters.АвтомобильTableAdapter();
            this.марка_автоTableAdapter = new CarSell.CarSellDataSetTableAdapters.Марка_автоTableAdapter();
            this.модель_автоTableAdapter = new CarSell.CarSellDataSetTableAdapters.Модель_автоTableAdapter();
            this.диапазон_ценыTableAdapter = new CarSell.CarSellDataSetTableAdapters.Диапазон_ценыTableAdapter();
            this.fullKlNameTableAdapter = new CarSell.CarSellDataSetTableAdapters.FullKlNameTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellKlCarsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fullKlNameBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.автомобильBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.маркаавтоBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.модельавтоBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.диапазонценыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientPhoneBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientAdressBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодклиентапродавцаDataGridViewTextBoxColumn,
            this.клиентПродавецDataGridViewTextBoxColumn,
            this.кодавтомобиляDataGridViewTextBoxColumn,
            this.маркаDataGridViewTextBoxColumn,
            this.модельDataGridViewTextBoxColumn,
            this.диапазонценыDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.sellKlCarsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(1, 1);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(812, 450);
            this.dataGridView1.TabIndex = 0;
            // 
            // кодклиентапродавцаDataGridViewTextBoxColumn
            // 
            this.кодклиентапродавцаDataGridViewTextBoxColumn.DataPropertyName = "Код_клиента_продавца";
            this.кодклиентапродавцаDataGridViewTextBoxColumn.FillWeight = 150F;
            this.кодклиентапродавцаDataGridViewTextBoxColumn.HeaderText = "Код_клиента_продавца";
            this.кодклиентапродавцаDataGridViewTextBoxColumn.Name = "кодклиентапродавцаDataGridViewTextBoxColumn";
            this.кодклиентапродавцаDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.кодклиентапродавцаDataGridViewTextBoxColumn.Width = 150;
            // 
            // клиентПродавецDataGridViewTextBoxColumn
            // 
            this.клиентПродавецDataGridViewTextBoxColumn.DataPropertyName = "Клиент - продавец";
            this.клиентПродавецDataGridViewTextBoxColumn.FillWeight = 200F;
            this.клиентПродавецDataGridViewTextBoxColumn.HeaderText = "Клиент - продавец";
            this.клиентПродавецDataGridViewTextBoxColumn.Name = "клиентПродавецDataGridViewTextBoxColumn";
            this.клиентПродавецDataGridViewTextBoxColumn.ReadOnly = true;
            this.клиентПродавецDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.клиентПродавецDataGridViewTextBoxColumn.Width = 200;
            // 
            // кодавтомобиляDataGridViewTextBoxColumn
            // 
            this.кодавтомобиляDataGridViewTextBoxColumn.DataPropertyName = "Код_автомобиля";
            this.кодавтомобиляDataGridViewTextBoxColumn.HeaderText = "Код_автомобиля";
            this.кодавтомобиляDataGridViewTextBoxColumn.Name = "кодавтомобиляDataGridViewTextBoxColumn";
            this.кодавтомобиляDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // маркаDataGridViewTextBoxColumn
            // 
            this.маркаDataGridViewTextBoxColumn.DataPropertyName = "Марка";
            this.маркаDataGridViewTextBoxColumn.HeaderText = "Марка";
            this.маркаDataGridViewTextBoxColumn.Name = "маркаDataGridViewTextBoxColumn";
            this.маркаDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // модельDataGridViewTextBoxColumn
            // 
            this.модельDataGridViewTextBoxColumn.DataPropertyName = "Модель";
            this.модельDataGridViewTextBoxColumn.HeaderText = "Модель";
            this.модельDataGridViewTextBoxColumn.Name = "модельDataGridViewTextBoxColumn";
            this.модельDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // диапазонценыDataGridViewTextBoxColumn
            // 
            this.диапазонценыDataGridViewTextBoxColumn.DataPropertyName = "Диапазон_цены";
            this.диапазонценыDataGridViewTextBoxColumn.FillWeight = 110F;
            this.диапазонценыDataGridViewTextBoxColumn.HeaderText = "Диапазон_цены";
            this.диапазонценыDataGridViewTextBoxColumn.Name = "диапазонценыDataGridViewTextBoxColumn";
            this.диапазонценыDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.диапазонценыDataGridViewTextBoxColumn.Width = 110;
            // 
            // sellKlCarsBindingSource
            // 
            this.sellKlCarsBindingSource.DataMember = "SellKlCars";
            this.sellKlCarsBindingSource.DataSource = this.carSellDataSet;
            // 
            // carSellDataSet
            // 
            this.carSellDataSet.DataSetName = "CarSellDataSet";
            this.carSellDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // клиентBindingSource
            // 
            this.клиентBindingSource.DataMember = "Клиент";
            this.клиентBindingSource.DataSource = this.carSellDataSet;
            // 
            // fullKlNameBindingSource
            // 
            this.fullKlNameBindingSource.DataMember = "FullKlName";
            this.fullKlNameBindingSource.DataSource = this.carSellDataSet;
            // 
            // автомобильBindingSource
            // 
            this.автомобильBindingSource.DataMember = "Автомобиль";
            this.автомобильBindingSource.DataSource = this.carSellDataSet;
            // 
            // маркаавтоBindingSource
            // 
            this.маркаавтоBindingSource.DataMember = "Марка_авто";
            this.маркаавтоBindingSource.DataSource = this.carSellDataSet;
            // 
            // модельавтоBindingSource
            // 
            this.модельавтоBindingSource.DataMember = "Модель_авто";
            this.модельавтоBindingSource.DataSource = this.carSellDataSet;
            // 
            // диапазонценыBindingSource
            // 
            this.диапазонценыBindingSource.DataMember = "Диапазон_цены";
            this.диапазонценыBindingSource.DataSource = this.carSellDataSet;
            // 
            // klientPhoneBindingSource
            // 
            this.klientPhoneBindingSource.DataMember = "KlientPhone";
            this.klientPhoneBindingSource.DataSource = this.carSellDataSet;
            // 
            // sellKlCarsTableAdapter
            // 
            this.sellKlCarsTableAdapter.ClearBeforeFill = true;
            // 
            // клиентTableAdapter
            // 
            this.клиентTableAdapter.ClearBeforeFill = true;
            // 
            // klientAdressBindingSource
            // 
            this.klientAdressBindingSource.DataMember = "KlientAdress";
            this.klientAdressBindingSource.DataSource = this.carSellDataSet;
            // 
            // klientAdressTableAdapter
            // 
            this.klientAdressTableAdapter.ClearBeforeFill = true;
            // 
            // klientPhoneTableAdapter
            // 
            this.klientPhoneTableAdapter.ClearBeforeFill = true;
            // 
            // автомобильTableAdapter
            // 
            this.автомобильTableAdapter.ClearBeforeFill = true;
            // 
            // марка_автоTableAdapter
            // 
            this.марка_автоTableAdapter.ClearBeforeFill = true;
            // 
            // модель_автоTableAdapter
            // 
            this.модель_автоTableAdapter.ClearBeforeFill = true;
            // 
            // диапазон_ценыTableAdapter
            // 
            this.диапазон_ценыTableAdapter.ClearBeforeFill = true;
            // 
            // fullKlNameTableAdapter
            // 
            this.fullKlNameTableAdapter.ClearBeforeFill = true;
            // 
            // Form34
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(813, 451);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form34";
            this.Text = "Form34";
            this.Load += new System.EventHandler(this.Form34_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellKlCarsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fullKlNameBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.автомобильBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.маркаавтоBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.модельавтоBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.диапазонценыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientPhoneBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientAdressBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CarSellDataSet carSellDataSet;
        private System.Windows.Forms.BindingSource sellKlCarsBindingSource;
        private CarSellDataSetTableAdapters.SellKlCarsTableAdapter sellKlCarsTableAdapter;
        private System.Windows.Forms.BindingSource клиентBindingSource;
        private CarSellDataSetTableAdapters.КлиентTableAdapter клиентTableAdapter;
        private System.Windows.Forms.BindingSource klientAdressBindingSource;
        private CarSellDataSetTableAdapters.KlientAdressTableAdapter klientAdressTableAdapter;
        private System.Windows.Forms.BindingSource klientPhoneBindingSource;
        private CarSellDataSetTableAdapters.KlientPhoneTableAdapter klientPhoneTableAdapter;
        private System.Windows.Forms.BindingSource автомобильBindingSource;
        private CarSellDataSetTableAdapters.АвтомобильTableAdapter автомобильTableAdapter;
        private System.Windows.Forms.BindingSource маркаавтоBindingSource;
        private CarSellDataSetTableAdapters.Марка_автоTableAdapter марка_автоTableAdapter;
        private System.Windows.Forms.BindingSource модельавтоBindingSource;
        private CarSellDataSetTableAdapters.Модель_автоTableAdapter модель_автоTableAdapter;
        private System.Windows.Forms.BindingSource диапазонценыBindingSource;
        private CarSellDataSetTableAdapters.Диапазон_ценыTableAdapter диапазон_ценыTableAdapter;
        private System.Windows.Forms.BindingSource fullKlNameBindingSource;
        private CarSellDataSetTableAdapters.FullKlNameTableAdapter fullKlNameTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодклиентапродавцаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn клиентПродавецDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодавтомобиляDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn маркаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn модельDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn диапазонценыDataGridViewTextBoxColumn;
    }
}