﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace CarSell
{
    public partial class Form36 : Form
    {
        SqlConnection conn = null;
        public Form36()
        {
            InitializeComponent();
        }

        private void Form36_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.FullKlName' table. You can move, or remove it, as needed.
            this.fullKlNameTableAdapter.Fill(this.carSellDataSet.FullKlName);
            // TODO: This line of code loads data into the 'carSellDataSet.Диапазон_цены' table. You can move, or remove it, as needed.
            this.диапазон_ценыTableAdapter.Fill(this.carSellDataSet.Диапазон_цены);
            // TODO: This line of code loads data into the 'carSellDataSet.Цвет' table. You can move, or remove it, as needed.
            this.цветTableAdapter.Fill(this.carSellDataSet.Цвет);
            // TODO: This line of code loads data into the 'carSellDataSet.Пробег' table. You can move, or remove it, as needed.
            this.пробегTableAdapter.Fill(this.carSellDataSet.Пробег);
            // TODO: This line of code loads data into the 'carSellDataSet.Мощность' table. You can move, or remove it, as needed.
            this.мощностьTableAdapter.Fill(this.carSellDataSet.Мощность);
            // TODO: This line of code loads data into the 'carSellDataSet.Объем_двигателя' table. You can move, or remove it, as needed.
            this.объем_двигателяTableAdapter.Fill(this.carSellDataSet.Объем_двигателя);
            // TODO: This line of code loads data into the 'carSellDataSet.Год_выпуска_до' table. You can move, or remove it, as needed.
            this.год_выпуска_доTableAdapter.Fill(this.carSellDataSet.Год_выпуска_до);
            // TODO: This line of code loads data into the 'carSellDataSet.Год_выпуска_от' table. You can move, or remove it, as needed.
            this.год_выпуска_отTableAdapter.Fill(this.carSellDataSet.Год_выпуска_от);
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_кузова' table. You can move, or remove it, as needed.
            this.тип_кузоваTableAdapter.Fill(this.carSellDataSet.Тип_кузова);
            // TODO: This line of code loads data into the 'carSellDataSet.Модель_авто' table. You can move, or remove it, as needed.
            this.модель_автоTableAdapter.Fill(this.carSellDataSet.Модель_авто);
            // TODO: This line of code loads data into the 'carSellDataSet.Марка_авто' table. You can move, or remove it, as needed.
            this.марка_автоTableAdapter.Fill(this.carSellDataSet.Марка_авто);
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_ТС' table. You can move, or remove it, as needed.
            this.тип_ТСTableAdapter.Fill(this.carSellDataSet.Тип_ТС);
            // TODO: This line of code loads data into the 'carSellDataSet.KlientPhone' table. You can move, or remove it, as needed.
            this.klientPhoneTableAdapter.Fill(this.carSellDataSet.KlientPhone);
            // TODO: This line of code loads data into the 'carSellDataSet.Клиент_покупатель' table. You can move, or remove it, as needed.
            this.клиент_покупательTableAdapter.Fill(this.carSellDataSet.Клиент_покупатель);
            // TODO: This line of code loads data into the 'carSellDataSet.Клиент' table. You can move, or remove it, as needed.
            this.клиентTableAdapter.Fill(this.carSellDataSet.Клиент);
            // TODO: This line of code loads data into the 'carSellDataSet.AllOrder' table. You can move, or remove it, as needed.
            this.allOrderTableAdapter.Fill(this.carSellDataSet.AllOrder);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form63 form63 = new Form63();
            form63.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int codeOrder = int.Parse(dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells["кодзаказаDataGridViewTextBoxColumn"].Value.ToString());
            DialogResult result = MessageBox.Show("Удалить заказ клиента?", "Предупреждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            switch (result)
            {
                case DialogResult.Yes:
                    {
                        try
                        {
                            conn = new SqlConnection();
                            conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                            conn.Open();
                            SqlCommand myCommand = conn.CreateCommand();
                            myCommand.CommandText = "Delete from Заказ_клиента Where Код_заказа = @codeOrder";
                            myCommand.Parameters.Add("@codeOrder", SqlDbType.Int, 4);
                            myCommand.Parameters["@codeOrder"].Value = codeOrder;


                            int UspeshnoeIzmenenie = myCommand.ExecuteNonQuery();
                            if (UspeshnoeIzmenenie != 0)
                            {
                                MessageBox.Show("Изменения внесены", "Изменение записи");
                            }
                            else
                            {
                                MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                        finally
                        {
                            conn.Close();
                        }
                        this.заказ_клиентаTableAdapter1.Fill(this.carSellDataSet.Заказ_клиента);
                        break;
                    }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.заказ_клиентаTableAdapter1.Update(this.carSellDataSet.Заказ_клиента);
        }
    }
}
