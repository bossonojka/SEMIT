﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSell
{
    public partial class Form19 : Form
    {
        public Form19()
        {
            InitializeComponent();
        }

        private void Form19_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Населенный_пункт' table. You can move, or remove it, as needed.
            this.населенный_пунктTableAdapter.Fill(this.carSellDataSet.Населенный_пункт);
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_НП' table. You can move, or remove it, as needed.
            this.тип_НПTableAdapter.Fill(this.carSellDataSet.Тип_НП);
            // TODO: This line of code loads data into the 'carSellDataSet.Район' table. You can move, or remove it, as needed.
            this.районTableAdapter.Fill(this.carSellDataSet.Район);
            // TODO: This line of code loads data into the 'carSellDataSet.NP' table. You can move, or remove it, as needed.
            this.nPTableAdapter.Fill(this.carSellDataSet.NP);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form41 form41 = new Form41();
            form41.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.населенный_пунктTableAdapter.Update(this.carSellDataSet.Населенный_пункт);
        }
    }
}
