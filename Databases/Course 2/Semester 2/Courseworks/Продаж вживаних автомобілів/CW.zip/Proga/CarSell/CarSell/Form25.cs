﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSell
{
    public partial class Form25 : Form
    {
        public Form25()
        {
            InitializeComponent();
        }

        private void Form25_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Номер_оператора' table. You can move, or remove it, as needed.
            this.номер_оператораTableAdapter.Fill(this.carSellDataSet.Номер_оператора);
            // TODO: This line of code loads data into the 'carSellDataSet.Оператор' table. You can move, or remove it, as needed.
            this.операторTableAdapter.Fill(this.carSellDataSet.Оператор);
            // TODO: This line of code loads data into the 'carSellDataSet.OperatorNumber' table. You can move, or remove it, as needed.
            this.operatorNumberTableAdapter.Fill(this.carSellDataSet.OperatorNumber);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form68 form68 = new Form68();
            form68.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.номер_оператораTableAdapter.Update(this.carSellDataSet.Номер_оператора);
        }
    }
}
