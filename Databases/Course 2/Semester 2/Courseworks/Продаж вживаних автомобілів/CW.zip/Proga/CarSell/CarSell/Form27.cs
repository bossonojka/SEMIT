﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSell
{
    public partial class Form27 : Form
    {
        public Form27()
        {
            InitializeComponent();
        }

        private void Form27_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Оператор' table. You can move, or remove it, as needed.
            this.операторTableAdapter.Fill(this.carSellDataSet.Оператор);
            // TODO: This line of code loads data into the 'carSellDataSet.Номер_оператора' table. You can move, or remove it, as needed.
            this.номер_оператораTableAdapter.Fill(this.carSellDataSet.Номер_оператора);
            // TODO: This line of code loads data into the 'carSellDataSet.Телефон' table. You can move, or remove it, as needed.
            this.телефонTableAdapter.Fill(this.carSellDataSet.Телефон);
            // TODO: This line of code loads data into the 'carSellDataSet.MobilePhone' table. You can move, or remove it, as needed.
            this.mobilePhoneTableAdapter.Fill(this.carSellDataSet.MobilePhone);

        }
    }
}
