﻿namespace CarSell
{
    partial class Form62
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.carSellDataSet1 = new CarSell.CarSellDataSet();
            this.диапазон_ценыTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Диапазон_ценыTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.диапазонценыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.коддиапазонаценыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.диапазонценыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.диапазонценыBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(74, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(325, 20);
            this.label1.TabIndex = 47;
            this.label1.Text = "Формат: от - до, с диапазоном 10 000 грн";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.Location = new System.Drawing.Point(52, 68);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(48, 20);
            this.label19.TabIndex = 44;
            this.label19.Text = "Цена";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button1.Location = new System.Drawing.Point(149, 136);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 30);
            this.button1.TabIndex = 46;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(186, 68);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(220, 20);
            this.textBox1.TabIndex = 45;
            // 
            // carSellDataSet1
            // 
            this.carSellDataSet1.DataSetName = "CarSellDataSet";
            this.carSellDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // диапазон_ценыTableAdapter1
            // 
            this.диапазон_ценыTableAdapter1.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.коддиапазонаценыDataGridViewTextBoxColumn,
            this.диапазонценыDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.диапазонценыBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(-1, 189);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(459, 270);
            this.dataGridView1.TabIndex = 93;
            // 
            // диапазонценыBindingSource
            // 
            this.диапазонценыBindingSource.DataMember = "Диапазон_цены";
            this.диапазонценыBindingSource.DataSource = this.carSellDataSet1;
            // 
            // коддиапазонаценыDataGridViewTextBoxColumn
            // 
            this.коддиапазонаценыDataGridViewTextBoxColumn.DataPropertyName = "Код_диапазона_цены";
            this.коддиапазонаценыDataGridViewTextBoxColumn.FillWeight = 200F;
            this.коддиапазонаценыDataGridViewTextBoxColumn.HeaderText = "Код_диапазона_цены";
            this.коддиапазонаценыDataGridViewTextBoxColumn.Name = "коддиапазонаценыDataGridViewTextBoxColumn";
            this.коддиапазонаценыDataGridViewTextBoxColumn.ReadOnly = true;
            this.коддиапазонаценыDataGridViewTextBoxColumn.Width = 200;
            // 
            // диапазонценыDataGridViewTextBoxColumn
            // 
            this.диапазонценыDataGridViewTextBoxColumn.DataPropertyName = "Диапазон_цены";
            this.диапазонценыDataGridViewTextBoxColumn.FillWeight = 200F;
            this.диапазонценыDataGridViewTextBoxColumn.HeaderText = "Диапазон_цены";
            this.диапазонценыDataGridViewTextBoxColumn.Name = "диапазонценыDataGridViewTextBoxColumn";
            this.диапазонценыDataGridViewTextBoxColumn.Width = 200;
            // 
            // Form62
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(458, 462);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Name = "Form62";
            this.Text = "Form62";
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.диапазонценыBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private CarSellDataSet carSellDataSet1;
        private CarSellDataSetTableAdapters.Диапазон_ценыTableAdapter диапазон_ценыTableAdapter1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn коддиапазонаценыDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn диапазонценыDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource диапазонценыBindingSource;
    }
}