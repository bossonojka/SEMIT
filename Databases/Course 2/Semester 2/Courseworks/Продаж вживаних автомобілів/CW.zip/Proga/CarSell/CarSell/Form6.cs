﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;

namespace CarSell
{
    public partial class Form6 : Form
    {
        SqlConnection conn = null;
        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Год_выпуска_от' table. You can move, or remove it, as needed.
            this.год_выпуска_отTableAdapter.Fill(this.carSellDataSet.Год_выпуска_от);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form55 form55 = new Form55();
            form55.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int yearOt = int.Parse(dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells["кодгодавыпускаотDataGridViewTextBoxColumn"].Value.ToString());
            DialogResult result = MessageBox.Show("Удалить год выпуска?", "Предупреждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            switch (result)
            {
                case DialogResult.Yes:
                    {
                        try
                        {
                            conn = new SqlConnection();
                            conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                            conn.Open();
                            SqlCommand myCommand = conn.CreateCommand();
                            myCommand.CommandText = "Delete from Год_выпуска_от Where Код_года_выпуска_от = @yearOt";
                            myCommand.Parameters.Add("@yearOt", SqlDbType.Int, 4);
                            myCommand.Parameters["@yearOt"].Value = yearOt;


                            int UspeshnoeIzmenenie = myCommand.ExecuteNonQuery();
                            if (UspeshnoeIzmenenie != 0)
                            {
                                MessageBox.Show("Изменения внесены", "Изменение записи");
                            }
                            else
                            {
                                MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                        finally
                        {
                            conn.Close();
                        }
                        this.год_выпуска_отTableAdapter.Fill(this.carSellDataSet.Год_выпуска_от);
                        break;
                    }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.год_выпуска_отTableAdapter.Update(this.carSellDataSet.Год_выпуска_от);
        }
    }
}
