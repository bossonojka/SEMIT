﻿namespace CarSell
{
    partial class Form19
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.кодНПDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.назварайонуDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиетипаНПDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nPBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carSellDataSet = new CarSell.CarSellDataSet();
            this.районBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.типНПBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nPTableAdapter = new CarSell.CarSellDataSetTableAdapters.NPTableAdapter();
            this.районTableAdapter = new CarSell.CarSellDataSetTableAdapters.РайонTableAdapter();
            this.тип_НПTableAdapter = new CarSell.CarSellDataSetTableAdapters.Тип_НПTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.населенныйпунктBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.населенный_пунктTableAdapter = new CarSell.CarSellDataSetTableAdapters.Населенный_пунктTableAdapter();
            this.кодНПDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодтипаНПDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодрайонуDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nPBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.районBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типНПBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.населенныйпунктBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодНПDataGridViewTextBoxColumn,
            this.назварайонуDataGridViewTextBoxColumn,
            this.названиетипаНПDataGridViewTextBoxColumn,
            this.названиеDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.nPBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(0, -1);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(523, 220);
            this.dataGridView1.TabIndex = 0;
            // 
            // кодНПDataGridViewTextBoxColumn
            // 
            this.кодНПDataGridViewTextBoxColumn.DataPropertyName = "Код_НП";
            this.кодНПDataGridViewTextBoxColumn.HeaderText = "Код_НП";
            this.кодНПDataGridViewTextBoxColumn.Name = "кодНПDataGridViewTextBoxColumn";
            // 
            // назварайонуDataGridViewTextBoxColumn
            // 
            this.назварайонуDataGridViewTextBoxColumn.DataPropertyName = "Назва_району";
            this.назварайонуDataGridViewTextBoxColumn.HeaderText = "Назва_району";
            this.назварайонуDataGridViewTextBoxColumn.Name = "назварайонуDataGridViewTextBoxColumn";
            this.назварайонуDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // названиетипаНПDataGridViewTextBoxColumn
            // 
            this.названиетипаНПDataGridViewTextBoxColumn.DataPropertyName = "Название_типа_НП";
            this.названиетипаНПDataGridViewTextBoxColumn.FillWeight = 160F;
            this.названиетипаНПDataGridViewTextBoxColumn.HeaderText = "Название_типа_НП";
            this.названиетипаНПDataGridViewTextBoxColumn.Name = "названиетипаНПDataGridViewTextBoxColumn";
            this.названиетипаНПDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.названиетипаНПDataGridViewTextBoxColumn.Width = 160;
            // 
            // названиеDataGridViewTextBoxColumn
            // 
            this.названиеDataGridViewTextBoxColumn.DataPropertyName = "Название";
            this.названиеDataGridViewTextBoxColumn.HeaderText = "Название";
            this.названиеDataGridViewTextBoxColumn.Name = "названиеDataGridViewTextBoxColumn";
            // 
            // nPBindingSource
            // 
            this.nPBindingSource.DataMember = "NP";
            this.nPBindingSource.DataSource = this.carSellDataSet;
            // 
            // carSellDataSet
            // 
            this.carSellDataSet.DataSetName = "CarSellDataSet";
            this.carSellDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // районBindingSource
            // 
            this.районBindingSource.DataMember = "Район";
            this.районBindingSource.DataSource = this.carSellDataSet;
            // 
            // типНПBindingSource
            // 
            this.типНПBindingSource.DataMember = "Тип_НП";
            this.типНПBindingSource.DataSource = this.carSellDataSet;
            // 
            // nPTableAdapter
            // 
            this.nPTableAdapter.ClearBeforeFill = true;
            // 
            // районTableAdapter
            // 
            this.районTableAdapter.ClearBeforeFill = true;
            // 
            // тип_НПTableAdapter
            // 
            this.тип_НПTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.OrangeRed;
            this.button1.Location = new System.Drawing.Point(72, 523);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 29);
            this.button1.TabIndex = 4;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодНПDataGridViewTextBoxColumn1,
            this.кодтипаНПDataGridViewTextBoxColumn,
            this.кодрайонуDataGridViewTextBoxColumn,
            this.названиеDataGridViewTextBoxColumn1});
            this.dataGridView2.DataSource = this.населенныйпунктBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(0, 282);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(523, 235);
            this.dataGridView2.TabIndex = 6;
            // 
            // населенныйпунктBindingSource
            // 
            this.населенныйпунктBindingSource.DataMember = "Населенный_пункт";
            this.населенныйпунктBindingSource.DataSource = this.carSellDataSet;
            // 
            // населенный_пунктTableAdapter
            // 
            this.населенный_пунктTableAdapter.ClearBeforeFill = true;
            // 
            // кодНПDataGridViewTextBoxColumn1
            // 
            this.кодНПDataGridViewTextBoxColumn1.DataPropertyName = "Код_НП";
            this.кодНПDataGridViewTextBoxColumn1.HeaderText = "Код_НП";
            this.кодНПDataGridViewTextBoxColumn1.Name = "кодНПDataGridViewTextBoxColumn1";
            this.кодНПDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // кодтипаНПDataGridViewTextBoxColumn
            // 
            this.кодтипаНПDataGridViewTextBoxColumn.DataPropertyName = "Код_типа_НП";
            this.кодтипаНПDataGridViewTextBoxColumn.HeaderText = "Код_типа_НП";
            this.кодтипаНПDataGridViewTextBoxColumn.Name = "кодтипаНПDataGridViewTextBoxColumn";
            // 
            // кодрайонуDataGridViewTextBoxColumn
            // 
            this.кодрайонуDataGridViewTextBoxColumn.DataPropertyName = "Код_району";
            this.кодрайонуDataGridViewTextBoxColumn.HeaderText = "Код_району";
            this.кодрайонуDataGridViewTextBoxColumn.Name = "кодрайонуDataGridViewTextBoxColumn";
            // 
            // названиеDataGridViewTextBoxColumn1
            // 
            this.названиеDataGridViewTextBoxColumn1.DataPropertyName = "Название";
            this.названиеDataGridViewTextBoxColumn1.HeaderText = "Название";
            this.названиеDataGridViewTextBoxColumn1.Name = "названиеDataGridViewTextBoxColumn1";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.RoyalBlue;
            this.button2.Location = new System.Drawing.Point(310, 523);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(168, 29);
            this.button2.TabIndex = 7;
            this.button2.Text = "Сохранить редактированное";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(78, 243);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(355, 24);
            this.label1.TabIndex = 8;
            this.label1.Text = "Редактировать только в нижнем окне";
            // 
            // Form19
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(522, 564);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form19";
            this.Text = "Form19";
            this.Load += new System.EventHandler(this.Form19_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nPBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.районBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типНПBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.населенныйпунктBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CarSellDataSet carSellDataSet;
        private System.Windows.Forms.BindingSource nPBindingSource;
        private CarSellDataSetTableAdapters.NPTableAdapter nPTableAdapter;
        private System.Windows.Forms.BindingSource районBindingSource;
        private CarSellDataSetTableAdapters.РайонTableAdapter районTableAdapter;
        private System.Windows.Forms.BindingSource типНПBindingSource;
        private CarSellDataSetTableAdapters.Тип_НПTableAdapter тип_НПTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодНПDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn назварайонуDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиетипаНПDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.BindingSource населенныйпунктBindingSource;
        private CarSellDataSetTableAdapters.Населенный_пунктTableAdapter населенный_пунктTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодНПDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодтипаНПDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодрайонуDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеDataGridViewTextBoxColumn1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
    }
}