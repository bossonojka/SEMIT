﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSell
{
    public partial class Form17 : Form
    {
        public Form17()
        {
            InitializeComponent();
        }

        private void Form17_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Область' table. You can move, or remove it, as needed.
            this.областьTableAdapter.Fill(this.carSellDataSet.Область);
            // TODO: This line of code loads data into the 'carSellDataSet.Rayon' table. You can move, or remove it, as needed.
            this.rayonTableAdapter.Fill(this.carSellDataSet.Rayon);
            // TODO: This line of code loads data into the 'carSellDataSet.Район' table. You can move, or remove it, as needed.
            this.районTableAdapter.Fill(this.carSellDataSet.Район);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form41 form41 = new Form41();
            form41.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.районTableAdapter.Update(this.carSellDataSet.Район);
            //this.rayonTableAdapter.Fill(this.carSellDataSet.Rayon);
        }
    }
}
