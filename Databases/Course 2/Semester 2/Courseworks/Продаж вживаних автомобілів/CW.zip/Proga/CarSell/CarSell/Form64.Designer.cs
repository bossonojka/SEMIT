﻿namespace CarSell
{
    partial class Form64
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.коддоговораDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.коддилераDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.дилерDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодзаказаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодклиентапродавцаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.клиентПродавецDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодклиентапокупателяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.клиентПокупательDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодавтомобиляDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.маркаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.модельDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датазаключениядоговораDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценасделкиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.размеркомиссионныхDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.allContractsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carSellDataSet = new CarSell.CarSellDataSet();
            this.allContractsTableAdapter = new CarSell.CarSellDataSetTableAdapters.AllContractsTableAdapter();
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.договорBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.договорTableAdapter = new CarSell.CarSellDataSetTableAdapters.ДоговорTableAdapter();
            this.коддоговораDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.коддилераDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодзаказаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодклиентапродавцаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодклиентапокупателяDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодавтомобиляDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датазаключениядоговораDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценасделкиDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.размеркомиссионныхDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.allContractsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.договорBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.коддоговораDataGridViewTextBoxColumn,
            this.коддилераDataGridViewTextBoxColumn,
            this.дилерDataGridViewTextBoxColumn,
            this.кодзаказаDataGridViewTextBoxColumn,
            this.кодклиентапродавцаDataGridViewTextBoxColumn,
            this.клиентПродавецDataGridViewTextBoxColumn,
            this.кодклиентапокупателяDataGridViewTextBoxColumn,
            this.клиентПокупательDataGridViewTextBoxColumn,
            this.кодавтомобиляDataGridViewTextBoxColumn,
            this.маркаDataGridViewTextBoxColumn,
            this.модельDataGridViewTextBoxColumn,
            this.датазаключениядоговораDataGridViewTextBoxColumn,
            this.ценасделкиDataGridViewTextBoxColumn,
            this.размеркомиссионныхDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.allContractsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(1, 1);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1252, 324);
            this.dataGridView1.TabIndex = 0;
            // 
            // коддоговораDataGridViewTextBoxColumn
            // 
            this.коддоговораDataGridViewTextBoxColumn.DataPropertyName = "Код_договора";
            this.коддоговораDataGridViewTextBoxColumn.HeaderText = "Код_договора";
            this.коддоговораDataGridViewTextBoxColumn.Name = "коддоговораDataGridViewTextBoxColumn";
            // 
            // коддилераDataGridViewTextBoxColumn
            // 
            this.коддилераDataGridViewTextBoxColumn.DataPropertyName = "Код_дилера";
            this.коддилераDataGridViewTextBoxColumn.HeaderText = "Код_дилера";
            this.коддилераDataGridViewTextBoxColumn.Name = "коддилераDataGridViewTextBoxColumn";
            // 
            // дилерDataGridViewTextBoxColumn
            // 
            this.дилерDataGridViewTextBoxColumn.DataPropertyName = "Дилер";
            this.дилерDataGridViewTextBoxColumn.FillWeight = 150F;
            this.дилерDataGridViewTextBoxColumn.HeaderText = "Дилер";
            this.дилерDataGridViewTextBoxColumn.Name = "дилерDataGridViewTextBoxColumn";
            this.дилерDataGridViewTextBoxColumn.ReadOnly = true;
            this.дилерDataGridViewTextBoxColumn.Width = 150;
            // 
            // кодзаказаDataGridViewTextBoxColumn
            // 
            this.кодзаказаDataGridViewTextBoxColumn.DataPropertyName = "Код_заказа";
            this.кодзаказаDataGridViewTextBoxColumn.HeaderText = "Код_заказа";
            this.кодзаказаDataGridViewTextBoxColumn.Name = "кодзаказаDataGridViewTextBoxColumn";
            // 
            // кодклиентапродавцаDataGridViewTextBoxColumn
            // 
            this.кодклиентапродавцаDataGridViewTextBoxColumn.DataPropertyName = "Код_клиента_продавца";
            this.кодклиентапродавцаDataGridViewTextBoxColumn.FillWeight = 150F;
            this.кодклиентапродавцаDataGridViewTextBoxColumn.HeaderText = "Код_клиента_продавца";
            this.кодклиентапродавцаDataGridViewTextBoxColumn.Name = "кодклиентапродавцаDataGridViewTextBoxColumn";
            this.кодклиентапродавцаDataGridViewTextBoxColumn.Width = 150;
            // 
            // клиентПродавецDataGridViewTextBoxColumn
            // 
            this.клиентПродавецDataGridViewTextBoxColumn.DataPropertyName = "Клиент - продавец";
            this.клиентПродавецDataGridViewTextBoxColumn.FillWeight = 200F;
            this.клиентПродавецDataGridViewTextBoxColumn.HeaderText = "Клиент - продавец";
            this.клиентПродавецDataGridViewTextBoxColumn.Name = "клиентПродавецDataGridViewTextBoxColumn";
            this.клиентПродавецDataGridViewTextBoxColumn.ReadOnly = true;
            this.клиентПродавецDataGridViewTextBoxColumn.Width = 200;
            // 
            // кодклиентапокупателяDataGridViewTextBoxColumn
            // 
            this.кодклиентапокупателяDataGridViewTextBoxColumn.DataPropertyName = "Код_клиента_покупателя";
            this.кодклиентапокупателяDataGridViewTextBoxColumn.FillWeight = 150F;
            this.кодклиентапокупателяDataGridViewTextBoxColumn.HeaderText = "Код_клиента_покупателя";
            this.кодклиентапокупателяDataGridViewTextBoxColumn.Name = "кодклиентапокупателяDataGridViewTextBoxColumn";
            this.кодклиентапокупателяDataGridViewTextBoxColumn.Width = 150;
            // 
            // клиентПокупательDataGridViewTextBoxColumn
            // 
            this.клиентПокупательDataGridViewTextBoxColumn.DataPropertyName = "Клиент - покупатель";
            this.клиентПокупательDataGridViewTextBoxColumn.FillWeight = 200F;
            this.клиентПокупательDataGridViewTextBoxColumn.HeaderText = "Клиент - покупатель";
            this.клиентПокупательDataGridViewTextBoxColumn.Name = "клиентПокупательDataGridViewTextBoxColumn";
            this.клиентПокупательDataGridViewTextBoxColumn.ReadOnly = true;
            this.клиентПокупательDataGridViewTextBoxColumn.Width = 200;
            // 
            // кодавтомобиляDataGridViewTextBoxColumn
            // 
            this.кодавтомобиляDataGridViewTextBoxColumn.DataPropertyName = "Код_автомобиля";
            this.кодавтомобиляDataGridViewTextBoxColumn.HeaderText = "Код_автомобиля";
            this.кодавтомобиляDataGridViewTextBoxColumn.Name = "кодавтомобиляDataGridViewTextBoxColumn";
            // 
            // маркаDataGridViewTextBoxColumn
            // 
            this.маркаDataGridViewTextBoxColumn.DataPropertyName = "Марка";
            this.маркаDataGridViewTextBoxColumn.FillWeight = 150F;
            this.маркаDataGridViewTextBoxColumn.HeaderText = "Марка";
            this.маркаDataGridViewTextBoxColumn.Name = "маркаDataGridViewTextBoxColumn";
            this.маркаDataGridViewTextBoxColumn.Width = 150;
            // 
            // модельDataGridViewTextBoxColumn
            // 
            this.модельDataGridViewTextBoxColumn.DataPropertyName = "Модель";
            this.модельDataGridViewTextBoxColumn.HeaderText = "Модель";
            this.модельDataGridViewTextBoxColumn.Name = "модельDataGridViewTextBoxColumn";
            // 
            // датазаключениядоговораDataGridViewTextBoxColumn
            // 
            this.датазаключениядоговораDataGridViewTextBoxColumn.DataPropertyName = "Дата_заключения_договора";
            this.датазаключениядоговораDataGridViewTextBoxColumn.FillWeight = 200F;
            this.датазаключениядоговораDataGridViewTextBoxColumn.HeaderText = "Дата_заключения_договора";
            this.датазаключениядоговораDataGridViewTextBoxColumn.Name = "датазаключениядоговораDataGridViewTextBoxColumn";
            this.датазаключениядоговораDataGridViewTextBoxColumn.Width = 200;
            // 
            // ценасделкиDataGridViewTextBoxColumn
            // 
            this.ценасделкиDataGridViewTextBoxColumn.DataPropertyName = "Цена_сделки";
            this.ценасделкиDataGridViewTextBoxColumn.HeaderText = "Цена_сделки";
            this.ценасделкиDataGridViewTextBoxColumn.Name = "ценасделкиDataGridViewTextBoxColumn";
            // 
            // размеркомиссионныхDataGridViewTextBoxColumn
            // 
            this.размеркомиссионныхDataGridViewTextBoxColumn.DataPropertyName = "Размер_комиссионных";
            this.размеркомиссионныхDataGridViewTextBoxColumn.FillWeight = 150F;
            this.размеркомиссионныхDataGridViewTextBoxColumn.HeaderText = "Размер_комиссионных";
            this.размеркомиссионныхDataGridViewTextBoxColumn.Name = "размеркомиссионныхDataGridViewTextBoxColumn";
            this.размеркомиссионныхDataGridViewTextBoxColumn.Width = 150;
            // 
            // allContractsBindingSource
            // 
            this.allContractsBindingSource.DataMember = "AllContracts";
            this.allContractsBindingSource.DataSource = this.carSellDataSet;
            // 
            // carSellDataSet
            // 
            this.carSellDataSet.DataSetName = "CarSellDataSet";
            this.carSellDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // allContractsTableAdapter
            // 
            this.allContractsTableAdapter.ClearBeforeFill = true;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Tomato;
            this.button4.Location = new System.Drawing.Point(769, 667);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(106, 29);
            this.button4.TabIndex = 6;
            this.button4.Text = "Удалить";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.OrangeRed;
            this.button1.Location = new System.Drawing.Point(409, 667);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 29);
            this.button1.TabIndex = 4;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(431, 340);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(355, 24);
            this.label1.TabIndex = 10;
            this.label1.Text = "Редактировать только в нижнем окне";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.коддоговораDataGridViewTextBoxColumn1,
            this.коддилераDataGridViewTextBoxColumn1,
            this.кодзаказаDataGridViewTextBoxColumn1,
            this.кодклиентапродавцаDataGridViewTextBoxColumn1,
            this.кодклиентапокупателяDataGridViewTextBoxColumn1,
            this.кодавтомобиляDataGridViewTextBoxColumn1,
            this.датазаключениядоговораDataGridViewTextBoxColumn1,
            this.ценасделкиDataGridViewTextBoxColumn1,
            this.размеркомиссионныхDataGridViewTextBoxColumn1});
            this.dataGridView2.DataSource = this.договорBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(1, 367);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(1252, 283);
            this.dataGridView2.TabIndex = 9;
            // 
            // договорBindingSource
            // 
            this.договорBindingSource.DataMember = "Договор";
            this.договорBindingSource.DataSource = this.carSellDataSet;
            // 
            // договорTableAdapter
            // 
            this.договорTableAdapter.ClearBeforeFill = true;
            // 
            // коддоговораDataGridViewTextBoxColumn1
            // 
            this.коддоговораDataGridViewTextBoxColumn1.DataPropertyName = "Код_договора";
            this.коддоговораDataGridViewTextBoxColumn1.HeaderText = "Код_договора";
            this.коддоговораDataGridViewTextBoxColumn1.Name = "коддоговораDataGridViewTextBoxColumn1";
            this.коддоговораDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // коддилераDataGridViewTextBoxColumn1
            // 
            this.коддилераDataGridViewTextBoxColumn1.DataPropertyName = "Код_дилера";
            this.коддилераDataGridViewTextBoxColumn1.HeaderText = "Код_дилера";
            this.коддилераDataGridViewTextBoxColumn1.Name = "коддилераDataGridViewTextBoxColumn1";
            // 
            // кодзаказаDataGridViewTextBoxColumn1
            // 
            this.кодзаказаDataGridViewTextBoxColumn1.DataPropertyName = "Код_заказа";
            this.кодзаказаDataGridViewTextBoxColumn1.HeaderText = "Код_заказа";
            this.кодзаказаDataGridViewTextBoxColumn1.Name = "кодзаказаDataGridViewTextBoxColumn1";
            // 
            // кодклиентапродавцаDataGridViewTextBoxColumn1
            // 
            this.кодклиентапродавцаDataGridViewTextBoxColumn1.DataPropertyName = "Код_клиента_продавца";
            this.кодклиентапродавцаDataGridViewTextBoxColumn1.FillWeight = 200F;
            this.кодклиентапродавцаDataGridViewTextBoxColumn1.HeaderText = "Код_клиента_продавца";
            this.кодклиентапродавцаDataGridViewTextBoxColumn1.Name = "кодклиентапродавцаDataGridViewTextBoxColumn1";
            this.кодклиентапродавцаDataGridViewTextBoxColumn1.Width = 200;
            // 
            // кодклиентапокупателяDataGridViewTextBoxColumn1
            // 
            this.кодклиентапокупателяDataGridViewTextBoxColumn1.DataPropertyName = "Код_клиента_покупателя";
            this.кодклиентапокупателяDataGridViewTextBoxColumn1.FillWeight = 200F;
            this.кодклиентапокупателяDataGridViewTextBoxColumn1.HeaderText = "Код_клиента_покупателя";
            this.кодклиентапокупателяDataGridViewTextBoxColumn1.Name = "кодклиентапокупателяDataGridViewTextBoxColumn1";
            this.кодклиентапокупателяDataGridViewTextBoxColumn1.Width = 200;
            // 
            // кодавтомобиляDataGridViewTextBoxColumn1
            // 
            this.кодавтомобиляDataGridViewTextBoxColumn1.DataPropertyName = "Код_автомобиля";
            this.кодавтомобиляDataGridViewTextBoxColumn1.FillWeight = 150F;
            this.кодавтомобиляDataGridViewTextBoxColumn1.HeaderText = "Код_автомобиля";
            this.кодавтомобиляDataGridViewTextBoxColumn1.Name = "кодавтомобиляDataGridViewTextBoxColumn1";
            this.кодавтомобиляDataGridViewTextBoxColumn1.Width = 150;
            // 
            // датазаключениядоговораDataGridViewTextBoxColumn1
            // 
            this.датазаключениядоговораDataGridViewTextBoxColumn1.DataPropertyName = "Дата_заключения_договора";
            this.датазаключениядоговораDataGridViewTextBoxColumn1.FillWeight = 220F;
            this.датазаключениядоговораDataGridViewTextBoxColumn1.HeaderText = "Дата_заключения_договора";
            this.датазаключениядоговораDataGridViewTextBoxColumn1.Name = "датазаключениядоговораDataGridViewTextBoxColumn1";
            this.датазаключениядоговораDataGridViewTextBoxColumn1.Width = 220;
            // 
            // ценасделкиDataGridViewTextBoxColumn1
            // 
            this.ценасделкиDataGridViewTextBoxColumn1.DataPropertyName = "Цена_сделки";
            this.ценасделкиDataGridViewTextBoxColumn1.HeaderText = "Цена_сделки";
            this.ценасделкиDataGridViewTextBoxColumn1.Name = "ценасделкиDataGridViewTextBoxColumn1";
            // 
            // размеркомиссионныхDataGridViewTextBoxColumn1
            // 
            this.размеркомиссионныхDataGridViewTextBoxColumn1.DataPropertyName = "Размер_комиссионных";
            this.размеркомиссионныхDataGridViewTextBoxColumn1.FillWeight = 150F;
            this.размеркомиссионныхDataGridViewTextBoxColumn1.HeaderText = "Размер_комиссионных";
            this.размеркомиссионныхDataGridViewTextBoxColumn1.Name = "размеркомиссионныхDataGridViewTextBoxColumn1";
            this.размеркомиссионныхDataGridViewTextBoxColumn1.Width = 150;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.RoyalBlue;
            this.button2.Location = new System.Drawing.Point(567, 667);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(168, 29);
            this.button2.TabIndex = 11;
            this.button2.Text = "Сохранить редактированное";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form64
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1251, 708);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form64";
            this.Text = "Form64";
            this.Load += new System.EventHandler(this.Form64_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.allContractsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.договорBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CarSellDataSet carSellDataSet;
        private System.Windows.Forms.BindingSource allContractsBindingSource;
        private CarSellDataSetTableAdapters.AllContractsTableAdapter allContractsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn коддоговораDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn коддилераDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn дилерDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодзаказаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодклиентапродавцаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn клиентПродавецDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодклиентапокупателяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn клиентПокупательDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодавтомобиляDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn маркаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn модельDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датазаключениядоговораDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценасделкиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn размеркомиссионныхDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.BindingSource договорBindingSource;
        private CarSellDataSetTableAdapters.ДоговорTableAdapter договорTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn коддоговораDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn коддилераDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодзаказаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодклиентапродавцаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодклиентапокупателяDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодавтомобиляDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn датазаключениядоговораDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценасделкиDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn размеркомиссионныхDataGridViewTextBoxColumn1;
        private System.Windows.Forms.Button button2;
    }
}