﻿namespace CarSell
{
    partial class Form63
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button2 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox20 = new System.Windows.Forms.ComboBox();
            this.диапазонценыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carSellDataSet = new CarSell.CarSellDataSet();
            this.comboBox19 = new System.Windows.Forms.ComboBox();
            this.цветBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label28 = new System.Windows.Forms.Label();
            this.comboBox18 = new System.Windows.Forms.ComboBox();
            this.пробегBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboBox17 = new System.Windows.Forms.ComboBox();
            this.мощностьBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboBox16 = new System.Windows.Forms.ComboBox();
            this.объемдвигателяBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboBox15 = new System.Windows.Forms.ComboBox();
            this.годвыпускадоBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label24 = new System.Windows.Forms.Label();
            this.comboBox14 = new System.Windows.Forms.ComboBox();
            this.годвыпускаотBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label23 = new System.Windows.Forms.Label();
            this.comboBox13 = new System.Windows.Forms.ComboBox();
            this.типкузоваBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label22 = new System.Windows.Forms.Label();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.модельавтоBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label21 = new System.Windows.Forms.Label();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.маркаавтоBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label20 = new System.Windows.Forms.Label();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.buyKlientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label19 = new System.Windows.Forms.Label();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.типТСBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label17 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.buyKlientTableAdapter = new CarSell.CarSellDataSetTableAdapters.BuyKlientTableAdapter();
            this.тип_ТСTableAdapter = new CarSell.CarSellDataSetTableAdapters.Тип_ТСTableAdapter();
            this.марка_автоTableAdapter = new CarSell.CarSellDataSetTableAdapters.Марка_автоTableAdapter();
            this.модель_автоTableAdapter = new CarSell.CarSellDataSetTableAdapters.Модель_автоTableAdapter();
            this.тип_кузоваTableAdapter = new CarSell.CarSellDataSetTableAdapters.Тип_кузоваTableAdapter();
            this.год_выпуска_отTableAdapter = new CarSell.CarSellDataSetTableAdapters.Год_выпуска_отTableAdapter();
            this.год_выпуска_доTableAdapter = new CarSell.CarSellDataSetTableAdapters.Год_выпуска_доTableAdapter();
            this.объем_двигателяTableAdapter = new CarSell.CarSellDataSetTableAdapters.Объем_двигателяTableAdapter();
            this.мощностьTableAdapter = new CarSell.CarSellDataSetTableAdapters.МощностьTableAdapter();
            this.пробегTableAdapter = new CarSell.CarSellDataSetTableAdapters.ПробегTableAdapter();
            this.цветTableAdapter = new CarSell.CarSellDataSetTableAdapters.ЦветTableAdapter();
            this.диапазон_ценыTableAdapter = new CarSell.CarSellDataSetTableAdapters.Диапазон_ценыTableAdapter();
            this.марка_автоTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Марка_автоTableAdapter();
            this.марка_модельTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Марка_модельTableAdapter();
            this.модель_автоTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Модель_автоTableAdapter();
            this.lastBrandTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.LastBrandTableAdapter();
            this.lastModelTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.LastModelTableAdapter();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.диапазонценыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.цветBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.пробегBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.мощностьBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.объемдвигателяBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.годвыпускадоBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.годвыпускаотBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типкузоваBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.модельавтоBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.маркаавтоBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.buyKlientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типТСBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Location = new System.Drawing.Point(265, 335);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(123, 35);
            this.button2.TabIndex = 147;
            this.button2.Text = "Добавить год выпуска";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button13.Location = new System.Drawing.Point(247, 166);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(128, 46);
            this.button13.TabIndex = 146;
            this.button13.Text = "Добавить марку и модель авто";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button11.Location = new System.Drawing.Point(948, 346);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(110, 25);
            this.button11.TabIndex = 144;
            this.button11.Text = "Добавить цену";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button10.Location = new System.Drawing.Point(948, 265);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(110, 27);
            this.button10.TabIndex = 143;
            this.button10.Text = "Добавить цвет";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button8.Location = new System.Drawing.Point(948, 146);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(124, 26);
            this.button8.TabIndex = 142;
            this.button8.Text = "Добавить мощность";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button9.Location = new System.Drawing.Point(948, 58);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(147, 44);
            this.button9.TabIndex = 141;
            this.button9.Text = "Добавить объем двигателя";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button4.Location = new System.Drawing.Point(365, 404);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(123, 39);
            this.button4.TabIndex = 140;
            this.button4.Text = "Добавить год снятия с производства";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button6.Location = new System.Drawing.Point(247, 271);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(128, 28);
            this.button6.TabIndex = 139;
            this.button6.Text = "Добавить тип кузова";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Location = new System.Drawing.Point(247, 73);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(128, 28);
            this.button1.TabIndex = 138;
            this.button1.Text = "Добавить тип ТС";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox20
            // 
            this.comboBox20.DataSource = this.диапазонценыBindingSource;
            this.comboBox20.DisplayMember = "Диапазон_цены";
            this.comboBox20.FormattingEnabled = true;
            this.comboBox20.ItemHeight = 13;
            this.comboBox20.Location = new System.Drawing.Point(665, 349);
            this.comboBox20.Name = "comboBox20";
            this.comboBox20.Size = new System.Drawing.Size(261, 21);
            this.comboBox20.TabIndex = 137;
            this.comboBox20.ValueMember = "Код_диапазона_цены";
            // 
            // диапазонценыBindingSource
            // 
            this.диапазонценыBindingSource.DataMember = "Диапазон_цены";
            this.диапазонценыBindingSource.DataSource = this.carSellDataSet;
            // 
            // carSellDataSet
            // 
            this.carSellDataSet.DataSetName = "CarSellDataSet";
            this.carSellDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboBox19
            // 
            this.comboBox19.DataSource = this.цветBindingSource;
            this.comboBox19.DisplayMember = "Цвет";
            this.comboBox19.FormattingEnabled = true;
            this.comboBox19.ItemHeight = 13;
            this.comboBox19.Location = new System.Drawing.Point(684, 271);
            this.comboBox19.Name = "comboBox19";
            this.comboBox19.Size = new System.Drawing.Size(242, 21);
            this.comboBox19.TabIndex = 135;
            this.comboBox19.ValueMember = "Код_цвета";
            // 
            // цветBindingSource
            // 
            this.цветBindingSource.DataMember = "Цвет";
            this.цветBindingSource.DataSource = this.carSellDataSet;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label28.Location = new System.Drawing.Point(612, 276);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(48, 20);
            this.label28.TabIndex = 134;
            this.label28.Text = "Цвет";
            // 
            // comboBox18
            // 
            this.comboBox18.DataSource = this.пробегBindingSource;
            this.comboBox18.DisplayMember = "Диапазон_пробега";
            this.comboBox18.FormattingEnabled = true;
            this.comboBox18.ItemHeight = 13;
            this.comboBox18.Location = new System.Drawing.Point(684, 215);
            this.comboBox18.Name = "comboBox18";
            this.comboBox18.Size = new System.Drawing.Size(242, 21);
            this.comboBox18.TabIndex = 133;
            this.comboBox18.ValueMember = "Код_диапазона_пробега";
            // 
            // пробегBindingSource
            // 
            this.пробегBindingSource.DataMember = "Пробег";
            this.пробегBindingSource.DataSource = this.carSellDataSet;
            // 
            // comboBox17
            // 
            this.comboBox17.DataSource = this.мощностьBindingSource;
            this.comboBox17.DisplayMember = "Диапазон_мощности";
            this.comboBox17.FormattingEnabled = true;
            this.comboBox17.ItemHeight = 13;
            this.comboBox17.Location = new System.Drawing.Point(706, 147);
            this.comboBox17.Name = "comboBox17";
            this.comboBox17.Size = new System.Drawing.Size(220, 21);
            this.comboBox17.TabIndex = 131;
            this.comboBox17.ValueMember = "Код_диапазона_мощности";
            // 
            // мощностьBindingSource
            // 
            this.мощностьBindingSource.DataMember = "Мощность";
            this.мощностьBindingSource.DataSource = this.carSellDataSet;
            // 
            // comboBox16
            // 
            this.comboBox16.DataSource = this.объемдвигателяBindingSource;
            this.comboBox16.DisplayMember = "Диапазон_объема_двигателя";
            this.comboBox16.FormattingEnabled = true;
            this.comboBox16.ItemHeight = 13;
            this.comboBox16.Location = new System.Drawing.Point(765, 81);
            this.comboBox16.Name = "comboBox16";
            this.comboBox16.Size = new System.Drawing.Size(161, 21);
            this.comboBox16.TabIndex = 129;
            this.comboBox16.ValueMember = "Код_диапазона_объема_двигателя";
            // 
            // объемдвигателяBindingSource
            // 
            this.объемдвигателяBindingSource.DataMember = "Объем_двигателя";
            this.объемдвигателяBindingSource.DataSource = this.carSellDataSet;
            // 
            // comboBox15
            // 
            this.comboBox15.DataSource = this.годвыпускадоBindingSource;
            this.comboBox15.DisplayMember = "Год_выпуска_до";
            this.comboBox15.FormattingEnabled = true;
            this.comboBox15.ItemHeight = 13;
            this.comboBox15.Location = new System.Drawing.Point(241, 422);
            this.comboBox15.Name = "comboBox15";
            this.comboBox15.Size = new System.Drawing.Size(118, 21);
            this.comboBox15.TabIndex = 127;
            this.comboBox15.ValueMember = "Код_года_выпуска_до";
            // 
            // годвыпускадоBindingSource
            // 
            this.годвыпускадоBindingSource.DataMember = "Год_выпуска_до";
            this.годвыпускадоBindingSource.DataSource = this.carSellDataSet;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label24.Location = new System.Drawing.Point(16, 423);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(219, 20);
            this.label24.TabIndex = 126;
            this.label24.Text = "Год снятия с производства";
            // 
            // comboBox14
            // 
            this.comboBox14.DataSource = this.годвыпускаотBindingSource;
            this.comboBox14.DisplayMember = "Год_выпуска_от";
            this.comboBox14.FormattingEnabled = true;
            this.comboBox14.ItemHeight = 13;
            this.comboBox14.Location = new System.Drawing.Point(132, 349);
            this.comboBox14.Name = "comboBox14";
            this.comboBox14.Size = new System.Drawing.Size(127, 21);
            this.comboBox14.TabIndex = 125;
            this.comboBox14.ValueMember = "Код_года_выпуска_от";
            // 
            // годвыпускаотBindingSource
            // 
            this.годвыпускаотBindingSource.DataMember = "Год_выпуска_от";
            this.годвыпускаотBindingSource.DataSource = this.carSellDataSet;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label23.Location = new System.Drawing.Point(23, 350);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(103, 20);
            this.label23.TabIndex = 124;
            this.label23.Text = "Год выпуска";
            // 
            // comboBox13
            // 
            this.comboBox13.DataSource = this.типкузоваBindingSource;
            this.comboBox13.DisplayMember = "Тип_кузова";
            this.comboBox13.FormattingEnabled = true;
            this.comboBox13.ItemHeight = 13;
            this.comboBox13.Location = new System.Drawing.Point(115, 278);
            this.comboBox13.Name = "comboBox13";
            this.comboBox13.Size = new System.Drawing.Size(121, 21);
            this.comboBox13.TabIndex = 123;
            this.comboBox13.ValueMember = "Код_типа_кузова";
            // 
            // типкузоваBindingSource
            // 
            this.типкузоваBindingSource.DataMember = "Тип_кузова";
            this.типкузоваBindingSource.DataSource = this.carSellDataSet;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.Location = new System.Drawing.Point(19, 279);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(90, 20);
            this.label22.TabIndex = 122;
            this.label22.Text = "Тип кузова";
            // 
            // comboBox12
            // 
            this.comboBox12.DataSource = this.модельавтоBindingSource;
            this.comboBox12.DisplayMember = "Модель";
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.ItemHeight = 13;
            this.comboBox12.Location = new System.Drawing.Point(91, 212);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(145, 21);
            this.comboBox12.TabIndex = 121;
            this.comboBox12.ValueMember = "Код_модели";
            // 
            // модельавтоBindingSource
            // 
            this.модельавтоBindingSource.DataMember = "Модель_авто";
            this.модельавтоBindingSource.DataSource = this.carSellDataSet;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.Location = new System.Drawing.Point(16, 213);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(70, 20);
            this.label21.TabIndex = 120;
            this.label21.Text = "Модель";
            // 
            // comboBox11
            // 
            this.comboBox11.DataSource = this.маркаавтоBindingSource;
            this.comboBox11.DisplayMember = "Марка";
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.ItemHeight = 13;
            this.comboBox11.Location = new System.Drawing.Point(79, 144);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(157, 21);
            this.comboBox11.TabIndex = 119;
            this.comboBox11.ValueMember = "Код_марки";
            // 
            // маркаавтоBindingSource
            // 
            this.маркаавтоBindingSource.DataMember = "Марка_авто";
            this.маркаавтоBindingSource.DataSource = this.carSellDataSet;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.Location = new System.Drawing.Point(16, 145);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(57, 20);
            this.label20.TabIndex = 118;
            this.label20.Text = "Марка";
            // 
            // comboBox10
            // 
            this.comboBox10.DataSource = this.buyKlientBindingSource;
            this.comboBox10.DisplayMember = "Клиент - покупатель";
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.ItemHeight = 13;
            this.comboBox10.Location = new System.Drawing.Point(640, 8);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(174, 21);
            this.comboBox10.TabIndex = 117;
            this.comboBox10.ValueMember = "Код_клиента_покупателя";
            // 
            // buyKlientBindingSource
            // 
            this.buyKlientBindingSource.DataMember = "BuyKlient";
            this.buyKlientBindingSource.DataSource = this.carSellDataSet;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.Location = new System.Drawing.Point(441, 9);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(166, 20);
            this.label19.TabIndex = 116;
            this.label19.Text = "Клиент - покупатель";
            // 
            // comboBox9
            // 
            this.comboBox9.DataSource = this.типТСBindingSource;
            this.comboBox9.DisplayMember = "Тип_ТС";
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.ItemHeight = 13;
            this.comboBox9.Location = new System.Drawing.Point(79, 78);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(157, 21);
            this.comboBox9.TabIndex = 115;
            this.comboBox9.ValueMember = "Код_типа_ТС";
            // 
            // типТСBindingSource
            // 
            this.типТСBindingSource.DataMember = "Тип_ТС";
            this.типТСBindingSource.DataSource = this.carSellDataSet;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(13, 79);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(60, 20);
            this.label17.TabIndex = 114;
            this.label17.Text = "Тип ТС";
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button12.Location = new System.Drawing.Point(477, 503);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(223, 28);
            this.button12.TabIndex = 149;
            this.button12.Text = "Сохранить";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // buyKlientTableAdapter
            // 
            this.buyKlientTableAdapter.ClearBeforeFill = true;
            // 
            // тип_ТСTableAdapter
            // 
            this.тип_ТСTableAdapter.ClearBeforeFill = true;
            // 
            // марка_автоTableAdapter
            // 
            this.марка_автоTableAdapter.ClearBeforeFill = true;
            // 
            // модель_автоTableAdapter
            // 
            this.модель_автоTableAdapter.ClearBeforeFill = true;
            // 
            // тип_кузоваTableAdapter
            // 
            this.тип_кузоваTableAdapter.ClearBeforeFill = true;
            // 
            // год_выпуска_отTableAdapter
            // 
            this.год_выпуска_отTableAdapter.ClearBeforeFill = true;
            // 
            // год_выпуска_доTableAdapter
            // 
            this.год_выпуска_доTableAdapter.ClearBeforeFill = true;
            // 
            // объем_двигателяTableAdapter
            // 
            this.объем_двигателяTableAdapter.ClearBeforeFill = true;
            // 
            // мощностьTableAdapter
            // 
            this.мощностьTableAdapter.ClearBeforeFill = true;
            // 
            // пробегTableAdapter
            // 
            this.пробегTableAdapter.ClearBeforeFill = true;
            // 
            // цветTableAdapter
            // 
            this.цветTableAdapter.ClearBeforeFill = true;
            // 
            // диапазон_ценыTableAdapter
            // 
            this.диапазон_ценыTableAdapter.ClearBeforeFill = true;
            // 
            // марка_автоTableAdapter1
            // 
            this.марка_автоTableAdapter1.ClearBeforeFill = true;
            // 
            // марка_модельTableAdapter1
            // 
            this.марка_модельTableAdapter1.ClearBeforeFill = true;
            // 
            // модель_автоTableAdapter1
            // 
            this.модель_автоTableAdapter1.ClearBeforeFill = true;
            // 
            // lastBrandTableAdapter1
            // 
            this.lastBrandTableAdapter1.ClearBeforeFill = true;
            // 
            // lastModelTableAdapter1
            // 
            this.lastModelTableAdapter1.ClearBeforeFill = true;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label25.Location = new System.Drawing.Point(565, 82);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(181, 20);
            this.label25.TabIndex = 150;
            this.label25.Text = "Объем двигателя, л^3";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label26.Location = new System.Drawing.Point(565, 148);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(114, 20);
            this.label26.TabIndex = 151;
            this.label26.Text = "Мощность, лс";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label27.Location = new System.Drawing.Point(569, 216);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(91, 20);
            this.label27.TabIndex = 152;
            this.label27.Text = "Пробег, км";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label29.Location = new System.Drawing.Point(565, 351);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(81, 20);
            this.label29.TabIndex = 153;
            this.label29.Text = "Цена, грн";
            // 
            // Form63
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1159, 560);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboBox20);
            this.Controls.Add(this.comboBox19);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.comboBox18);
            this.Controls.Add(this.comboBox17);
            this.Controls.Add(this.comboBox16);
            this.Controls.Add(this.comboBox15);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.comboBox14);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.comboBox13);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.comboBox12);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.comboBox11);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.comboBox10);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.comboBox9);
            this.Controls.Add(this.label17);
            this.Name = "Form63";
            this.Text = "Form63";
            this.Load += new System.EventHandler(this.Form63_Load);
            ((System.ComponentModel.ISupportInitialize)(this.диапазонценыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.цветBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.пробегBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.мощностьBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.объемдвигателяBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.годвыпускадоBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.годвыпускаотBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типкузоваBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.модельавтоBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.маркаавтоBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.buyKlientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типТСBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox20;
        private System.Windows.Forms.ComboBox comboBox19;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox comboBox18;
        private System.Windows.Forms.ComboBox comboBox17;
        private System.Windows.Forms.ComboBox comboBox16;
        private System.Windows.Forms.ComboBox comboBox15;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox comboBox14;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox comboBox13;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button12;
        private CarSellDataSet carSellDataSet;
        private System.Windows.Forms.BindingSource buyKlientBindingSource;
        private CarSellDataSetTableAdapters.BuyKlientTableAdapter buyKlientTableAdapter;
        private System.Windows.Forms.BindingSource типТСBindingSource;
        private CarSellDataSetTableAdapters.Тип_ТСTableAdapter тип_ТСTableAdapter;
        private System.Windows.Forms.BindingSource маркаавтоBindingSource;
        private CarSellDataSetTableAdapters.Марка_автоTableAdapter марка_автоTableAdapter;
        private System.Windows.Forms.BindingSource модельавтоBindingSource;
        private CarSellDataSetTableAdapters.Модель_автоTableAdapter модель_автоTableAdapter;
        private System.Windows.Forms.BindingSource типкузоваBindingSource;
        private CarSellDataSetTableAdapters.Тип_кузоваTableAdapter тип_кузоваTableAdapter;
        private System.Windows.Forms.BindingSource годвыпускаотBindingSource;
        private CarSellDataSetTableAdapters.Год_выпуска_отTableAdapter год_выпуска_отTableAdapter;
        private System.Windows.Forms.BindingSource годвыпускадоBindingSource;
        private CarSellDataSetTableAdapters.Год_выпуска_доTableAdapter год_выпуска_доTableAdapter;
        private System.Windows.Forms.BindingSource объемдвигателяBindingSource;
        private CarSellDataSetTableAdapters.Объем_двигателяTableAdapter объем_двигателяTableAdapter;
        private System.Windows.Forms.BindingSource мощностьBindingSource;
        private CarSellDataSetTableAdapters.МощностьTableAdapter мощностьTableAdapter;
        private System.Windows.Forms.BindingSource пробегBindingSource;
        private CarSellDataSetTableAdapters.ПробегTableAdapter пробегTableAdapter;
        private System.Windows.Forms.BindingSource цветBindingSource;
        private CarSellDataSetTableAdapters.ЦветTableAdapter цветTableAdapter;
        private System.Windows.Forms.BindingSource диапазонценыBindingSource;
        private CarSellDataSetTableAdapters.Диапазон_ценыTableAdapter диапазон_ценыTableAdapter;
        private CarSellDataSetTableAdapters.Марка_автоTableAdapter марка_автоTableAdapter1;
        private CarSellDataSetTableAdapters.Марка_модельTableAdapter марка_модельTableAdapter1;
        private CarSellDataSetTableAdapters.Модель_автоTableAdapter модель_автоTableAdapter1;
        private CarSellDataSetTableAdapters.LastBrandTableAdapter lastBrandTableAdapter1;
        private CarSellDataSetTableAdapters.LastModelTableAdapter lastModelTableAdapter1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label29;
    }
}