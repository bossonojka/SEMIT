﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSell
{
    public partial class Form34 : Form
    {
        public Form34()
        {
            InitializeComponent();
        }

        private void Form34_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.FullKlName' table. You can move, or remove it, as needed.
            this.fullKlNameTableAdapter.Fill(this.carSellDataSet.FullKlName);
            // TODO: This line of code loads data into the 'carSellDataSet.Диапазон_цены' table. You can move, or remove it, as needed.
            this.диапазон_ценыTableAdapter.Fill(this.carSellDataSet.Диапазон_цены);
            // TODO: This line of code loads data into the 'carSellDataSet.Модель_авто' table. You can move, or remove it, as needed.
            this.модель_автоTableAdapter.Fill(this.carSellDataSet.Модель_авто);
            // TODO: This line of code loads data into the 'carSellDataSet.Марка_авто' table. You can move, or remove it, as needed.
            this.марка_автоTableAdapter.Fill(this.carSellDataSet.Марка_авто);
            // TODO: This line of code loads data into the 'carSellDataSet.Автомобиль' table. You can move, or remove it, as needed.
            this.автомобильTableAdapter.Fill(this.carSellDataSet.Автомобиль);
            // TODO: This line of code loads data into the 'carSellDataSet.KlientPhone' table. You can move, or remove it, as needed.
            this.klientPhoneTableAdapter.Fill(this.carSellDataSet.KlientPhone);
            // TODO: This line of code loads data into the 'carSellDataSet.KlientAdress' table. You can move, or remove it, as needed.
            this.klientAdressTableAdapter.Fill(this.carSellDataSet.KlientAdress);
            // TODO: This line of code loads data into the 'carSellDataSet.Клиент' table. You can move, or remove it, as needed.
            this.клиентTableAdapter.Fill(this.carSellDataSet.Клиент);
            // TODO: This line of code loads data into the 'carSellDataSet.SellKlCars' table. You can move, or remove it, as needed.
            this.sellKlCarsTableAdapter.Fill(this.carSellDataSet.SellKlCars);

        }
    }
}
