﻿namespace CarSell
{
    partial class Form60
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.carSellDataSet1 = new CarSell.CarSellDataSet();
            this.мощностьTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.МощностьTableAdapter();
            this.label1 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.мощностьBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.коддиапазонамощностиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.диапазонмощностиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.мощностьBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // carSellDataSet1
            // 
            this.carSellDataSet1.DataSetName = "CarSellDataSet";
            this.carSellDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // мощностьTableAdapter1
            // 
            this.мощностьTableAdapter1.ClearBeforeFill = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(165, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(287, 20);
            this.label1.TabIndex = 43;
            this.label1.Text = "Формат: от - до, с диапазоном 75 лс";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.Location = new System.Drawing.Point(121, 71);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(88, 20);
            this.label19.TabIndex = 40;
            this.label19.Text = "Мощность";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button1.Location = new System.Drawing.Point(218, 144);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 30);
            this.button1.TabIndex = 42;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(277, 73);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(220, 20);
            this.textBox1.TabIndex = 41;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.коддиапазонамощностиDataGridViewTextBoxColumn,
            this.диапазонмощностиDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.мощностьBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(2, 180);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(584, 270);
            this.dataGridView1.TabIndex = 93;
            // 
            // мощностьBindingSource
            // 
            this.мощностьBindingSource.DataMember = "Мощность";
            this.мощностьBindingSource.DataSource = this.carSellDataSet1;
            // 
            // коддиапазонамощностиDataGridViewTextBoxColumn
            // 
            this.коддиапазонамощностиDataGridViewTextBoxColumn.DataPropertyName = "Код_диапазона_мощности";
            this.коддиапазонамощностиDataGridViewTextBoxColumn.FillWeight = 200F;
            this.коддиапазонамощностиDataGridViewTextBoxColumn.HeaderText = "Код_диапазона_мощности";
            this.коддиапазонамощностиDataGridViewTextBoxColumn.Name = "коддиапазонамощностиDataGridViewTextBoxColumn";
            this.коддиапазонамощностиDataGridViewTextBoxColumn.ReadOnly = true;
            this.коддиапазонамощностиDataGridViewTextBoxColumn.Width = 200;
            // 
            // диапазонмощностиDataGridViewTextBoxColumn
            // 
            this.диапазонмощностиDataGridViewTextBoxColumn.DataPropertyName = "Диапазон_мощности";
            this.диапазонмощностиDataGridViewTextBoxColumn.FillWeight = 200F;
            this.диапазонмощностиDataGridViewTextBoxColumn.HeaderText = "Диапазон_мощности";
            this.диапазонмощностиDataGridViewTextBoxColumn.Name = "диапазонмощностиDataGridViewTextBoxColumn";
            this.диапазонмощностиDataGridViewTextBoxColumn.Width = 200;
            // 
            // Form60
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(586, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Name = "Form60";
            this.Text = "Form60";
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.мощностьBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CarSellDataSet carSellDataSet1;
        private CarSellDataSetTableAdapters.МощностьTableAdapter мощностьTableAdapter1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn коддиапазонамощностиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn диапазонмощностиDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource мощностьBindingSource;
    }
}