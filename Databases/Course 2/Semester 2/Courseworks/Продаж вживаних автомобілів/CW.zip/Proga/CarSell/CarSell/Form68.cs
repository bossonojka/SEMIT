﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;

namespace CarSell
{
    public partial class Form68 : Form
    {
        SqlConnection conn = null;
        public Form68()
        {
            InitializeComponent();
        }

        private void Form68_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Оператор' table. You can move, or remove it, as needed.
            this.операторTableAdapter.Fill(this.carSellDataSet.Оператор);

        }

        private void button11_Click(object sender, EventArgs e)
        {
            try
            {
                string numbOper = Convert.ToString(this.textBox5.Text);
                int codeOper = int.Parse(this.comboBox1.SelectedValue.ToString());
                


                conn = new SqlConnection();
                conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                conn.Open();
                SqlCommand myComand = conn.CreateCommand();
                myComand.CommandText = "INSERT into Номер_оператора (Номер_оператора, Код_оператора) VALUES (@numbOper, @codeOper)";
                myComand.Parameters.Add("@numbOper", SqlDbType.NVarChar, 10);
                myComand.Parameters["@numbOper"].Value = numbOper;
                myComand.Parameters.Add("@codeOper", SqlDbType.Int, 4);
                myComand.Parameters["@codeOper"].Value = codeOper;
                

                int UspeshnoeIzmenenie = myComand.ExecuteNonQuery();
                if (UspeshnoeIzmenenie != 0)
                {
                    MessageBox.Show("Изменения внесены", "Изменение записи");
                }
                else
                {
                    MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            this.номер_оператораTableAdapter1.Fill(this.carSellDataSet.Номер_оператора);
        }
    }
}
