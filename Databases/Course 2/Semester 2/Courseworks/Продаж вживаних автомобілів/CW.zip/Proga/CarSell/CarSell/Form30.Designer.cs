﻿namespace CarSell
{
    partial class Form30
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.коддилераDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.дилерDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодадрисаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеобластиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.назварайонуDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеулицыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерстроенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерпомещенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.индексDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dilersAdressBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carSellDataSet = new CarSell.CarSellDataSet();
            this.дилерBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fullDlNameBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.адресBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.областьBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.районBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.населенныйпунктBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.улицаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dilersAdressTableAdapter = new CarSell.CarSellDataSetTableAdapters.DilersAdressTableAdapter();
            this.дилерTableAdapter = new CarSell.CarSellDataSetTableAdapters.ДилерTableAdapter();
            this.адресTableAdapter = new CarSell.CarSellDataSetTableAdapters.АдресTableAdapter();
            this.областьTableAdapter = new CarSell.CarSellDataSetTableAdapters.ОбластьTableAdapter();
            this.районTableAdapter = new CarSell.CarSellDataSetTableAdapters.РайонTableAdapter();
            this.населенный_пунктTableAdapter = new CarSell.CarSellDataSetTableAdapters.Населенный_пунктTableAdapter();
            this.улицаTableAdapter = new CarSell.CarSellDataSetTableAdapters.УлицаTableAdapter();
            this.fullDlNameTableAdapter = new CarSell.CarSellDataSetTableAdapters.FullDlNameTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.кодадрисаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодулицыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодтипастроенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодтипапомещенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерстроенияDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерпомещенияDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.индексDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.кодулицыDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодтипаулицыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодНПDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеулицыDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.кодНПDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодтипаНПDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодрайонуDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dilersAdressBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.дилерBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fullDlNameBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.адресBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.областьBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.районBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.населенныйпунктBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.улицаBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.коддилераDataGridViewTextBoxColumn,
            this.дилерDataGridViewTextBoxColumn,
            this.кодадрисаDataGridViewTextBoxColumn,
            this.названиеобластиDataGridViewTextBoxColumn,
            this.назварайонуDataGridViewTextBoxColumn,
            this.названиеDataGridViewTextBoxColumn,
            this.названиеулицыDataGridViewTextBoxColumn,
            this.номерстроенияDataGridViewTextBoxColumn,
            this.номерпомещенияDataGridViewTextBoxColumn,
            this.индексDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.dilersAdressBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1224, 241);
            this.dataGridView1.TabIndex = 0;
            // 
            // коддилераDataGridViewTextBoxColumn
            // 
            this.коддилераDataGridViewTextBoxColumn.DataPropertyName = "Код_дилера";
            this.коддилераDataGridViewTextBoxColumn.HeaderText = "Код_дилера";
            this.коддилераDataGridViewTextBoxColumn.Name = "коддилераDataGridViewTextBoxColumn";
            this.коддилераDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // дилерDataGridViewTextBoxColumn
            // 
            this.дилерDataGridViewTextBoxColumn.DataPropertyName = "Дилер";
            this.дилерDataGridViewTextBoxColumn.FillWeight = 200F;
            this.дилерDataGridViewTextBoxColumn.HeaderText = "Дилер";
            this.дилерDataGridViewTextBoxColumn.Name = "дилерDataGridViewTextBoxColumn";
            this.дилерDataGridViewTextBoxColumn.ReadOnly = true;
            this.дилерDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.дилерDataGridViewTextBoxColumn.Width = 200;
            // 
            // кодадрисаDataGridViewTextBoxColumn
            // 
            this.кодадрисаDataGridViewTextBoxColumn.DataPropertyName = "Код_адриса";
            this.кодадрисаDataGridViewTextBoxColumn.HeaderText = "Код_адриса";
            this.кодадрисаDataGridViewTextBoxColumn.Name = "кодадрисаDataGridViewTextBoxColumn";
            this.кодадрисаDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // названиеобластиDataGridViewTextBoxColumn
            // 
            this.названиеобластиDataGridViewTextBoxColumn.DataPropertyName = "Название_области";
            this.названиеобластиDataGridViewTextBoxColumn.FillWeight = 120F;
            this.названиеобластиDataGridViewTextBoxColumn.HeaderText = "Название_области";
            this.названиеобластиDataGridViewTextBoxColumn.Name = "названиеобластиDataGridViewTextBoxColumn";
            this.названиеобластиDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.названиеобластиDataGridViewTextBoxColumn.Width = 120;
            // 
            // назварайонуDataGridViewTextBoxColumn
            // 
            this.назварайонуDataGridViewTextBoxColumn.DataPropertyName = "Назва_району";
            this.назварайонуDataGridViewTextBoxColumn.HeaderText = "Назва_району";
            this.назварайонуDataGridViewTextBoxColumn.Name = "назварайонуDataGridViewTextBoxColumn";
            this.назварайонуDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // названиеDataGridViewTextBoxColumn
            // 
            this.названиеDataGridViewTextBoxColumn.DataPropertyName = "Название";
            this.названиеDataGridViewTextBoxColumn.FillWeight = 120F;
            this.названиеDataGridViewTextBoxColumn.HeaderText = "Название НП";
            this.названиеDataGridViewTextBoxColumn.Name = "названиеDataGridViewTextBoxColumn";
            this.названиеDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.названиеDataGridViewTextBoxColumn.Width = 120;
            // 
            // названиеулицыDataGridViewTextBoxColumn
            // 
            this.названиеулицыDataGridViewTextBoxColumn.DataPropertyName = "Название_улицы";
            this.названиеулицыDataGridViewTextBoxColumn.HeaderText = "Название_улицы";
            this.названиеулицыDataGridViewTextBoxColumn.Name = "названиеулицыDataGridViewTextBoxColumn";
            this.названиеулицыDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // номерстроенияDataGridViewTextBoxColumn
            // 
            this.номерстроенияDataGridViewTextBoxColumn.DataPropertyName = "Номер_строения";
            this.номерстроенияDataGridViewTextBoxColumn.HeaderText = "Номер_строения";
            this.номерстроенияDataGridViewTextBoxColumn.Name = "номерстроенияDataGridViewTextBoxColumn";
            // 
            // номерпомещенияDataGridViewTextBoxColumn
            // 
            this.номерпомещенияDataGridViewTextBoxColumn.DataPropertyName = "Номер_помещения";
            this.номерпомещенияDataGridViewTextBoxColumn.FillWeight = 120F;
            this.номерпомещенияDataGridViewTextBoxColumn.HeaderText = "Номер_помещения";
            this.номерпомещенияDataGridViewTextBoxColumn.Name = "номерпомещенияDataGridViewTextBoxColumn";
            this.номерпомещенияDataGridViewTextBoxColumn.Width = 120;
            // 
            // индексDataGridViewTextBoxColumn
            // 
            this.индексDataGridViewTextBoxColumn.DataPropertyName = "Индекс";
            this.индексDataGridViewTextBoxColumn.HeaderText = "Индекс";
            this.индексDataGridViewTextBoxColumn.Name = "индексDataGridViewTextBoxColumn";
            // 
            // dilersAdressBindingSource
            // 
            this.dilersAdressBindingSource.DataMember = "DilersAdress";
            this.dilersAdressBindingSource.DataSource = this.carSellDataSet;
            // 
            // carSellDataSet
            // 
            this.carSellDataSet.DataSetName = "CarSellDataSet";
            this.carSellDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // дилерBindingSource
            // 
            this.дилерBindingSource.DataMember = "Дилер";
            this.дилерBindingSource.DataSource = this.carSellDataSet;
            // 
            // fullDlNameBindingSource
            // 
            this.fullDlNameBindingSource.DataMember = "FullDlName";
            this.fullDlNameBindingSource.DataSource = this.carSellDataSet;
            // 
            // адресBindingSource
            // 
            this.адресBindingSource.DataMember = "Адрес";
            this.адресBindingSource.DataSource = this.carSellDataSet;
            // 
            // областьBindingSource
            // 
            this.областьBindingSource.DataMember = "Область";
            this.областьBindingSource.DataSource = this.carSellDataSet;
            // 
            // районBindingSource
            // 
            this.районBindingSource.DataMember = "Район";
            this.районBindingSource.DataSource = this.carSellDataSet;
            // 
            // населенныйпунктBindingSource
            // 
            this.населенныйпунктBindingSource.DataMember = "Населенный_пункт";
            this.населенныйпунктBindingSource.DataSource = this.carSellDataSet;
            // 
            // улицаBindingSource
            // 
            this.улицаBindingSource.DataMember = "Улица";
            this.улицаBindingSource.DataSource = this.carSellDataSet;
            // 
            // dilersAdressTableAdapter
            // 
            this.dilersAdressTableAdapter.ClearBeforeFill = true;
            // 
            // дилерTableAdapter
            // 
            this.дилерTableAdapter.ClearBeforeFill = true;
            // 
            // адресTableAdapter
            // 
            this.адресTableAdapter.ClearBeforeFill = true;
            // 
            // областьTableAdapter
            // 
            this.областьTableAdapter.ClearBeforeFill = true;
            // 
            // районTableAdapter
            // 
            this.районTableAdapter.ClearBeforeFill = true;
            // 
            // населенный_пунктTableAdapter
            // 
            this.населенный_пунктTableAdapter.ClearBeforeFill = true;
            // 
            // улицаTableAdapter
            // 
            this.улицаTableAdapter.ClearBeforeFill = true;
            // 
            // fullDlNameTableAdapter
            // 
            this.fullDlNameTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.OrangeRed;
            this.button1.Location = new System.Drawing.Point(447, 602);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 29);
            this.button1.TabIndex = 4;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодадрисаDataGridViewTextBoxColumn1,
            this.кодулицыDataGridViewTextBoxColumn,
            this.кодтипастроенияDataGridViewTextBoxColumn,
            this.кодтипапомещенияDataGridViewTextBoxColumn,
            this.номерстроенияDataGridViewTextBoxColumn1,
            this.номерпомещенияDataGridViewTextBoxColumn1,
            this.индексDataGridViewTextBoxColumn1});
            this.dataGridView2.DataSource = this.адресBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(0, 282);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(425, 314);
            this.dataGridView2.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(468, 255);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(355, 24);
            this.label1.TabIndex = 9;
            this.label1.Text = "Редактировать только в нижнем окне";
            // 
            // кодадрисаDataGridViewTextBoxColumn1
            // 
            this.кодадрисаDataGridViewTextBoxColumn1.DataPropertyName = "Код_адриса";
            this.кодадрисаDataGridViewTextBoxColumn1.HeaderText = "Код_адриса";
            this.кодадрисаDataGridViewTextBoxColumn1.Name = "кодадрисаDataGridViewTextBoxColumn1";
            this.кодадрисаDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // кодулицыDataGridViewTextBoxColumn
            // 
            this.кодулицыDataGridViewTextBoxColumn.DataPropertyName = "Код_улицы";
            this.кодулицыDataGridViewTextBoxColumn.HeaderText = "Код_улицы";
            this.кодулицыDataGridViewTextBoxColumn.Name = "кодулицыDataGridViewTextBoxColumn";
            // 
            // кодтипастроенияDataGridViewTextBoxColumn
            // 
            this.кодтипастроенияDataGridViewTextBoxColumn.DataPropertyName = "Код_типа_строения";
            this.кодтипастроенияDataGridViewTextBoxColumn.HeaderText = "Код_типа_строения";
            this.кодтипастроенияDataGridViewTextBoxColumn.Name = "кодтипастроенияDataGridViewTextBoxColumn";
            // 
            // кодтипапомещенияDataGridViewTextBoxColumn
            // 
            this.кодтипапомещенияDataGridViewTextBoxColumn.DataPropertyName = "Код_типа_помещения";
            this.кодтипапомещенияDataGridViewTextBoxColumn.HeaderText = "Код_типа_помещения";
            this.кодтипапомещенияDataGridViewTextBoxColumn.Name = "кодтипапомещенияDataGridViewTextBoxColumn";
            // 
            // номерстроенияDataGridViewTextBoxColumn1
            // 
            this.номерстроенияDataGridViewTextBoxColumn1.DataPropertyName = "Номер_строения";
            this.номерстроенияDataGridViewTextBoxColumn1.HeaderText = "Номер_строения";
            this.номерстроенияDataGridViewTextBoxColumn1.Name = "номерстроенияDataGridViewTextBoxColumn1";
            // 
            // номерпомещенияDataGridViewTextBoxColumn1
            // 
            this.номерпомещенияDataGridViewTextBoxColumn1.DataPropertyName = "Номер_помещения";
            this.номерпомещенияDataGridViewTextBoxColumn1.HeaderText = "Номер_помещения";
            this.номерпомещенияDataGridViewTextBoxColumn1.Name = "номерпомещенияDataGridViewTextBoxColumn1";
            // 
            // индексDataGridViewTextBoxColumn1
            // 
            this.индексDataGridViewTextBoxColumn1.DataPropertyName = "Индекс";
            this.индексDataGridViewTextBoxColumn1.HeaderText = "Индекс";
            this.индексDataGridViewTextBoxColumn1.Name = "индексDataGridViewTextBoxColumn1";
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодулицыDataGridViewTextBoxColumn1,
            this.кодтипаулицыDataGridViewTextBoxColumn,
            this.кодНПDataGridViewTextBoxColumn,
            this.названиеулицыDataGridViewTextBoxColumn1});
            this.dataGridView3.DataSource = this.улицаBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(447, 282);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(401, 314);
            this.dataGridView3.TabIndex = 10;
            // 
            // кодулицыDataGridViewTextBoxColumn1
            // 
            this.кодулицыDataGridViewTextBoxColumn1.DataPropertyName = "Код_улицы";
            this.кодулицыDataGridViewTextBoxColumn1.HeaderText = "Код_улицы";
            this.кодулицыDataGridViewTextBoxColumn1.Name = "кодулицыDataGridViewTextBoxColumn1";
            this.кодулицыDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // кодтипаулицыDataGridViewTextBoxColumn
            // 
            this.кодтипаулицыDataGridViewTextBoxColumn.DataPropertyName = "Код_типа_улицы";
            this.кодтипаулицыDataGridViewTextBoxColumn.HeaderText = "Код_типа_улицы";
            this.кодтипаулицыDataGridViewTextBoxColumn.Name = "кодтипаулицыDataGridViewTextBoxColumn";
            // 
            // кодНПDataGridViewTextBoxColumn
            // 
            this.кодНПDataGridViewTextBoxColumn.DataPropertyName = "Код_НП";
            this.кодНПDataGridViewTextBoxColumn.HeaderText = "Код_НП";
            this.кодНПDataGridViewTextBoxColumn.Name = "кодНПDataGridViewTextBoxColumn";
            // 
            // названиеулицыDataGridViewTextBoxColumn1
            // 
            this.названиеулицыDataGridViewTextBoxColumn1.DataPropertyName = "Название_улицы";
            this.названиеулицыDataGridViewTextBoxColumn1.HeaderText = "Название_улицы";
            this.названиеулицыDataGridViewTextBoxColumn1.Name = "названиеулицыDataGridViewTextBoxColumn1";
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодНПDataGridViewTextBoxColumn1,
            this.кодтипаНПDataGridViewTextBoxColumn,
            this.кодрайонуDataGridViewTextBoxColumn,
            this.названиеDataGridViewTextBoxColumn1});
            this.dataGridView4.DataSource = this.населенныйпунктBindingSource;
            this.dataGridView4.Location = new System.Drawing.Point(871, 282);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(353, 314);
            this.dataGridView4.TabIndex = 11;
            // 
            // кодНПDataGridViewTextBoxColumn1
            // 
            this.кодНПDataGridViewTextBoxColumn1.DataPropertyName = "Код_НП";
            this.кодНПDataGridViewTextBoxColumn1.HeaderText = "Код_НП";
            this.кодНПDataGridViewTextBoxColumn1.Name = "кодНПDataGridViewTextBoxColumn1";
            this.кодНПDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // кодтипаНПDataGridViewTextBoxColumn
            // 
            this.кодтипаНПDataGridViewTextBoxColumn.DataPropertyName = "Код_типа_НП";
            this.кодтипаНПDataGridViewTextBoxColumn.HeaderText = "Код_типа_НП";
            this.кодтипаНПDataGridViewTextBoxColumn.Name = "кодтипаНПDataGridViewTextBoxColumn";
            // 
            // кодрайонуDataGridViewTextBoxColumn
            // 
            this.кодрайонуDataGridViewTextBoxColumn.DataPropertyName = "Код_району";
            this.кодрайонуDataGridViewTextBoxColumn.HeaderText = "Код_району";
            this.кодрайонуDataGridViewTextBoxColumn.Name = "кодрайонуDataGridViewTextBoxColumn";
            // 
            // названиеDataGridViewTextBoxColumn1
            // 
            this.названиеDataGridViewTextBoxColumn1.DataPropertyName = "Название";
            this.названиеDataGridViewTextBoxColumn1.HeaderText = "Название";
            this.названиеDataGridViewTextBoxColumn1.Name = "названиеDataGridViewTextBoxColumn1";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.RoyalBlue;
            this.button2.Location = new System.Drawing.Point(680, 602);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(168, 29);
            this.button2.TabIndex = 12;
            this.button2.Text = "Сохранить редактированное";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form30
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1224, 643);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.dataGridView4);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form30";
            this.Text = "Form30";
            this.Load += new System.EventHandler(this.Form30_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dilersAdressBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.дилерBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fullDlNameBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.адресBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.областьBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.районBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.населенныйпунктBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.улицаBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CarSellDataSet carSellDataSet;
        private System.Windows.Forms.BindingSource dilersAdressBindingSource;
        private CarSellDataSetTableAdapters.DilersAdressTableAdapter dilersAdressTableAdapter;
        private System.Windows.Forms.BindingSource дилерBindingSource;
        private CarSellDataSetTableAdapters.ДилерTableAdapter дилерTableAdapter;
        private System.Windows.Forms.BindingSource адресBindingSource;
        private CarSellDataSetTableAdapters.АдресTableAdapter адресTableAdapter;
        private System.Windows.Forms.BindingSource областьBindingSource;
        private CarSellDataSetTableAdapters.ОбластьTableAdapter областьTableAdapter;
        private System.Windows.Forms.BindingSource районBindingSource;
        private CarSellDataSetTableAdapters.РайонTableAdapter районTableAdapter;
        private System.Windows.Forms.BindingSource населенныйпунктBindingSource;
        private CarSellDataSetTableAdapters.Населенный_пунктTableAdapter населенный_пунктTableAdapter;
        private System.Windows.Forms.BindingSource улицаBindingSource;
        private CarSellDataSetTableAdapters.УлицаTableAdapter улицаTableAdapter;
        private System.Windows.Forms.BindingSource fullDlNameBindingSource;
        private CarSellDataSetTableAdapters.FullDlNameTableAdapter fullDlNameTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn коддилераDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn дилерDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодадрисаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеобластиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn назварайонуDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеулицыDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерстроенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерпомещенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn индексDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодадрисаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодулицыDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодтипастроенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодтипапомещенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерстроенияDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерпомещенияDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn индексDataGridViewTextBoxColumn1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодулицыDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодтипаулицыDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодНПDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеулицыDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодНПDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодтипаНПDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодрайонуDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеDataGridViewTextBoxColumn1;
        private System.Windows.Forms.Button button2;
    }
}