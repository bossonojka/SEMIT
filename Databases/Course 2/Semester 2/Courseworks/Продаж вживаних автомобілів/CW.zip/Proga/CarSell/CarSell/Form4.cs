﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;
using System.Data.Entity;

namespace CarSell
{
    public partial class Form4 : Form
    {
        SqlConnection conn = null;
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_ТС' table. You can move, or remove it, as needed.
            this.тип_ТСTableAdapter.Fill(this.carSellDataSet.Тип_ТС);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form53 form53 = new Form53();
            form53.Show();
        }
        

        private void button4_Click(object sender, EventArgs e)
        {
            int codeTpTC = int.Parse(dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells["кодтипаТСDataGridViewTextBoxColumn"].Value.ToString());
            DialogResult result = MessageBox.Show("Удалить Тип ТС?", "Предупреждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            switch (result)
            {
                case DialogResult.Yes:
                    {
                        try
                        {
                            conn = new SqlConnection();
                            conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                            conn.Open();
                            SqlCommand myCommand = conn.CreateCommand();
                            myCommand.CommandText = "Delete from Тип_ТС Where Код_типа_ТС = @codeTpTC";
                            myCommand.Parameters.Add("@codeTpTC", SqlDbType.Int, 4);
                            myCommand.Parameters["@codeTpTC"].Value = codeTpTC;


                            int UspeshnoeIzmenenie = myCommand.ExecuteNonQuery();
                            if (UspeshnoeIzmenenie != 0)
                            {
                                MessageBox.Show("Изменения внесены", "Изменение записи");
                            }
                            else
                            {
                                MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                        finally
                        {
                            conn.Close();
                        }
                        this.тип_ТСTableAdapter.Fill(this.carSellDataSet.Тип_ТС);
                        break;
                    }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.тип_ТСTableAdapter.Update(this.carSellDataSet.Тип_ТС);
        }
    }
}
