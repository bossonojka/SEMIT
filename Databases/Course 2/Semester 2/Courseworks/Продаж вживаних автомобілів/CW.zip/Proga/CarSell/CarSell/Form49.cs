﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;

namespace CarSell
{
    public partial class Form49 : Form
    {
        SqlConnection conn = null;
        public Form49()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string nameTpRoom = Convert.ToString(this.textBox1.Text);


                conn = new SqlConnection();
                conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                conn.Open();
                SqlCommand myComand = conn.CreateCommand();
                myComand.CommandText = "INSERT into Тип_помещения (Тип_помещения) VALUES (@nameTpRoom)";
                myComand.Parameters.Add("@nameTpRoom", SqlDbType.NVarChar, 20);
                myComand.Parameters["@nameTpRoom"].Value = nameTpRoom;

                int UspeshnoeIzmenenie = myComand.ExecuteNonQuery();
                if (UspeshnoeIzmenenie != 0)
                {
                    MessageBox.Show("Изменения внесены", "Изменение записи");
                }
                else
                {
                    MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            this.тип_помещенияTableAdapter1.Fill(this.carSellDataSet1.Тип_помещения);
            Form41 form41 = new Form41();
            form41.Update();
        }
    }
}
