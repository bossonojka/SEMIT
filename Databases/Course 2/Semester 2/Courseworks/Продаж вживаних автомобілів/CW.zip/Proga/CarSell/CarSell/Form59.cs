﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;

namespace CarSell
{
    public partial class Form59 : Form
    {
        SqlConnection conn = null;
        public Form59()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string engineCapacity = Convert.ToString(this.textBox1.Text);


                conn = new SqlConnection();
                conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                conn.Open();
                SqlCommand myComand = conn.CreateCommand();
                myComand.CommandText = "INSERT into Объем_двигателя (Диапазон_объема_двигателя) VALUES (@engineCapacity)";
                myComand.Parameters.Add("@engineCapacity", SqlDbType.NVarChar, 20);
                myComand.Parameters["@engineCapacity"].Value = engineCapacity;

                int UspeshnoeIzmenenie = myComand.ExecuteNonQuery();
                if (UspeshnoeIzmenenie != 0)
                {
                    MessageBox.Show("Изменения внесены", "Изменение записи");
                }
                else
                {
                    MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            this.объем_двигателяTableAdapter1.Fill(this.carSellDataSet1.Объем_двигателя);
            Form42 form42 = new Form42();
            form42.Update();
        }
    }
}
