﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;

namespace CarSell
{
    public partial class Form1 : Form
    {
        SqlConnection conn = new SqlConnection("integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell");
        
        public Form1()
        {
            InitializeComponent();
        }

        private void маркаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
        }

        private void модельToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
        }

        private void типТСToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
        }

        private void типКузоваToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Show();
        }

        private void годВыпускаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            form6.Show();
        }

        private void годСнятияСПроизводстваToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();
            form7.Show();
        }

        private void объемДвигателяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form8 form8 = new Form8();
            form8.Show();
        }

        private void мощностьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form9 form9 = new Form9();
            form9.Show();
        }

        private void пробегToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form10 form10 = new Form10();
            form10.Show();
        }

        private void цветToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form11 form11 = new Form11();
            form11.Show();
        }

        private void ценаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form12 form12 = new Form12();
            form12.Show();
        }

        private void инофрмацияОВсехАвтомобиляхToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form13 form13 = new Form13();
            form13.Show();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

            // TODO: This line of code loads data into the 'carSellDataSet.InfAbCarWOKlients' table. You can move, or remove it, as needed.
            this.infAbCarWOKlientsTableAdapter.Fill(this.carSellDataSet.InfAbCarWOKlients);
            // TODO: This line of code loads data into the 'carSellDataSet.CarsHaventContracts' table. You can move, or remove it, as needed.
            this.carsHaventContractsTableAdapter.Fill(this.carSellDataSet.CarsHaventContracts);
            // TODO: This line of code loads data into the 'carSellDataSet.Заказ_клиента' table. You can move, or remove it, as needed.
            this.заказ_клиентаTableAdapter1.Fill(this.carSellDataSet.Заказ_клиента);
            // TODO: This line of code loads data into the 'carSellDataSet.Диапазон_цены' table. You can move, or remove it, as needed.
            this.диапазон_ценыTableAdapter1.Fill(this.carSellDataSet.Диапазон_цены);
            // TODO: This line of code loads data into the 'carSellDataSet.Цвет' table. You can move, or remove it, as needed.
            this.цветTableAdapter1.Fill(this.carSellDataSet.Цвет);
            // TODO: This line of code loads data into the 'carSellDataSet.Мощность' table. You can move, or remove it, as needed.
            this.мощностьTableAdapter1.Fill(this.carSellDataSet.Мощность);
            // TODO: This line of code loads data into the 'carSellDataSet.Объем_двигателя' table. You can move, or remove it, as needed.
            this.объем_двигателяTableAdapter1.Fill(this.carSellDataSet.Объем_двигателя);
            // TODO: This line of code loads data into the 'carSellDataSet.Модель_авто' table. You can move, or remove it, as needed.
            this.модель_автоTableAdapter1.Fill(this.carSellDataSet.Модель_авто);
            // TODO: This line of code loads data into the 'carSellDataSet.Марка_авто' table. You can move, or remove it, as needed.
            this.марка_автоTableAdapter1.Fill(this.carSellDataSet.Марка_авто);
            // TODO: This line of code loads data into the 'carSellDataSet.Пробег' table. You can move, or remove it, as needed.
            this.пробегTableAdapter1.Fill(this.carSellDataSet.Пробег);
            // TODO: This line of code loads data into the 'carSellDataSet.Год_выпуска_до' table. You can move, or remove it, as needed.
            this.год_выпуска_доTableAdapter1.Fill(this.carSellDataSet.Год_выпуска_до);
            // TODO: This line of code loads data into the 'carSellDataSet.Год_выпуска_от' table. You can move, or remove it, as needed.
            this.год_выпуска_отTableAdapter1.Fill(this.carSellDataSet.Год_выпуска_от);
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_кузова' table. You can move, or remove it, as needed.
            this.тип_кузоваTableAdapter1.Fill(this.carSellDataSet.Тип_кузова);
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_ТС' table. You can move, or remove it, as needed.
            this.тип_ТСTableAdapter1.Fill(this.carSellDataSet.Тип_ТС);

        }

        private void оАвтомобиляхToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void дилерыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form14 form14 = new Form14();
            form14.Show();
        }

        private void областьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form15 form15 = new Form15();
            form15.Show();
        }

        private void всеАдресаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form16 form16 = new Form16();
            form16.Show();
        }

        private void районToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form17 form17 = new Form17();
            form17.Show();
        }

        private void типНПToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form18 form18 = new Form18();
            form18.Show();
        }

        private void населенныйПунктToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form19 form19 = new Form19();
            form19.Show();
        }

        private void типУлицыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form20 form20 = new Form20();
            form20.Show();
        }

        private void улицаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form21 form21 = new Form21();
            form21.Show();
        }

        private void типСтроенияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form22 form22 = new Form22();
            form22.Show();
        }

        private void типПомещенияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form23 form23 = new Form23();
            form23.Show();
        }

        private void мобильныйОператорToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form24 form24 = new Form24();
            form24.Show();
        }

        private void номерОператораToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form25 form25 = new Form25();
            form25.Show();
        }

        private void телефонToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form26 form26 = new Form26();
            form26.Show();
        }

        private void мобильныйТелефонToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form27 form27 = new Form27();
            form27.Show();
        }

        private void стационарныйТелефонToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form28 form28 = new Form28();
            form28.Show();
        }

        private void видТелефонаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form29 form29 = new Form29();
            form29.Show();
        }

        private void адерсДилераToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form30 form30 = new Form30();
            form30.Show();
        }

        private void телефонДилераToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form31 form31 = new Form31();
            form31.Show();
        }

        private void всеКлиентыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form32 form32 = new Form32();
            form32.Show();
        }

        private void клиентыПродавцыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void информацияОКлиентеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form33 form33 = new Form33();
            form33.Show();
        }

        private void адресКлиентовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form39 form39 = new Form39();
            form39.Show();
        }

        private void автомобилиКлиентовПродавцовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form34 form34 = new Form34();
            form34.Show();
        }

        private void информациОКлиентахToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form35 form35 = new Form35();
            form35.Show();
        }

        private void заказыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form36 form36 = new Form36();
            form36.Show();
        }

        private void выполненыеЗаказыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form37 form37 = new Form37();
            form37.Show();
        }

        private void невыполненыеЗаказыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form38 form38 = new Form38();
            form38.Show();
        }

        private void телефоныКлиентовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form40 form40 = new Form40();
            form40.Show();
        }



        private void новыйКлиентToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form41 form41 = new Form41();
            form41.Show();
        }

        private void дляКлиентаПродавцаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form42 form42 = new Form42();
            form42.Show();
        }

        private void дляКлиентаПокупателяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form63 form63 = new Form63();
            form63.Show();
        }

        private void данныеToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void новыйДилерToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form43 form43 = new Form43();
            form43.ShowDialog(this);
        }

        private void дилерToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void дилерToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            TabControl tabControl1 = new TabControl();
            tabControl1.Show();
        }

        private void количествоДоговоровУКаждогоДилераToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form44 form44 = new Form44();
            form44.Show();
        }

        private void маркаМодельToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form57 form57 = new Form57();
            form57.Show();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void всеДоговораToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form64 form64 = new Form64();
            form64.Show();
        }

        private void новыйДоговорToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form65 form65 = new Form65();
            form65.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        
        private void comboBox9_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Form65 form65 = new Form65();
            form65.ShowDialog(this);
            this.carsHaventContractsTableAdapter.Fill(carSellDataSet.CarsHaventContracts);
            this.договорTableAdapter1.Fill(carSellDataSet.Договор);
        }

        

        private void button1_Click_1(object sender, EventArgs e)
        {
            
           /* int codeTC = int.Parse(this.comboBox1.SelectedValue.ToString());
            int codeBr = int.Parse(this.comboBox2.SelectedValue.ToString());
            int codeMod = int.Parse(this.comboBox3.SelectedValue.ToString());
            int codeBod = int.Parse(this.comboBox4.SelectedValue.ToString());
            int codeYrSince = int.Parse(this.comboBox5.SelectedValue.ToString());
            int codeYrFor = int.Parse(this.comboBox6.SelectedValue.ToString());
            int codeEmp = int.Parse(this.comboBox7.SelectedValue.ToString());
            int codePow = int.Parse(this.comboBox8.SelectedValue.ToString());
            int codeMAge = int.Parse(this.comboBox9.SelectedValue.ToString());
            int codeCol = int.Parse(this.comboBox10.SelectedValue.ToString());
            int codePr = int.Parse(this.comboBox11.SelectedValue.ToString());*/


            


        }

        private void comboBox18_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }


        private void comboBox11_SelectedIndexChanged(object sender, EventArgs e)
        {

           

        }

       /* private List<String> getMark(int markAuto)
        {
            List<String> mark = new List<String>();

            using (SqlConnection conn = new SqlConnection())
            {
                conn.Open();
                using (SqlCommand command = conn.CreateCommand())
                {
                    command.CommandText = string.Format("SELECT * FROM Марка_модель WHERE={0}", markAuto);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            mark.Add((string)reader[1]);
                        }
                    }
                }
                conn.Close();
            }
            return mark;
        }*/

        private void comboBox12_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void сформироватьЗаказToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void оПродажахЗаФевральToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form70 form70 = new Form70();
            form70.MdiParent = this;
            form70.Show();
        }
    }
}
