﻿namespace CarSell
{
    partial class Form48
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.тип_строенияTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Тип_строенияTableAdapter();
            this.carSellDataSet1 = new CarSell.CarSellDataSet();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // тип_строенияTableAdapter1
            // 
            this.тип_строенияTableAdapter1.ClearBeforeFill = true;
            // 
            // carSellDataSet1
            // 
            this.carSellDataSet1.DataSetName = "CarSellDataSet";
            this.carSellDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(199, 64);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(174, 20);
            this.textBox11.TabIndex = 35;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label23.Location = new System.Drawing.Point(41, 64);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(111, 20);
            this.label23.TabIndex = 34;
            this.label23.Text = "Тип строения";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DodgerBlue;
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Location = new System.Drawing.Point(130, 172);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(151, 23);
            this.button1.TabIndex = 36;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form48
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(445, 300);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.label23);
            this.Name = "Form48";
            this.Text = "Form48";
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CarSellDataSetTableAdapters.Тип_строенияTableAdapter тип_строенияTableAdapter1;
        private CarSellDataSet carSellDataSet1;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button1;
    }
}