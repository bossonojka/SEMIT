﻿namespace CarSell
{
    partial class Form25
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.operatorNumberBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carSellDataSet = new CarSell.CarSellDataSet();
            this.операторBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.operatorNumberTableAdapter = new CarSell.CarSellDataSetTableAdapters.OperatorNumberTableAdapter();
            this.операторTableAdapter = new CarSell.CarSellDataSetTableAdapters.ОператорTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.номер_оператораTableAdapter = new CarSell.CarSellDataSetTableAdapters.Номер_оператораTableAdapter();
            this.номероператораBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.номероператораDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодоператораDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.operatorNumberBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.операторBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.номероператораBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // operatorNumberBindingSource
            // 
            this.operatorNumberBindingSource.DataMember = "OperatorNumber";
            this.operatorNumberBindingSource.DataSource = this.carSellDataSet;
            // 
            // carSellDataSet
            // 
            this.carSellDataSet.DataSetName = "CarSellDataSet";
            this.carSellDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // операторBindingSource
            // 
            this.операторBindingSource.DataMember = "Оператор";
            this.операторBindingSource.DataSource = this.carSellDataSet;
            // 
            // operatorNumberTableAdapter
            // 
            this.operatorNumberTableAdapter.ClearBeforeFill = true;
            // 
            // операторTableAdapter
            // 
            this.операторTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.OrangeRed;
            this.button1.Location = new System.Drawing.Point(24, 484);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 29);
            this.button1.TabIndex = 4;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.RoyalBlue;
            this.button2.Location = new System.Drawing.Point(317, 484);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(168, 29);
            this.button2.TabIndex = 8;
            this.button2.Text = "Сохранить редактированное";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // номер_оператораTableAdapter
            // 
            this.номер_оператораTableAdapter.ClearBeforeFill = true;
            // 
            // номероператораBindingSource
            // 
            this.номероператораBindingSource.DataMember = "Номер_оператора";
            this.номероператораBindingSource.DataSource = this.carSellDataSet;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.номероператораDataGridViewTextBoxColumn,
            this.кодоператораDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.номероператораBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(-1, -1);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(514, 468);
            this.dataGridView1.TabIndex = 9;
            // 
            // номероператораDataGridViewTextBoxColumn
            // 
            this.номероператораDataGridViewTextBoxColumn.DataPropertyName = "Номер_оператора";
            this.номероператораDataGridViewTextBoxColumn.HeaderText = "Номер_оператора";
            this.номероператораDataGridViewTextBoxColumn.Name = "номероператораDataGridViewTextBoxColumn";
            // 
            // кодоператораDataGridViewTextBoxColumn
            // 
            this.кодоператораDataGridViewTextBoxColumn.DataPropertyName = "Код_оператора";
            this.кодоператораDataGridViewTextBoxColumn.HeaderText = "Код_оператора";
            this.кодоператораDataGridViewTextBoxColumn.Name = "кодоператораDataGridViewTextBoxColumn";
            // 
            // Form25
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(513, 525);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form25";
            this.Text = "Form25";
            this.Load += new System.EventHandler(this.Form25_Load);
            ((System.ComponentModel.ISupportInitialize)(this.operatorNumberBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.операторBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.номероператораBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private CarSellDataSet carSellDataSet;
        private System.Windows.Forms.BindingSource operatorNumberBindingSource;
        private CarSellDataSetTableAdapters.OperatorNumberTableAdapter operatorNumberTableAdapter;
        private System.Windows.Forms.BindingSource операторBindingSource;
        private CarSellDataSetTableAdapters.ОператорTableAdapter операторTableAdapter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private CarSellDataSetTableAdapters.Номер_оператораTableAdapter номер_оператораTableAdapter;
        private System.Windows.Forms.BindingSource номероператораBindingSource;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn номероператораDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодоператораDataGridViewTextBoxColumn;
    }
}