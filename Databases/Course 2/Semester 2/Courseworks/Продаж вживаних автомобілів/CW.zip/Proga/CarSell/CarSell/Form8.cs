﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;

namespace CarSell
{
    public partial class Form8 : Form
    {
        SqlConnection conn = null;
        public Form8()
        {
            InitializeComponent();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Объем_двигателя' table. You can move, or remove it, as needed.
            this.объем_двигателяTableAdapter.Fill(this.carSellDataSet.Объем_двигателя);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form59 form59 = new Form59();
            form59.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int codeCar = int.Parse(dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells["коддиапазонаобъемадвигателяDataGridViewTextBoxColumn"].Value.ToString());
            DialogResult result = MessageBox.Show("Удалить диапазон объема двигателя?", "Предупреждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            switch (result)
            {
                case DialogResult.Yes:
                    {
                        try
                        {
                            conn = new SqlConnection();
                            conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                            conn.Open();
                            SqlCommand myCommand = conn.CreateCommand();
                            myCommand.CommandText = "Delete from Объем_двигателя Where Код_диапазона_объема_двигателя = @codeCar";
                            myCommand.Parameters.Add("@codeCar", SqlDbType.Int, 4);
                            myCommand.Parameters["@codeCar"].Value = codeCar;


                            int UspeshnoeIzmenenie = myCommand.ExecuteNonQuery();
                            if (UspeshnoeIzmenenie != 0)
                            {
                                MessageBox.Show("Изменения внесены", "Изменение записи");
                            }
                            else
                            {
                                MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                        finally
                        {
                            conn.Close();
                        }
                        this.объем_двигателяTableAdapter.Fill(this.carSellDataSet.Объем_двигателя);
                        break;
                    }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.объем_двигателяTableAdapter.Update(this.carSellDataSet.Объем_двигателя);
        }
    }
}
