﻿namespace CarSell
{
    partial class Form13
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.кодавтомобиляDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодклиентапродавцаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.клиентDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типТСDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.маркаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.модельDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.годвыпускаотDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.годвыпускадоDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типкузоваDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.диапазонобъемадвигателяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.диапазонмощностиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.диапазонпробегаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.цветDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.диапазонценыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vINкодкузоваDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.infAbCarBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carSellDataSet = new CarSell.CarSellDataSet();
            this.button1 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.carSellDataSet1 = new CarSell.CarSellDataSet();
            this.типТСBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.типТСBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.infAbCarTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.InfAbCarTableAdapter();
            this.автомобильTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.АвтомобильTableAdapter();
            this.тип_ТСTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Тип_ТСTableAdapter();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.infAbCarBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типТСBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типТСBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодавтомобиляDataGridViewTextBoxColumn,
            this.кодклиентапродавцаDataGridViewTextBoxColumn,
            this.клиентDataGridViewTextBoxColumn,
            this.типТСDataGridViewTextBoxColumn,
            this.маркаDataGridViewTextBoxColumn,
            this.модельDataGridViewTextBoxColumn,
            this.годвыпускаотDataGridViewTextBoxColumn,
            this.годвыпускадоDataGridViewTextBoxColumn,
            this.типкузоваDataGridViewTextBoxColumn,
            this.диапазонобъемадвигателяDataGridViewTextBoxColumn,
            this.диапазонмощностиDataGridViewTextBoxColumn,
            this.диапазонпробегаDataGridViewTextBoxColumn,
            this.цветDataGridViewTextBoxColumn,
            this.диапазонценыDataGridViewTextBoxColumn,
            this.vINкодкузоваDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.infAbCarBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(-1, -1);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1275, 450);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // кодавтомобиляDataGridViewTextBoxColumn
            // 
            this.кодавтомобиляDataGridViewTextBoxColumn.DataPropertyName = "Код_автомобиля";
            this.кодавтомобиляDataGridViewTextBoxColumn.HeaderText = "Код_автомобиля";
            this.кодавтомобиляDataGridViewTextBoxColumn.Name = "кодавтомобиляDataGridViewTextBoxColumn";
            // 
            // кодклиентапродавцаDataGridViewTextBoxColumn
            // 
            this.кодклиентапродавцаDataGridViewTextBoxColumn.DataPropertyName = "Код_клиента_продавца";
            this.кодклиентапродавцаDataGridViewTextBoxColumn.HeaderText = "Код_клиента_продавца";
            this.кодклиентапродавцаDataGridViewTextBoxColumn.Name = "кодклиентапродавцаDataGridViewTextBoxColumn";
            // 
            // клиентDataGridViewTextBoxColumn
            // 
            this.клиентDataGridViewTextBoxColumn.DataPropertyName = "Клиент";
            this.клиентDataGridViewTextBoxColumn.HeaderText = "Клиент";
            this.клиентDataGridViewTextBoxColumn.Name = "клиентDataGridViewTextBoxColumn";
            this.клиентDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // типТСDataGridViewTextBoxColumn
            // 
            this.типТСDataGridViewTextBoxColumn.DataPropertyName = "Тип_ТС";
            this.типТСDataGridViewTextBoxColumn.HeaderText = "Тип_ТС";
            this.типТСDataGridViewTextBoxColumn.Name = "типТСDataGridViewTextBoxColumn";
            this.типТСDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // маркаDataGridViewTextBoxColumn
            // 
            this.маркаDataGridViewTextBoxColumn.DataPropertyName = "Марка";
            this.маркаDataGridViewTextBoxColumn.HeaderText = "Марка";
            this.маркаDataGridViewTextBoxColumn.Name = "маркаDataGridViewTextBoxColumn";
            // 
            // модельDataGridViewTextBoxColumn
            // 
            this.модельDataGridViewTextBoxColumn.DataPropertyName = "Модель";
            this.модельDataGridViewTextBoxColumn.HeaderText = "Модель";
            this.модельDataGridViewTextBoxColumn.Name = "модельDataGridViewTextBoxColumn";
            // 
            // годвыпускаотDataGridViewTextBoxColumn
            // 
            this.годвыпускаотDataGridViewTextBoxColumn.DataPropertyName = "Год_выпуска_от";
            this.годвыпускаотDataGridViewTextBoxColumn.HeaderText = "Год_выпуска_от";
            this.годвыпускаотDataGridViewTextBoxColumn.Name = "годвыпускаотDataGridViewTextBoxColumn";
            // 
            // годвыпускадоDataGridViewTextBoxColumn
            // 
            this.годвыпускадоDataGridViewTextBoxColumn.DataPropertyName = "Год_выпуска_до";
            this.годвыпускадоDataGridViewTextBoxColumn.HeaderText = "Год_выпуска_до";
            this.годвыпускадоDataGridViewTextBoxColumn.Name = "годвыпускадоDataGridViewTextBoxColumn";
            // 
            // типкузоваDataGridViewTextBoxColumn
            // 
            this.типкузоваDataGridViewTextBoxColumn.DataPropertyName = "Тип_кузова";
            this.типкузоваDataGridViewTextBoxColumn.HeaderText = "Тип_кузова";
            this.типкузоваDataGridViewTextBoxColumn.Name = "типкузоваDataGridViewTextBoxColumn";
            // 
            // диапазонобъемадвигателяDataGridViewTextBoxColumn
            // 
            this.диапазонобъемадвигателяDataGridViewTextBoxColumn.DataPropertyName = "Диапазон_объема_двигателя";
            this.диапазонобъемадвигателяDataGridViewTextBoxColumn.HeaderText = "Диапазон_объема_двигателя";
            this.диапазонобъемадвигателяDataGridViewTextBoxColumn.Name = "диапазонобъемадвигателяDataGridViewTextBoxColumn";
            // 
            // диапазонмощностиDataGridViewTextBoxColumn
            // 
            this.диапазонмощностиDataGridViewTextBoxColumn.DataPropertyName = "Диапазон_мощности";
            this.диапазонмощностиDataGridViewTextBoxColumn.HeaderText = "Диапазон_мощности";
            this.диапазонмощностиDataGridViewTextBoxColumn.Name = "диапазонмощностиDataGridViewTextBoxColumn";
            // 
            // диапазонпробегаDataGridViewTextBoxColumn
            // 
            this.диапазонпробегаDataGridViewTextBoxColumn.DataPropertyName = "Диапазон_пробега";
            this.диапазонпробегаDataGridViewTextBoxColumn.HeaderText = "Диапазон_пробега";
            this.диапазонпробегаDataGridViewTextBoxColumn.Name = "диапазонпробегаDataGridViewTextBoxColumn";
            // 
            // цветDataGridViewTextBoxColumn
            // 
            this.цветDataGridViewTextBoxColumn.DataPropertyName = "Цвет";
            this.цветDataGridViewTextBoxColumn.HeaderText = "Цвет";
            this.цветDataGridViewTextBoxColumn.Name = "цветDataGridViewTextBoxColumn";
            // 
            // диапазонценыDataGridViewTextBoxColumn
            // 
            this.диапазонценыDataGridViewTextBoxColumn.DataPropertyName = "Диапазон_цены";
            this.диапазонценыDataGridViewTextBoxColumn.HeaderText = "Диапазон_цены";
            this.диапазонценыDataGridViewTextBoxColumn.Name = "диапазонценыDataGridViewTextBoxColumn";
            // 
            // vINкодкузоваDataGridViewTextBoxColumn
            // 
            this.vINкодкузоваDataGridViewTextBoxColumn.DataPropertyName = "VIN_код_кузова";
            this.vINкодкузоваDataGridViewTextBoxColumn.HeaderText = "VIN_код_кузова";
            this.vINкодкузоваDataGridViewTextBoxColumn.Name = "vINкодкузоваDataGridViewTextBoxColumn";
            // 
            // infAbCarBindingSource
            // 
            this.infAbCarBindingSource.DataMember = "InfAbCar";
            this.infAbCarBindingSource.DataSource = this.carSellDataSet;
            // 
            // carSellDataSet
            // 
            this.carSellDataSet.DataSetName = "CarSellDataSet";
            this.carSellDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.OrangeRed;
            this.button1.Location = new System.Drawing.Point(380, 468);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 29);
            this.button1.TabIndex = 1;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Tomato;
            this.button4.Location = new System.Drawing.Point(741, 468);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(106, 29);
            this.button4.TabIndex = 3;
            this.button4.Text = "Удалить";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // carSellDataSet1
            // 
            this.carSellDataSet1.DataSetName = "CarSellDataSet";
            this.carSellDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // типТСBindingSource
            // 
            this.типТСBindingSource.DataMember = "Тип_ТС";
            this.типТСBindingSource.DataSource = this.carSellDataSet1;
            // 
            // типТСBindingSource1
            // 
            this.типТСBindingSource1.DataMember = "Тип_ТС";
            this.типТСBindingSource1.DataSource = this.carSellDataSet1;
            // 
            // infAbCarTableAdapter1
            // 
            this.infAbCarTableAdapter1.ClearBeforeFill = true;
            // 
            // автомобильTableAdapter1
            // 
            this.автомобильTableAdapter1.ClearBeforeFill = true;
            // 
            // тип_ТСTableAdapter1
            // 
            this.тип_ТСTableAdapter1.ClearBeforeFill = true;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.RoyalBlue;
            this.button2.Location = new System.Drawing.Point(537, 468);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(168, 29);
            this.button2.TabIndex = 6;
            this.button2.Text = "Сохранить редактированное";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // Form13
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1274, 509);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form13";
            this.Text = "Form13";
            this.Load += new System.EventHandler(this.Form13_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.infAbCarBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типТСBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типТСBindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CarSellDataSet carSellDataSet;
        private System.Windows.Forms.BindingSource infAbCarBindingSource;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private CarSellDataSet carSellDataSet1;
        private System.Windows.Forms.BindingSource типТСBindingSource;
        private System.Windows.Forms.BindingSource типТСBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодавтомобиляDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодклиентапродавцаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn клиентDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn типТСDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn маркаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn модельDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn годвыпускаотDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn годвыпускадоDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn типкузоваDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn диапазонобъемадвигателяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn диапазонмощностиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn диапазонпробегаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn цветDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn диапазонценыDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vINкодкузоваDataGridViewTextBoxColumn;
        private CarSellDataSetTableAdapters.InfAbCarTableAdapter infAbCarTableAdapter1;
        private CarSellDataSetTableAdapters.АвтомобильTableAdapter автомобильTableAdapter1;
        private CarSellDataSetTableAdapters.Тип_ТСTableAdapter тип_ТСTableAdapter1;
        private System.Windows.Forms.Button button2;
    }
}