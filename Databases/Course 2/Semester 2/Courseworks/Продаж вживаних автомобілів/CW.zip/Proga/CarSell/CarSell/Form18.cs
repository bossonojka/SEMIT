﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSell
{
    public partial class Form18 : Form
    {
        public Form18()
        {
            InitializeComponent();
        }

        private void Form18_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_НП' table. You can move, or remove it, as needed.
            this.тип_НПTableAdapter.Fill(this.carSellDataSet.Тип_НП);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form46 form46 = new Form46();
            form46.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.тип_НПTableAdapter.Update(this.carSellDataSet.Тип_НП);
        }
    }
}
