﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSell
{
    public partial class Form30 : Form
    {
        public Form30()
        {
            InitializeComponent();
        }

        private void Form30_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.FullDlName' table. You can move, or remove it, as needed.
            this.fullDlNameTableAdapter.Fill(this.carSellDataSet.FullDlName);
            // TODO: This line of code loads data into the 'carSellDataSet.Улица' table. You can move, or remove it, as needed.
            this.улицаTableAdapter.Fill(this.carSellDataSet.Улица);
            // TODO: This line of code loads data into the 'carSellDataSet.Населенный_пункт' table. You can move, or remove it, as needed.
            this.населенный_пунктTableAdapter.Fill(this.carSellDataSet.Населенный_пункт);
            // TODO: This line of code loads data into the 'carSellDataSet.Район' table. You can move, or remove it, as needed.
            this.районTableAdapter.Fill(this.carSellDataSet.Район);
            // TODO: This line of code loads data into the 'carSellDataSet.Область' table. You can move, or remove it, as needed.
            this.областьTableAdapter.Fill(this.carSellDataSet.Область);
            // TODO: This line of code loads data into the 'carSellDataSet.Адрес' table. You can move, or remove it, as needed.
            this.адресTableAdapter.Fill(this.carSellDataSet.Адрес);
            // TODO: This line of code loads data into the 'carSellDataSet.Дилер' table. You can move, or remove it, as needed.
            this.дилерTableAdapter.Fill(this.carSellDataSet.Дилер);
            // TODO: This line of code loads data into the 'carSellDataSet.DilersAdress' table. You can move, or remove it, as needed.
            this.dilersAdressTableAdapter.Fill(this.carSellDataSet.DilersAdress);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form43 form43 = new Form43();
            form43.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.адресTableAdapter.Update(this.carSellDataSet.Адрес);
            this.улицаTableAdapter.Update(this.carSellDataSet.Улица);
            this.населенный_пунктTableAdapter.Update(this.carSellDataSet.Населенный_пункт);
        }
    }
}
