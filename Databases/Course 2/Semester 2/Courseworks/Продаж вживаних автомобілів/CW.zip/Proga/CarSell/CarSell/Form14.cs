﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;

namespace CarSell
{
    public partial class Form14 : Form
    {
        SqlConnection conn = null;
        public Form14()
        {
            InitializeComponent();
        }

        private void Form14_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Адрес' table. You can move, or remove it, as needed.
            this.адресTableAdapter.Fill(this.carSellDataSet.Адрес);
            // TODO: This line of code loads data into the 'carSellDataSet.Дилер' table. You can move, or remove it, as needed.
            this.дилерTableAdapter.Fill(this.carSellDataSet.Дилер);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form43 form43 = new Form43();
            form43.ShowDialog(this);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int codeDl = int.Parse(dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells["коддилераDataGridViewTextBoxColumn"].Value.ToString());
            DialogResult result = MessageBox.Show("Удалить дилера?", "Предупреждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            switch (result)
            {
                case DialogResult.Yes:
                    {
                        try
                        {
                            conn = new SqlConnection();
                            conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                            conn.Open();
                            SqlCommand myCommand = conn.CreateCommand();
                            myCommand.CommandText = "Delete from Дилер Where Код_дилера = @codeDl";
                            myCommand.Parameters.Add("@codeDl", SqlDbType.Int, 4);
                            myCommand.Parameters["@codeDl"].Value = codeDl;


                            int UspeshnoeIzmenenie = myCommand.ExecuteNonQuery();
                            if (UspeshnoeIzmenenie != 0)
                            {
                                MessageBox.Show("Изменения внесены", "Изменение записи");
                            }
                            else
                            {
                                MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                        finally
                        {
                            conn.Close();
                        }
                        this.дилерTableAdapter.Fill(this.carSellDataSet.Дилер);
                        break;
                    }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.дилерTableAdapter.Update(this.carSellDataSet.Дилер);
        }
    }
}
