﻿namespace CarSell
{


    partial class CarSellDataSet
    {
    }
}
