﻿namespace CarSell
{
    partial class Form16
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.кодадрисаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеобластиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.назварайонуDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиетипаНПDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типулицыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеулицыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типстроенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерстроенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типпомещенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерпомещенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.индексDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.allAdressBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carSellDataSet = new CarSell.CarSellDataSet();
            this.областьBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.районBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.типНПBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.населенныйпунктBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.типулицыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.улицаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.типстроенияBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.типпомещенияBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.allOrderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.allOrderTableAdapter = new CarSell.CarSellDataSetTableAdapters.AllOrderTableAdapter();
            this.allAdressTableAdapter = new CarSell.CarSellDataSetTableAdapters.AllAdressTableAdapter();
            this.областьTableAdapter = new CarSell.CarSellDataSetTableAdapters.ОбластьTableAdapter();
            this.районTableAdapter = new CarSell.CarSellDataSetTableAdapters.РайонTableAdapter();
            this.тип_НПTableAdapter = new CarSell.CarSellDataSetTableAdapters.Тип_НПTableAdapter();
            this.населенный_пунктTableAdapter = new CarSell.CarSellDataSetTableAdapters.Населенный_пунктTableAdapter();
            this.тип_улицыTableAdapter = new CarSell.CarSellDataSetTableAdapters.Тип_улицыTableAdapter();
            this.улицаTableAdapter = new CarSell.CarSellDataSetTableAdapters.УлицаTableAdapter();
            this.тип_строенияTableAdapter = new CarSell.CarSellDataSetTableAdapters.Тип_строенияTableAdapter();
            this.carSellDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.тип_помещенияTableAdapter = new CarSell.CarSellDataSetTableAdapters.Тип_помещенияTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.allAdressBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.областьBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.районBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типНПBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.населенныйпунктBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типулицыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.улицаBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типстроенияBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типпомещенияBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.allOrderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодадрисаDataGridViewTextBoxColumn,
            this.названиеобластиDataGridViewTextBoxColumn,
            this.назварайонуDataGridViewTextBoxColumn,
            this.названиетипаНПDataGridViewTextBoxColumn,
            this.названиеDataGridViewTextBoxColumn,
            this.типулицыDataGridViewTextBoxColumn,
            this.названиеулицыDataGridViewTextBoxColumn,
            this.типстроенияDataGridViewTextBoxColumn,
            this.номерстроенияDataGridViewTextBoxColumn,
            this.типпомещенияDataGridViewTextBoxColumn,
            this.номерпомещенияDataGridViewTextBoxColumn,
            this.индексDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.allAdressBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(1, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1242, 578);
            this.dataGridView1.TabIndex = 0;
            // 
            // кодадрисаDataGridViewTextBoxColumn
            // 
            this.кодадрисаDataGridViewTextBoxColumn.DataPropertyName = "Код_адриса";
            this.кодадрисаDataGridViewTextBoxColumn.HeaderText = "Код_адриса";
            this.кодадрисаDataGridViewTextBoxColumn.Name = "кодадрисаDataGridViewTextBoxColumn";
            // 
            // названиеобластиDataGridViewTextBoxColumn
            // 
            this.названиеобластиDataGridViewTextBoxColumn.DataPropertyName = "Название_области";
            this.названиеобластиDataGridViewTextBoxColumn.FillWeight = 150F;
            this.названиеобластиDataGridViewTextBoxColumn.HeaderText = "Название_области";
            this.названиеобластиDataGridViewTextBoxColumn.Name = "названиеобластиDataGridViewTextBoxColumn";
            this.названиеобластиDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.названиеобластиDataGridViewTextBoxColumn.Width = 150;
            // 
            // назварайонуDataGridViewTextBoxColumn
            // 
            this.назварайонуDataGridViewTextBoxColumn.DataPropertyName = "Назва_району";
            this.назварайонуDataGridViewTextBoxColumn.FillWeight = 150F;
            this.назварайонуDataGridViewTextBoxColumn.HeaderText = "Назва_району";
            this.назварайонуDataGridViewTextBoxColumn.Name = "назварайонуDataGridViewTextBoxColumn";
            this.назварайонуDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.назварайонуDataGridViewTextBoxColumn.Width = 150;
            // 
            // названиетипаНПDataGridViewTextBoxColumn
            // 
            this.названиетипаНПDataGridViewTextBoxColumn.DataPropertyName = "Название_типа_НП";
            this.названиетипаНПDataGridViewTextBoxColumn.HeaderText = "Название_типа_НП";
            this.названиетипаНПDataGridViewTextBoxColumn.Name = "названиетипаНПDataGridViewTextBoxColumn";
            this.названиетипаНПDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // названиеDataGridViewTextBoxColumn
            // 
            this.названиеDataGridViewTextBoxColumn.DataPropertyName = "Название";
            this.названиеDataGridViewTextBoxColumn.FillWeight = 150F;
            this.названиеDataGridViewTextBoxColumn.HeaderText = "Название НП";
            this.названиеDataGridViewTextBoxColumn.Name = "названиеDataGridViewTextBoxColumn";
            this.названиеDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.названиеDataGridViewTextBoxColumn.Width = 150;
            // 
            // типулицыDataGridViewTextBoxColumn
            // 
            this.типулицыDataGridViewTextBoxColumn.DataPropertyName = "Тип_улицы";
            this.типулицыDataGridViewTextBoxColumn.HeaderText = "Тип_улицы";
            this.типулицыDataGridViewTextBoxColumn.Name = "типулицыDataGridViewTextBoxColumn";
            this.типулицыDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // названиеулицыDataGridViewTextBoxColumn
            // 
            this.названиеулицыDataGridViewTextBoxColumn.DataPropertyName = "Название_улицы";
            this.названиеулицыDataGridViewTextBoxColumn.FillWeight = 150F;
            this.названиеулицыDataGridViewTextBoxColumn.HeaderText = "Название_улицы";
            this.названиеулицыDataGridViewTextBoxColumn.Name = "названиеулицыDataGridViewTextBoxColumn";
            this.названиеулицыDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.названиеулицыDataGridViewTextBoxColumn.Width = 150;
            // 
            // типстроенияDataGridViewTextBoxColumn
            // 
            this.типстроенияDataGridViewTextBoxColumn.DataPropertyName = "Тип_строения";
            this.типстроенияDataGridViewTextBoxColumn.HeaderText = "Тип_строения";
            this.типстроенияDataGridViewTextBoxColumn.Name = "типстроенияDataGridViewTextBoxColumn";
            this.типстроенияDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // номерстроенияDataGridViewTextBoxColumn
            // 
            this.номерстроенияDataGridViewTextBoxColumn.DataPropertyName = "Номер_строения";
            this.номерстроенияDataGridViewTextBoxColumn.HeaderText = "Номер_строения";
            this.номерстроенияDataGridViewTextBoxColumn.Name = "номерстроенияDataGridViewTextBoxColumn";
            // 
            // типпомещенияDataGridViewTextBoxColumn
            // 
            this.типпомещенияDataGridViewTextBoxColumn.DataPropertyName = "Тип_помещения";
            this.типпомещенияDataGridViewTextBoxColumn.HeaderText = "Тип_помещения";
            this.типпомещенияDataGridViewTextBoxColumn.Name = "типпомещенияDataGridViewTextBoxColumn";
            this.типпомещенияDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // номерпомещенияDataGridViewTextBoxColumn
            // 
            this.номерпомещенияDataGridViewTextBoxColumn.DataPropertyName = "Номер_помещения";
            this.номерпомещенияDataGridViewTextBoxColumn.HeaderText = "Номер_помещения";
            this.номерпомещенияDataGridViewTextBoxColumn.Name = "номерпомещенияDataGridViewTextBoxColumn";
            // 
            // индексDataGridViewTextBoxColumn
            // 
            this.индексDataGridViewTextBoxColumn.DataPropertyName = "Индекс";
            this.индексDataGridViewTextBoxColumn.HeaderText = "Индекс";
            this.индексDataGridViewTextBoxColumn.Name = "индексDataGridViewTextBoxColumn";
            // 
            // allAdressBindingSource
            // 
            this.allAdressBindingSource.DataMember = "AllAdress";
            this.allAdressBindingSource.DataSource = this.carSellDataSet;
            // 
            // carSellDataSet
            // 
            this.carSellDataSet.DataSetName = "CarSellDataSet";
            this.carSellDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // областьBindingSource
            // 
            this.областьBindingSource.DataMember = "Область";
            this.областьBindingSource.DataSource = this.carSellDataSet;
            // 
            // районBindingSource
            // 
            this.районBindingSource.DataMember = "Район";
            this.районBindingSource.DataSource = this.carSellDataSet;
            // 
            // типНПBindingSource
            // 
            this.типНПBindingSource.DataMember = "Тип_НП";
            this.типНПBindingSource.DataSource = this.carSellDataSet;
            // 
            // населенныйпунктBindingSource
            // 
            this.населенныйпунктBindingSource.DataMember = "Населенный_пункт";
            this.населенныйпунктBindingSource.DataSource = this.carSellDataSet;
            // 
            // типулицыBindingSource
            // 
            this.типулицыBindingSource.DataMember = "Тип_улицы";
            this.типулицыBindingSource.DataSource = this.carSellDataSet;
            // 
            // улицаBindingSource
            // 
            this.улицаBindingSource.DataMember = "Улица";
            this.улицаBindingSource.DataSource = this.carSellDataSet;
            // 
            // типстроенияBindingSource
            // 
            this.типстроенияBindingSource.DataMember = "Тип_строения";
            this.типстроенияBindingSource.DataSource = this.carSellDataSet;
            // 
            // типпомещенияBindingSource
            // 
            this.типпомещенияBindingSource.DataMember = "Тип_помещения";
            this.типпомещенияBindingSource.DataSource = this.carSellDataSet;
            // 
            // allOrderBindingSource
            // 
            this.allOrderBindingSource.DataMember = "AllOrder";
            this.allOrderBindingSource.DataSource = this.carSellDataSet;
            // 
            // allOrderTableAdapter
            // 
            this.allOrderTableAdapter.ClearBeforeFill = true;
            // 
            // allAdressTableAdapter
            // 
            this.allAdressTableAdapter.ClearBeforeFill = true;
            // 
            // областьTableAdapter
            // 
            this.областьTableAdapter.ClearBeforeFill = true;
            // 
            // районTableAdapter
            // 
            this.районTableAdapter.ClearBeforeFill = true;
            // 
            // тип_НПTableAdapter
            // 
            this.тип_НПTableAdapter.ClearBeforeFill = true;
            // 
            // населенный_пунктTableAdapter
            // 
            this.населенный_пунктTableAdapter.ClearBeforeFill = true;
            // 
            // тип_улицыTableAdapter
            // 
            this.тип_улицыTableAdapter.ClearBeforeFill = true;
            // 
            // улицаTableAdapter
            // 
            this.улицаTableAdapter.ClearBeforeFill = true;
            // 
            // тип_строенияTableAdapter
            // 
            this.тип_строенияTableAdapter.ClearBeforeFill = true;
            // 
            // carSellDataSetBindingSource
            // 
            this.carSellDataSetBindingSource.DataSource = this.carSellDataSet;
            this.carSellDataSetBindingSource.Position = 0;
            // 
            // тип_помещенияTableAdapter
            // 
            this.тип_помещенияTableAdapter.ClearBeforeFill = true;
            // 
            // Form16
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1245, 579);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form16";
            this.Text = "Form16";
            this.Load += new System.EventHandler(this.Form16_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.allAdressBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.областьBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.районBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типНПBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.населенныйпунктBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типулицыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.улицаBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типстроенияBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типпомещенияBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.allOrderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSetBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CarSellDataSet carSellDataSet;
        private System.Windows.Forms.BindingSource allOrderBindingSource;
        private CarSellDataSetTableAdapters.AllOrderTableAdapter allOrderTableAdapter;
        private System.Windows.Forms.BindingSource allAdressBindingSource;
        private CarSellDataSetTableAdapters.AllAdressTableAdapter allAdressTableAdapter;
        private System.Windows.Forms.BindingSource областьBindingSource;
        private CarSellDataSetTableAdapters.ОбластьTableAdapter областьTableAdapter;
        private System.Windows.Forms.BindingSource районBindingSource;
        private CarSellDataSetTableAdapters.РайонTableAdapter районTableAdapter;
        private System.Windows.Forms.BindingSource типНПBindingSource;
        private CarSellDataSetTableAdapters.Тип_НПTableAdapter тип_НПTableAdapter;
        private System.Windows.Forms.BindingSource населенныйпунктBindingSource;
        private CarSellDataSetTableAdapters.Населенный_пунктTableAdapter населенный_пунктTableAdapter;
        private System.Windows.Forms.BindingSource типулицыBindingSource;
        private CarSellDataSetTableAdapters.Тип_улицыTableAdapter тип_улицыTableAdapter;
        private System.Windows.Forms.BindingSource улицаBindingSource;
        private CarSellDataSetTableAdapters.УлицаTableAdapter улицаTableAdapter;
        private System.Windows.Forms.BindingSource типстроенияBindingSource;
        private CarSellDataSetTableAdapters.Тип_строенияTableAdapter тип_строенияTableAdapter;
        private System.Windows.Forms.BindingSource carSellDataSetBindingSource;
        private System.Windows.Forms.BindingSource типпомещенияBindingSource;
        private CarSellDataSetTableAdapters.Тип_помещенияTableAdapter тип_помещенияTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодадрисаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеобластиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn назварайонуDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиетипаНПDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn типулицыDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеулицыDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn типстроенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерстроенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn типпомещенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерпомещенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn индексDataGridViewTextBoxColumn;
    }
}