﻿namespace CarSell
{
    partial class Form44
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.carSellDataSet = new CarSell.CarSellDataSet();
            this.dgCountDlBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dgCountDlTableAdapter = new CarSell.CarSellDataSetTableAdapters.DgCountDlTableAdapter();
            this.коддилераDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.дилерDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.количествоДоговоровDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgCountDlBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.коддилераDataGridViewTextBoxColumn,
            this.дилерDataGridViewTextBoxColumn,
            this.количествоДоговоровDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.dgCountDlBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(-1, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(630, 354);
            this.dataGridView1.TabIndex = 0;
            // 
            // carSellDataSet
            // 
            this.carSellDataSet.DataSetName = "CarSellDataSet";
            this.carSellDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dgCountDlBindingSource
            // 
            this.dgCountDlBindingSource.DataMember = "DgCountDl";
            this.dgCountDlBindingSource.DataSource = this.carSellDataSet;
            // 
            // dgCountDlTableAdapter
            // 
            this.dgCountDlTableAdapter.ClearBeforeFill = true;
            // 
            // коддилераDataGridViewTextBoxColumn
            // 
            this.коддилераDataGridViewTextBoxColumn.DataPropertyName = "Код_дилера";
            this.коддилераDataGridViewTextBoxColumn.HeaderText = "Код_дилера";
            this.коддилераDataGridViewTextBoxColumn.Name = "коддилераDataGridViewTextBoxColumn";
            // 
            // дилерDataGridViewTextBoxColumn
            // 
            this.дилерDataGridViewTextBoxColumn.DataPropertyName = "Дилер";
            this.дилерDataGridViewTextBoxColumn.HeaderText = "Дилер";
            this.дилерDataGridViewTextBoxColumn.Name = "дилерDataGridViewTextBoxColumn";
            this.дилерDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // количествоДоговоровDataGridViewTextBoxColumn
            // 
            this.количествоДоговоровDataGridViewTextBoxColumn.DataPropertyName = "Количество договоров";
            this.количествоДоговоровDataGridViewTextBoxColumn.FillWeight = 150F;
            this.количествоДоговоровDataGridViewTextBoxColumn.HeaderText = "Количество договоров";
            this.количествоДоговоровDataGridViewTextBoxColumn.Name = "количествоДоговоровDataGridViewTextBoxColumn";
            this.количествоДоговоровDataGridViewTextBoxColumn.Width = 150;
            // 
            // Form44
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(628, 352);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form44";
            this.Text = "Form44";
            this.Load += new System.EventHandler(this.Form44_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgCountDlBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CarSellDataSet carSellDataSet;
        private System.Windows.Forms.BindingSource dgCountDlBindingSource;
        private CarSellDataSetTableAdapters.DgCountDlTableAdapter dgCountDlTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn коддилераDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn дилерDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоДоговоровDataGridViewTextBoxColumn;
    }
}