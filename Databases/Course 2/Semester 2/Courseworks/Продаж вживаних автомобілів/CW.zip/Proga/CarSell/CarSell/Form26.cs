﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSell
{
    public partial class Form26 : Form
    {
        public Form26()
        {
            InitializeComponent();
        }

        private void Form26_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Телефон' table. You can move, or remove it, as needed.
            this.телефонTableAdapter.Fill(this.carSellDataSet.Телефон);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form50 form50 = new Form50();
            form50.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.телефонTableAdapter.Update(this.carSellDataSet.Телефон);
        }
    }
}
