﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;
using System.Data.Sql;
namespace CarSell
{
    public partial class Form56 : Form
    {
        SqlConnection conn = null;
        public Form56()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
                try
                {
                    string nameBrand = Convert.ToString(this.textBox1.Text);
                    

                    conn = new SqlConnection();
                    conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                    conn.Open();

                    SqlCommand myComand = conn.CreateCommand();
                    myComand.CommandText = "INSERT into Марка_авто (Марка) VALUES (@nameBrand)";
                    

                    myComand.Parameters.Add("@nameBrand", SqlDbType.NVarChar, 20);
                    myComand.Parameters["@nameBrand"].Value = nameBrand;
                
                int UspeshnoeIzmenenie = myComand.ExecuteNonQuery();
                if (UspeshnoeIzmenenie != 0)

                    {
                         MessageBox.Show("Изменения внесены", "Изменение записи");
                    }
                else
                    {
                        MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                    }
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                finally
                {
                    conn.Close();
                }
                this.марка_автоTableAdapter1.Fill(this.carSellDataSet1.Марка_авто);
                

            try
            {
                string nameModel = Convert.ToString(this.textBox2.Text);
                conn = new SqlConnection();
                conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                conn.Open();

                SqlCommand myComand = conn.CreateCommand();
                myComand.CommandText = "INSERT into Модель_авто (Модель) VALUES (@nameModel)";
                myComand.Parameters.Add("@nameModel", SqlDbType.NVarChar, 20);
                myComand.Parameters["@nameModel"].Value = nameModel;
                int UspeshnoeIzmenenie = myComand.ExecuteNonQuery();
                if (UspeshnoeIzmenenie != 0)

                {
                    
                }
                else
                {
                    
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            this.модель_автоTableAdapter1.Fill(this.carSellDataSet1.Модель_авто);

            this.lastBrandTableAdapter.Fill(this.carSellDataSet1.LastBrand);
            this.lastModelTableAdapter.Fill(this.carSellDataSet1.LastModel);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int codeBrand = int.Parse(this.comboBox1.SelectedValue.ToString());
                int codeModel = int.Parse(this.comboBox2.SelectedValue.ToString());

                conn = new SqlConnection();
                conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                conn.Open();

                SqlCommand myComand = conn.CreateCommand();
                myComand.CommandText = "INSERT into Марка_модель (Код_марки, Код_модели) VALUES (@codeBrand, @codeModel)";


                myComand.Parameters.Add("@codeBrand", SqlDbType.Int, 4);
                myComand.Parameters["@codeBrand"].Value = codeBrand;

                myComand.Parameters.Add("@codeModel", SqlDbType.Int, 4);
                myComand.Parameters["@codeModel"].Value = codeModel;

                int UspeshnoeIzmenenie = myComand.ExecuteNonQuery();
                if (UspeshnoeIzmenenie != 0)

                {
                    MessageBox.Show("Изменения внесены", "Изменение записи");
                }
                else
                {
                    MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            this.марка_модельTableAdapter1.Fill(this.carSellDataSet1.Марка_модель);
            
        }

        private void Form56_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet1.LastModel' table. You can move, or remove it, as needed.
            this.lastModelTableAdapter.Fill(this.carSellDataSet1.LastModel);
            // TODO: This line of code loads data into the 'carSellDataSet1.LastBrand' table. You can move, or remove it, as needed.
            this.lastBrandTableAdapter.Fill(this.carSellDataSet1.LastBrand);
            // TODO: This line of code loads data into the 'carSellDataSet1.CarBrand' table. You can move, or remove it, as needed.
            this.carBrandTableAdapter.Fill(this.carSellDataSet1.CarBrand);
            // TODO: This line of code loads data into the 'carSellDataSet1.Brand_model' table. You can move, or remove it, as needed.
            this.brand_modelTableAdapter.Fill(this.carSellDataSet1.Brand_model);

        }
    }

    }

