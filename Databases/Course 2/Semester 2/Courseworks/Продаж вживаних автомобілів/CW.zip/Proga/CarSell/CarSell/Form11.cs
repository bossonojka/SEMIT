﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;


namespace CarSell
{
    public partial class Form11 : Form
    {
        SqlConnection conn = null;
        public Form11()
        {
            InitializeComponent();
        }

        private void Form11_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Цвет' table. You can move, or remove it, as needed.
            this.цветTableAdapter.Fill(this.carSellDataSet.Цвет);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form61 form61 = new Form61();
            form61.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int codeCar = int.Parse(dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells["кодцветаDataGridViewTextBoxColumn"].Value.ToString());
            DialogResult result = MessageBox.Show("Удалить цвет автомобиля клиента?", "Предупреждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            switch (result)
            {
                case DialogResult.Yes:
                    {
                        try
                        {
                            conn = new SqlConnection();
                            conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                            conn.Open();
                            SqlCommand myCommand = conn.CreateCommand();
                            myCommand.CommandText = "Delete from Цвет Where Код_цвета = @codeCar";
                            myCommand.Parameters.Add("@codeCar", SqlDbType.Int, 4);
                            myCommand.Parameters["@codeCar"].Value = codeCar;


                            int UspeshnoeIzmenenie = myCommand.ExecuteNonQuery();
                            if (UspeshnoeIzmenenie != 0)
                            {
                                MessageBox.Show("Изменения внесены", "Изменение записи");
                            }
                            else
                            {
                                MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                        finally
                        {
                            conn.Close();
                        }
                        this.цветTableAdapter.Fill(this.carSellDataSet.Цвет);
                        break;
                    }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.цветTableAdapter.Update(this.carSellDataSet.Цвет);
        }
    }
}
