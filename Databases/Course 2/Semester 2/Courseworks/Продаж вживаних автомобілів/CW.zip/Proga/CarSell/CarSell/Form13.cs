﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Sql;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;
using System.Data;
using System.Data.Entity;

namespace CarSell
{
    public partial class Form13 : Form
    {
        SqlConnection conn = null;
        public Form13()
        {
            InitializeComponent();
        }

         
        private void Form13_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet1.Тип_ТС' table. You can move, or remove it, as needed.
            this.тип_ТСTableAdapter1.Fill(this.carSellDataSet1.Тип_ТС);
            // TODO: This line of code loads data into the 'carSellDataSet.InfAbCar' table. You can move, or remove it, as needed.
            this.infAbCarTableAdapter1.Fill(this.carSellDataSet.InfAbCar);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form42 form42 = new Form42();
            form42.ShowDialog(this);
            this.infAbCarTableAdapter1.Fill(this.carSellDataSet.InfAbCar);
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int codeCar = int.Parse(dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells["кодавтомобиляDataGridViewTextBoxColumn"].Value.ToString());
            DialogResult result = MessageBox.Show("Удалить автомобиль клиента?", "Предупреждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            switch (result)
            {
                case DialogResult.Yes:
                    {
                        try
                        {
                            conn = new SqlConnection();
                            conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                            conn.Open();
                            SqlCommand myCommand = conn.CreateCommand();
                            myCommand.CommandText = "Delete from Автомобиль Where Код_автомобиля = @codeCar";
                            myCommand.Parameters.Add("@codeCar", SqlDbType.Int, 4);
                            myCommand.Parameters["@codeCar"].Value = codeCar;


                            int UspeshnoeIzmenenie = myCommand.ExecuteNonQuery();
                            if (UspeshnoeIzmenenie != 0)
                            {
                                MessageBox.Show("Изменения внесены", "Изменение записи");
                            }
                            else
                            {
                                MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                        finally
                        {
                            conn.Close();
                        }
                        this.автомобильTableAdapter1.Fill(this.carSellDataSet.Автомобиль);
                        this.infAbCarTableAdapter1.Fill(this.carSellDataSet.InfAbCar);
                        break;
                    }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Refresh();
            Application.DoEvents();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        

        private void brandToolStripTextBox_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.автомобильTableAdapter1.Update(this.carSellDataSet.Автомобиль);
        }

        /* try
         {
             if (MessageBox.Show("Вы действительно хотите удалить этот автомобиль?\nВсе связанные данные будут удалены", "Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
             {
                 int index = dataGridView1.CurrentCell.RowIndex;
                 CarSellEntities context = new CarSellEntities();
                 //CourseWorkBDEntities context = new CourseWorkBDEntities();
                 int kod = int.Parse(dataGridView1.Rows[index].Cells["кодавтомобиляDataGridViewTextBoxColumn"].Value.ToString());
                 context.Автомобиль.Remove(context.Автомобиль.Find(kod));
                 context.SaveChanges();
                 this.автомобильTableAdapter1.Fill(this.carSellDataSet.Автомобиль);
                 dataGridView1.Refresh();
             }
         }
         catch { }*/

        /* DialogResult result = MessageBox.Show("Удалить автомобиль клиента?", "Предупреждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
         switch (result)
         {
            case DialogResult.Yes:
                 {
                     int rowIndex = dataGridView1.CurrentCell.RowIndex;
                     dataGridView1.Rows.RemoveAt(rowIndex);
                 }
                break;
         }
         conn = new SqlConnection();
         conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";

         SqlCommand myComand = conn.CreateCommand();
         string Car = "DELETE From Автомобиль (Код_клиента_продавца, Код_типа_ТС, Код_марки, Код_модели, " +
             "Код_типа_кузова, Код_года_выпуска_от, Код_года_выпуска_до, Код_диапазона_объема_двигателя, " +
             "Код_диапазона_мощности, Код_диапазона_пробега, Код_цвета, Код_диапазона_цены, VIN_код_кузова)";

         SqlCommand sqlCommand = new SqlCommand(Car, conn);
         SqlDataReader myReader;
         try
         {
             conn.Open();
             myReader = sqlCommand.ExecuteReader();
             MessageBox.Show("Изменения внесены", "Изменение записи");
             while (myReader.Read())
             {

             }

         }
         catch (Exception ex)
         {
             MessageBox.Show(ex.Message);
         }*/
    }

        
    }

