﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;

namespace CarSell
{
    public partial class Form12 : Form
    {
        SqlConnection conn = null;
        public Form12()
        {
            InitializeComponent();
        }

        private void Form12_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Диапазон_цены' table. You can move, or remove it, as needed.
            this.диапазон_ценыTableAdapter.Fill(this.carSellDataSet.Диапазон_цены);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form62 form62 = new Form62();
            form62.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int codeCar = int.Parse(dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells["коддиапазонаценыDataGridViewTextBoxColumn"].Value.ToString());
            DialogResult result = MessageBox.Show("Удалить цену на автомобиль???", "Предупреждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            switch (result)
            {
                case DialogResult.Yes:
                    {
                        try
                        {
                            conn = new SqlConnection();
                            conn.ConnectionString = "integrated security=SSPI;data source=\".\"; persist security info=False;initial catalog=CarSell";
                            conn.Open();
                            SqlCommand myCommand = conn.CreateCommand();
                            myCommand.CommandText = "Delete from Диапазон_цены Where Код_диапазона_цены = @codeCar";
                            myCommand.Parameters.Add("@codeCar", SqlDbType.Int, 4);
                            myCommand.Parameters["@codeCar"].Value = codeCar;


                            int UspeshnoeIzmenenie = myCommand.ExecuteNonQuery();
                            if (UspeshnoeIzmenenie != 0)
                            {
                                MessageBox.Show("Изменения внесены", "Изменение записи");
                            }
                            else
                            {
                                MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                        finally
                        {
                            conn.Close();
                        }
                        this.диапазон_ценыTableAdapter.Fill(this.carSellDataSet.Диапазон_цены);
                        break;
                    }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.диапазон_ценыTableAdapter.Update(this.carSellDataSet.Диапазон_цены);
        }
    }
}
