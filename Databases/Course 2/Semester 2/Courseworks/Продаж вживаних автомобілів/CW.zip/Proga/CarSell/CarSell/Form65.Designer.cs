﻿namespace CarSell
{
    partial class Form65
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.fullDlNameBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carSellDataSet = new CarSell.CarSellDataSet();
            this.fullDlNameTableAdapter = new CarSell.CarSellDataSetTableAdapters.FullDlNameTableAdapter();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.allOrderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.sellKlientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.buyKlientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.sellKlientTableAdapter = new CarSell.CarSellDataSetTableAdapters.SellKlientTableAdapter();
            this.buyKlientTableAdapter = new CarSell.CarSellDataSetTableAdapters.BuyKlientTableAdapter();
            this.маркамодельBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.марка_модельTableAdapter = new CarSell.CarSellDataSetTableAdapters.Марка_модельTableAdapter();
            this.carsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.shortCarsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sellKlCarsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.автомобильBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carsNameBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.allOrderTableAdapter = new CarSell.CarSellDataSetTableAdapters.AllOrderTableAdapter();
            this.автомобильTableAdapter = new CarSell.CarSellDataSetTableAdapters.АвтомобильTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.кодзаказаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодклиентапокупателяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.клиентDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типТСDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.маркаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.модельDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типкузоваDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.годвыпускаотDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.годвыпускадоDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.диапазонобъемадвигателяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.диапазонмощностиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.диапазонпробегаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.цветDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.диапазонценыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Автомобиль = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.infAbCarBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.infAbCarTableAdapter = new CarSell.CarSellDataSetTableAdapters.InfAbCarTableAdapter();
            this.sellKlCarsTableAdapter = new CarSell.CarSellDataSetTableAdapters.SellKlCarsTableAdapter();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.shortCarsTableAdapter = new CarSell.CarSellDataSetTableAdapters.ShortCarsTableAdapter();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.кодавтомобиляDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодклиентапродавцаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.клиентПродавецDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.автомобильDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carsHaventContractsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carsHaventContractsTableAdapter = new CarSell.CarSellDataSetTableAdapters.CarsHaventContractsTableAdapter();
            this.договорTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.ДоговорTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.fullDlNameBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.allOrderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellKlientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.buyKlientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.маркамодельBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shortCarsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellKlCarsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.автомобильBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carsNameBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.infAbCarBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carsHaventContractsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(245, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Дилер";
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.fullDlNameBindingSource;
            this.comboBox1.DisplayMember = "Дилер";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(245, 48);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(209, 21);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.ValueMember = "Код_дилера";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // fullDlNameBindingSource
            // 
            this.fullDlNameBindingSource.DataMember = "FullDlName";
            this.fullDlNameBindingSource.DataSource = this.carSellDataSet;
            // 
            // carSellDataSet
            // 
            this.carSellDataSet.DataSetName = "CarSellDataSet";
            this.carSellDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // fullDlNameTableAdapter
            // 
            this.fullDlNameTableAdapter.ClearBeforeFill = true;
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.allOrderBindingSource;
            this.comboBox2.DisplayMember = "Код_заказа";
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(488, 48);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(172, 21);
            this.comboBox2.TabIndex = 3;
            this.comboBox2.ValueMember = "Код_заказа";
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // allOrderBindingSource
            // 
            this.allOrderBindingSource.DataMember = "AllOrder";
            this.allOrderBindingSource.DataSource = this.carSellDataSet;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(484, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Код заказа";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(702, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(179, 24);
            this.label3.TabIndex = 4;
            this.label3.Text = "Клиент - продавец";
            // 
            // comboBox3
            // 
            this.comboBox3.DataSource = this.sellKlientBindingSource;
            this.comboBox3.DisplayMember = "Клиент - продавец";
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(706, 48);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(205, 21);
            this.comboBox3.TabIndex = 5;
            this.comboBox3.ValueMember = "Код_клиента_продавца";
            // 
            // sellKlientBindingSource
            // 
            this.sellKlientBindingSource.DataMember = "SellKlient";
            this.sellKlientBindingSource.DataSource = this.carSellDataSet;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(954, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(194, 24);
            this.label4.TabIndex = 6;
            this.label4.Text = "Клиент - покупатель";
            // 
            // comboBox4
            // 
            this.comboBox4.DataSource = this.buyKlientBindingSource;
            this.comboBox4.DisplayMember = "Клиент - покупатель";
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(958, 48);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(205, 21);
            this.comboBox4.TabIndex = 7;
            this.comboBox4.ValueMember = "Код_клиента_покупателя";
            // 
            // buyKlientBindingSource
            // 
            this.buyKlientBindingSource.DataMember = "BuyKlient";
            this.buyKlientBindingSource.DataSource = this.carSellDataSet;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(245, 107);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(158, 24);
            this.label5.TabIndex = 8;
            this.label5.Text = "Код автомобиля";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(484, 116);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(256, 24);
            this.label6.TabIndex = 10;
            this.label6.Text = "Дата заключения договора";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(488, 152);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(252, 20);
            this.dateTimePicker1.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(777, 116);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(163, 24);
            this.label7.TabIndex = 12;
            this.label7.Text = "Цена сделки, грн";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(781, 153);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(139, 20);
            this.textBox1.TabIndex = 13;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(958, 153);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(316, 20);
            this.textBox2.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(954, 116);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(320, 24);
            this.label8.TabIndex = 14;
            this.label8.Text = "Размер комиссионных для дилера";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gold;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(686, 235);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(169, 36);
            this.button1.TabIndex = 16;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // sellKlientTableAdapter
            // 
            this.sellKlientTableAdapter.ClearBeforeFill = true;
            // 
            // buyKlientTableAdapter
            // 
            this.buyKlientTableAdapter.ClearBeforeFill = true;
            // 
            // марка_модельTableAdapter
            // 
            this.марка_модельTableAdapter.ClearBeforeFill = true;
            // 
            // carsBindingSource
            // 
            this.carsBindingSource.DataSource = this.carSellDataSet;
            this.carsBindingSource.Position = 0;
            // 
            // carsBindingSource1
            // 
            this.carsBindingSource1.DataSource = this.carSellDataSet;
            this.carsBindingSource1.Position = 0;
            // 
            // comboBox5
            // 
            this.comboBox5.DataSource = this.shortCarsBindingSource;
            this.comboBox5.DisplayMember = "Автомобиль";
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(249, 152);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(205, 21);
            this.comboBox5.TabIndex = 17;
            this.comboBox5.ValueMember = "Код_автомобиля";
            // 
            // shortCarsBindingSource
            // 
            this.shortCarsBindingSource.DataMember = "ShortCars";
            this.shortCarsBindingSource.DataSource = this.carSellDataSet;
            // 
            // sellKlCarsBindingSource
            // 
            this.sellKlCarsBindingSource.DataMember = "SellKlCars";
            this.sellKlCarsBindingSource.DataSource = this.carSellDataSet;
            // 
            // автомобильBindingSource
            // 
            this.автомобильBindingSource.DataMember = "Автомобиль";
            this.автомобильBindingSource.DataSource = this.carSellDataSet;
            // 
            // carsNameBindingSource
            // 
            this.carsNameBindingSource.DataSource = this.carSellDataSet;
            this.carsNameBindingSource.Position = 0;
            // 
            // allOrderTableAdapter
            // 
            this.allOrderTableAdapter.ClearBeforeFill = true;
            // 
            // автомобильTableAdapter
            // 
            this.автомобильTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодзаказаDataGridViewTextBoxColumn,
            this.кодклиентапокупателяDataGridViewTextBoxColumn,
            this.клиентDataGridViewTextBoxColumn,
            this.типТСDataGridViewTextBoxColumn,
            this.маркаDataGridViewTextBoxColumn,
            this.модельDataGridViewTextBoxColumn,
            this.типкузоваDataGridViewTextBoxColumn,
            this.годвыпускаотDataGridViewTextBoxColumn,
            this.годвыпускадоDataGridViewTextBoxColumn,
            this.диапазонобъемадвигателяDataGridViewTextBoxColumn,
            this.диапазонмощностиDataGridViewTextBoxColumn,
            this.диапазонпробегаDataGridViewTextBoxColumn,
            this.цветDataGridViewTextBoxColumn,
            this.диапазонценыDataGridViewTextBoxColumn,
            this.Автомобиль});
            this.dataGridView1.DataSource = this.allOrderBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(1, 382);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(765, 194);
            this.dataGridView1.TabIndex = 18;
            // 
            // кодзаказаDataGridViewTextBoxColumn
            // 
            this.кодзаказаDataGridViewTextBoxColumn.DataPropertyName = "Код_заказа";
            this.кодзаказаDataGridViewTextBoxColumn.HeaderText = "Код_заказа";
            this.кодзаказаDataGridViewTextBoxColumn.Name = "кодзаказаDataGridViewTextBoxColumn";
            // 
            // кодклиентапокупателяDataGridViewTextBoxColumn
            // 
            this.кодклиентапокупателяDataGridViewTextBoxColumn.DataPropertyName = "Код_клиента_покупателя";
            this.кодклиентапокупателяDataGridViewTextBoxColumn.FillWeight = 150F;
            this.кодклиентапокупателяDataGridViewTextBoxColumn.HeaderText = "Код_клиента_покупателя";
            this.кодклиентапокупателяDataGridViewTextBoxColumn.Name = "кодклиентапокупателяDataGridViewTextBoxColumn";
            this.кодклиентапокупателяDataGridViewTextBoxColumn.Width = 150;
            // 
            // клиентDataGridViewTextBoxColumn
            // 
            this.клиентDataGridViewTextBoxColumn.DataPropertyName = "Клиент";
            this.клиентDataGridViewTextBoxColumn.FillWeight = 200F;
            this.клиентDataGridViewTextBoxColumn.HeaderText = "Клиент";
            this.клиентDataGridViewTextBoxColumn.Name = "клиентDataGridViewTextBoxColumn";
            this.клиентDataGridViewTextBoxColumn.ReadOnly = true;
            this.клиентDataGridViewTextBoxColumn.Width = 200;
            // 
            // типТСDataGridViewTextBoxColumn
            // 
            this.типТСDataGridViewTextBoxColumn.DataPropertyName = "Тип_ТС";
            this.типТСDataGridViewTextBoxColumn.HeaderText = "Тип_ТС";
            this.типТСDataGridViewTextBoxColumn.Name = "типТСDataGridViewTextBoxColumn";
            // 
            // маркаDataGridViewTextBoxColumn
            // 
            this.маркаDataGridViewTextBoxColumn.DataPropertyName = "Марка";
            this.маркаDataGridViewTextBoxColumn.FillWeight = 120F;
            this.маркаDataGridViewTextBoxColumn.HeaderText = "Марка";
            this.маркаDataGridViewTextBoxColumn.Name = "маркаDataGridViewTextBoxColumn";
            this.маркаDataGridViewTextBoxColumn.Width = 120;
            // 
            // модельDataGridViewTextBoxColumn
            // 
            this.модельDataGridViewTextBoxColumn.DataPropertyName = "Модель";
            this.модельDataGridViewTextBoxColumn.HeaderText = "Модель";
            this.модельDataGridViewTextBoxColumn.Name = "модельDataGridViewTextBoxColumn";
            // 
            // типкузоваDataGridViewTextBoxColumn
            // 
            this.типкузоваDataGridViewTextBoxColumn.DataPropertyName = "Тип_кузова";
            this.типкузоваDataGridViewTextBoxColumn.HeaderText = "Тип_кузова";
            this.типкузоваDataGridViewTextBoxColumn.Name = "типкузоваDataGridViewTextBoxColumn";
            // 
            // годвыпускаотDataGridViewTextBoxColumn
            // 
            this.годвыпускаотDataGridViewTextBoxColumn.DataPropertyName = "Год_выпуска_от";
            this.годвыпускаотDataGridViewTextBoxColumn.FillWeight = 130F;
            this.годвыпускаотDataGridViewTextBoxColumn.HeaderText = "Год_выпуска_от";
            this.годвыпускаотDataGridViewTextBoxColumn.Name = "годвыпускаотDataGridViewTextBoxColumn";
            this.годвыпускаотDataGridViewTextBoxColumn.Width = 130;
            // 
            // годвыпускадоDataGridViewTextBoxColumn
            // 
            this.годвыпускадоDataGridViewTextBoxColumn.DataPropertyName = "Год_выпуска_до";
            this.годвыпускадоDataGridViewTextBoxColumn.FillWeight = 130F;
            this.годвыпускадоDataGridViewTextBoxColumn.HeaderText = "Год_выпуска_до";
            this.годвыпускадоDataGridViewTextBoxColumn.Name = "годвыпускадоDataGridViewTextBoxColumn";
            this.годвыпускадоDataGridViewTextBoxColumn.Width = 130;
            // 
            // диапазонобъемадвигателяDataGridViewTextBoxColumn
            // 
            this.диапазонобъемадвигателяDataGridViewTextBoxColumn.DataPropertyName = "Диапазон_объема_двигателя";
            this.диапазонобъемадвигателяDataGridViewTextBoxColumn.FillWeight = 150F;
            this.диапазонобъемадвигателяDataGridViewTextBoxColumn.HeaderText = "Диапазон_объема_двигателя";
            this.диапазонобъемадвигателяDataGridViewTextBoxColumn.Name = "диапазонобъемадвигателяDataGridViewTextBoxColumn";
            this.диапазонобъемадвигателяDataGridViewTextBoxColumn.Width = 150;
            // 
            // диапазонмощностиDataGridViewTextBoxColumn
            // 
            this.диапазонмощностиDataGridViewTextBoxColumn.DataPropertyName = "Диапазон_мощности";
            this.диапазонмощностиDataGridViewTextBoxColumn.FillWeight = 130F;
            this.диапазонмощностиDataGridViewTextBoxColumn.HeaderText = "Диапазон_мощности";
            this.диапазонмощностиDataGridViewTextBoxColumn.Name = "диапазонмощностиDataGridViewTextBoxColumn";
            this.диапазонмощностиDataGridViewTextBoxColumn.Width = 130;
            // 
            // диапазонпробегаDataGridViewTextBoxColumn
            // 
            this.диапазонпробегаDataGridViewTextBoxColumn.DataPropertyName = "Диапазон_пробега";
            this.диапазонпробегаDataGridViewTextBoxColumn.FillWeight = 130F;
            this.диапазонпробегаDataGridViewTextBoxColumn.HeaderText = "Диапазон_пробега";
            this.диапазонпробегаDataGridViewTextBoxColumn.Name = "диапазонпробегаDataGridViewTextBoxColumn";
            this.диапазонпробегаDataGridViewTextBoxColumn.Width = 130;
            // 
            // цветDataGridViewTextBoxColumn
            // 
            this.цветDataGridViewTextBoxColumn.DataPropertyName = "Цвет";
            this.цветDataGridViewTextBoxColumn.FillWeight = 110F;
            this.цветDataGridViewTextBoxColumn.HeaderText = "Цвет";
            this.цветDataGridViewTextBoxColumn.Name = "цветDataGridViewTextBoxColumn";
            this.цветDataGridViewTextBoxColumn.Width = 110;
            // 
            // диапазонценыDataGridViewTextBoxColumn
            // 
            this.диапазонценыDataGridViewTextBoxColumn.DataPropertyName = "Диапазон_цены";
            this.диапазонценыDataGridViewTextBoxColumn.FillWeight = 120F;
            this.диапазонценыDataGridViewTextBoxColumn.HeaderText = "Диапазон_цены";
            this.диапазонценыDataGridViewTextBoxColumn.Name = "диапазонценыDataGridViewTextBoxColumn";
            this.диапазонценыDataGridViewTextBoxColumn.Width = 120;
            // 
            // Автомобиль
            // 
            this.Автомобиль.HeaderText = "Автомобиль";
            this.Автомобиль.Name = "Автомобиль";
            // 
            // infAbCarBindingSource
            // 
            this.infAbCarBindingSource.DataMember = "InfAbCar";
            this.infAbCarBindingSource.DataSource = this.carSellDataSet;
            // 
            // infAbCarTableAdapter
            // 
            this.infAbCarTableAdapter.ClearBeforeFill = true;
            // 
            // sellKlCarsTableAdapter
            // 
            this.sellKlCarsTableAdapter.ClearBeforeFill = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(330, 320);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(108, 31);
            this.label9.TabIndex = 20;
            this.label9.Text = "Заказы";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(1055, 320);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(167, 31);
            this.label10.TabIndex = 21;
            this.label10.Text = "Автомобили";
            // 
            // shortCarsTableAdapter
            // 
            this.shortCarsTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодавтомобиляDataGridViewTextBoxColumn,
            this.кодклиентапродавцаDataGridViewTextBoxColumn,
            this.клиентПродавецDataGridViewTextBoxColumn,
            this.автомобильDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.shortCarsBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(781, 382);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(589, 194);
            this.dataGridView2.TabIndex = 22;
            // 
            // кодавтомобиляDataGridViewTextBoxColumn
            // 
            this.кодавтомобиляDataGridViewTextBoxColumn.DataPropertyName = "Код_автомобиля";
            this.кодавтомобиляDataGridViewTextBoxColumn.HeaderText = "Код_автомобиля";
            this.кодавтомобиляDataGridViewTextBoxColumn.Name = "кодавтомобиляDataGridViewTextBoxColumn";
            // 
            // кодклиентапродавцаDataGridViewTextBoxColumn
            // 
            this.кодклиентапродавцаDataGridViewTextBoxColumn.DataPropertyName = "Код_клиента_продавца";
            this.кодклиентапродавцаDataGridViewTextBoxColumn.FillWeight = 150F;
            this.кодклиентапродавцаDataGridViewTextBoxColumn.HeaderText = "Код_клиента_продавца";
            this.кодклиентапродавцаDataGridViewTextBoxColumn.Name = "кодклиентапродавцаDataGridViewTextBoxColumn";
            this.кодклиентапродавцаDataGridViewTextBoxColumn.Width = 150;
            // 
            // клиентПродавецDataGridViewTextBoxColumn
            // 
            this.клиентПродавецDataGridViewTextBoxColumn.DataPropertyName = "Клиент - продавец";
            this.клиентПродавецDataGridViewTextBoxColumn.FillWeight = 200F;
            this.клиентПродавецDataGridViewTextBoxColumn.HeaderText = "Клиент - продавец";
            this.клиентПродавецDataGridViewTextBoxColumn.Name = "клиентПродавецDataGridViewTextBoxColumn";
            this.клиентПродавецDataGridViewTextBoxColumn.ReadOnly = true;
            this.клиентПродавецDataGridViewTextBoxColumn.Width = 200;
            // 
            // автомобильDataGridViewTextBoxColumn
            // 
            this.автомобильDataGridViewTextBoxColumn.DataPropertyName = "Автомобиль";
            this.автомобильDataGridViewTextBoxColumn.FillWeight = 200F;
            this.автомобильDataGridViewTextBoxColumn.HeaderText = "Автомобиль";
            this.автомобильDataGridViewTextBoxColumn.Name = "автомобильDataGridViewTextBoxColumn";
            this.автомобильDataGridViewTextBoxColumn.ReadOnly = true;
            this.автомобильDataGridViewTextBoxColumn.Width = 200;
            // 
            // carsHaventContractsBindingSource
            // 
            this.carsHaventContractsBindingSource.DataMember = "CarsHaventContracts";
            this.carsHaventContractsBindingSource.DataSource = this.carSellDataSet;
            // 
            // carsHaventContractsTableAdapter
            // 
            this.carsHaventContractsTableAdapter.ClearBeforeFill = true;
            // 
            // договорTableAdapter1
            // 
            this.договорTableAdapter1.ClearBeforeFill = true;
            // 
            // Form65
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1370, 576);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.comboBox5);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form65";
            this.Text = "Form65";
            this.Load += new System.EventHandler(this.Form65_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fullDlNameBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.allOrderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellKlientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.buyKlientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.маркамодельBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shortCarsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellKlCarsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.автомобильBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carsNameBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.infAbCarBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carsHaventContractsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private CarSellDataSet carSellDataSet;
        private System.Windows.Forms.BindingSource fullDlNameBindingSource;
        private CarSellDataSetTableAdapters.FullDlNameTableAdapter fullDlNameTableAdapter;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.BindingSource sellKlientBindingSource;
        private CarSellDataSetTableAdapters.SellKlientTableAdapter sellKlientTableAdapter;
        private System.Windows.Forms.BindingSource buyKlientBindingSource;
        private CarSellDataSetTableAdapters.BuyKlientTableAdapter buyKlientTableAdapter;
        private System.Windows.Forms.BindingSource маркамодельBindingSource;
        private CarSellDataSetTableAdapters.Марка_модельTableAdapter марка_модельTableAdapter;
        private System.Windows.Forms.BindingSource carsBindingSource;
        private System.Windows.Forms.BindingSource carsBindingSource1;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.BindingSource carsNameBindingSource;
        private System.Windows.Forms.BindingSource allOrderBindingSource;
        private CarSellDataSetTableAdapters.AllOrderTableAdapter allOrderTableAdapter;
        private System.Windows.Forms.BindingSource автомобильBindingSource;
        private CarSellDataSetTableAdapters.АвтомобильTableAdapter автомобильTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодзаказаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодклиентапокупателяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn клиентDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn типТСDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn маркаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn модельDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn типкузоваDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn годвыпускаотDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn годвыпускадоDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn диапазонобъемадвигателяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn диапазонмощностиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn диапазонпробегаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn цветDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn диапазонценыDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Автомобиль;
        private System.Windows.Forms.BindingSource infAbCarBindingSource;
        private CarSellDataSetTableAdapters.InfAbCarTableAdapter infAbCarTableAdapter;
        private System.Windows.Forms.BindingSource sellKlCarsBindingSource;
        private CarSellDataSetTableAdapters.SellKlCarsTableAdapter sellKlCarsTableAdapter;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.BindingSource shortCarsBindingSource;
        private CarSellDataSetTableAdapters.ShortCarsTableAdapter shortCarsTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодавтомобиляDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодклиентапродавцаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn клиентПродавецDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn автомобильDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource carsHaventContractsBindingSource;
        private CarSellDataSetTableAdapters.CarsHaventContractsTableAdapter carsHaventContractsTableAdapter;
        private CarSellDataSetTableAdapters.ДоговорTableAdapter договорTableAdapter1;
    }
}