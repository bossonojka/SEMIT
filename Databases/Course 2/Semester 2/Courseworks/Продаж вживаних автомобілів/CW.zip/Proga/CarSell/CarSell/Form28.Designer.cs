﻿namespace CarSell
{
    partial class Form28
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDтелефонаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодНПDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номертелефонаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.homePhoneBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carSellDataSet = new CarSell.CarSellDataSet();
            this.телефонBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.населенныйпунктBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carSellDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.homePhoneTableAdapter = new CarSell.CarSellDataSetTableAdapters.HomePhoneTableAdapter();
            this.телефонTableAdapter = new CarSell.CarSellDataSetTableAdapters.ТелефонTableAdapter();
            this.населенный_пунктTableAdapter = new CarSell.CarSellDataSetTableAdapters.Населенный_пунктTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.homePhoneBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.телефонBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.населенныйпунктBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDтелефонаDataGridViewTextBoxColumn,
            this.кодНПDataGridViewTextBoxColumn,
            this.названиеDataGridViewTextBoxColumn,
            this.номертелефонаDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.homePhoneBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(1, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(538, 491);
            this.dataGridView1.TabIndex = 0;
            // 
            // iDтелефонаDataGridViewTextBoxColumn
            // 
            this.iDтелефонаDataGridViewTextBoxColumn.DataPropertyName = "ID_телефона";
            this.iDтелефонаDataGridViewTextBoxColumn.HeaderText = "ID_телефона";
            this.iDтелефонаDataGridViewTextBoxColumn.Name = "iDтелефонаDataGridViewTextBoxColumn";
            this.iDтелефонаDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // кодНПDataGridViewTextBoxColumn
            // 
            this.кодНПDataGridViewTextBoxColumn.DataPropertyName = "Код_НП";
            this.кодНПDataGridViewTextBoxColumn.HeaderText = "Код_НП";
            this.кодНПDataGridViewTextBoxColumn.Name = "кодНПDataGridViewTextBoxColumn";
            this.кодНПDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // названиеDataGridViewTextBoxColumn
            // 
            this.названиеDataGridViewTextBoxColumn.DataPropertyName = "Название";
            this.названиеDataGridViewTextBoxColumn.HeaderText = "Название НП";
            this.названиеDataGridViewTextBoxColumn.Name = "названиеDataGridViewTextBoxColumn";
            this.названиеDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // номертелефонаDataGridViewTextBoxColumn
            // 
            this.номертелефонаDataGridViewTextBoxColumn.DataPropertyName = "Номер_телефона";
            this.номертелефонаDataGridViewTextBoxColumn.HeaderText = "Номер_телефона";
            this.номертелефонаDataGridViewTextBoxColumn.Name = "номертелефонаDataGridViewTextBoxColumn";
            this.номертелефонаDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // homePhoneBindingSource
            // 
            this.homePhoneBindingSource.DataMember = "HomePhone";
            this.homePhoneBindingSource.DataSource = this.carSellDataSet;
            // 
            // carSellDataSet
            // 
            this.carSellDataSet.DataSetName = "CarSellDataSet";
            this.carSellDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // телефонBindingSource
            // 
            this.телефонBindingSource.DataMember = "Телефон";
            this.телефонBindingSource.DataSource = this.carSellDataSet;
            // 
            // населенныйпунктBindingSource
            // 
            this.населенныйпунктBindingSource.DataMember = "Населенный_пункт";
            this.населенныйпунктBindingSource.DataSource = this.carSellDataSet;
            // 
            // carSellDataSetBindingSource
            // 
            this.carSellDataSetBindingSource.DataSource = this.carSellDataSet;
            this.carSellDataSetBindingSource.Position = 0;
            // 
            // homePhoneTableAdapter
            // 
            this.homePhoneTableAdapter.ClearBeforeFill = true;
            // 
            // телефонTableAdapter
            // 
            this.телефонTableAdapter.ClearBeforeFill = true;
            // 
            // населенный_пунктTableAdapter
            // 
            this.населенный_пунктTableAdapter.ClearBeforeFill = true;
            // 
            // Form28
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(541, 492);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form28";
            this.Text = "Form28";
            this.Load += new System.EventHandler(this.Form28_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.homePhoneBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.телефонBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.населенныйпунктBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSetBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource carSellDataSetBindingSource;
        private CarSellDataSet carSellDataSet;
        private System.Windows.Forms.BindingSource homePhoneBindingSource;
        private CarSellDataSetTableAdapters.HomePhoneTableAdapter homePhoneTableAdapter;
        private System.Windows.Forms.BindingSource телефонBindingSource;
        private CarSellDataSetTableAdapters.ТелефонTableAdapter телефонTableAdapter;
        private System.Windows.Forms.BindingSource населенныйпунктBindingSource;
        private CarSellDataSetTableAdapters.Населенный_пунктTableAdapter населенный_пунктTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDтелефонаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодНПDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номертелефонаDataGridViewTextBoxColumn;
    }
}