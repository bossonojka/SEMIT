﻿namespace CarSell
{
    partial class Form21
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.кодулицыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типулицыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеулицыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.streetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carSellDataSet = new CarSell.CarSellDataSet();
            this.населенныйпунктBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.типулицыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.streetTableAdapter = new CarSell.CarSellDataSetTableAdapters.StreetTableAdapter();
            this.населенный_пунктTableAdapter = new CarSell.CarSellDataSetTableAdapters.Населенный_пунктTableAdapter();
            this.тип_улицыTableAdapter = new CarSell.CarSellDataSetTableAdapters.Тип_улицыTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.улицаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.улицаTableAdapter = new CarSell.CarSellDataSetTableAdapters.УлицаTableAdapter();
            this.кодулицыDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодтипаулицыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодНПDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеулицыDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.streetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.населенныйпунктBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типулицыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.улицаBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодулицыDataGridViewTextBoxColumn,
            this.типулицыDataGridViewTextBoxColumn,
            this.названиеулицыDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.streetBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(0, 1);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(521, 326);
            this.dataGridView1.TabIndex = 0;
            // 
            // кодулицыDataGridViewTextBoxColumn
            // 
            this.кодулицыDataGridViewTextBoxColumn.DataPropertyName = "Код_улицы";
            this.кодулицыDataGridViewTextBoxColumn.HeaderText = "Код_улицы";
            this.кодулицыDataGridViewTextBoxColumn.Name = "кодулицыDataGridViewTextBoxColumn";
            // 
            // типулицыDataGridViewTextBoxColumn
            // 
            this.типулицыDataGridViewTextBoxColumn.DataPropertyName = "Тип_улицы";
            this.типулицыDataGridViewTextBoxColumn.HeaderText = "Тип_улицы";
            this.типулицыDataGridViewTextBoxColumn.Name = "типулицыDataGridViewTextBoxColumn";
            this.типулицыDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // названиеулицыDataGridViewTextBoxColumn
            // 
            this.названиеулицыDataGridViewTextBoxColumn.DataPropertyName = "Название_улицы";
            this.названиеулицыDataGridViewTextBoxColumn.HeaderText = "Название_улицы";
            this.названиеулицыDataGridViewTextBoxColumn.Name = "названиеулицыDataGridViewTextBoxColumn";
            // 
            // streetBindingSource
            // 
            this.streetBindingSource.DataMember = "Street";
            this.streetBindingSource.DataSource = this.carSellDataSet;
            // 
            // carSellDataSet
            // 
            this.carSellDataSet.DataSetName = "CarSellDataSet";
            this.carSellDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // населенныйпунктBindingSource
            // 
            this.населенныйпунктBindingSource.DataMember = "Населенный_пункт";
            this.населенныйпунктBindingSource.DataSource = this.carSellDataSet;
            // 
            // типулицыBindingSource
            // 
            this.типулицыBindingSource.DataMember = "Тип_улицы";
            this.типулицыBindingSource.DataSource = this.carSellDataSet;
            // 
            // streetTableAdapter
            // 
            this.streetTableAdapter.ClearBeforeFill = true;
            // 
            // населенный_пунктTableAdapter
            // 
            this.населенный_пунктTableAdapter.ClearBeforeFill = true;
            // 
            // тип_улицыTableAdapter
            // 
            this.тип_улицыTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.OrangeRed;
            this.button1.Location = new System.Drawing.Point(81, 679);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 29);
            this.button1.TabIndex = 4;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.RoyalBlue;
            this.button3.Location = new System.Drawing.Point(314, 679);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(168, 29);
            this.button3.TabIndex = 6;
            this.button3.Text = "Сохранить редактированное";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодулицыDataGridViewTextBoxColumn1,
            this.кодтипаулицыDataGridViewTextBoxColumn,
            this.кодНПDataGridViewTextBoxColumn,
            this.названиеулицыDataGridViewTextBoxColumn1});
            this.dataGridView2.DataSource = this.улицаBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(0, 370);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(521, 303);
            this.dataGridView2.TabIndex = 7;
            // 
            // улицаBindingSource
            // 
            this.улицаBindingSource.DataMember = "Улица";
            this.улицаBindingSource.DataSource = this.carSellDataSet;
            // 
            // улицаTableAdapter
            // 
            this.улицаTableAdapter.ClearBeforeFill = true;
            // 
            // кодулицыDataGridViewTextBoxColumn1
            // 
            this.кодулицыDataGridViewTextBoxColumn1.DataPropertyName = "Код_улицы";
            this.кодулицыDataGridViewTextBoxColumn1.HeaderText = "Код_улицы";
            this.кодулицыDataGridViewTextBoxColumn1.Name = "кодулицыDataGridViewTextBoxColumn1";
            this.кодулицыDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // кодтипаулицыDataGridViewTextBoxColumn
            // 
            this.кодтипаулицыDataGridViewTextBoxColumn.DataPropertyName = "Код_типа_улицы";
            this.кодтипаулицыDataGridViewTextBoxColumn.HeaderText = "Код_типа_улицы";
            this.кодтипаулицыDataGridViewTextBoxColumn.Name = "кодтипаулицыDataGridViewTextBoxColumn";
            // 
            // кодНПDataGridViewTextBoxColumn
            // 
            this.кодНПDataGridViewTextBoxColumn.DataPropertyName = "Код_НП";
            this.кодНПDataGridViewTextBoxColumn.HeaderText = "Код_НП";
            this.кодНПDataGridViewTextBoxColumn.Name = "кодНПDataGridViewTextBoxColumn";
            // 
            // названиеулицыDataGridViewTextBoxColumn1
            // 
            this.названиеулицыDataGridViewTextBoxColumn1.DataPropertyName = "Название_улицы";
            this.названиеулицыDataGridViewTextBoxColumn1.HeaderText = "Название_улицы";
            this.названиеулицыDataGridViewTextBoxColumn1.Name = "названиеулицыDataGridViewTextBoxColumn1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(77, 343);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(355, 24);
            this.label1.TabIndex = 9;
            this.label1.Text = "Редактировать только в нижнем окне";
            // 
            // Form21
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(523, 720);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form21";
            this.Text = "Form21";
            this.Load += new System.EventHandler(this.Form21_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.streetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.населенныйпунктBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типулицыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.улицаBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CarSellDataSet carSellDataSet;
        private System.Windows.Forms.BindingSource streetBindingSource;
        private CarSellDataSetTableAdapters.StreetTableAdapter streetTableAdapter;
        private System.Windows.Forms.BindingSource населенныйпунктBindingSource;
        private CarSellDataSetTableAdapters.Населенный_пунктTableAdapter населенный_пунктTableAdapter;
        private System.Windows.Forms.BindingSource типулицыBindingSource;
        private CarSellDataSetTableAdapters.Тип_улицыTableAdapter тип_улицыTableAdapter;
        private System.Windows.Forms.DataGridViewComboBoxColumn названиеDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодулицыDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn типулицыDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеулицыDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.BindingSource улицаBindingSource;
        private CarSellDataSetTableAdapters.УлицаTableAdapter улицаTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодулицыDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодтипаулицыDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодНПDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеулицыDataGridViewTextBoxColumn1;
        private System.Windows.Forms.Label label1;
    }
}