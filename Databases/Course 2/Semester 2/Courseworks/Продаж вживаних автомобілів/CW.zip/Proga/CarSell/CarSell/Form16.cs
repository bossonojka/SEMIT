﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSell
{
    public partial class Form16 : Form
    {
        public Form16()
        {
            InitializeComponent();
        }

        private void Form16_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_помещения' table. You can move, or remove it, as needed.
            this.тип_помещенияTableAdapter.Fill(this.carSellDataSet.Тип_помещения);
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_строения' table. You can move, or remove it, as needed.
            this.тип_строенияTableAdapter.Fill(this.carSellDataSet.Тип_строения);
            // TODO: This line of code loads data into the 'carSellDataSet.Улица' table. You can move, or remove it, as needed.
            this.улицаTableAdapter.Fill(this.carSellDataSet.Улица);
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_улицы' table. You can move, or remove it, as needed.
            this.тип_улицыTableAdapter.Fill(this.carSellDataSet.Тип_улицы);
            // TODO: This line of code loads data into the 'carSellDataSet.Населенный_пункт' table. You can move, or remove it, as needed.
            this.населенный_пунктTableAdapter.Fill(this.carSellDataSet.Населенный_пункт);
            // TODO: This line of code loads data into the 'carSellDataSet.Тип_НП' table. You can move, or remove it, as needed.
            this.тип_НПTableAdapter.Fill(this.carSellDataSet.Тип_НП);
            // TODO: This line of code loads data into the 'carSellDataSet.Район' table. You can move, or remove it, as needed.
            this.районTableAdapter.Fill(this.carSellDataSet.Район);
            // TODO: This line of code loads data into the 'carSellDataSet.Область' table. You can move, or remove it, as needed.
            this.областьTableAdapter.Fill(this.carSellDataSet.Область);
            // TODO: This line of code loads data into the 'carSellDataSet.AllAdress' table. You can move, or remove it, as needed.
            this.allAdressTableAdapter.Fill(this.carSellDataSet.AllAdress);
            // TODO: This line of code loads data into the 'carSellDataSet.AllOrder' table. You can move, or remove it, as needed.
            this.allOrderTableAdapter.Fill(this.carSellDataSet.AllOrder);

        }
    }
}
