﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSell
{
    public partial class Form28 : Form
    {
        public Form28()
        {
            InitializeComponent();
        }

        private void Form28_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Населенный_пункт' table. You can move, or remove it, as needed.
            this.населенный_пунктTableAdapter.Fill(this.carSellDataSet.Населенный_пункт);
            // TODO: This line of code loads data into the 'carSellDataSet.Телефон' table. You can move, or remove it, as needed.
            this.телефонTableAdapter.Fill(this.carSellDataSet.Телефон);
            // TODO: This line of code loads data into the 'carSellDataSet.HomePhone' table. You can move, or remove it, as needed.
            this.homePhoneTableAdapter.Fill(this.carSellDataSet.HomePhone);

        }
    }
}
