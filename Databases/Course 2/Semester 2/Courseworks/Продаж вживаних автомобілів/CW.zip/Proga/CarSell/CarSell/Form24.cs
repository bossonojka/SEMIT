﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSell
{
    public partial class Form24 : Form
    {
        public Form24()
        {
            InitializeComponent();
        }

        private void Form24_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.Оператор' table. You can move, or remove it, as needed.
            this.операторTableAdapter.Fill(this.carSellDataSet.Оператор);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form67 form67 = new Form67();
            form67.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.операторTableAdapter.Update(this.carSellDataSet.Оператор);
        }
    }
}
