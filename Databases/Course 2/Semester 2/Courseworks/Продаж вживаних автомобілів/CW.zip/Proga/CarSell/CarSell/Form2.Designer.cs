﻿namespace CarSell
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.маркаавтоBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carSellDataSet = new CarSell.CarSellDataSet();
            this.carBrandBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.марка_автоTableAdapter = new CarSell.CarSellDataSetTableAdapters.Марка_автоTableAdapter();
            this.carBrandTableAdapter = new CarSell.CarSellDataSetTableAdapters.CarBrandTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.кодмаркиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.маркаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.модельавтоBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.модель_автоTableAdapter = new CarSell.CarSellDataSetTableAdapters.Модель_автоTableAdapter();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.марка_автоTableAdapter1 = new CarSell.CarSellDataSetTableAdapters.Марка_автоTableAdapter();
            this.carSellDataSet1 = new CarSell.CarSellDataSet();
            ((System.ComponentModel.ISupportInitialize)(this.маркаавтоBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carBrandBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.модельавтоBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // маркаавтоBindingSource
            // 
            this.маркаавтоBindingSource.DataMember = "Марка_авто";
            this.маркаавтоBindingSource.DataSource = this.carSellDataSet;
            // 
            // carSellDataSet
            // 
            this.carSellDataSet.DataSetName = "CarSellDataSet";
            this.carSellDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // carBrandBindingSource
            // 
            this.carBrandBindingSource.DataMember = "CarBrand";
            this.carBrandBindingSource.DataSource = this.carSellDataSet;
            // 
            // марка_автоTableAdapter
            // 
            this.марка_автоTableAdapter.ClearBeforeFill = true;
            // 
            // carBrandTableAdapter
            // 
            this.carBrandTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодмаркиDataGridViewTextBoxColumn,
            this.маркаDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.маркаавтоBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(-1, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(486, 349);
            this.dataGridView1.TabIndex = 1;
            // 
            // кодмаркиDataGridViewTextBoxColumn
            // 
            this.кодмаркиDataGridViewTextBoxColumn.DataPropertyName = "Код_марки";
            this.кодмаркиDataGridViewTextBoxColumn.HeaderText = "Код_марки";
            this.кодмаркиDataGridViewTextBoxColumn.Name = "кодмаркиDataGridViewTextBoxColumn";
            this.кодмаркиDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // маркаDataGridViewTextBoxColumn
            // 
            this.маркаDataGridViewTextBoxColumn.DataPropertyName = "Марка";
            this.маркаDataGridViewTextBoxColumn.HeaderText = "Марка";
            this.маркаDataGridViewTextBoxColumn.Name = "маркаDataGridViewTextBoxColumn";
            this.маркаDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // модельавтоBindingSource
            // 
            this.модельавтоBindingSource.DataMember = "Модель_авто";
            this.модельавтоBindingSource.DataSource = this.carSellDataSet;
            // 
            // модель_автоTableAdapter
            // 
            this.модель_автоTableAdapter.ClearBeforeFill = true;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.RoyalBlue;
            this.button2.Location = new System.Drawing.Point(291, 357);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(168, 29);
            this.button2.TabIndex = 5;
            this.button2.Text = "Сохранить редактированное";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.OrangeRed;
            this.button1.Location = new System.Drawing.Point(60, 358);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 29);
            this.button1.TabIndex = 4;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // марка_автоTableAdapter1
            // 
            this.марка_автоTableAdapter1.ClearBeforeFill = true;
            // 
            // carSellDataSet1
            // 
            this.carSellDataSet1.DataSetName = "CarSellDataSet";
            this.carSellDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(486, 399);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.IsMdiContainer = true;
            this.Name = "Form2";
            this.Text = "Марка автомобиля";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.маркаавтоBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carBrandBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.модельавтоBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private CarSellDataSet carSellDataSet;
        private System.Windows.Forms.BindingSource маркаавтоBindingSource;
        private CarSellDataSetTableAdapters.Марка_автоTableAdapter марка_автоTableAdapter;
        private System.Windows.Forms.BindingSource carBrandBindingSource;
        private CarSellDataSetTableAdapters.CarBrandTableAdapter carBrandTableAdapter;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодмоделиDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource модельавтоBindingSource;
        private CarSellDataSetTableAdapters.Модель_автоTableAdapter модель_автоTableAdapter;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодмаркиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn маркаDataGridViewTextBoxColumn;
        private CarSellDataSetTableAdapters.Марка_автоTableAdapter марка_автоTableAdapter1;
        private CarSellDataSet carSellDataSet1;
    }
}