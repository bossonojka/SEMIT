﻿namespace CarSell
{
    partial class Form17
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.carSellDataSet = new CarSell.CarSellDataSet();
            this.районBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.районTableAdapter = new CarSell.CarSellDataSetTableAdapters.РайонTableAdapter();
            this.rayonBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rayonTableAdapter = new CarSell.CarSellDataSetTableAdapters.RayonTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.кодрайонуDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодобластиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.назварайонуDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.областьBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.областьTableAdapter = new CarSell.CarSellDataSetTableAdapters.ОбластьTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.районBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rayonBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.областьBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // carSellDataSet
            // 
            this.carSellDataSet.DataSetName = "CarSellDataSet";
            this.carSellDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // районBindingSource
            // 
            this.районBindingSource.DataMember = "Район";
            this.районBindingSource.DataSource = this.carSellDataSet;
            // 
            // районTableAdapter
            // 
            this.районTableAdapter.ClearBeforeFill = true;
            // 
            // rayonBindingSource
            // 
            this.rayonBindingSource.DataMember = "Rayon";
            this.rayonBindingSource.DataSource = this.carSellDataSet;
            // 
            // rayonTableAdapter
            // 
            this.rayonTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодрайонуDataGridViewTextBoxColumn,
            this.кодобластиDataGridViewTextBoxColumn,
            this.назварайонуDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.районBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(-1, -1);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(564, 451);
            this.dataGridView1.TabIndex = 0;
            // 
            // кодрайонуDataGridViewTextBoxColumn
            // 
            this.кодрайонуDataGridViewTextBoxColumn.DataPropertyName = "Код_району";
            this.кодрайонуDataGridViewTextBoxColumn.HeaderText = "Код_району";
            this.кодрайонуDataGridViewTextBoxColumn.Name = "кодрайонуDataGridViewTextBoxColumn";
            // 
            // кодобластиDataGridViewTextBoxColumn
            // 
            this.кодобластиDataGridViewTextBoxColumn.DataPropertyName = "Код_области";
            this.кодобластиDataGridViewTextBoxColumn.HeaderText = "Код_области";
            this.кодобластиDataGridViewTextBoxColumn.Name = "кодобластиDataGridViewTextBoxColumn";
            this.кодобластиDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // назварайонуDataGridViewTextBoxColumn
            // 
            this.назварайонуDataGridViewTextBoxColumn.DataPropertyName = "Назва_району";
            this.назварайонуDataGridViewTextBoxColumn.HeaderText = "Назва_району";
            this.назварайонуDataGridViewTextBoxColumn.Name = "назварайонуDataGridViewTextBoxColumn";
            // 
            // областьBindingSource
            // 
            this.областьBindingSource.DataMember = "Область";
            this.областьBindingSource.DataSource = this.carSellDataSet;
            // 
            // областьTableAdapter
            // 
            this.областьTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.OrangeRed;
            this.button1.Location = new System.Drawing.Point(108, 456);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 29);
            this.button1.TabIndex = 4;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.RoyalBlue;
            this.button2.Location = new System.Drawing.Point(351, 456);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(168, 29);
            this.button2.TabIndex = 6;
            this.button2.Text = "Сохранить редактированное";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form17
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(562, 495);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form17";
            this.Text = "Form17";
            this.Load += new System.EventHandler(this.Form17_Load);
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.районBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rayonBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.областьBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private CarSellDataSet carSellDataSet;
        private System.Windows.Forms.BindingSource районBindingSource;
        private CarSellDataSetTableAdapters.РайонTableAdapter районTableAdapter;
        private System.Windows.Forms.BindingSource rayonBindingSource;
        private CarSellDataSetTableAdapters.RayonTableAdapter rayonTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource областьBindingSource;
        private CarSellDataSetTableAdapters.ОбластьTableAdapter областьTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодрайонуDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодобластиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn назварайонуDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}