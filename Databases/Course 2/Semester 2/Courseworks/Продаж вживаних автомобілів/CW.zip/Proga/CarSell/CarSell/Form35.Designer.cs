﻿namespace CarSell
{
    partial class Form35
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.кодклиентапокупателяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.клиентПокупательDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.серияпаспортаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерпаспортаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buyKlientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.carSellDataSet = new CarSell.CarSellDataSet();
            this.клиентBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fullKlNameBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.klientPhoneBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.buyKlientTableAdapter = new CarSell.CarSellDataSetTableAdapters.BuyKlientTableAdapter();
            this.клиентTableAdapter = new CarSell.CarSellDataSetTableAdapters.КлиентTableAdapter();
            this.klientPhoneTableAdapter = new CarSell.CarSellDataSetTableAdapters.KlientPhoneTableAdapter();
            this.fullKlNameTableAdapter = new CarSell.CarSellDataSetTableAdapters.FullKlNameTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.buyKlientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fullKlNameBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientPhoneBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодклиентапокупателяDataGridViewTextBoxColumn,
            this.клиентПокупательDataGridViewTextBoxColumn,
            this.серияпаспортаDataGridViewTextBoxColumn,
            this.номерпаспортаDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.buyKlientBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(600, 386);
            this.dataGridView1.TabIndex = 0;
            // 
            // кодклиентапокупателяDataGridViewTextBoxColumn
            // 
            this.кодклиентапокупателяDataGridViewTextBoxColumn.DataPropertyName = "Код_клиента_покупателя";
            this.кодклиентапокупателяDataGridViewTextBoxColumn.FillWeight = 150F;
            this.кодклиентапокупателяDataGridViewTextBoxColumn.HeaderText = "Код_клиента_покупателя";
            this.кодклиентапокупателяDataGridViewTextBoxColumn.Name = "кодклиентапокупателяDataGridViewTextBoxColumn";
            this.кодклиентапокупателяDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.кодклиентапокупателяDataGridViewTextBoxColumn.Width = 150;
            // 
            // клиентПокупательDataGridViewTextBoxColumn
            // 
            this.клиентПокупательDataGridViewTextBoxColumn.DataPropertyName = "Клиент - покупатель";
            this.клиентПокупательDataGridViewTextBoxColumn.FillWeight = 200F;
            this.клиентПокупательDataGridViewTextBoxColumn.HeaderText = "Клиент - покупатель";
            this.клиентПокупательDataGridViewTextBoxColumn.Name = "клиентПокупательDataGridViewTextBoxColumn";
            this.клиентПокупательDataGridViewTextBoxColumn.ReadOnly = true;
            this.клиентПокупательDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.клиентПокупательDataGridViewTextBoxColumn.Width = 200;
            // 
            // серияпаспортаDataGridViewTextBoxColumn
            // 
            this.серияпаспортаDataGridViewTextBoxColumn.DataPropertyName = "Серия_паспорта";
            this.серияпаспортаDataGridViewTextBoxColumn.HeaderText = "Серия_паспорта";
            this.серияпаспортаDataGridViewTextBoxColumn.Name = "серияпаспортаDataGridViewTextBoxColumn";
            // 
            // номерпаспортаDataGridViewTextBoxColumn
            // 
            this.номерпаспортаDataGridViewTextBoxColumn.DataPropertyName = "Номер_паспорта";
            this.номерпаспортаDataGridViewTextBoxColumn.HeaderText = "Номер_паспорта";
            this.номерпаспортаDataGridViewTextBoxColumn.Name = "номерпаспортаDataGridViewTextBoxColumn";
            // 
            // buyKlientBindingSource
            // 
            this.buyKlientBindingSource.DataMember = "BuyKlient";
            this.buyKlientBindingSource.DataSource = this.carSellDataSet;
            // 
            // carSellDataSet
            // 
            this.carSellDataSet.DataSetName = "CarSellDataSet";
            this.carSellDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // клиентBindingSource
            // 
            this.клиентBindingSource.DataMember = "Клиент";
            this.клиентBindingSource.DataSource = this.carSellDataSet;
            // 
            // fullKlNameBindingSource
            // 
            this.fullKlNameBindingSource.DataMember = "FullKlName";
            this.fullKlNameBindingSource.DataSource = this.carSellDataSet;
            // 
            // klientPhoneBindingSource
            // 
            this.klientPhoneBindingSource.DataMember = "KlientPhone";
            this.klientPhoneBindingSource.DataSource = this.carSellDataSet;
            // 
            // buyKlientTableAdapter
            // 
            this.buyKlientTableAdapter.ClearBeforeFill = true;
            // 
            // клиентTableAdapter
            // 
            this.клиентTableAdapter.ClearBeforeFill = true;
            // 
            // klientPhoneTableAdapter
            // 
            this.klientPhoneTableAdapter.ClearBeforeFill = true;
            // 
            // fullKlNameTableAdapter
            // 
            this.fullKlNameTableAdapter.ClearBeforeFill = true;
            // 
            // Form35
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 384);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form35";
            this.Text = "Form35";
            this.Load += new System.EventHandler(this.Form35_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.buyKlientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carSellDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fullKlNameBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientPhoneBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CarSellDataSet carSellDataSet;
        private System.Windows.Forms.BindingSource buyKlientBindingSource;
        private CarSellDataSetTableAdapters.BuyKlientTableAdapter buyKlientTableAdapter;
        private System.Windows.Forms.BindingSource клиентBindingSource;
        private CarSellDataSetTableAdapters.КлиентTableAdapter клиентTableAdapter;
        private System.Windows.Forms.BindingSource klientPhoneBindingSource;
        private CarSellDataSetTableAdapters.KlientPhoneTableAdapter klientPhoneTableAdapter;
        private System.Windows.Forms.BindingSource fullKlNameBindingSource;
        private CarSellDataSetTableAdapters.FullKlNameTableAdapter fullKlNameTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодклиентапокупателяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn клиентПокупательDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn серияпаспортаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерпаспортаDataGridViewTextBoxColumn;
    }
}