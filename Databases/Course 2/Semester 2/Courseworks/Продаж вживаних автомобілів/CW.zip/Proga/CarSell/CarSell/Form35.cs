﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSell
{
    public partial class Form35 : Form
    {
        public Form35()
        {
            InitializeComponent();
        }

        private void Form35_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carSellDataSet.FullKlName' table. You can move, or remove it, as needed.
            this.fullKlNameTableAdapter.Fill(this.carSellDataSet.FullKlName);
            // TODO: This line of code loads data into the 'carSellDataSet.KlientPhone' table. You can move, or remove it, as needed.
            this.klientPhoneTableAdapter.Fill(this.carSellDataSet.KlientPhone);
            // TODO: This line of code loads data into the 'carSellDataSet.Клиент' table. You can move, or remove it, as needed.
            this.клиентTableAdapter.Fill(this.carSellDataSet.Клиент);
            // TODO: This line of code loads data into the 'carSellDataSet.BuyKlient' table. You can move, or remove it, as needed.
            this.buyKlientTableAdapter.Fill(this.carSellDataSet.BuyKlient);

        }
    }
}
