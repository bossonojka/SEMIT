use library_db

alter table Editions
add constraint FK_Editions_Languages foreign key (language_id)
references dbo.Languages (language_id)
on update no action
on delete no action
;