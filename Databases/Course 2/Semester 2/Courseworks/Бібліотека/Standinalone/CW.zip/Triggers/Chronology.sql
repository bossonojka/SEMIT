-- ================================================
-- Template generated from Template Explorer using:
-- Create Trigger (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- See additional Create Trigger templates for more
-- examples of different Trigger statements.
--
-- This block of comments will not be included in
-- the definition of the function.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[addToChronology] ON dbo.Debentures
   AFTER INSERT NOT FOR REPLICATION
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    declare @date datetime
    declare @lending_date datetime
    declare @returning_date datetime
    declare @reader_id int
    declare @copy_id int
    
    select @lending_date = lending_date from inserted
    select @returning_date = returning_date from inserted
    select @reader_id = reader_id from inserted
    select @copy_id = copy_id from inserted
    
    print('������� �������� ������ � ���������� ��� �������� ' + str(@reader_id))
    if @returning_date = null
		begin
			insert into Chronology(date, operation_id, copy_id, reader_id)
			values(@lending_date, 1, @copy_id, @reader_id)
		end
	else
		begin
			insert into Chronology(date, operation_id, copy_id, reader_id)
			values(@lending_date, 2, @copy_id, @reader_id)
		end
END
GO
