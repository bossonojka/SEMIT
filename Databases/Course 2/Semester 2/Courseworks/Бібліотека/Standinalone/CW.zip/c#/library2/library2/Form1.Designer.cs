﻿using System;

namespace library2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.таблицыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.книгиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.экземплярыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.читателиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задолженностиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.хронологияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.авторыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.адресаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.страныToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.улицыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.населенныеПунктыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.типыУлицToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.типыНаселенныхПунктовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.работникиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.должностиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.предметыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.издательстваToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.дополнительноToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.полыToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.типыОперацийToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.типыИзданийToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.языкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.жанрыToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.книгиКлючевыеСловаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поискИзданияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.помощьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.помощьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.getLocalitiesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.library_dbDataSet = new library2.library_dbDataSet();
            this.getStreetTypesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.streetsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.streetsTableAdapter = new library2.library_dbDataSetTableAdapters.StreetsTableAdapter();
            this.getLocalitiesTableAdapter = new library2.library_dbDataSetTableAdapters.GetLocalitiesTableAdapter();
            this.getStreetTypesTableAdapter = new library2.library_dbDataSetTableAdapters.GetStreetTypesTableAdapter();
            this.хронологияИзданийToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.DataGrid_ToolstripAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.DataGrid_ToolstripMoveNext = new System.Windows.Forms.ToolStripButton();
            this.DataGrid_ToolstripMoveBack = new System.Windows.Forms.ToolStripButton();
            this.DataGrid_MyButton = new System.Windows.Forms.ToolStripButton();
            this.tabControl1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.getLocalitiesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.library_dbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.getStreetTypesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.streetsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tabPage4
            // 
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(866, 464);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Издательства";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(866, 464);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Авторы";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(866, 464);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Читатели";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(866, 464);
            this.tabPage1.TabIndex = 4;
            this.tabPage1.Text = "Издания";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            if (this.rank != "Читатель")
            {
                this.tabControl1.Controls.Add(this.tabPage2);
                this.tabControl1.Controls.Add(this.tabPage3);
                this.tabControl1.Controls.Add(this.tabPage4);
                this.tabControl1.Controls.Add(this.tabPage5);
            }
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 24);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(874, 490);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage5
            // 
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(866, 464);
            this.tabPage5.TabIndex = 5;
            this.tabPage5.Text = "Задолженности";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.поискИзданияToolStripMenuItem,
            this.помощьToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(874, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            if (this.rank != "Читатель") this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.таблицыToolStripMenuItem,
            this.отчетыToolStripMenuItem
            });
            // 
            // таблицыToolStripMenuItem
            // 
            this.таблицыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.книгиToolStripMenuItem,
            this.экземплярыToolStripMenuItem,
            this.читателиToolStripMenuItem,
            this.задолженностиToolStripMenuItem,
            this.хронологияToolStripMenuItem,
            this.авторыToolStripMenuItem,
            this.toolStripSeparator4,
            this.адресаToolStripMenuItem,
            this.работникиToolStripMenuItem,
            this.предметыToolStripMenuItem,
            this.издательстваToolStripMenuItem,
            this.toolStripSeparator5,
            this.дополнительноToolStripMenuItem});
            this.таблицыToolStripMenuItem.Name = "таблицыToolStripMenuItem";
            this.таблицыToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.таблицыToolStripMenuItem.Text = "Таблицы";
            // 
            // книгиToolStripMenuItem
            // 
            this.книгиToolStripMenuItem.Name = "книгиToolStripMenuItem";
            this.книгиToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.книгиToolStripMenuItem.Text = "Издания";
            this.книгиToolStripMenuItem.Click += new System.EventHandler(this.книгиToolStripMenuItem_Click);
            // 
            // экземплярыToolStripMenuItem
            // 
            this.экземплярыToolStripMenuItem.Name = "экземплярыToolStripMenuItem";
            this.экземплярыToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.экземплярыToolStripMenuItem.Text = "Экземпляры";
            this.экземплярыToolStripMenuItem.Click += new System.EventHandler(this.экземплярыToolStripMenuItem_Click);
            // 
            // читателиToolStripMenuItem
            // 
            this.читателиToolStripMenuItem.Name = "читателиToolStripMenuItem";
            this.читателиToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.читателиToolStripMenuItem.Text = "Читатели";
            this.читателиToolStripMenuItem.Click += new System.EventHandler(this.читателиToolStripMenuItem_Click_1);
            // 
            // задолженностиToolStripMenuItem
            // 
            this.задолженностиToolStripMenuItem.Name = "задолженностиToolStripMenuItem";
            this.задолженностиToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.задолженностиToolStripMenuItem.Text = "Задолженности";
            this.задолженностиToolStripMenuItem.Click += new System.EventHandler(this.задолженностиToolStripMenuItem_Click);
            // 
            // хронологияToolStripMenuItem
            // 
            this.хронологияToolStripMenuItem.Name = "хронологияToolStripMenuItem";
            this.хронологияToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.хронологияToolStripMenuItem.Text = "Хронология";
            this.хронологияToolStripMenuItem.Click += new System.EventHandler(this.хронологияToolStripMenuItem_Click);
            // 
            // авторыToolStripMenuItem
            // 
            this.авторыToolStripMenuItem.Name = "авторыToolStripMenuItem";
            this.авторыToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.авторыToolStripMenuItem.Text = "Авторы";
            this.авторыToolStripMenuItem.Click += new System.EventHandler(this.авторыToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(159, 6);
            // 
            // адресаToolStripMenuItem
            // 
            this.адресаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.страныToolStripMenuItem,
            this.улицыToolStripMenuItem,
            this.населенныеПунктыToolStripMenuItem,
            this.toolStripSeparator3,
            this.типыУлицToolStripMenuItem,
            this.типыНаселенныхПунктовToolStripMenuItem});
            this.адресаToolStripMenuItem.Name = "адресаToolStripMenuItem";
            this.адресаToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.адресаToolStripMenuItem.Text = "Адреса";
            this.адресаToolStripMenuItem.Click += new System.EventHandler(this.адресаToolStripMenuItem_Click);
            // 
            // страныToolStripMenuItem
            // 
            this.страныToolStripMenuItem.Name = "страныToolStripMenuItem";
            this.страныToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.страныToolStripMenuItem.Text = "Страны";
            this.страныToolStripMenuItem.Click += new System.EventHandler(this.страныToolStripMenuItem_Click);
            // 
            // улицыToolStripMenuItem
            // 
            this.улицыToolStripMenuItem.Name = "улицыToolStripMenuItem";
            this.улицыToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.улицыToolStripMenuItem.Text = "Улицы";
            this.улицыToolStripMenuItem.Click += new System.EventHandler(this.улицыToolStripMenuItem_Click);
            // 
            // населенныеПунктыToolStripMenuItem
            // 
            this.населенныеПунктыToolStripMenuItem.Name = "населенныеПунктыToolStripMenuItem";
            this.населенныеПунктыToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.населенныеПунктыToolStripMenuItem.Text = "Населенные пункты";
            this.населенныеПунктыToolStripMenuItem.Click += new System.EventHandler(this.населенныеПунктыToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(217, 6);
            // 
            // типыУлицToolStripMenuItem
            // 
            this.типыУлицToolStripMenuItem.Name = "типыУлицToolStripMenuItem";
            this.типыУлицToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.типыУлицToolStripMenuItem.Text = "Типы улиц";
            this.типыУлицToolStripMenuItem.Click += new System.EventHandler(this.типыУлицToolStripMenuItem_Click);
            // 
            // типыНаселенныхПунктовToolStripMenuItem
            // 
            this.типыНаселенныхПунктовToolStripMenuItem.Name = "типыНаселенныхПунктовToolStripMenuItem";
            this.типыНаселенныхПунктовToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.типыНаселенныхПунктовToolStripMenuItem.Text = "Типы населенных пунктов";
            this.типыНаселенныхПунктовToolStripMenuItem.Click += new System.EventHandler(this.типыНаселенныхПунктовToolStripMenuItem_Click);
            // 
            // работникиToolStripMenuItem
            // 
            this.работникиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.должностиToolStripMenuItem});
            this.работникиToolStripMenuItem.Name = "работникиToolStripMenuItem";
            this.работникиToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.работникиToolStripMenuItem.Text = "Работники";
            this.работникиToolStripMenuItem.Click += new System.EventHandler(this.работникиToolStripMenuItem_Click);
            // 
            // должностиToolStripMenuItem
            // 
            this.должностиToolStripMenuItem.Name = "должностиToolStripMenuItem";
            this.должностиToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.должностиToolStripMenuItem.Text = "Должности";
            this.должностиToolStripMenuItem.Click += new System.EventHandler(this.должностиToolStripMenuItem_Click);
            // 
            // предметыToolStripMenuItem
            // 
            this.предметыToolStripMenuItem.Name = "предметыToolStripMenuItem";
            this.предметыToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.предметыToolStripMenuItem.Text = "Предметы";
            this.предметыToolStripMenuItem.Click += new System.EventHandler(this.предметыToolStripMenuItem_Click);
            // 
            // издательстваToolStripMenuItem
            // 
            this.издательстваToolStripMenuItem.Name = "издательстваToolStripMenuItem";
            this.издательстваToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.издательстваToolStripMenuItem.Text = "Издательства";
            this.издательстваToolStripMenuItem.Click += new System.EventHandler(this.издательстваToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(159, 6);
            // 
            // дополнительноToolStripMenuItem
            // 
            this.дополнительноToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.полыToolStripMenuItem1,
            this.типыОперацийToolStripMenuItem1,
            this.типыИзданийToolStripMenuItem1,
            this.языкиToolStripMenuItem,
            this.жанрыToolStripMenuItem1,
            this.toolStripSeparator6,
            this.книгиКлючевыеСловаToolStripMenuItem});
            this.дополнительноToolStripMenuItem.Name = "дополнительноToolStripMenuItem";
            this.дополнительноToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.дополнительноToolStripMenuItem.Text = "Дополнительно";
            // 
            // полыToolStripMenuItem1
            // 
            this.полыToolStripMenuItem1.Name = "полыToolStripMenuItem1";
            this.полыToolStripMenuItem1.Size = new System.Drawing.Size(211, 22);
            this.полыToolStripMenuItem1.Text = "Полы";
            this.полыToolStripMenuItem1.Click += new System.EventHandler(this.полыToolStripMenuItem1_Click);
            // 
            // типыОперацийToolStripMenuItem1
            // 
            this.типыОперацийToolStripMenuItem1.Name = "типыОперацийToolStripMenuItem1";
            this.типыОперацийToolStripMenuItem1.Size = new System.Drawing.Size(211, 22);
            this.типыОперацийToolStripMenuItem1.Text = "Типы операций";
            this.типыОперацийToolStripMenuItem1.Click += new System.EventHandler(this.типыОперацийToolStripMenuItem1_Click);
            // 
            // типыИзданийToolStripMenuItem1
            // 
            this.типыИзданийToolStripMenuItem1.Name = "типыИзданийToolStripMenuItem1";
            this.типыИзданийToolStripMenuItem1.Size = new System.Drawing.Size(211, 22);
            this.типыИзданийToolStripMenuItem1.Text = "Типы изданий";
            this.типыИзданийToolStripMenuItem1.Click += new System.EventHandler(this.типыИзданийToolStripMenuItem1_Click);
            // 
            // языкиToolStripMenuItem
            // 
            this.языкиToolStripMenuItem.Name = "языкиToolStripMenuItem";
            this.языкиToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.языкиToolStripMenuItem.Text = "Языки";
            this.языкиToolStripMenuItem.Click += new System.EventHandler(this.языкиToolStripMenuItem_Click);
            // 
            // жанрыToolStripMenuItem1
            // 
            this.жанрыToolStripMenuItem1.Name = "жанрыToolStripMenuItem1";
            this.жанрыToolStripMenuItem1.Size = new System.Drawing.Size(211, 22);
            this.жанрыToolStripMenuItem1.Text = "Жанры";
            this.жанрыToolStripMenuItem1.Click += new System.EventHandler(this.жанрыToolStripMenuItem1_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(208, 6);
            // 
            // книгиКлючевыеСловаToolStripMenuItem
            // 
            this.книгиКлючевыеСловаToolStripMenuItem.Name = "книгиКлючевыеСловаToolStripMenuItem";
            this.книгиКлючевыеСловаToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.книгиКлючевыеСловаToolStripMenuItem.Text = "Книги - Ключевые слова";
            this.книгиКлючевыеСловаToolStripMenuItem.Click += new System.EventHandler(this.книгиКлючевыеСловаToolStripMenuItem_Click);
            // 
            // отчетыToolStripMenuItem
            // 
            this.отчетыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.testToolStripMenuItem,
            this.хронологияИзданийToolStripMenuItem,
            this.toolStripMenuItem2});
            this.отчетыToolStripMenuItem.Name = "отчетыToolStripMenuItem";
            this.отчетыToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.отчетыToolStripMenuItem.Text = "Отчеты";
            // 
            // testToolStripMenuItem
            // 
            this.testToolStripMenuItem.Name = "testToolStripMenuItem";
            this.testToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.testToolStripMenuItem.Text = "Хронология читателей";
            this.testToolStripMenuItem.Click += new System.EventHandler(this.testToolStripMenuItem_Click);
            // 
            // поискИзданияToolStripMenuItem
            // 
            this.поискИзданияToolStripMenuItem.Name = "поискИзданияToolStripMenuItem";
            this.поискИзданияToolStripMenuItem.Size = new System.Drawing.Size(101, 20);
            this.поискИзданияToolStripMenuItem.Text = "Поиск издания";
            this.поискИзданияToolStripMenuItem.Click += new System.EventHandler(this.поискИзданияToolStripMenuItem_Click);
            // 
            // помощьToolStripMenuItem
            // 
            this.помощьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem});
            if (this.rank != "Читатель") this.помощьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.помощьToolStripMenuItem1});
            this.помощьToolStripMenuItem.Name = "помощьToolStripMenuItem";
            this.помощьToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.помощьToolStripMenuItem.Text = "Помощь";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            оПрограммеToolStripMenuItem.Click += оПрограммеToolStripMenuItem_Click;
            // 
            // помощьToolStripMenuItem1
            // 
            this.помощьToolStripMenuItem1.Name = "помощьToolStripMenuItem1";
            this.помощьToolStripMenuItem1.Size = new System.Drawing.Size(149, 22);
            this.помощьToolStripMenuItem1.Text = "Помощь";
            this.помощьToolStripMenuItem1.Click += new System.EventHandler(помощьToolStripMenuItem_Click);
            // 
            // getLocalitiesBindingSource
            // 
            this.getLocalitiesBindingSource.DataMember = "GetLocalities";
            this.getLocalitiesBindingSource.DataSource = this.library_dbDataSet;
            // 
            // library_dbDataSet
            // 
            this.library_dbDataSet.DataSetName = "library_dbDataSet";
            this.library_dbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // getStreetTypesBindingSource
            // 
            this.getStreetTypesBindingSource.DataMember = "GetStreetTypes";
            this.getStreetTypesBindingSource.DataSource = this.library_dbDataSet;
            // 
            // streetsBindingSource
            // 
            this.streetsBindingSource.DataMember = "Streets";
            this.streetsBindingSource.DataSource = this.library_dbDataSet;
            // 
            // streetsTableAdapter
            // 
            this.streetsTableAdapter.ClearBeforeFill = true;
            // 
            // getLocalitiesTableAdapter
            // 
            this.getLocalitiesTableAdapter.ClearBeforeFill = true;
            // 
            // getStreetTypesTableAdapter
            // 
            this.getStreetTypesTableAdapter.ClearBeforeFill = true;
            // 
            // хронологияИзданийToolStripMenuItem
            // 
            this.хронологияИзданийToolStripMenuItem.Name = "хронологияИзданийToolStripMenuItem";
            this.хронологияИзданийToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.хронологияИзданийToolStripMenuItem.Text = "Хронология изданий";
            this.хронологияИзданийToolStripMenuItem.Click += new System.EventHandler(this.хронологияИзданийToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(200, 22);
            this.toolStripMenuItem2.Text = "Издания";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // DataGrid_ToolstripAddNewItem
            // 
            this.DataGrid_ToolstripAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.DataGrid_ToolstripAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("DataGrid_ToolstripAddNewItem.Image")));
            this.DataGrid_ToolstripAddNewItem.Name = "DataGrid_ToolstripAddNewItem";
            this.DataGrid_ToolstripAddNewItem.RightToLeftAutoMirrorImage = true;
            this.DataGrid_ToolstripAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.DataGrid_ToolstripAddNewItem.Text = "Add new";
            // 
            // DataGrid_ToolstripMoveNext
            // 
            this.DataGrid_ToolstripMoveNext.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.DataGrid_ToolstripMoveNext.Image = ((System.Drawing.Image)(resources.GetObject("DataGrid_ToolstripMoveNext.Image")));
            this.DataGrid_ToolstripMoveNext.Name = "DataGrid_ToolstripMoveNext";
            this.DataGrid_ToolstripMoveNext.RightToLeftAutoMirrorImage = true;
            this.DataGrid_ToolstripMoveNext.Size = new System.Drawing.Size(23, 22);
            this.DataGrid_ToolstripMoveNext.Text = "Move next";
            // 
            // DataGrid_ToolstripMoveBack
            // 
            this.DataGrid_ToolstripMoveBack.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.DataGrid_ToolstripMoveBack.Image = ((System.Drawing.Image)(resources.GetObject("DataGrid_ToolstripMoveBack.Image")));
            this.DataGrid_ToolstripMoveBack.Name = "DataGrid_ToolstripMoveBack";
            this.DataGrid_ToolstripMoveBack.RightToLeftAutoMirrorImage = true;
            this.DataGrid_ToolstripMoveBack.Size = new System.Drawing.Size(23, 22);
            this.DataGrid_ToolstripMoveBack.Text = "Move back";
            // 
            // DataGrid_MyButton
            // 
            this.DataGrid_MyButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.DataGrid_MyButton.Image = ((System.Drawing.Image)(resources.GetObject("DataGrid_MyButton.Image")));
            this.DataGrid_MyButton.Name = "DataGrid_MyButton";
            this.DataGrid_MyButton.Size = new System.Drawing.Size(23, 22);
            this.DataGrid_MyButton.Text = "My Button2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(874, 514);
            this.Controls.Add(this.tabControl1);
             
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Library";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.getLocalitiesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.library_dbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.getStreetTypesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.streetsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }



        #endregion
        private System.Windows.Forms.ToolStripMenuItem изданияToolStripMenuItem;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton newToolStripButton;
        private System.Windows.Forms.ToolStripButton openToolStripButton;
        private System.Windows.Forms.ToolStripButton saveToolStripButton;
        private System.Windows.Forms.ToolStripButton printToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripButton cutToolStripButton;
        private System.Windows.Forms.ToolStripButton copyToolStripButton;
        private System.Windows.Forms.ToolStripButton pasteToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton helpToolStripButton;
        //private library2.MyToolBar myToolBar1;
        private System.Windows.Forms.ToolStripButton DataGrid_ToolstripAddNewItem;
        private System.Windows.Forms.ToolStripButton DataGrid_ToolstripMoveNext;
        private System.Windows.Forms.ToolStripButton DataGrid_ToolstripMoveBack;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton DataGrid_MyButton;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl tabControl1;
        private library_dbDataSet library_dbDataSet;
        private System.Windows.Forms.BindingSource streetsBindingSource;
        private library_dbDataSetTableAdapters.StreetsTableAdapter streetsTableAdapter;
        private System.Windows.Forms.BindingSource getLocalitiesBindingSource;
        private library_dbDataSetTableAdapters.GetLocalitiesTableAdapter getLocalitiesTableAdapter;
        private System.Windows.Forms.BindingSource getStreetTypesBindingSource;
        private library_dbDataSetTableAdapters.GetStreetTypesTableAdapter getStreetTypesTableAdapter;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem таблицыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem адресаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem улицыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem страныToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem населенныеПунктыToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem типыУлицToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem типыНаселенныхПунктовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem книгиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem экземплярыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem читателиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задолженностиToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem хронологияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem работникиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem издательстваToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem предметыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem дополнительноToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem полыToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem типыОперацийToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem типыИзданийToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem языкиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem жанрыToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem должностиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem авторыToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem книгиКлючевыеСловаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчетыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem помощьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem помощьToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem поискИзданияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem testToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem хронологияИзданийToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
    }
}

