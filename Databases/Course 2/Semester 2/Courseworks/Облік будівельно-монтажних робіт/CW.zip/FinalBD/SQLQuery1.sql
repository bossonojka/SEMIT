use [FinalBD]
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE sp_finalYearService
AS
BEGIN
	SET NOCOUNT ON;

	select distinct TypeOfWorkOnObject.IdObject, TypeOfWorkOnObject.IdTypeOfWork, TypeOfWorkOnObject.PriceService, Building.IdObject, Building.NameObject, Building.TypeOfObject
	from Building inner join TypeOfWorkOnObject on TypeOfWorkOnObject.IdObject = Building.IdObject

END
GO
