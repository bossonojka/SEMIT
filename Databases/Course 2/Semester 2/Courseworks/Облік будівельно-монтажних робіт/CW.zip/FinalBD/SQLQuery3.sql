use [FinalBD]
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE sp_finaldlv
AS
BEGIN
	SET NOCOUNT ON;

	select distinct DeliveredMaterials.IdProcurementContract, DeliveredMaterials.IdMaterials, sum(DeliveredMaterials.Amount * DeliveredMaterials.PurchasePrice) as costPrice
	from DeliveredMaterials
	group by DeliveredMaterials.IdProcurementContract, DeliveredMaterials.IdMaterials

END
GO
