﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace FinalBD
{
    public partial class FirstForm : Form
    {
        public FirstForm()
        {
            InitializeComponent();
        }

        private void exit_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void work_btn_Click(object sender, EventArgs e)
        {
            WorkList forma = new WorkList();
            forma.Show();
        }

        private void materials_btn_Click(object sender, EventArgs e)
        {
            materials forma = new materials();
            forma.Show();
        }

        private void building_btn_Click(object sender, EventArgs e)
        {
            building forma = new building();
            forma.Show();
        }

        private void person_btn_Click(object sender, EventArgs e)
        {
            person forma = new person();
            forma.Show();
        }

        private void address_btn_Click(object sender, EventArgs e)
        {
            address forma = new address();
            forma.Show();
        }

        private void speciality_btn_Click(object sender, EventArgs e)
        {
            speciality forma = new speciality();
            forma.Show();
        }

        private void report_btn_Click(object sender, EventArgs e)
        {
            report forma = new report();
            forma.Show();
        }

        private void FirstForm_Load(object sender, EventArgs e)
        {

        }
    }

}
