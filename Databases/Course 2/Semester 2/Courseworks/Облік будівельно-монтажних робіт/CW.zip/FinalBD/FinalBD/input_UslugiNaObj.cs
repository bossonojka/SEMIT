﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalBD
{
    public partial class input_UslugiNaObj : Form
    {
        public input_UslugiNaObj()
        {
            InitializeComponent();
        }

        private void btn_exec_Click(object sender, EventArgs e)
        {
            reportProfitService zlp = new reportProfitService();
            zlp.setContent(this.textBox1.Text);
            zlp.Show();
            this.Close();
        }
    }
}
