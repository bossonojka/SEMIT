﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalBD
{
    public partial class WorkList : Form
    {
        public WorkList()
        {
            InitializeComponent();
        }

        private void workListBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.workListBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.finalBDDataSet);

        }

        private void WorkList_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.WorkList". При необходимости она может быть перемещена или удалена.
            this.workListTableAdapter.Fill(this.finalBDDataSet.WorkList);

        }

        private void workLisDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_AddStaff_Click(object sender, EventArgs e)
        {
            form_add_worker zlp = new form_add_worker();
            zlp.Show();
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            this.workListTableAdapter.Update(this.finalBDDataSet);
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in workListDataGridView.SelectedRows)
            {
                workListDataGridView.Rows.Remove(row);
            }
        }
    }
}
