﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalBD
{
    public partial class address : Form
    {
        public address()
        {
            InitializeComponent();
        }

        private void countryBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.countryBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.finalBDDataSet);

        }

        private void address_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet2.view_Adress". При необходимости она может быть перемещена или удалена.
            this.view_AdressTableAdapter.Fill(this.finalBDDataSet2.view_Adress);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet1.view_Street". При необходимости она может быть перемещена или удалена.
            this.view_StreetTableAdapter.Fill(this.finalBDDataSet1.view_Street);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.view_Country". При необходимости она может быть перемещена или удалена.
            this.view_CountryTableAdapter.Fill(this.finalBDDataSet.view_Country);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Address". При необходимости она может быть перемещена или удалена.
            this.addressTableAdapter.Fill(this.finalBDDataSet.Address);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Street". При необходимости она может быть перемещена или удалена.
            this.streetTableAdapter.Fill(this.finalBDDataSet.Street);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.TypeOfStreet". При необходимости она может быть перемещена или удалена.
            this.typeOfStreetTableAdapter.Fill(this.finalBDDataSet.TypeOfStreet);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Locality". При необходимости она может быть перемещена или удалена.
            this.localityTableAdapter.Fill(this.finalBDDataSet.Locality);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Region". При необходимости она может быть перемещена или удалена.
            this.regionTableAdapter.Fill(this.finalBDDataSet.Region);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Country". При необходимости она может быть перемещена или удалена.
            this.countryTableAdapter.Fill(this.finalBDDataSet.Country);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            form_add_typeofstreet zlp = new form_add_typeofstreet();
            zlp.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach(DataGridViewRow row in typeOfStreetDataGridView.SelectedRows)
            {
                typeOfStreetDataGridView.Rows.Remove(row);
            }
        }

        private void typeOfStreetDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.typeOfStreetTableAdapter.Fill(this.finalBDDataSet.TypeOfStreet);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in countryDataGridView.SelectedRows)
            {
                countryDataGridView.Rows.Remove(row);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.countryTableAdapter.Fill(this.finalBDDataSet.Country);
        }
    }
}
