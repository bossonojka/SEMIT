﻿namespace FinalBD
{
    partial class speciality
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(speciality));
            this.specialtyBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.specialtyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.finalBDDataSet = new FinalBD.FinalBDDataSet();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.specialtyBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.specialtyDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qualificationsDataGridView = new System.Windows.Forms.DataGridView();
            this.idWorkerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewWorkerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.idSpecialtyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewSpecialityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.skillLevelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r104BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.job_SpecialtyDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewTypeOfWorkBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.r106BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.job_SpecialtyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.qualificationsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.specialtyTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.SpecialtyTableAdapter();
            this.tableAdapterManager = new FinalBD.FinalBDDataSetTableAdapters.TableAdapterManager();
            this.job_SpecialtyTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.Job_SpecialtyTableAdapter();
            this.qualificationsTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.QualificationsTableAdapter();
            this.view_WorkerTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.view_WorkerTableAdapter();
            this.view_SpecialityTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.view_SpecialityTableAdapter();
            this.viewSpecialityBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.view_TypeOfWorkTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.view_TypeOfWorkTableAdapter();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            ((System.ComponentModel.ISupportInitialize)(this.specialtyBindingNavigator)).BeginInit();
            this.specialtyBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.specialtyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.specialtyDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qualificationsDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewWorkerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewSpecialityBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r104BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.job_SpecialtyDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewTypeOfWorkBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r106BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.job_SpecialtyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qualificationsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewSpecialityBindingSource1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // specialtyBindingNavigator
            // 
            this.specialtyBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.specialtyBindingNavigator.BindingSource = this.specialtyBindingSource;
            this.specialtyBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.specialtyBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.specialtyBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.specialtyBindingNavigatorSaveItem});
            this.specialtyBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.specialtyBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.specialtyBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.specialtyBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.specialtyBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.specialtyBindingNavigator.Name = "specialtyBindingNavigator";
            this.specialtyBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.specialtyBindingNavigator.Size = new System.Drawing.Size(551, 25);
            this.specialtyBindingNavigator.TabIndex = 0;
            this.specialtyBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // specialtyBindingSource
            // 
            this.specialtyBindingSource.DataMember = "Specialty";
            this.specialtyBindingSource.DataSource = this.finalBDDataSet;
            // 
            // finalBDDataSet
            // 
            this.finalBDDataSet.DataSetName = "FinalBDDataSet";
            this.finalBDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // specialtyBindingNavigatorSaveItem
            // 
            this.specialtyBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.specialtyBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("specialtyBindingNavigatorSaveItem.Image")));
            this.specialtyBindingNavigatorSaveItem.Name = "specialtyBindingNavigatorSaveItem";
            this.specialtyBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.specialtyBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.specialtyBindingNavigatorSaveItem.Click += new System.EventHandler(this.specialtyBindingNavigatorSaveItem_Click);
            // 
            // specialtyDataGridView
            // 
            this.specialtyDataGridView.AutoGenerateColumns = false;
            this.specialtyDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.specialtyDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.specialtyDataGridView.DataSource = this.specialtyBindingSource;
            this.specialtyDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.specialtyDataGridView.Location = new System.Drawing.Point(3, 3);
            this.specialtyDataGridView.Name = "specialtyDataGridView";
            this.specialtyDataGridView.Size = new System.Drawing.Size(537, 311);
            this.specialtyDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "IdSpecialty";
            this.dataGridViewTextBoxColumn1.HeaderText = "IdSpecialty";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "SpecialtyName";
            this.dataGridViewTextBoxColumn2.HeaderText = "SpecialtyName";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // qualificationsDataGridView
            // 
            this.qualificationsDataGridView.AutoGenerateColumns = false;
            this.qualificationsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.qualificationsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idWorkerDataGridViewTextBoxColumn,
            this.idSpecialtyDataGridViewTextBoxColumn,
            this.skillLevelDataGridViewTextBoxColumn});
            this.qualificationsDataGridView.DataSource = this.r104BindingSource;
            this.qualificationsDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.qualificationsDataGridView.Location = new System.Drawing.Point(3, 3);
            this.qualificationsDataGridView.Name = "qualificationsDataGridView";
            this.qualificationsDataGridView.Size = new System.Drawing.Size(537, 311);
            this.qualificationsDataGridView.TabIndex = 2;
            // 
            // idWorkerDataGridViewTextBoxColumn
            // 
            this.idWorkerDataGridViewTextBoxColumn.DataPropertyName = "IdWorker";
            this.idWorkerDataGridViewTextBoxColumn.DataSource = this.viewWorkerBindingSource;
            this.idWorkerDataGridViewTextBoxColumn.DisplayMember = "Worker";
            this.idWorkerDataGridViewTextBoxColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.idWorkerDataGridViewTextBoxColumn.HeaderText = "IdWorker";
            this.idWorkerDataGridViewTextBoxColumn.Name = "idWorkerDataGridViewTextBoxColumn";
            this.idWorkerDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.idWorkerDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.idWorkerDataGridViewTextBoxColumn.ValueMember = "IdWorker";
            // 
            // viewWorkerBindingSource
            // 
            this.viewWorkerBindingSource.DataMember = "view_Worker";
            this.viewWorkerBindingSource.DataSource = this.finalBDDataSet;
            // 
            // idSpecialtyDataGridViewTextBoxColumn
            // 
            this.idSpecialtyDataGridViewTextBoxColumn.DataPropertyName = "IdSpecialty";
            this.idSpecialtyDataGridViewTextBoxColumn.DataSource = this.viewSpecialityBindingSource;
            this.idSpecialtyDataGridViewTextBoxColumn.DisplayMember = "SpecialtyName";
            this.idSpecialtyDataGridViewTextBoxColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.idSpecialtyDataGridViewTextBoxColumn.HeaderText = "IdSpecialty";
            this.idSpecialtyDataGridViewTextBoxColumn.Name = "idSpecialtyDataGridViewTextBoxColumn";
            this.idSpecialtyDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.idSpecialtyDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.idSpecialtyDataGridViewTextBoxColumn.ValueMember = "IdSpecialty";
            // 
            // viewSpecialityBindingSource
            // 
            this.viewSpecialityBindingSource.DataMember = "view_Speciality";
            this.viewSpecialityBindingSource.DataSource = this.finalBDDataSet;
            // 
            // skillLevelDataGridViewTextBoxColumn
            // 
            this.skillLevelDataGridViewTextBoxColumn.DataPropertyName = "SkillLevel";
            this.skillLevelDataGridViewTextBoxColumn.HeaderText = "SkillLevel";
            this.skillLevelDataGridViewTextBoxColumn.Name = "skillLevelDataGridViewTextBoxColumn";
            // 
            // r104BindingSource
            // 
            this.r104BindingSource.DataMember = "R_104";
            this.r104BindingSource.DataSource = this.specialtyBindingSource;
            // 
            // job_SpecialtyDataGridView
            // 
            this.job_SpecialtyDataGridView.AutoGenerateColumns = false;
            this.job_SpecialtyDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.job_SpecialtyDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn6});
            this.job_SpecialtyDataGridView.DataSource = this.r106BindingSource;
            this.job_SpecialtyDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.job_SpecialtyDataGridView.Location = new System.Drawing.Point(3, 3);
            this.job_SpecialtyDataGridView.Name = "job_SpecialtyDataGridView";
            this.job_SpecialtyDataGridView.Size = new System.Drawing.Size(537, 311);
            this.job_SpecialtyDataGridView.TabIndex = 3;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "IdSpecialty";
            this.dataGridViewTextBoxColumn7.DataSource = this.viewSpecialityBindingSource;
            this.dataGridViewTextBoxColumn7.DisplayMember = "SpecialtyName";
            this.dataGridViewTextBoxColumn7.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn7.HeaderText = "IdSpecialty";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn7.ValueMember = "IdSpecialty";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "IdTypeOfWork";
            this.dataGridViewTextBoxColumn6.DataSource = this.viewTypeOfWorkBindingSource;
            this.dataGridViewTextBoxColumn6.DisplayMember = "NameTypeOfWork";
            this.dataGridViewTextBoxColumn6.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn6.HeaderText = "IdTypeOfWork";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn6.ValueMember = "IdTypeOfWork";
            // 
            // viewTypeOfWorkBindingSource
            // 
            this.viewTypeOfWorkBindingSource.DataMember = "view_TypeOfWork";
            this.viewTypeOfWorkBindingSource.DataSource = this.finalBDDataSet;
            // 
            // r106BindingSource
            // 
            this.r106BindingSource.DataMember = "R_106";
            this.r106BindingSource.DataSource = this.specialtyBindingSource;
            // 
            // job_SpecialtyBindingSource
            // 
            this.job_SpecialtyBindingSource.DataMember = "Job_Specialty";
            this.job_SpecialtyBindingSource.DataSource = this.finalBDDataSet;
            // 
            // qualificationsBindingSource
            // 
            this.qualificationsBindingSource.DataMember = "Qualifications";
            this.qualificationsBindingSource.DataSource = this.finalBDDataSet;
            // 
            // specialtyTableAdapter
            // 
            this.specialtyTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AddressTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BrigadeListTableAdapter = null;
            this.tableAdapterManager.BrigadeTableAdapter = null;
            this.tableAdapterManager.BuildingTableAdapter = null;
            this.tableAdapterManager.ContactInformationTableAdapter = null;
            this.tableAdapterManager.ContractTableAdapter = null;
            this.tableAdapterManager.CountryTableAdapter = null;
            this.tableAdapterManager.DeliveredMaterialsTableAdapter = null;
            this.tableAdapterManager.GenderTableAdapter = null;
            this.tableAdapterManager.Job_SpecialtyTableAdapter = this.job_SpecialtyTableAdapter;
            this.tableAdapterManager.LegalEntityTableAdapter = null;
            this.tableAdapterManager.LocalityTableAdapter = null;
            this.tableAdapterManager.MaterialsTableAdapter = null;
            this.tableAdapterManager.MobileNumberTableAdapter = null;
            this.tableAdapterManager.MobileOperatorTableAdapter = null;
            this.tableAdapterManager.NumberMobileOperatorTableAdapter = null;
            this.tableAdapterManager.PersonTableAdapter = null;
            this.tableAdapterManager.PhoneTableAdapter = null;
            this.tableAdapterManager.PhysicalPersonTableAdapter = null;
            this.tableAdapterManager.ProcurementContractTableAdapter = null;
            this.tableAdapterManager.ProcurementTypeTableAdapter = null;
            this.tableAdapterManager.QualificationsTableAdapter = this.qualificationsTableAdapter;
            this.tableAdapterManager.RegionTableAdapter = null;
            this.tableAdapterManager.ServiceContractTableAdapter = null;
            this.tableAdapterManager.SpecialtyTableAdapter = this.specialtyTableAdapter;
            this.tableAdapterManager.StationaryNumberTableAdapter = null;
            this.tableAdapterManager.StreetTableAdapter = null;
            this.tableAdapterManager.TypeOfPersonTableAdapter = null;
            this.tableAdapterManager.TypeOfStreetTableAdapter = null;
            this.tableAdapterManager.TypeOfWorkOnObjectTableAdapter = null;
            this.tableAdapterManager.TypeOfWorkTableAdapter = null;
            this.tableAdapterManager.UnitsTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = FinalBD.FinalBDDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UsedMaterialsTableAdapter = null;
            this.tableAdapterManager.WorkListTableAdapter = null;
            this.tableAdapterManager.WorkScheduleTableAdapter = null;
            // 
            // job_SpecialtyTableAdapter
            // 
            this.job_SpecialtyTableAdapter.ClearBeforeFill = true;
            // 
            // qualificationsTableAdapter
            // 
            this.qualificationsTableAdapter.ClearBeforeFill = true;
            // 
            // view_WorkerTableAdapter
            // 
            this.view_WorkerTableAdapter.ClearBeforeFill = true;
            // 
            // view_SpecialityTableAdapter
            // 
            this.view_SpecialityTableAdapter.ClearBeforeFill = true;
            // 
            // viewSpecialityBindingSource1
            // 
            this.viewSpecialityBindingSource1.DataMember = "view_Speciality";
            this.viewSpecialityBindingSource1.DataSource = this.finalBDDataSet;
            // 
            // view_TypeOfWorkTableAdapter
            // 
            this.view_TypeOfWorkTableAdapter.ClearBeforeFill = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(0, 28);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(551, 343);
            this.tabControl1.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.specialtyDataGridView);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(543, 317);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Специальности";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.qualificationsDataGridView);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(543, 317);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Квалификации";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.job_SpecialtyDataGridView);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(543, 317);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Специальность_Работа";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // speciality
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(551, 369);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.specialtyBindingNavigator);
            this.Name = "speciality";
            this.Text = "speciality";
            this.Load += new System.EventHandler(this.speciality_Load);
            ((System.ComponentModel.ISupportInitialize)(this.specialtyBindingNavigator)).EndInit();
            this.specialtyBindingNavigator.ResumeLayout(false);
            this.specialtyBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.specialtyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.specialtyDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qualificationsDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewWorkerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewSpecialityBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r104BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.job_SpecialtyDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewTypeOfWorkBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r106BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.job_SpecialtyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qualificationsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewSpecialityBindingSource1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private FinalBDDataSet finalBDDataSet;
        private System.Windows.Forms.BindingSource specialtyBindingSource;
        private FinalBDDataSetTableAdapters.SpecialtyTableAdapter specialtyTableAdapter;
        private FinalBDDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator specialtyBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton specialtyBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView specialtyDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private FinalBDDataSetTableAdapters.QualificationsTableAdapter qualificationsTableAdapter;
        private FinalBDDataSetTableAdapters.Job_SpecialtyTableAdapter job_SpecialtyTableAdapter;
        private System.Windows.Forms.DataGridView qualificationsDataGridView;
        private System.Windows.Forms.BindingSource job_SpecialtyBindingSource;
        private System.Windows.Forms.DataGridView job_SpecialtyDataGridView;
        private System.Windows.Forms.BindingSource qualificationsBindingSource;
        private System.Windows.Forms.BindingSource r104BindingSource;
        private System.Windows.Forms.BindingSource r106BindingSource;
        private System.Windows.Forms.BindingSource viewWorkerBindingSource;
        private FinalBDDataSetTableAdapters.view_WorkerTableAdapter view_WorkerTableAdapter;
        private System.Windows.Forms.BindingSource viewSpecialityBindingSource;
        private FinalBDDataSetTableAdapters.view_SpecialityTableAdapter view_SpecialityTableAdapter;
        private System.Windows.Forms.DataGridViewComboBoxColumn idWorkerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn idSpecialtyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn skillLevelDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource viewSpecialityBindingSource1;
        private System.Windows.Forms.BindingSource viewTypeOfWorkBindingSource;
        private FinalBDDataSetTableAdapters.view_TypeOfWorkTableAdapter view_TypeOfWorkTableAdapter;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
    }
}