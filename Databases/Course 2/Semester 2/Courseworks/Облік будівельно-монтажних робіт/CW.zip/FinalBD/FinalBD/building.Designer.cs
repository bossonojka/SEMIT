﻿namespace FinalBD
{
    partial class building
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(building));
            this.buildingBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.buildingBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.buildingDataGridView = new System.Windows.Forms.DataGridView();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.typeOfWorkOnObjectDataGridView = new System.Windows.Forms.DataGridView();
            this.typeOfWorkDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buildingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.finalBDDataSet = new FinalBD.FinalBDDataSet();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typeOfWorkBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typeOfWorkOnObjectBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.buildingTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.BuildingTableAdapter();
            this.tableAdapterManager = new FinalBD.FinalBDDataSetTableAdapters.TableAdapterManager();
            this.typeOfWorkOnObjectTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.TypeOfWorkOnObjectTableAdapter();
            this.typeOfWorkTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.TypeOfWorkTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.buildingBindingNavigator)).BeginInit();
            this.buildingBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.buildingDataGridView)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.typeOfWorkOnObjectDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeOfWorkDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.buildingBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeOfWorkBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeOfWorkOnObjectBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // buildingBindingNavigator
            // 
            this.buildingBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.buildingBindingNavigator.BindingSource = this.buildingBindingSource;
            this.buildingBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.buildingBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.buildingBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.buildingBindingNavigatorSaveItem});
            this.buildingBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.buildingBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.buildingBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.buildingBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.buildingBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.buildingBindingNavigator.Name = "buildingBindingNavigator";
            this.buildingBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.buildingBindingNavigator.Size = new System.Drawing.Size(497, 25);
            this.buildingBindingNavigator.TabIndex = 0;
            this.buildingBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // buildingBindingNavigatorSaveItem
            // 
            this.buildingBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.buildingBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("buildingBindingNavigatorSaveItem.Image")));
            this.buildingBindingNavigatorSaveItem.Name = "buildingBindingNavigatorSaveItem";
            this.buildingBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.buildingBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.buildingBindingNavigatorSaveItem.Click += new System.EventHandler(this.buildingBindingNavigatorSaveItem_Click);
            // 
            // buildingDataGridView
            // 
            this.buildingDataGridView.AutoGenerateColumns = false;
            this.buildingDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.buildingDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.buildingDataGridView.DataSource = this.buildingBindingSource;
            this.buildingDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buildingDataGridView.Location = new System.Drawing.Point(3, 3);
            this.buildingDataGridView.Name = "buildingDataGridView";
            this.buildingDataGridView.Size = new System.Drawing.Size(483, 354);
            this.buildingDataGridView.TabIndex = 1;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(0, 28);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(497, 386);
            this.tabControl1.TabIndex = 5;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.buildingDataGridView);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(489, 360);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Объекты";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.Controls.Add(this.typeOfWorkDataGridView);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(489, 360);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Виды работ";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.AutoScroll = true;
            this.tabPage3.Controls.Add(this.typeOfWorkOnObjectDataGridView);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(489, 360);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Виды работ на объекте";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // typeOfWorkOnObjectDataGridView
            // 
            this.typeOfWorkOnObjectDataGridView.AutoGenerateColumns = false;
            this.typeOfWorkOnObjectDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.typeOfWorkOnObjectDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.typeOfWorkOnObjectDataGridView.DataSource = this.typeOfWorkOnObjectBindingSource;
            this.typeOfWorkOnObjectDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.typeOfWorkOnObjectDataGridView.Location = new System.Drawing.Point(3, 3);
            this.typeOfWorkOnObjectDataGridView.Name = "typeOfWorkOnObjectDataGridView";
            this.typeOfWorkOnObjectDataGridView.Size = new System.Drawing.Size(483, 354);
            this.typeOfWorkOnObjectDataGridView.TabIndex = 0;
            this.typeOfWorkOnObjectDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.typeOfWorkOnObjectDataGridView_CellContentClick);
            // 
            // typeOfWorkDataGridView
            // 
            this.typeOfWorkDataGridView.AutoGenerateColumns = false;
            this.typeOfWorkDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.typeOfWorkDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10});
            this.typeOfWorkDataGridView.DataSource = this.typeOfWorkBindingSource;
            this.typeOfWorkDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.typeOfWorkDataGridView.Location = new System.Drawing.Point(3, 3);
            this.typeOfWorkDataGridView.Name = "typeOfWorkDataGridView";
            this.typeOfWorkDataGridView.Size = new System.Drawing.Size(483, 354);
            this.typeOfWorkDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "IdObject";
            this.dataGridViewTextBoxColumn1.HeaderText = "IdObject";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "NameObject";
            this.dataGridViewTextBoxColumn2.HeaderText = "NameObject";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "TypeOfObject";
            this.dataGridViewTextBoxColumn3.HeaderText = "TypeOfObject";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "IdAddress";
            this.dataGridViewTextBoxColumn4.HeaderText = "IdAddress";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // buildingBindingSource
            // 
            this.buildingBindingSource.DataMember = "Building";
            this.buildingBindingSource.DataSource = this.finalBDDataSet;
            // 
            // finalBDDataSet
            // 
            this.finalBDDataSet.DataSetName = "FinalBDDataSet";
            this.finalBDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "IdTypeOfWork";
            this.dataGridViewTextBoxColumn8.HeaderText = "IdTypeOfWork";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "NameTypeOfWork";
            this.dataGridViewTextBoxColumn9.HeaderText = "NameTypeOfWork";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Description";
            this.dataGridViewTextBoxColumn10.HeaderText = "Description";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // typeOfWorkBindingSource
            // 
            this.typeOfWorkBindingSource.DataMember = "TypeOfWork";
            this.typeOfWorkBindingSource.DataSource = this.finalBDDataSet;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "IdObject";
            this.dataGridViewTextBoxColumn5.HeaderText = "IdObject";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "IdTypeOfWork";
            this.dataGridViewTextBoxColumn6.HeaderText = "IdTypeOfWork";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "PriceService";
            this.dataGridViewTextBoxColumn7.HeaderText = "PriceService";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // typeOfWorkOnObjectBindingSource
            // 
            this.typeOfWorkOnObjectBindingSource.DataMember = "TypeOfWorkOnObject";
            this.typeOfWorkOnObjectBindingSource.DataSource = this.finalBDDataSet;
            // 
            // buildingTableAdapter
            // 
            this.buildingTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AddressTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BrigadeListTableAdapter = null;
            this.tableAdapterManager.BrigadeTableAdapter = null;
            this.tableAdapterManager.BuildingTableAdapter = this.buildingTableAdapter;
            this.tableAdapterManager.ContactInformationTableAdapter = null;
            this.tableAdapterManager.ContractTableAdapter = null;
            this.tableAdapterManager.CountryTableAdapter = null;
            this.tableAdapterManager.DeliveredMaterialsTableAdapter = null;
            this.tableAdapterManager.GenderTableAdapter = null;
            this.tableAdapterManager.Job_SpecialtyTableAdapter = null;
            this.tableAdapterManager.LegalEntityTableAdapter = null;
            this.tableAdapterManager.LocalityTableAdapter = null;
            this.tableAdapterManager.MaterialsTableAdapter = null;
            this.tableAdapterManager.MobileNumberTableAdapter = null;
            this.tableAdapterManager.MobileOperatorTableAdapter = null;
            this.tableAdapterManager.NumberMobileOperatorTableAdapter = null;
            this.tableAdapterManager.PersonTableAdapter = null;
            this.tableAdapterManager.PhoneTableAdapter = null;
            this.tableAdapterManager.PhysicalPersonTableAdapter = null;
            this.tableAdapterManager.ProcurementContractTableAdapter = null;
            this.tableAdapterManager.ProcurementTypeTableAdapter = null;
            this.tableAdapterManager.QualificationsTableAdapter = null;
            this.tableAdapterManager.RegionTableAdapter = null;
            this.tableAdapterManager.ServiceContractTableAdapter = null;
            this.tableAdapterManager.SpecialtyTableAdapter = null;
            this.tableAdapterManager.StationaryNumberTableAdapter = null;
            this.tableAdapterManager.StreetTableAdapter = null;
            this.tableAdapterManager.TypeOfPersonTableAdapter = null;
            this.tableAdapterManager.TypeOfStreetTableAdapter = null;
            this.tableAdapterManager.TypeOfWorkOnObjectTableAdapter = null;
            this.tableAdapterManager.TypeOfWorkTableAdapter = null;
            this.tableAdapterManager.UnitsTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = FinalBD.FinalBDDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UsedMaterialsTableAdapter = null;
            this.tableAdapterManager.WorkListTableAdapter = null;
            this.tableAdapterManager.WorkScheduleTableAdapter = null;
            // 
            // typeOfWorkOnObjectTableAdapter
            // 
            this.typeOfWorkOnObjectTableAdapter.ClearBeforeFill = true;
            // 
            // typeOfWorkTableAdapter
            // 
            this.typeOfWorkTableAdapter.ClearBeforeFill = true;
            // 
            // building
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(497, 414);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.buildingBindingNavigator);
            this.Name = "building";
            this.Text = "building";
            this.Load += new System.EventHandler(this.building_Load);
            ((System.ComponentModel.ISupportInitialize)(this.buildingBindingNavigator)).EndInit();
            this.buildingBindingNavigator.ResumeLayout(false);
            this.buildingBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.buildingDataGridView)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.typeOfWorkOnObjectDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeOfWorkDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.buildingBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeOfWorkBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeOfWorkOnObjectBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private FinalBDDataSet finalBDDataSet;
        private System.Windows.Forms.BindingSource buildingBindingSource;
        private FinalBDDataSetTableAdapters.BuildingTableAdapter buildingTableAdapter;
        private FinalBDDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator buildingBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton buildingBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView buildingDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.BindingSource typeOfWorkOnObjectBindingSource;
        private FinalBDDataSetTableAdapters.TypeOfWorkOnObjectTableAdapter typeOfWorkOnObjectTableAdapter;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.BindingSource typeOfWorkBindingSource;
        private FinalBDDataSetTableAdapters.TypeOfWorkTableAdapter typeOfWorkTableAdapter;
        private System.Windows.Forms.DataGridView typeOfWorkOnObjectDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridView typeOfWorkDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
    }
}