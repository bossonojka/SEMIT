﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalBD
{
    public partial class form_add_delivered_materials : Form
    {
        public form_add_delivered_materials()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            string conS = "Data Source=BODYAS-PC;Initial Catalog=FinalBD;Integrated Security=True";
            try
            {
                using (SqlConnection con = new SqlConnection(conS))
                {
                    using (SqlCommand cmd = new SqlCommand("add_DeliveredMaterials", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@IdProcurementContract", SqlDbType.Int).Value = int.Parse(comboBox1.SelectedValue.ToString());
                        cmd.Parameters.AddWithValue("@IdMaterials", SqlDbType.Int).Value = int.Parse(comboBox2.SelectedValue.ToString());
                        cmd.Parameters.AddWithValue("@Amount", SqlDbType.VarChar).Value = txt_input2.Text.ToString();
                        cmd.Parameters.AddWithValue("@PurchasePrise", SqlDbType.VarChar).Value = txt_input1.Text.ToString();
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Data Error!", "Error!",
               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Close();
        }

        private void form_add_delivered_materials_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Materials". При необходимости она может быть перемещена или удалена.
            this.materialsTableAdapter.Fill(this.finalBDDataSet.Materials);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.ProcurementContract". При необходимости она может быть перемещена или удалена.
            this.procurementContractTableAdapter.Fill(this.finalBDDataSet.ProcurementContract);

        }
    }
}
