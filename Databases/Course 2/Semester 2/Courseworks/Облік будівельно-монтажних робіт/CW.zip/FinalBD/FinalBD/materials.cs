﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalBD
{
    public partial class materials : Form
    {
        public materials()
        {
            InitializeComponent();
        }

        private void deliveredMaterialsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.deliveredMaterialsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.finalBDDataSet);

        }

        private void materials_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.ProcurementType". При необходимости она может быть перемещена или удалена.
            this.procurementTypeTableAdapter.Fill(this.finalBDDataSet.ProcurementType);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.view_Materials". При необходимости она может быть перемещена или удалена.
            this.view_MaterialsTableAdapter.Fill(this.finalBDDataSet.view_Materials);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.view_Provider". При необходимости она может быть перемещена или удалена.
            this.view_ProviderTableAdapter.Fill(this.finalBDDataSet.view_Provider);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.view_Building". При необходимости она может быть перемещена или удалена.
            this.view_BuildingTableAdapter.Fill(this.finalBDDataSet.view_Building);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.view_Unit". При необходимости она может быть перемещена или удалена.
            this.view_UnitTableAdapter.Fill(this.finalBDDataSet.view_Unit);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.UsedMaterials". При необходимости она может быть перемещена или удалена.
            this.deliveredMaterialsTableAdapter.Fill(this.finalBDDataSet.DeliveredMaterials);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.UsedMaterials". При необходимости она может быть перемещена или удалена.
            this.usedMaterialsTableAdapter.Fill(this.finalBDDataSet.UsedMaterials);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.ServiceContract". При необходимости она может быть перемещена или удалена.
            this.serviceContractTableAdapter.Fill(this.finalBDDataSet.ServiceContract);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Contract". При необходимости она может быть перемещена или удалена.
            this.contractTableAdapter.Fill(this.finalBDDataSet.Contract);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.ProcurementContract". При необходимости она может быть перемещена или удалена.
            this.procurementContractTableAdapter.Fill(this.finalBDDataSet.ProcurementContract);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Materials". При необходимости она может быть перемещена или удалена.
            this.materialsTableAdapter.Fill(this.finalBDDataSet.Materials);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Units". При необходимости она может быть перемещена или удалена.
            this.unitsTableAdapter.Fill(this.finalBDDataSet.Units);

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void materialsDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void deliveredMaterialsDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_AddStaff_Click(object sender, EventArgs e)
        {
            form_add_units zlp = new form_add_units();
            zlp.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            form_add_materials zlp = new form_add_materials();
            zlp.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            form_add_procurementcontract zlp = new form_add_procurementcontract();
            zlp.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            form_add_contract zlp = new form_add_contract();
            zlp.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            form_add_servicecontract zlp = new form_add_servicecontract();
            zlp.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            form_add_delivered_materials zlp = new form_add_delivered_materials();
            zlp.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            form_add_used_materials zlp = new form_add_used_materials();
            zlp.Show();
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in unitsDataGridView.SelectedRows)
            {
               unitsDataGridView.Rows.Remove(row);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in materialsDataGridView.SelectedRows)
            {
                materialsDataGridView.Rows.Remove(row);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in procurementContractDataGridView.SelectedRows)
            {
                procurementContractDataGridView.Rows.Remove(row);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in serviceContractDataGridView.SelectedRows)
            {
                serviceContractDataGridView.Rows.Remove(row);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
                foreach (DataGridViewRow row in contractDataGridView.SelectedRows)
            {
                contractDataGridView.Rows.Remove(row);
            }
        }
    }
}
