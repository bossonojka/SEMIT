﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalBD
{
    public partial class reportProfitService : Form
    {
        public reportProfitService()
        {
            InitializeComponent();
        }

        private void reportProfitService_Load(object sender, EventArgs e)
        {
            int input = int.Parse(this.textBox1.Text.ToString());
            // TODO: данная строка кода позволяет загрузить данные в таблицу "FinalBDDataSet.sp_profitService". При необходимости она может быть перемещена или удалена.
            this.sp_profitServiceTableAdapter.Fill(this.FinalBDDataSet.sp_profitService, input);

            this.reportViewer1.RefreshReport();
        }

        public void setContent(string txt)
        {
            this.textBox1.Text = txt;
        }
    }
}
