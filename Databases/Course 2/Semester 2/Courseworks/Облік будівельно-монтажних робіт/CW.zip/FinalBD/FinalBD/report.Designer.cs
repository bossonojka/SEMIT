﻿namespace FinalBD
{
    partial class report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.profitMaterials = new System.Windows.Forms.Button();
            this.costMaterials = new System.Windows.Forms.Button();
            this.profitService = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // profitMaterials
            // 
            this.profitMaterials.Location = new System.Drawing.Point(12, 12);
            this.profitMaterials.Name = "profitMaterials";
            this.profitMaterials.Size = new System.Drawing.Size(171, 36);
            this.profitMaterials.TabIndex = 0;
            this.profitMaterials.Text = "Отчет по проданым товарам";
            this.profitMaterials.UseVisualStyleBackColor = true;
            this.profitMaterials.Click += new System.EventHandler(this.button1_Click);
            // 
            // costMaterials
            // 
            this.costMaterials.Location = new System.Drawing.Point(12, 54);
            this.costMaterials.Name = "costMaterials";
            this.costMaterials.Size = new System.Drawing.Size(171, 36);
            this.costMaterials.TabIndex = 1;
            this.costMaterials.Text = "Отчет по закупленым товарам";
            this.costMaterials.UseVisualStyleBackColor = true;
            this.costMaterials.Click += new System.EventHandler(this.costMaterials_Click);
            // 
            // profitService
            // 
            this.profitService.Location = new System.Drawing.Point(12, 96);
            this.profitService.Name = "profitService";
            this.profitService.Size = new System.Drawing.Size(171, 36);
            this.profitService.TabIndex = 2;
            this.profitService.Text = "Отчет по услугам на объект";
            this.profitService.UseVisualStyleBackColor = true;
            this.profitService.Click += new System.EventHandler(this.profitService_Click);
            // 
            // exit
            // 
            this.exit.Location = new System.Drawing.Point(690, 402);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(98, 36);
            this.exit.TabIndex = 3;
            this.exit.Text = "Exit";
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.profitService);
            this.Controls.Add(this.costMaterials);
            this.Controls.Add(this.profitMaterials);
            this.Name = "report";
            this.Text = "report";
            this.Load += new System.EventHandler(this.report_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button profitMaterials;
        private System.Windows.Forms.Button costMaterials;
        private System.Windows.Forms.Button profitService;
        private System.Windows.Forms.Button exit;
    }
}