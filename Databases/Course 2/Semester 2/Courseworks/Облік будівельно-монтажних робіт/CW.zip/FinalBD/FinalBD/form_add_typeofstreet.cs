﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalBD
{
    public partial class form_add_typeofstreet : Form
    {
        public form_add_typeofstreet()
        {
            InitializeComponent();
        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            string conS = "Data Source=BODYAS-PC;Initial Catalog=FinalBD;Integrated Security=True";

            try
            {
                
                using (SqlConnection con = new SqlConnection(conS))
                {
                    
                    using (SqlCommand cmd = new SqlCommand("add_TypeOfStreet", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@name", SqlDbType.VarChar).Value = txt_ToS.Text.ToString();
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Data Error", "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Close();
        }

        private void form_add_typeofstreet_Load(object sender, EventArgs e)
        {

        }

        private void txt_ToS_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
