﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalBD
{
    public partial class person : Form
    {
        public person()
        {
            InitializeComponent();
        }

        //private void addressBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        //{
        //    this.Validate();
        //    this.addressBindingSource.EndEdit();
        //    this.tableAdapterManager.UpdateAll(this.finalBDDataSet);

        //}

        private void personBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.personBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.finalBDDataSet);

        }

        private void personBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.personBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.finalBDDataSet);

        }

        private void person_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet1.view_Adress". При необходимости она может быть перемещена или удалена.
            this.view_AdressTableAdapter.Fill(this.finalBDDataSet1.view_Adress);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet1.view_Provider". При необходимости она может быть перемещена или удалена.
            this.view_ProviderTableAdapter.Fill(this.finalBDDataSet1.view_Provider);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.PhysicalPerson". При необходимости она может быть перемещена или удалена.
            this.physicalPersonTableAdapter.Fill(this.finalBDDataSet.PhysicalPerson);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.LegalEntity". При необходимости она может быть перемещена или удалена.
            this.legalEntityTableAdapter.Fill(this.finalBDDataSet.LegalEntity);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.TypeOfPerson". При необходимости она может быть перемещена или удалена.
            this.typeOfPersonTableAdapter.Fill(this.finalBDDataSet.TypeOfPerson);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Person". При необходимости она может быть перемещена или удалена.
            this.personTableAdapter.Fill(this.finalBDDataSet.Person);

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
