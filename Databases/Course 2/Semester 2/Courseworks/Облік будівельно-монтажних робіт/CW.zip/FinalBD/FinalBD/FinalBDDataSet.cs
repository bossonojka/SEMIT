﻿namespace FinalBD
{


    public partial class FinalBDDataSet
    {
    }
}
namespace FinalBD {
    
    
    public partial class FinalBDDataSet {
    }
}
