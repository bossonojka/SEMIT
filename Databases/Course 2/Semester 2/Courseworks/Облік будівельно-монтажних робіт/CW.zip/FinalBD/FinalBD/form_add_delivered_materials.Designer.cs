﻿namespace FinalBD
{
    partial class form_add_delivered_materials
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_input2 = new System.Windows.Forms.TextBox();
            this.txt_input1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_save = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.finalBDDataSet = new FinalBD.FinalBDDataSet();
            this.finalBDDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.procurementContractBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.procurementContractTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.ProcurementContractTableAdapter();
            this.materialsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.materialsTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.MaterialsTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.procurementContractBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.procurementContractBindingSource;
            this.comboBox1.DisplayMember = "IdProcurementContract";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(12, 28);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 56;
            this.comboBox1.ValueMember = "IdProcurement";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(9, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 17);
            this.label3.TabIndex = 53;
            this.label3.Text = "Выберите контракт";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // txt_input2
            // 
            this.txt_input2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txt_input2.Location = new System.Drawing.Point(12, 96);
            this.txt_input2.Name = "txt_input2";
            this.txt_input2.Size = new System.Drawing.Size(121, 23);
            this.txt_input2.TabIndex = 52;
            // 
            // txt_input1
            // 
            this.txt_input1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txt_input1.Location = new System.Drawing.Point(156, 96);
            this.txt_input1.Name = "txt_input1";
            this.txt_input1.Size = new System.Drawing.Size(121, 23);
            this.txt_input1.TabIndex = 51;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(153, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 17);
            this.label2.TabIndex = 50;
            this.label2.Text = "Выберите материал";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(9, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 17);
            this.label1.TabIndex = 49;
            this.label1.Text = "Введите кол-во";
            // 
            // btn_save
            // 
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_save.Location = new System.Drawing.Point(93, 149);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(100, 35);
            this.btn_save.TabIndex = 48;
            this.btn_save.Text = "Сохранить";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.materialsBindingSource;
            this.comboBox2.DisplayMember = "NameMaterials";
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(156, 28);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 57;
            this.comboBox2.ValueMember = "IdMaterials";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(153, 76);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 17);
            this.label4.TabIndex = 58;
            this.label4.Text = "Введите цену";
            // 
            // finalBDDataSet
            // 
            this.finalBDDataSet.DataSetName = "FinalBDDataSet";
            this.finalBDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // finalBDDataSetBindingSource
            // 
            this.finalBDDataSetBindingSource.DataSource = this.finalBDDataSet;
            this.finalBDDataSetBindingSource.Position = 0;
            // 
            // procurementContractBindingSource
            // 
            this.procurementContractBindingSource.DataMember = "ProcurementContract";
            this.procurementContractBindingSource.DataSource = this.finalBDDataSet;
            // 
            // procurementContractTableAdapter
            // 
            this.procurementContractTableAdapter.ClearBeforeFill = true;
            // 
            // materialsBindingSource
            // 
            this.materialsBindingSource.DataMember = "Materials";
            this.materialsBindingSource.DataSource = this.finalBDDataSetBindingSource;
            // 
            // materialsTableAdapter
            // 
            this.materialsTableAdapter.ClearBeforeFill = true;
            // 
            // form_add_delivered_materials
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(303, 239);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_input2);
            this.Controls.Add(this.txt_input1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_save);
            this.Name = "form_add_delivered_materials";
            this.Text = "form_add_delivered_materials";
            this.Load += new System.EventHandler(this.form_add_delivered_materials_Load);
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.procurementContractBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_input2;
        private System.Windows.Forms.TextBox txt_input1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.BindingSource finalBDDataSetBindingSource;
        private FinalBDDataSet finalBDDataSet;
        private System.Windows.Forms.BindingSource procurementContractBindingSource;
        private FinalBDDataSetTableAdapters.ProcurementContractTableAdapter procurementContractTableAdapter;
        private System.Windows.Forms.BindingSource materialsBindingSource;
        private FinalBDDataSetTableAdapters.MaterialsTableAdapter materialsTableAdapter;
    }
}