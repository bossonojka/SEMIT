﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalBD
{
    public partial class speciality : Form
    {
        public speciality()
        {
            InitializeComponent();
        }

        private void specialtyBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.specialtyBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.finalBDDataSet);

        }

        private void speciality_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.view_TypeOfWork". При необходимости она может быть перемещена или удалена.
            this.view_TypeOfWorkTableAdapter.Fill(this.finalBDDataSet.view_TypeOfWork);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.view_Speciality". При необходимости она может быть перемещена или удалена.
            this.view_SpecialityTableAdapter.Fill(this.finalBDDataSet.view_Speciality);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.view_Worker". При необходимости она может быть перемещена или удалена.
            this.view_WorkerTableAdapter.Fill(this.finalBDDataSet.view_Worker);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Job_Specialty". При необходимости она может быть перемещена или удалена.
            this.job_SpecialtyTableAdapter.Fill(this.finalBDDataSet.Job_Specialty);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Qualifications". При необходимости она может быть перемещена или удалена.
            this.qualificationsTableAdapter.Fill(this.finalBDDataSet.Qualifications);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Specialty". При необходимости она может быть перемещена или удалена.
            this.specialtyTableAdapter.Fill(this.finalBDDataSet.Specialty);

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
