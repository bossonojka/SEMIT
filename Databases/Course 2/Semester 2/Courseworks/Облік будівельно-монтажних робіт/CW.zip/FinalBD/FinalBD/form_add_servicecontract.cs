﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalBD
{
    public partial class form_add_servicecontract : Form
    {
        public form_add_servicecontract()
        {
            InitializeComponent();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            string conS = "Data Source=BODYAS-PC;Initial Catalog=FinalBD;Integrated Security=True";
            try
            {
                using (SqlConnection con = new SqlConnection(conS))
                {
                    using (SqlCommand cmd = new SqlCommand("add_ServiceContract", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@IdObject", SqlDbType.Int).Value = int.Parse(comboBox1.SelectedValue.ToString());
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Data Error!", "Error!",
               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Close();
        }

        private void form_add_servicecontract_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Building". При необходимости она может быть перемещена или удалена.
            this.buildingTableAdapter.Fill(this.finalBDDataSet.Building);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.sp_CostDlvr". При необходимости она может быть перемещена или удалена.
            this.sp_CostDlvrTableAdapter.Fill(this.finalBDDataSet.sp_CostDlvr);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.view_Building". При необходимости она может быть перемещена или удалена.
            this.view_BuildingTableAdapter.Fill(this.finalBDDataSet.view_Building);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.ServiceContract". При необходимости она может быть перемещена или удалена.
            this.serviceContractTableAdapter.Fill(this.finalBDDataSet.ServiceContract);

        }
    }
}
