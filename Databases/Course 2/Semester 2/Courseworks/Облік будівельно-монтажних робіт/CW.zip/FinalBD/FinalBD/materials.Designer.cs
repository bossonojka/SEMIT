﻿namespace FinalBD
{
    partial class materials
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(materials));
            this.finalBDDataSet = new FinalBD.FinalBDDataSet();
            this.deliveredMaterialsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.deliveredMaterialsTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.DeliveredMaterialsTableAdapter();
            this.tableAdapterManager = new FinalBD.FinalBDDataSetTableAdapters.TableAdapterManager();
            this.contractTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.ContractTableAdapter();
            this.materialsTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.MaterialsTableAdapter();
            this.procurementContractTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.ProcurementContractTableAdapter();
            this.serviceContractTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.ServiceContractTableAdapter();
            this.unitsTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.UnitsTableAdapter();
            this.usedMaterialsTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.UsedMaterialsTableAdapter();
            this.deliveredMaterialsBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.deliveredMaterialsBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Материалы = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btn_AddStaff = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.materialsDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewUnitBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.finalBDDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.materialsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.unitsDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.serviceContractDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewBuildingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fKServiceCoIdSer114A936ABindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.contractBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.contractDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewProviderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.procurementContractDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fKProcuremeIdPro0C85DE4DBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.deliveredMaterialsDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewMaterialsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usedMaterialsDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewMaterialsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r60BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.serviceContractBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.procurementContractBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.usedMaterialsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.view_UnitTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.view_UnitTableAdapter();
            this.view_BuildingTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.view_BuildingTableAdapter();
            this.view_ProviderTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.view_ProviderTableAdapter();
            this.view_MaterialsTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.view_MaterialsTableAdapter();
            this.procurementTypeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.procurementTypeTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.ProcurementTypeTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deliveredMaterialsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deliveredMaterialsBindingNavigator)).BeginInit();
            this.deliveredMaterialsBindingNavigator.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.Материалы.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.materialsDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewUnitBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unitsDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unitsBindingSource)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.serviceContractDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewBuildingBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKServiceCoIdSer114A936ABindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.contractBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.contractDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewProviderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.procurementContractDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKProcuremeIdPro0C85DE4DBindingSource)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.deliveredMaterialsDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewMaterialsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usedMaterialsDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewMaterialsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r60BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.serviceContractBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.procurementContractBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usedMaterialsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.procurementTypeBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // finalBDDataSet
            // 
            this.finalBDDataSet.DataSetName = "FinalBDDataSet";
            this.finalBDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // deliveredMaterialsBindingSource
            // 
            this.deliveredMaterialsBindingSource.DataMember = "DeliveredMaterials";
            this.deliveredMaterialsBindingSource.DataSource = this.finalBDDataSet;
            // 
            // deliveredMaterialsTableAdapter
            // 
            this.deliveredMaterialsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AddressTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BrigadeListTableAdapter = null;
            this.tableAdapterManager.BrigadeTableAdapter = null;
            this.tableAdapterManager.BuildingTableAdapter = null;
            this.tableAdapterManager.ContactInformationTableAdapter = null;
            this.tableAdapterManager.ContractTableAdapter = this.contractTableAdapter;
            this.tableAdapterManager.CountryTableAdapter = null;
            this.tableAdapterManager.DeliveredMaterialsTableAdapter = this.deliveredMaterialsTableAdapter;
            this.tableAdapterManager.GenderTableAdapter = null;
            this.tableAdapterManager.Job_SpecialtyTableAdapter = null;
            this.tableAdapterManager.LegalEntityTableAdapter = null;
            this.tableAdapterManager.LocalityTableAdapter = null;
            this.tableAdapterManager.MaterialsTableAdapter = this.materialsTableAdapter;
            this.tableAdapterManager.MobileNumberTableAdapter = null;
            this.tableAdapterManager.MobileOperatorTableAdapter = null;
            this.tableAdapterManager.NumberMobileOperatorTableAdapter = null;
            this.tableAdapterManager.PersonTableAdapter = null;
            this.tableAdapterManager.PhoneTableAdapter = null;
            this.tableAdapterManager.PhysicalPersonTableAdapter = null;
            this.tableAdapterManager.ProcurementContractTableAdapter = this.procurementContractTableAdapter;
            this.tableAdapterManager.ProcurementTypeTableAdapter = null;
            this.tableAdapterManager.QualificationsTableAdapter = null;
            this.tableAdapterManager.RegionTableAdapter = null;
            this.tableAdapterManager.ServiceContractTableAdapter = this.serviceContractTableAdapter;
            this.tableAdapterManager.SpecialtyTableAdapter = null;
            this.tableAdapterManager.StationaryNumberTableAdapter = null;
            this.tableAdapterManager.StreetTableAdapter = null;
            this.tableAdapterManager.TypeOfPersonTableAdapter = null;
            this.tableAdapterManager.TypeOfStreetTableAdapter = null;
            this.tableAdapterManager.TypeOfWorkOnObjectTableAdapter = null;
            this.tableAdapterManager.TypeOfWorkTableAdapter = null;
            this.tableAdapterManager.UnitsTableAdapter = this.unitsTableAdapter;
            this.tableAdapterManager.UpdateOrder = FinalBD.FinalBDDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UsedMaterialsTableAdapter = this.usedMaterialsTableAdapter;
            this.tableAdapterManager.WorkListTableAdapter = null;
            this.tableAdapterManager.WorkScheduleTableAdapter = null;
            // 
            // contractTableAdapter
            // 
            this.contractTableAdapter.ClearBeforeFill = true;
            // 
            // materialsTableAdapter
            // 
            this.materialsTableAdapter.ClearBeforeFill = true;
            // 
            // procurementContractTableAdapter
            // 
            this.procurementContractTableAdapter.ClearBeforeFill = true;
            // 
            // serviceContractTableAdapter
            // 
            this.serviceContractTableAdapter.ClearBeforeFill = true;
            // 
            // unitsTableAdapter
            // 
            this.unitsTableAdapter.ClearBeforeFill = true;
            // 
            // usedMaterialsTableAdapter
            // 
            this.usedMaterialsTableAdapter.ClearBeforeFill = true;
            // 
            // deliveredMaterialsBindingNavigator
            // 
            this.deliveredMaterialsBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.deliveredMaterialsBindingNavigator.BindingSource = this.deliveredMaterialsBindingSource;
            this.deliveredMaterialsBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.deliveredMaterialsBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.deliveredMaterialsBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.deliveredMaterialsBindingNavigatorSaveItem});
            this.deliveredMaterialsBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.deliveredMaterialsBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.deliveredMaterialsBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.deliveredMaterialsBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.deliveredMaterialsBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.deliveredMaterialsBindingNavigator.Name = "deliveredMaterialsBindingNavigator";
            this.deliveredMaterialsBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.deliveredMaterialsBindingNavigator.Size = new System.Drawing.Size(918, 25);
            this.deliveredMaterialsBindingNavigator.TabIndex = 0;
            this.deliveredMaterialsBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // deliveredMaterialsBindingNavigatorSaveItem
            // 
            this.deliveredMaterialsBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.deliveredMaterialsBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("deliveredMaterialsBindingNavigatorSaveItem.Image")));
            this.deliveredMaterialsBindingNavigatorSaveItem.Name = "deliveredMaterialsBindingNavigatorSaveItem";
            this.deliveredMaterialsBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.deliveredMaterialsBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.deliveredMaterialsBindingNavigatorSaveItem.Click += new System.EventHandler(this.deliveredMaterialsBindingNavigatorSaveItem_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Материалы);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(0, 28);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(918, 486);
            this.tabControl1.TabIndex = 2;
            // 
            // Материалы
            // 
            this.Материалы.AutoScroll = true;
            this.Материалы.Controls.Add(this.button1);
            this.Материалы.Controls.Add(this.button2);
            this.Материалы.Controls.Add(this.btn_AddStaff);
            this.Материалы.Controls.Add(this.btn_Delete);
            this.Материалы.Controls.Add(this.btn_Refresh);
            this.Материалы.Controls.Add(this.label2);
            this.Материалы.Controls.Add(this.label1);
            this.Материалы.Controls.Add(this.materialsDataGridView);
            this.Материалы.Controls.Add(this.unitsDataGridView);
            this.Материалы.Location = new System.Drawing.Point(4, 22);
            this.Материалы.Name = "Материалы";
            this.Материалы.Padding = new System.Windows.Forms.Padding(3);
            this.Материалы.Size = new System.Drawing.Size(910, 460);
            this.Материалы.TabIndex = 0;
            this.Материалы.Text = "Материалы";
            this.Материалы.UseVisualStyleBackColor = true;
            this.Материалы.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(802, 264);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 35);
            this.button1.TabIndex = 14;
            this.button1.Text = "Добавить новый";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(556, 264);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 35);
            this.button2.TabIndex = 13;
            this.button2.Text = "Удалить строку";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_AddStaff
            // 
            this.btn_AddStaff.Location = new System.Drawing.Point(151, 264);
            this.btn_AddStaff.Name = "btn_AddStaff";
            this.btn_AddStaff.Size = new System.Drawing.Size(100, 35);
            this.btn_AddStaff.TabIndex = 12;
            this.btn_AddStaff.Text = "Добавить новый";
            this.btn_AddStaff.UseVisualStyleBackColor = true;
            this.btn_AddStaff.Click += new System.EventHandler(this.btn_AddStaff_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(8, 264);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(100, 35);
            this.btn_Delete.TabIndex = 11;
            this.btn_Delete.Text = "Удалить строку";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.Location = new System.Drawing.Point(376, 264);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(100, 35);
            this.btn_Refresh.TabIndex = 10;
            this.btn_Refresh.Text = "Обновить";
            this.btn_Refresh.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(630, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(157, 31);
            this.label2.TabIndex = 3;
            this.label2.Text = "Материалы";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(8, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(273, 31);
            this.label1.TabIndex = 2;
            this.label1.Text = "Единицы измерения";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // materialsDataGridView
            // 
            this.materialsDataGridView.AutoGenerateColumns = false;
            this.materialsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.materialsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.materialsDataGridView.DataSource = this.materialsBindingSource;
            this.materialsDataGridView.Location = new System.Drawing.Point(556, 50);
            this.materialsDataGridView.Name = "materialsDataGridView";
            this.materialsDataGridView.Size = new System.Drawing.Size(346, 177);
            this.materialsDataGridView.TabIndex = 1;
            this.materialsDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.materialsDataGridView_CellContentClick);
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "IdMaterials";
            this.dataGridViewTextBoxColumn3.HeaderText = "IdMaterials";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "NameMaterials";
            this.dataGridViewTextBoxColumn4.HeaderText = "NameMaterials";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "IdUnits";
            this.dataGridViewTextBoxColumn5.DataSource = this.viewUnitBindingSource;
            this.dataGridViewTextBoxColumn5.DisplayMember = "NameUnits";
            this.dataGridViewTextBoxColumn5.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn5.HeaderText = "IdUnits";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn5.ValueMember = "IdUnits";
            // 
            // viewUnitBindingSource
            // 
            this.viewUnitBindingSource.DataMember = "view_Unit";
            this.viewUnitBindingSource.DataSource = this.finalBDDataSetBindingSource;
            // 
            // finalBDDataSetBindingSource
            // 
            this.finalBDDataSetBindingSource.DataSource = this.finalBDDataSet;
            this.finalBDDataSetBindingSource.Position = 0;
            // 
            // materialsBindingSource
            // 
            this.materialsBindingSource.DataMember = "Materials";
            this.materialsBindingSource.DataSource = this.finalBDDataSet;
            // 
            // unitsDataGridView
            // 
            this.unitsDataGridView.AutoGenerateColumns = false;
            this.unitsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.unitsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.unitsDataGridView.DataSource = this.unitsBindingSource;
            this.unitsDataGridView.Location = new System.Drawing.Point(8, 50);
            this.unitsDataGridView.Name = "unitsDataGridView";
            this.unitsDataGridView.Size = new System.Drawing.Size(243, 177);
            this.unitsDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "IdUnits";
            this.dataGridViewTextBoxColumn1.HeaderText = "IdUnits";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "NameUnits";
            this.dataGridViewTextBoxColumn2.HeaderText = "NameUnits";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // unitsBindingSource
            // 
            this.unitsBindingSource.DataMember = "Units";
            this.unitsBindingSource.DataSource = this.finalBDDataSet;
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.Controls.Add(this.button7);
            this.tabPage2.Controls.Add(this.button8);
            this.tabPage2.Controls.Add(this.button5);
            this.tabPage2.Controls.Add(this.button6);
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.button4);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.serviceContractDataGridView);
            this.tabPage2.Controls.Add(this.contractDataGridView);
            this.tabPage2.Controls.Add(this.procurementContractDataGridView);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(910, 460);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Договоры";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(788, 341);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(100, 35);
            this.button7.TabIndex = 18;
            this.button7.Text = "Добавить новый";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(788, 300);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(100, 35);
            this.button8.TabIndex = 17;
            this.button8.Text = "Удалить строку";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(302, 62);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(100, 35);
            this.button5.TabIndex = 16;
            this.button5.Text = "Добавить новый";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(172, 300);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(100, 35);
            this.button6.TabIndex = 15;
            this.button6.Text = "Удалить строку";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(172, 341);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 35);
            this.button3.TabIndex = 14;
            this.button3.Text = "Добавить новый";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(302, 21);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(100, 35);
            this.button4.TabIndex = 13;
            this.button4.Text = "Удалить строку";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(695, 240);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(193, 31);
            this.label5.TabIndex = 6;
            this.label5.Text = "Договор услуг";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(374, 129);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(134, 31);
            this.label4.TabIndex = 5;
            this.label4.Text = "Договора";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(30, 226);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(227, 31);
            this.label3.TabIndex = 4;
            this.label3.Text = "Договор закупки";
            // 
            // serviceContractDataGridView
            // 
            this.serviceContractDataGridView.AutoGenerateColumns = false;
            this.serviceContractDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.serviceContractDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            this.serviceContractDataGridView.DataSource = this.fKServiceCoIdSer114A936ABindingSource;
            this.serviceContractDataGridView.Location = new System.Drawing.Point(610, 0);
            this.serviceContractDataGridView.Name = "serviceContractDataGridView";
            this.serviceContractDataGridView.Size = new System.Drawing.Size(300, 220);
            this.serviceContractDataGridView.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "IdServiceContract";
            this.dataGridViewTextBoxColumn11.HeaderText = "IdServiceContract";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "IdObject";
            this.dataGridViewTextBoxColumn12.DataSource = this.viewBuildingBindingSource;
            this.dataGridViewTextBoxColumn12.DisplayMember = "NameObject";
            this.dataGridViewTextBoxColumn12.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn12.HeaderText = "IdObject";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn12.ValueMember = "IdObject";
            // 
            // viewBuildingBindingSource
            // 
            this.viewBuildingBindingSource.DataMember = "view_Building";
            this.viewBuildingBindingSource.DataSource = this.finalBDDataSet;
            // 
            // fKServiceCoIdSer114A936ABindingSource
            // 
            this.fKServiceCoIdSer114A936ABindingSource.DataMember = "FK__ServiceCo__IdSer__114A936A";
            this.fKServiceCoIdSer114A936ABindingSource.DataSource = this.contractBindingSource;
            // 
            // contractBindingSource
            // 
            this.contractBindingSource.DataMember = "Contract";
            this.contractBindingSource.DataSource = this.finalBDDataSet;
            // 
            // contractDataGridView
            // 
            this.contractDataGridView.AutoGenerateColumns = false;
            this.contractDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.contractDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10});
            this.contractDataGridView.DataSource = this.contractBindingSource;
            this.contractDataGridView.Location = new System.Drawing.Point(278, 226);
            this.contractDataGridView.Name = "contractDataGridView";
            this.contractDataGridView.Size = new System.Drawing.Size(349, 220);
            this.contractDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "IdContract";
            this.dataGridViewTextBoxColumn8.HeaderText = "IdContract";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "IdPerson";
            this.dataGridViewTextBoxColumn9.DataSource = this.viewProviderBindingSource;
            this.dataGridViewTextBoxColumn9.DisplayMember = "_Person";
            this.dataGridViewTextBoxColumn9.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn9.HeaderText = "IdPerson";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn9.ValueMember = "IdPerson";
            // 
            // viewProviderBindingSource
            // 
            this.viewProviderBindingSource.DataMember = "view_Provider";
            this.viewProviderBindingSource.DataSource = this.finalBDDataSet;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "DOC";
            this.dataGridViewTextBoxColumn10.HeaderText = "DOC";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // procurementContractDataGridView
            // 
            this.procurementContractDataGridView.AutoGenerateColumns = false;
            this.procurementContractDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.procurementContractDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.procurementContractDataGridView.DataSource = this.fKProcuremeIdPro0C85DE4DBindingSource;
            this.procurementContractDataGridView.Location = new System.Drawing.Point(-4, 0);
            this.procurementContractDataGridView.Name = "procurementContractDataGridView";
            this.procurementContractDataGridView.Size = new System.Drawing.Size(300, 220);
            this.procurementContractDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "IdProcurementContract";
            this.dataGridViewTextBoxColumn6.HeaderText = "IdProcurementContract";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "IdProcurement";
            this.dataGridViewTextBoxColumn7.HeaderText = "IdProcurement";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // fKProcuremeIdPro0C85DE4DBindingSource
            // 
            this.fKProcuremeIdPro0C85DE4DBindingSource.DataMember = "FK__Procureme__IdPro__0C85DE4D";
            this.fKProcuremeIdPro0C85DE4DBindingSource.DataSource = this.contractBindingSource;
            // 
            // tabPage3
            // 
            this.tabPage3.AutoScroll = true;
            this.tabPage3.Controls.Add(this.button11);
            this.tabPage3.Controls.Add(this.button12);
            this.tabPage3.Controls.Add(this.button9);
            this.tabPage3.Controls.Add(this.button10);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.deliveredMaterialsDataGridView);
            this.tabPage3.Controls.Add(this.usedMaterialsDataGridView);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(910, 460);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Поставленные \\ использованные материалы";
            this.tabPage3.UseVisualStyleBackColor = true;
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(698, 309);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(100, 35);
            this.button11.TabIndex = 22;
            this.button11.Text = "Добавить новый";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(555, 309);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(100, 35);
            this.button12.TabIndex = 21;
            this.button12.Text = "Удалить строку";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(698, 65);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(100, 35);
            this.button9.TabIndex = 20;
            this.button9.Text = "Добавить новый";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(555, 65);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(100, 35);
            this.button10.TabIndex = 19;
            this.button10.Text = "Удалить строку";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(549, 262);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(306, 31);
            this.label7.TabIndex = 5;
            this.label7.Text = "Проданные материалы";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(549, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(330, 31);
            this.label6.TabIndex = 4;
            this.label6.Text = "Закупленные материалы";
            // 
            // deliveredMaterialsDataGridView
            // 
            this.deliveredMaterialsDataGridView.AutoGenerateColumns = false;
            this.deliveredMaterialsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.deliveredMaterialsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16});
            this.deliveredMaterialsDataGridView.DataSource = this.deliveredMaterialsBindingSource;
            this.deliveredMaterialsDataGridView.Location = new System.Drawing.Point(-4, 0);
            this.deliveredMaterialsDataGridView.Name = "deliveredMaterialsDataGridView";
            this.deliveredMaterialsDataGridView.Size = new System.Drawing.Size(547, 220);
            this.deliveredMaterialsDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "IdProcurementContract";
            this.dataGridViewTextBoxColumn13.HeaderText = "IdProcurementContract";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "IdMaterials";
            this.dataGridViewTextBoxColumn14.DataSource = this.viewMaterialsBindingSource;
            this.dataGridViewTextBoxColumn14.DisplayMember = "NameMaterials";
            this.dataGridViewTextBoxColumn14.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn14.HeaderText = "IdMaterials";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn14.ValueMember = "IdMaterials";
            // 
            // viewMaterialsBindingSource
            // 
            this.viewMaterialsBindingSource.DataMember = "view_Materials";
            this.viewMaterialsBindingSource.DataSource = this.finalBDDataSet;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "Amount";
            this.dataGridViewTextBoxColumn15.HeaderText = "Amount";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "PurchasePrice";
            this.dataGridViewTextBoxColumn16.HeaderText = "PurchasePrice";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // usedMaterialsDataGridView
            // 
            this.usedMaterialsDataGridView.AutoGenerateColumns = false;
            this.usedMaterialsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.usedMaterialsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21});
            this.usedMaterialsDataGridView.DataSource = this.r60BindingSource;
            this.usedMaterialsDataGridView.Location = new System.Drawing.Point(-4, 234);
            this.usedMaterialsDataGridView.Name = "usedMaterialsDataGridView";
            this.usedMaterialsDataGridView.Size = new System.Drawing.Size(547, 220);
            this.usedMaterialsDataGridView.TabIndex = 1;
            this.usedMaterialsDataGridView.Tag = "";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "IdMaterials";
            this.dataGridViewTextBoxColumn17.DataSource = this.viewMaterialsBindingSource1;
            this.dataGridViewTextBoxColumn17.DisplayMember = "NameMaterials";
            this.dataGridViewTextBoxColumn17.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn17.HeaderText = "IdMaterials";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn17.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn17.ValueMember = "IdMaterials";
            // 
            // viewMaterialsBindingSource1
            // 
            this.viewMaterialsBindingSource1.DataMember = "view_Materials";
            this.viewMaterialsBindingSource1.DataSource = this.finalBDDataSet;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "Amount";
            this.dataGridViewTextBoxColumn18.HeaderText = "Amount";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "IdProcurementContract";
            this.dataGridViewTextBoxColumn19.HeaderText = "IdProcurementContract";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn20.HeaderText = "Price";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "IdServiceContract";
            this.dataGridViewTextBoxColumn21.HeaderText = "IdServiceContract";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            // 
            // r60BindingSource
            // 
            this.r60BindingSource.DataMember = "R_60";
            this.r60BindingSource.DataSource = this.deliveredMaterialsBindingSource;
            // 
            // serviceContractBindingSource
            // 
            this.serviceContractBindingSource.DataMember = "ServiceContract";
            this.serviceContractBindingSource.DataSource = this.finalBDDataSet;
            // 
            // procurementContractBindingSource
            // 
            this.procurementContractBindingSource.DataMember = "ProcurementContract";
            this.procurementContractBindingSource.DataSource = this.finalBDDataSet;
            // 
            // usedMaterialsBindingSource
            // 
            this.usedMaterialsBindingSource.DataMember = "UsedMaterials";
            this.usedMaterialsBindingSource.DataSource = this.finalBDDataSet;
            // 
            // view_UnitTableAdapter
            // 
            this.view_UnitTableAdapter.ClearBeforeFill = true;
            // 
            // view_BuildingTableAdapter
            // 
            this.view_BuildingTableAdapter.ClearBeforeFill = true;
            // 
            // view_ProviderTableAdapter
            // 
            this.view_ProviderTableAdapter.ClearBeforeFill = true;
            // 
            // view_MaterialsTableAdapter
            // 
            this.view_MaterialsTableAdapter.ClearBeforeFill = true;
            // 
            // procurementTypeBindingSource
            // 
            this.procurementTypeBindingSource.DataMember = "ProcurementType";
            this.procurementTypeBindingSource.DataSource = this.finalBDDataSet;
            // 
            // procurementTypeTableAdapter
            // 
            this.procurementTypeTableAdapter.ClearBeforeFill = true;
            // 
            // materials
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(918, 514);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.deliveredMaterialsBindingNavigator);
            this.Name = "materials";
            this.Text = "materials";
            this.Load += new System.EventHandler(this.materials_Load);
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deliveredMaterialsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deliveredMaterialsBindingNavigator)).EndInit();
            this.deliveredMaterialsBindingNavigator.ResumeLayout(false);
            this.deliveredMaterialsBindingNavigator.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.Материалы.ResumeLayout(false);
            this.Материалы.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.materialsDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewUnitBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unitsDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unitsBindingSource)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.serviceContractDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewBuildingBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKServiceCoIdSer114A936ABindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.contractBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.contractDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewProviderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.procurementContractDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKProcuremeIdPro0C85DE4DBindingSource)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.deliveredMaterialsDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewMaterialsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usedMaterialsDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewMaterialsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r60BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.serviceContractBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.procurementContractBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usedMaterialsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.procurementTypeBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private FinalBDDataSet finalBDDataSet;
        private System.Windows.Forms.BindingSource deliveredMaterialsBindingSource;
        private FinalBDDataSetTableAdapters.DeliveredMaterialsTableAdapter deliveredMaterialsTableAdapter;
        private FinalBDDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator deliveredMaterialsBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton deliveredMaterialsBindingNavigatorSaveItem;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Материалы;
        private System.Windows.Forms.TabPage tabPage2;
        private FinalBDDataSetTableAdapters.UnitsTableAdapter unitsTableAdapter;
        private System.Windows.Forms.BindingSource unitsBindingSource;
        private FinalBDDataSetTableAdapters.MaterialsTableAdapter materialsTableAdapter;
        private System.Windows.Forms.DataGridView unitsDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.BindingSource materialsBindingSource;
        private System.Windows.Forms.DataGridView materialsDataGridView;
        private System.Windows.Forms.TabPage tabPage3;
        private FinalBDDataSetTableAdapters.ProcurementContractTableAdapter procurementContractTableAdapter;
        private System.Windows.Forms.BindingSource procurementContractBindingSource;
        private FinalBDDataSetTableAdapters.ContractTableAdapter contractTableAdapter;
        private System.Windows.Forms.DataGridView procurementContractDataGridView;
        private System.Windows.Forms.BindingSource contractBindingSource;
        private FinalBDDataSetTableAdapters.ServiceContractTableAdapter serviceContractTableAdapter;
        private System.Windows.Forms.DataGridView contractDataGridView;
        private System.Windows.Forms.BindingSource serviceContractBindingSource;
        private System.Windows.Forms.DataGridView serviceContractDataGridView;
        private FinalBDDataSetTableAdapters.UsedMaterialsTableAdapter usedMaterialsTableAdapter;
        private System.Windows.Forms.BindingSource usedMaterialsBindingSource;
        private System.Windows.Forms.DataGridView usedMaterialsDataGridView;
        private System.Windows.Forms.DataGridView deliveredMaterialsDataGridView;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.BindingSource r60BindingSource;
        private System.Windows.Forms.BindingSource fKServiceCoIdSer114A936ABindingSource;
        private System.Windows.Forms.BindingSource fKProcuremeIdPro0C85DE4DBindingSource;
        private System.Windows.Forms.BindingSource finalBDDataSetBindingSource;
        private System.Windows.Forms.BindingSource viewUnitBindingSource;
        private FinalBDDataSetTableAdapters.view_UnitTableAdapter view_UnitTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.BindingSource viewBuildingBindingSource;
        private FinalBDDataSetTableAdapters.view_BuildingTableAdapter view_BuildingTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.BindingSource viewProviderBindingSource;
        private FinalBDDataSetTableAdapters.view_ProviderTableAdapter view_ProviderTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.BindingSource viewMaterialsBindingSource;
        private FinalBDDataSetTableAdapters.view_MaterialsTableAdapter view_MaterialsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.BindingSource viewMaterialsBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btn_AddStaff;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.BindingSource procurementTypeBindingSource;
        private FinalBDDataSetTableAdapters.ProcurementTypeTableAdapter procurementTypeTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
    }
}