﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalBD
{
    public partial class building : Form
    {
        public building()
        {
            InitializeComponent();
        }

        private void buildingBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.buildingBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.finalBDDataSet);

        }

        private void building_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.TypeOfWork". При необходимости она может быть перемещена или удалена.
            this.typeOfWorkTableAdapter.Fill(this.finalBDDataSet.TypeOfWork);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.TypeOfWorkOnObject". При необходимости она может быть перемещена или удалена.
            this.typeOfWorkOnObjectTableAdapter.Fill(this.finalBDDataSet.TypeOfWorkOnObject);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Building". При необходимости она может быть перемещена или удалена.
            this.buildingTableAdapter.Fill(this.finalBDDataSet.Building);

        }

        private void typeOfWorkOnObjectDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
