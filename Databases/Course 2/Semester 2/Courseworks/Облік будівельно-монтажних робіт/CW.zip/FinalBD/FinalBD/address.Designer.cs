﻿namespace FinalBD
{
    partial class address
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(address));
            this.addressBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.finalBDDataSet = new FinalBD.FinalBDDataSet();
            this.streetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.typeOfStreetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.localityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.regionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.countryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.countryTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.CountryTableAdapter();
            this.tableAdapterManager = new FinalBD.FinalBDDataSetTableAdapters.TableAdapterManager();
            this.addressTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.AddressTableAdapter();
            this.localityTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.LocalityTableAdapter();
            this.regionTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.RegionTableAdapter();
            this.streetTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.StreetTableAdapter();
            this.typeOfStreetTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.TypeOfStreetTableAdapter();
            this.countryBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.countryBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.r131BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.r12BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.r15BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.countryDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.regionDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewCountryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.localityDataGridView = new System.Windows.Forms.DataGridView();
            this.idLocalityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idRegionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameLocalityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r12BindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.typeOfStreetDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.streetDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewStreetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.finalBDDataSet1 = new FinalBD.FinalBDDataSet();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r15BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.addressDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewAdressBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.finalBDDataSet2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.finalBDDataSet2 = new FinalBD.FinalBDDataSet();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r12BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.r12BindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.view_CountryTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.view_CountryTableAdapter();
            this.view_StreetTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.view_StreetTableAdapter();
            this.view_AdressTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.view_AdressTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.addressBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.streetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeOfStreetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.localityBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.regionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.countryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.countryBindingNavigator)).BeginInit();
            this.countryBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.r131BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r12BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r15BindingSource)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.countryDataGridView)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.regionDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewCountryBindingSource)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.localityDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r12BindingSource3)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.typeOfStreetDataGridView)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.streetDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewStreetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r15BindingSource1)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.addressDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewAdressBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSet2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r12BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r12BindingSource2)).BeginInit();
            this.SuspendLayout();
            // 
            // addressBindingSource
            // 
            this.addressBindingSource.DataMember = "Address";
            this.addressBindingSource.DataSource = this.finalBDDataSet;
            // 
            // finalBDDataSet
            // 
            this.finalBDDataSet.DataSetName = "FinalBDDataSet";
            this.finalBDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // streetBindingSource
            // 
            this.streetBindingSource.DataMember = "Street";
            this.streetBindingSource.DataSource = this.finalBDDataSet;
            // 
            // typeOfStreetBindingSource
            // 
            this.typeOfStreetBindingSource.DataMember = "TypeOfStreet";
            this.typeOfStreetBindingSource.DataSource = this.finalBDDataSet;
            // 
            // localityBindingSource
            // 
            this.localityBindingSource.DataMember = "Locality";
            this.localityBindingSource.DataSource = this.finalBDDataSet;
            // 
            // regionBindingSource
            // 
            this.regionBindingSource.DataMember = "Region";
            this.regionBindingSource.DataSource = this.finalBDDataSet;
            // 
            // countryBindingSource
            // 
            this.countryBindingSource.DataMember = "Country";
            this.countryBindingSource.DataSource = this.finalBDDataSet;
            // 
            // countryTableAdapter
            // 
            this.countryTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AddressTableAdapter = this.addressTableAdapter;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BrigadeListTableAdapter = null;
            this.tableAdapterManager.BrigadeTableAdapter = null;
            this.tableAdapterManager.BuildingTableAdapter = null;
            this.tableAdapterManager.ContactInformationTableAdapter = null;
            this.tableAdapterManager.ContractTableAdapter = null;
            this.tableAdapterManager.CountryTableAdapter = this.countryTableAdapter;
            this.tableAdapterManager.DeliveredMaterialsTableAdapter = null;
            this.tableAdapterManager.GenderTableAdapter = null;
            this.tableAdapterManager.Job_SpecialtyTableAdapter = null;
            this.tableAdapterManager.LegalEntityTableAdapter = null;
            this.tableAdapterManager.LocalityTableAdapter = this.localityTableAdapter;
            this.tableAdapterManager.MaterialsTableAdapter = null;
            this.tableAdapterManager.MobileNumberTableAdapter = null;
            this.tableAdapterManager.MobileOperatorTableAdapter = null;
            this.tableAdapterManager.NumberMobileOperatorTableAdapter = null;
            this.tableAdapterManager.PersonTableAdapter = null;
            this.tableAdapterManager.PhoneTableAdapter = null;
            this.tableAdapterManager.PhysicalPersonTableAdapter = null;
            this.tableAdapterManager.ProcurementContractTableAdapter = null;
            this.tableAdapterManager.ProcurementTypeTableAdapter = null;
            this.tableAdapterManager.QualificationsTableAdapter = null;
            this.tableAdapterManager.RegionTableAdapter = this.regionTableAdapter;
            this.tableAdapterManager.ServiceContractTableAdapter = null;
            this.tableAdapterManager.SpecialtyTableAdapter = null;
            this.tableAdapterManager.StationaryNumberTableAdapter = null;
            this.tableAdapterManager.StreetTableAdapter = this.streetTableAdapter;
            this.tableAdapterManager.TypeOfPersonTableAdapter = null;
            this.tableAdapterManager.TypeOfStreetTableAdapter = this.typeOfStreetTableAdapter;
            this.tableAdapterManager.TypeOfWorkOnObjectTableAdapter = null;
            this.tableAdapterManager.TypeOfWorkTableAdapter = null;
            this.tableAdapterManager.UnitsTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = FinalBD.FinalBDDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UsedMaterialsTableAdapter = null;
            this.tableAdapterManager.WorkListTableAdapter = null;
            this.tableAdapterManager.WorkScheduleTableAdapter = null;
            // 
            // addressTableAdapter
            // 
            this.addressTableAdapter.ClearBeforeFill = true;
            // 
            // localityTableAdapter
            // 
            this.localityTableAdapter.ClearBeforeFill = true;
            // 
            // regionTableAdapter
            // 
            this.regionTableAdapter.ClearBeforeFill = true;
            // 
            // streetTableAdapter
            // 
            this.streetTableAdapter.ClearBeforeFill = true;
            // 
            // typeOfStreetTableAdapter
            // 
            this.typeOfStreetTableAdapter.ClearBeforeFill = true;
            // 
            // countryBindingNavigator
            // 
            this.countryBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.countryBindingNavigator.BindingSource = this.countryBindingSource;
            this.countryBindingNavigator.CountItem = null;
            this.countryBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.countryBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorSeparator,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.countryBindingNavigatorSaveItem,
            this.toolStripSeparator1});
            this.countryBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.countryBindingNavigator.MoveFirstItem = null;
            this.countryBindingNavigator.MoveLastItem = null;
            this.countryBindingNavigator.MoveNextItem = null;
            this.countryBindingNavigator.MovePreviousItem = null;
            this.countryBindingNavigator.Name = "countryBindingNavigator";
            this.countryBindingNavigator.PositionItem = null;
            this.countryBindingNavigator.Size = new System.Drawing.Size(667, 25);
            this.countryBindingNavigator.TabIndex = 1;
            this.countryBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Enabled = false;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Enabled = false;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // countryBindingNavigatorSaveItem
            // 
            this.countryBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.countryBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("countryBindingNavigatorSaveItem.Image")));
            this.countryBindingNavigatorSaveItem.Name = "countryBindingNavigatorSaveItem";
            this.countryBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.countryBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.countryBindingNavigatorSaveItem.Click += new System.EventHandler(this.countryBindingNavigatorSaveItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // r131BindingSource
            // 
            this.r131BindingSource.DataMember = "R_131";
            this.r131BindingSource.DataSource = this.countryBindingSource;
            // 
            // r12BindingSource
            // 
            this.r12BindingSource.DataMember = "R_12";
            this.r12BindingSource.DataSource = this.regionBindingSource;
            // 
            // r15BindingSource
            // 
            this.r15BindingSource.DataMember = "R_15";
            this.r15BindingSource.DataSource = this.localityBindingSource;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(0, 28);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(667, 377);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.button5);
            this.tabPage1.Controls.Add(this.button6);
            this.tabPage1.Controls.Add(this.countryDataGridView);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(659, 351);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Страна";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(419, 128);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(109, 23);
            this.button4.TabIndex = 9;
            this.button4.Text = "Обновить";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(419, 75);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(109, 23);
            this.button5.TabIndex = 8;
            this.button5.Text = "Удалить строку";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(419, 26);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(109, 23);
            this.button6.TabIndex = 7;
            this.button6.Text = "Добавить тип";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // countryDataGridView
            // 
            this.countryDataGridView.AutoGenerateColumns = false;
            this.countryDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.countryDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.countryDataGridView.DataSource = this.countryBindingSource;
            this.countryDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.countryDataGridView.Location = new System.Drawing.Point(3, 3);
            this.countryDataGridView.Name = "countryDataGridView";
            this.countryDataGridView.Size = new System.Drawing.Size(653, 345);
            this.countryDataGridView.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "IdCountry";
            this.dataGridViewTextBoxColumn1.HeaderText = "IdCountry";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "NameCountry";
            this.dataGridViewTextBoxColumn2.HeaderText = "NameCountry";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button7);
            this.tabPage2.Controls.Add(this.button8);
            this.tabPage2.Controls.Add(this.button9);
            this.tabPage2.Controls.Add(this.regionDataGridView);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(659, 351);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Регион";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(518, 115);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(109, 23);
            this.button7.TabIndex = 12;
            this.button7.Text = "Обновить";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(518, 62);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(109, 23);
            this.button8.TabIndex = 11;
            this.button8.Text = "Удалить строку";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(518, 17);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(109, 23);
            this.button9.TabIndex = 10;
            this.button9.Text = "Добавить тип";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // regionDataGridView
            // 
            this.regionDataGridView.AutoGenerateColumns = false;
            this.regionDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.regionDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.regionDataGridView.DataSource = this.r131BindingSource;
            this.regionDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.regionDataGridView.Location = new System.Drawing.Point(3, 3);
            this.regionDataGridView.Name = "regionDataGridView";
            this.regionDataGridView.Size = new System.Drawing.Size(653, 345);
            this.regionDataGridView.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "IdRegion";
            this.dataGridViewTextBoxColumn3.HeaderText = "IdRegion";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "NameRegion";
            this.dataGridViewTextBoxColumn4.HeaderText = "NameRegion";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "IdCountry";
            this.dataGridViewTextBoxColumn5.DataSource = this.viewCountryBindingSource;
            this.dataGridViewTextBoxColumn5.DisplayMember = "NameCountry";
            this.dataGridViewTextBoxColumn5.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn5.HeaderText = "IdCountry";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn5.ValueMember = "IdCountry";
            // 
            // viewCountryBindingSource
            // 
            this.viewCountryBindingSource.DataMember = "view_Country";
            this.viewCountryBindingSource.DataSource = this.finalBDDataSet;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button10);
            this.tabPage3.Controls.Add(this.button11);
            this.tabPage3.Controls.Add(this.button12);
            this.tabPage3.Controls.Add(this.localityDataGridView);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(659, 351);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Населенный пункт";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(419, 125);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(109, 23);
            this.button10.TabIndex = 12;
            this.button10.Text = "Обновить";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(419, 72);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(109, 23);
            this.button11.TabIndex = 11;
            this.button11.Text = "Удалить строку";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(419, 23);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(109, 23);
            this.button12.TabIndex = 10;
            this.button12.Text = "Добавить тип";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // localityDataGridView
            // 
            this.localityDataGridView.AutoGenerateColumns = false;
            this.localityDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.localityDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idLocalityDataGridViewTextBoxColumn,
            this.idRegionDataGridViewTextBoxColumn,
            this.nameLocalityDataGridViewTextBoxColumn});
            this.localityDataGridView.DataSource = this.r12BindingSource3;
            this.localityDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.localityDataGridView.Location = new System.Drawing.Point(3, 3);
            this.localityDataGridView.Name = "localityDataGridView";
            this.localityDataGridView.Size = new System.Drawing.Size(653, 345);
            this.localityDataGridView.TabIndex = 2;
            // 
            // idLocalityDataGridViewTextBoxColumn
            // 
            this.idLocalityDataGridViewTextBoxColumn.DataPropertyName = "IdLocality";
            this.idLocalityDataGridViewTextBoxColumn.HeaderText = "IdLocality";
            this.idLocalityDataGridViewTextBoxColumn.Name = "idLocalityDataGridViewTextBoxColumn";
            // 
            // idRegionDataGridViewTextBoxColumn
            // 
            this.idRegionDataGridViewTextBoxColumn.DataPropertyName = "IdRegion";
            this.idRegionDataGridViewTextBoxColumn.HeaderText = "IdRegion";
            this.idRegionDataGridViewTextBoxColumn.Name = "idRegionDataGridViewTextBoxColumn";
            // 
            // nameLocalityDataGridViewTextBoxColumn
            // 
            this.nameLocalityDataGridViewTextBoxColumn.DataPropertyName = "NameLocality";
            this.nameLocalityDataGridViewTextBoxColumn.HeaderText = "NameLocality";
            this.nameLocalityDataGridViewTextBoxColumn.Name = "nameLocalityDataGridViewTextBoxColumn";
            // 
            // r12BindingSource3
            // 
            this.r12BindingSource3.DataMember = "R_12";
            this.r12BindingSource3.DataSource = this.r131BindingSource;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.button3);
            this.tabPage4.Controls.Add(this.button2);
            this.tabPage4.Controls.Add(this.button1);
            this.tabPage4.Controls.Add(this.typeOfStreetDataGridView);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(659, 351);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Тип улицы";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(418, 133);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(109, 23);
            this.button3.TabIndex = 6;
            this.button3.Text = "Обновить";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(418, 80);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(109, 23);
            this.button2.TabIndex = 5;
            this.button2.Text = "Удалить строку";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(418, 31);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(109, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Добавить тип";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // typeOfStreetDataGridView
            // 
            this.typeOfStreetDataGridView.AutoGenerateColumns = false;
            this.typeOfStreetDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.typeOfStreetDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10});
            this.typeOfStreetDataGridView.DataSource = this.typeOfStreetBindingSource;
            this.typeOfStreetDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.typeOfStreetDataGridView.Location = new System.Drawing.Point(3, 3);
            this.typeOfStreetDataGridView.Name = "typeOfStreetDataGridView";
            this.typeOfStreetDataGridView.Size = new System.Drawing.Size(653, 345);
            this.typeOfStreetDataGridView.TabIndex = 3;
            this.typeOfStreetDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.typeOfStreetDataGridView_CellContentClick);
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "IdTypeOfStreet";
            this.dataGridViewTextBoxColumn9.HeaderText = "IdTypeOfStreet";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "NameTypeOfStreet";
            this.dataGridViewTextBoxColumn10.HeaderText = "NameTypeOfStreet";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.button13);
            this.tabPage5.Controls.Add(this.button14);
            this.tabPage5.Controls.Add(this.button15);
            this.tabPage5.Controls.Add(this.streetDataGridView);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(659, 351);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Улица";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(532, 116);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(109, 23);
            this.button13.TabIndex = 12;
            this.button13.Text = "Обновить";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(532, 63);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(109, 23);
            this.button14.TabIndex = 11;
            this.button14.Text = "Удалить строку";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(532, 14);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(109, 23);
            this.button15.TabIndex = 10;
            this.button15.Text = "Добавить тип";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // streetDataGridView
            // 
            this.streetDataGridView.AutoGenerateColumns = false;
            this.streetDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.streetDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14});
            this.streetDataGridView.DataSource = this.r15BindingSource1;
            this.streetDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.streetDataGridView.Location = new System.Drawing.Point(3, 3);
            this.streetDataGridView.Name = "streetDataGridView";
            this.streetDataGridView.Size = new System.Drawing.Size(653, 345);
            this.streetDataGridView.TabIndex = 4;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "IdStreet";
            this.dataGridViewTextBoxColumn11.HeaderText = "IdStreet";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "IdTypeOfStreet";
            this.dataGridViewTextBoxColumn12.DataSource = this.viewStreetBindingSource;
            this.dataGridViewTextBoxColumn12.DisplayMember = "NameTypeOfStreet";
            this.dataGridViewTextBoxColumn12.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn12.HeaderText = "IdTypeOfStreet";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn12.ValueMember = "idStreet";
            // 
            // viewStreetBindingSource
            // 
            this.viewStreetBindingSource.DataMember = "view_Street";
            this.viewStreetBindingSource.DataSource = this.finalBDDataSet1;
            // 
            // finalBDDataSet1
            // 
            this.finalBDDataSet1.DataSetName = "FinalBDDataSet";
            this.finalBDDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "IdLocality";
            this.dataGridViewTextBoxColumn13.DataSource = this.viewStreetBindingSource;
            this.dataGridViewTextBoxColumn13.DisplayMember = "NameLocality";
            this.dataGridViewTextBoxColumn13.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn13.HeaderText = "IdLocality";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn13.ValueMember = "idStreet";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "NameStreet";
            this.dataGridViewTextBoxColumn14.HeaderText = "NameStreet";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // r15BindingSource1
            // 
            this.r15BindingSource1.DataMember = "R_15";
            this.r15BindingSource1.DataSource = this.r12BindingSource3;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.button16);
            this.tabPage6.Controls.Add(this.button17);
            this.tabPage6.Controls.Add(this.button18);
            this.tabPage6.Controls.Add(this.addressDataGridView);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(659, 351);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Адрес";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(533, 115);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(109, 23);
            this.button16.TabIndex = 12;
            this.button16.Text = "Обновить";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(533, 62);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(109, 23);
            this.button17.TabIndex = 11;
            this.button17.Text = "Удалить строку";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(533, 13);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(109, 23);
            this.button18.TabIndex = 10;
            this.button18.Text = "Добавить тип";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // addressDataGridView
            // 
            this.addressDataGridView.AutoGenerateColumns = false;
            this.addressDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.addressDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18});
            this.addressDataGridView.DataSource = this.addressBindingSource;
            this.addressDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addressDataGridView.Location = new System.Drawing.Point(3, 3);
            this.addressDataGridView.Name = "addressDataGridView";
            this.addressDataGridView.Size = new System.Drawing.Size(653, 345);
            this.addressDataGridView.TabIndex = 5;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "IdAddress";
            this.dataGridViewTextBoxColumn15.HeaderText = "IdAddress";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "IdStreet";
            this.dataGridViewTextBoxColumn16.DataSource = this.viewAdressBindingSource;
            this.dataGridViewTextBoxColumn16.DisplayMember = "Adress";
            this.dataGridViewTextBoxColumn16.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn16.HeaderText = "IdStreet";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn16.ValueMember = "idAddress";
            // 
            // viewAdressBindingSource
            // 
            this.viewAdressBindingSource.DataMember = "view_Adress";
            this.viewAdressBindingSource.DataSource = this.finalBDDataSet2BindingSource;
            // 
            // finalBDDataSet2BindingSource
            // 
            this.finalBDDataSet2BindingSource.DataSource = this.finalBDDataSet2;
            this.finalBDDataSet2BindingSource.Position = 0;
            // 
            // finalBDDataSet2
            // 
            this.finalBDDataSet2.DataSetName = "FinalBDDataSet";
            this.finalBDDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "HouseNumber";
            this.dataGridViewTextBoxColumn17.HeaderText = "HouseNumber";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "ApartmentNumber";
            this.dataGridViewTextBoxColumn18.HeaderText = "ApartmentNumber";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // r12BindingSource1
            // 
            this.r12BindingSource1.DataMember = "R_12";
            this.r12BindingSource1.DataSource = this.regionBindingSource;
            // 
            // r12BindingSource2
            // 
            this.r12BindingSource2.DataMember = "R_12";
            this.r12BindingSource2.DataSource = this.regionBindingSource;
            // 
            // view_CountryTableAdapter
            // 
            this.view_CountryTableAdapter.ClearBeforeFill = true;
            // 
            // view_StreetTableAdapter
            // 
            this.view_StreetTableAdapter.ClearBeforeFill = true;
            // 
            // view_AdressTableAdapter
            // 
            this.view_AdressTableAdapter.ClearBeforeFill = true;
            // 
            // address
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(667, 417);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.countryBindingNavigator);
            this.Name = "address";
            this.Load += new System.EventHandler(this.address_Load);
            ((System.ComponentModel.ISupportInitialize)(this.addressBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.streetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeOfStreetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.localityBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.regionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.countryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.countryBindingNavigator)).EndInit();
            this.countryBindingNavigator.ResumeLayout(false);
            this.countryBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.r131BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r12BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r15BindingSource)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.countryDataGridView)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.regionDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewCountryBindingSource)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.localityDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r12BindingSource3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.typeOfStreetDataGridView)).EndInit();
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.streetDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewStreetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r15BindingSource1)).EndInit();
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.addressDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewAdressBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSet2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r12BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r12BindingSource2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private FinalBDDataSet finalBDDataSet;
        private System.Windows.Forms.BindingSource countryBindingSource;
        private FinalBDDataSetTableAdapters.CountryTableAdapter countryTableAdapter;
        private FinalBDDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator countryBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripButton countryBindingNavigatorSaveItem;
        private FinalBDDataSetTableAdapters.RegionTableAdapter regionTableAdapter;
        private System.Windows.Forms.BindingSource regionBindingSource;
        private FinalBDDataSetTableAdapters.LocalityTableAdapter localityTableAdapter;
        private System.Windows.Forms.BindingSource localityBindingSource;
        private FinalBDDataSetTableAdapters.TypeOfStreetTableAdapter typeOfStreetTableAdapter;
        private System.Windows.Forms.BindingSource typeOfStreetBindingSource;
        private FinalBDDataSetTableAdapters.StreetTableAdapter streetTableAdapter;
        private System.Windows.Forms.BindingSource streetBindingSource;
        private FinalBDDataSetTableAdapters.AddressTableAdapter addressTableAdapter;
        private System.Windows.Forms.BindingSource addressBindingSource;
        private System.Windows.Forms.BindingSource r15BindingSource;
        private System.Windows.Forms.BindingSource r12BindingSource;
        private System.Windows.Forms.BindingSource r131BindingSource;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView countryDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView regionDataGridView;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView localityDataGridView;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView typeOfStreetDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.DataGridView streetDataGridView;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.DataGridView addressDataGridView;
        private System.Windows.Forms.BindingSource r12BindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idLocalityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idRegionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameLocalityDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource r12BindingSource2;
        private System.Windows.Forms.BindingSource r12BindingSource3;
        private System.Windows.Forms.BindingSource r15BindingSource1;
        private System.Windows.Forms.BindingSource viewCountryBindingSource;
        private FinalBDDataSetTableAdapters.view_CountryTableAdapter view_CountryTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn5;
        private FinalBDDataSet finalBDDataSet1;
        private System.Windows.Forms.BindingSource viewStreetBindingSource;
        private FinalBDDataSetTableAdapters.view_StreetTableAdapter view_StreetTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private FinalBDDataSet finalBDDataSet2;
        private System.Windows.Forms.BindingSource finalBDDataSet2BindingSource;
        private System.Windows.Forms.BindingSource viewAdressBindingSource;
        private FinalBDDataSetTableAdapters.view_AdressTableAdapter view_AdressTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
    }
}