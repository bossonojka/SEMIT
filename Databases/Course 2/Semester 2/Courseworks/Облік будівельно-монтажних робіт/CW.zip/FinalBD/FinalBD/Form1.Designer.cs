﻿namespace FinalBD
{
    partial class FirstForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.exit_btn = new System.Windows.Forms.Button();
            this.work_btn = new System.Windows.Forms.Button();
            this.materials_btn = new System.Windows.Forms.Button();
            this.building_btn = new System.Windows.Forms.Button();
            this.address_btn = new System.Windows.Forms.Button();
            this.person_btn = new System.Windows.Forms.Button();
            this.speciality_btn = new System.Windows.Forms.Button();
            this.report_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // exit_btn
            // 
            this.exit_btn.Location = new System.Drawing.Point(702, 402);
            this.exit_btn.Name = "exit_btn";
            this.exit_btn.Size = new System.Drawing.Size(86, 36);
            this.exit_btn.TabIndex = 0;
            this.exit_btn.Text = "Выход";
            this.exit_btn.UseVisualStyleBackColor = true;
            this.exit_btn.Click += new System.EventHandler(this.exit_btn_Click);
            // 
            // work_btn
            // 
            this.work_btn.Location = new System.Drawing.Point(12, 12);
            this.work_btn.Name = "work_btn";
            this.work_btn.Size = new System.Drawing.Size(98, 36);
            this.work_btn.TabIndex = 1;
            this.work_btn.Text = "Список рабочих";
            this.work_btn.UseVisualStyleBackColor = true;
            this.work_btn.Click += new System.EventHandler(this.work_btn_Click);
            // 
            // materials_btn
            // 
            this.materials_btn.Location = new System.Drawing.Point(12, 54);
            this.materials_btn.Name = "materials_btn";
            this.materials_btn.Size = new System.Drawing.Size(98, 36);
            this.materials_btn.TabIndex = 2;
            this.materials_btn.Text = "Материалы";
            this.materials_btn.UseVisualStyleBackColor = true;
            this.materials_btn.Click += new System.EventHandler(this.materials_btn_Click);
            // 
            // building_btn
            // 
            this.building_btn.Location = new System.Drawing.Point(12, 96);
            this.building_btn.Name = "building_btn";
            this.building_btn.Size = new System.Drawing.Size(98, 36);
            this.building_btn.TabIndex = 3;
            this.building_btn.Text = "Объекты";
            this.building_btn.UseVisualStyleBackColor = true;
            this.building_btn.Click += new System.EventHandler(this.building_btn_Click);
            // 
            // address_btn
            // 
            this.address_btn.Location = new System.Drawing.Point(12, 138);
            this.address_btn.Name = "address_btn";
            this.address_btn.Size = new System.Drawing.Size(98, 36);
            this.address_btn.TabIndex = 4;
            this.address_btn.Text = "Адреса";
            this.address_btn.UseVisualStyleBackColor = true;
            this.address_btn.Click += new System.EventHandler(this.address_btn_Click);
            // 
            // person_btn
            // 
            this.person_btn.Location = new System.Drawing.Point(12, 180);
            this.person_btn.Name = "person_btn";
            this.person_btn.Size = new System.Drawing.Size(98, 36);
            this.person_btn.TabIndex = 5;
            this.person_btn.Text = "Персоны";
            this.person_btn.UseVisualStyleBackColor = true;
            this.person_btn.Click += new System.EventHandler(this.person_btn_Click);
            // 
            // speciality_btn
            // 
            this.speciality_btn.Location = new System.Drawing.Point(12, 222);
            this.speciality_btn.Name = "speciality_btn";
            this.speciality_btn.Size = new System.Drawing.Size(98, 36);
            this.speciality_btn.TabIndex = 6;
            this.speciality_btn.Text = "Специальности";
            this.speciality_btn.UseVisualStyleBackColor = true;
            this.speciality_btn.Click += new System.EventHandler(this.speciality_btn_Click);
            // 
            // report_btn
            // 
            this.report_btn.Location = new System.Drawing.Point(12, 402);
            this.report_btn.Name = "report_btn";
            this.report_btn.Size = new System.Drawing.Size(98, 36);
            this.report_btn.TabIndex = 7;
            this.report_btn.Text = "Отчетность";
            this.report_btn.UseVisualStyleBackColor = true;
            this.report_btn.Click += new System.EventHandler(this.report_btn_Click);
            // 
            // FirstForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.report_btn);
            this.Controls.Add(this.speciality_btn);
            this.Controls.Add(this.person_btn);
            this.Controls.Add(this.address_btn);
            this.Controls.Add(this.building_btn);
            this.Controls.Add(this.materials_btn);
            this.Controls.Add(this.work_btn);
            this.Controls.Add(this.exit_btn);
            this.Name = "FirstForm";
            this.Text = "Прикладная програма для управления базой данных: \'Учет строительно-монтажных рабо" +
    "т.\' ";
            this.Load += new System.EventHandler(this.FirstForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button exit_btn;
        private System.Windows.Forms.Button work_btn;
        private System.Windows.Forms.Button materials_btn;
        private System.Windows.Forms.Button building_btn;
        private System.Windows.Forms.Button address_btn;
        private System.Windows.Forms.Button person_btn;
        private System.Windows.Forms.Button speciality_btn;
        private System.Windows.Forms.Button report_btn;
    }
}

