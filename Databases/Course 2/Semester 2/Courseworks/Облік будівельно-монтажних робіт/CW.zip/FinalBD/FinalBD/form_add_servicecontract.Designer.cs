﻿namespace FinalBD
{
    partial class form_add_servicecontract
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_save = new System.Windows.Forms.Button();
            this.finalBDDataSet = new FinalBD.FinalBDDataSet();
            this.serviceContractBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.serviceContractTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.ServiceContractTableAdapter();
            this.viewBuildingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.view_BuildingTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.view_BuildingTableAdapter();
            this.spCostDlvrBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sp_CostDlvrTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.sp_CostDlvrTableAdapter();
            this.buildingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.buildingTableAdapter = new FinalBD.FinalBDDataSetTableAdapters.BuildingTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.serviceContractBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewBuildingBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spCostDlvrBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.buildingBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.buildingBindingSource;
            this.comboBox1.DisplayMember = "NameObject";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(50, 50);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(125, 21);
            this.comboBox1.TabIndex = 50;
            this.comboBox1.ValueMember = "IdObject";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(47, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 17);
            this.label3.TabIndex = 49;
            this.label3.Text = "Выберите объект";
            // 
            // btn_save
            // 
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_save.Location = new System.Drawing.Point(50, 91);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(122, 35);
            this.btn_save.TabIndex = 48;
            this.btn_save.Text = "Сохранить";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // finalBDDataSet
            // 
            this.finalBDDataSet.DataSetName = "FinalBDDataSet";
            this.finalBDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // serviceContractBindingSource
            // 
            this.serviceContractBindingSource.DataMember = "ServiceContract";
            this.serviceContractBindingSource.DataSource = this.finalBDDataSet;
            // 
            // serviceContractTableAdapter
            // 
            this.serviceContractTableAdapter.ClearBeforeFill = true;
            // 
            // viewBuildingBindingSource
            // 
            this.viewBuildingBindingSource.DataMember = "view_Building";
            this.viewBuildingBindingSource.DataSource = this.finalBDDataSet;
            // 
            // view_BuildingTableAdapter
            // 
            this.view_BuildingTableAdapter.ClearBeforeFill = true;
            // 
            // spCostDlvrBindingSource
            // 
            this.spCostDlvrBindingSource.DataMember = "sp_CostDlvr";
            this.spCostDlvrBindingSource.DataSource = this.finalBDDataSet;
            // 
            // sp_CostDlvrTableAdapter
            // 
            this.sp_CostDlvrTableAdapter.ClearBeforeFill = true;
            // 
            // buildingBindingSource
            // 
            this.buildingBindingSource.DataMember = "Building";
            this.buildingBindingSource.DataSource = this.finalBDDataSet;
            // 
            // buildingTableAdapter
            // 
            this.buildingTableAdapter.ClearBeforeFill = true;
            // 
            // form_add_servicecontract
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(227, 196);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_save);
            this.Name = "form_add_servicecontract";
            this.Text = "form_add_servicecontract";
            this.Load += new System.EventHandler(this.form_add_servicecontract_Load);
            ((System.ComponentModel.ISupportInitialize)(this.finalBDDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.serviceContractBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewBuildingBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spCostDlvrBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.buildingBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_save;
        private FinalBDDataSet finalBDDataSet;
        private System.Windows.Forms.BindingSource serviceContractBindingSource;
        private FinalBDDataSetTableAdapters.ServiceContractTableAdapter serviceContractTableAdapter;
        private System.Windows.Forms.BindingSource viewBuildingBindingSource;
        private FinalBDDataSetTableAdapters.view_BuildingTableAdapter view_BuildingTableAdapter;
        private System.Windows.Forms.BindingSource spCostDlvrBindingSource;
        private FinalBDDataSetTableAdapters.sp_CostDlvrTableAdapter sp_CostDlvrTableAdapter;
        private System.Windows.Forms.BindingSource buildingBindingSource;
        private FinalBDDataSetTableAdapters.BuildingTableAdapter buildingTableAdapter;
    }
}