﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalBD
{
    public partial class form_add_worker : Form
    {
        public form_add_worker()
        {
            InitializeComponent();
        }

        private void form_add_worker_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Gender". При необходимости она может быть перемещена или удалена.
            this.genderTableAdapter.Fill(this.finalBDDataSet.Gender);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Address". При необходимости она может быть перемещена или удалена.
            this.addressTableAdapter.Fill(this.finalBDDataSet.Address);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Street". При необходимости она может быть перемещена или удалена.
            this.streetTableAdapter.Fill(this.finalBDDataSet.Street);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Locality". При необходимости она может быть перемещена или удалена.
            this.localityTableAdapter.Fill(this.finalBDDataSet.Locality);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Region". При необходимости она может быть перемещена или удалена.
            this.regionTableAdapter.Fill(this.finalBDDataSet.Region);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Country". При необходимости она может быть перемещена или удалена.
            this.countryTableAdapter.Fill(this.finalBDDataSet.Country);

        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            string conS = "Data Source=BODYAS-PC;Initial Catalog=FinalBD;Integrated Security=True";
            try
            {
                using (SqlConnection con = new SqlConnection(conS))
                {
                    using (SqlCommand cmd = new SqlCommand("add_Worker", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@IdAddressWorker", SqlDbType.Int).Value = int.Parse(comboBox6.SelectedValue.ToString());
                        cmd.Parameters.AddWithValue("@Surname", SqlDbType.VarChar).Value = txt_input2.Text.ToString();
                        cmd.Parameters.AddWithValue("@Name", SqlDbType.VarChar).Value = txt_input1.Text.ToString();
                        cmd.Parameters.AddWithValue("@MiddleName", SqlDbType.VarChar).Value = textBox1.Text.ToString();
                        cmd.Parameters.AddWithValue("@Phone", SqlDbType.Int).Value = 1;
                        cmd.Parameters.AddWithValue("@IdGender", SqlDbType.Int).Value = int.Parse(comboBox1.SelectedValue.ToString());  
                        cmd.Parameters.AddWithValue("@DataBirth", SqlDbType.DateTime).Value = DateTime.Parse(dateTimePicker1.Text.ToString());
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }   
            catch
            {
                MessageBox.Show("Data Error!", "Error!",
               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Close();
        }
    }
}
