﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalBD
{
    public partial class form_add_contract : Form
    {
        public form_add_contract()
        {
            InitializeComponent();
        }

        private void form_add_contract_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.view_Provider". При необходимости она может быть перемещена или удалена.
            this.view_ProviderTableAdapter.Fill(this.finalBDDataSet.view_Provider);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.Person". При необходимости она может быть перемещена или удалена.
            this.personTableAdapter.Fill(this.finalBDDataSet.Person);
            //form_add_contract
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            string conS = "Data Source=BODYAS-PC;Initial Catalog=FinalBD;Integrated Security=True";
            try
            {
                using (SqlConnection con = new SqlConnection(conS))
                {
                    using (SqlCommand cmd = new SqlCommand("add_contract", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@IdPerson", SqlDbType.Int).Value = int.Parse(comboBox1.SelectedValue.ToString());
                        cmd.Parameters.AddWithValue("@DOC", SqlDbType.DateTime).Value = DateTime.Parse(dateTimePicker1.Text.ToString());
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Data Error!", "Error!",
               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Close();
        }
    }
}
