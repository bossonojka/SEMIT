﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalBD
{
    public partial class form_add_procurementcontract : Form
    {
        public form_add_procurementcontract()
        {
            InitializeComponent();
        }

        private void form_add_procurementcontract_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.view_Materials". При необходимости она может быть перемещена или удалена.
            this.view_MaterialsTableAdapter.Fill(this.finalBDDataSet.view_Materials);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.DeliveredMaterials". При необходимости она может быть перемещена или удалена.
            this.deliveredMaterialsTableAdapter.Fill(this.finalBDDataSet.DeliveredMaterials);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.ProcurementType". При необходимости она может быть перемещена или удалена.
            this.procurementTypeTableAdapter.Fill(this.finalBDDataSet.ProcurementType);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "finalBDDataSet.ProcurementContract". При необходимости она может быть перемещена или удалена.
            this.procurementContractTableAdapter.Fill(this.finalBDDataSet.ProcurementContract);

        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            string conS = "Data Source=BODYAS-PC;Initial Catalog=FinalBD;Integrated Security=True";
            try
            {
                using (SqlConnection con = new SqlConnection(conS))
                {
                    using (SqlCommand cmd = new SqlCommand("add_ProcurementContract", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@IdProcurement", SqlDbType.Int).Value = int.Parse(comboBox1.SelectedValue.ToString());
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Data Error!", "Error!",
               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Close();
        }
    }
}
