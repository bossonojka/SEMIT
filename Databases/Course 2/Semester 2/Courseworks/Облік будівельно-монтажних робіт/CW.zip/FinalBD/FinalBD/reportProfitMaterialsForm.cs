﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalBD
{
    public partial class reportProfitMaterialsForm : Form
    {
        public reportProfitMaterialsForm()
        {
            InitializeComponent();
        }

        private void reportProfitMaterialsForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "FinalBDDataSet.sp_ProfitMaterials". При необходимости она может быть перемещена или удалена.
            this.sp_ProfitMaterialsTableAdapter.Fill(this.FinalBDDataSet.sp_ProfitMaterials);

            this.reportViewer1.RefreshReport();
        }
    }
}
