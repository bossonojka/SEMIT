﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dlvr
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        SqlConnection connection;

        private async void Form5_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'deliveryDataSet.Поставлено' table. You can move, or remove it, as needed.
            this.поставленоTableAdapter.Fill(this.deliveryDataSet.Поставлено);

            connection = new SqlConnection(@"Data Source=JARVIS\SQLEXPRESS;Initial Catalog=delivery;Integrated Security=True");
            await connection.OpenAsync();

            // TODO: This line of code loads data into the 'deliveryDataSet.Поставщики' table. You can move, or remove it, as needed.
            this.поставщикиTableAdapter.Fill(this.deliveryDataSet.Поставщики);
            // TODO: This line of code loads data into the 'deliveryDataSet.View_4' table. You can move, or remove it, as needed.
            this.view_4TableAdapter.Fill(this.deliveryDataSet.View_4);
            // TODO: This line of code loads data into the 'deliveryDataSet.Договоры' table. You can move, or remove it, as needed.
            this.договорыTableAdapter.Fill(this.deliveryDataSet.Договоры);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private async void button2_Click(object sender, EventArgs e)
        {
            int supplierId = int.Parse(this.comboBox1.SelectedValue.ToString());
            DateTime date = Convert.ToDateTime(this.dateTimePicker1.Text);
            string comment = Convert.ToString(this.textBox1.Text);

            SqlCommand command = new SqlCommand("INSERT INTO Договоры (КодПоставщика, ДатаДоговора, Комментарий) VALUES (@supplierId, @date, @comment)", connection);

            command.Parameters.AddWithValue("supplierId", supplierId);
            command.Parameters.AddWithValue("date", date.ToShortDateString());
            command.Parameters.AddWithValue("comment", comment);

            int state = await command.ExecuteNonQueryAsync();

            if (state != 0)
            {
                this.договорыTableAdapter.Fill(deliveryDataSet.Договоры);
                MessageBox.Show("Изменения внесены", "Изменение записи");
            } else
            {
                MessageBox.Show("Не удалось внести изменения", "Изменение записи");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

        private async void button4_Click(object sender, EventArgs e)
        {
            int contractId = int.Parse(this.dataGridView1.Rows[this.dataGridView1.CurrentCell.RowIndex].Cells["номерДоговораDataGridViewTextBoxColumn"].Value.ToString());

            DialogResult result = MessageBox.Show("Удалить договор №" + contractId + "?", "Предупреждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);

            if (result == DialogResult.Yes)
            {
                SqlCommand command = new SqlCommand("DELETE FROM Договоры WHERE НомерДоговора = @contractId", connection);
                command.Parameters.AddWithValue("contractId", contractId);

                int state = await command.ExecuteNonQueryAsync();

                if (state != 0)
                {
                    this.договорыTableAdapter.Fill(deliveryDataSet.Договоры);
                    MessageBox.Show("Изменения внесены", "Удаление записи");
                }
                else
                {
                    MessageBox.Show("Не удалось внести изменения", "Удаление записи");
                }
            }
        }

        private void Form5_FormClosing(object sender, FormClosingEventArgs e)
        {
            connection.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.tabControl2.SelectedTab = tabPage4;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.tabControl2.SelectedTab = tabPage3;
        }

        private async void button7_Click(object sender, EventArgs e)
        {
            int contractId = int.Parse(this.dataGridView1.Rows[this.dataGridView1.CurrentCell.RowIndex].Cells["номерДоговораDataGridViewTextBoxColumn"].Value.ToString());
            string good = Convert.ToString(this.textBox4.Text);
            int count = int.Parse(this.textBox3.Text);
            decimal price = decimal.Parse(this.textBox2.Text);

            SqlCommand command = new SqlCommand("INSERT INTO Поставлено VALUES(@contractId,@good,@count,@price)",connection);
            command.Parameters.AddWithValue("@contractId", contractId);
            command.Parameters.AddWithValue("@good", good);
            command.Parameters.AddWithValue("@count", count);
            command.Parameters.AddWithValue("@price", price);

            int state = await command.ExecuteNonQueryAsync();

            if (state != 0)
            {
                this.поставленоTableAdapter.Fill(this.deliveryDataSet.Поставлено);
                MessageBox.Show("Товар добавлен", "Добавление товара");
            }
            else
            {
                MessageBox.Show("Не удалось добавить товар", "Добавление товара");
            }
        }

        private async void button6_Click(object sender, EventArgs e)
        {
            int supplierId = int.Parse(this.dataGridView2.Rows[this.dataGridView2.CurrentCell.RowIndex].Cells["номерДоговораDataGridViewTextBoxColumn1"].Value.ToString());
            string good = Convert.ToString(this.dataGridView2.CurrentRow.Cells["товарDataGridViewTextBoxColumn"].Value);

            SqlCommand command = new SqlCommand("DELETE FROM Поставлено WHERE НомерДоговора = @supplierId AND Товар = @good",connection);
            command.Parameters.AddWithValue("@supplierId", supplierId);
            command.Parameters.AddWithValue("@good", good);

            int state = await command.ExecuteNonQueryAsync();

            if (state != 0)
            {
                this.поставленоTableAdapter.Fill(this.deliveryDataSet.Поставлено);
                MessageBox.Show("Товар удален", "Удаление товара");
            }
            else
            {
                MessageBox.Show("Не удалось удалить товар", "Удаление товара");
            }
        }

        private async void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int contractId = int.Parse(this.dataGridView1.Rows[this.dataGridView1.CurrentCell.RowIndex].Cells["номерДоговораDataGridViewTextBoxColumn"].Value.ToString());

            SqlCommand command = new SqlCommand("[sp_sum_dgvr]", connection);
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.AddWithValue("@dgvrNumber", contractId);
            command.Parameters["@dgvrNumber"].Direction = ParameterDirection.Input;

            command.Parameters.Add("@sum_kol_vo", SqlDbType.Int, 4);
            command.Parameters["@sum_kol_vo"].Direction = ParameterDirection.Output;

            command.Parameters.Add("@sum_summa", SqlDbType.Decimal, 4);
            command.Parameters["@sum_summa"].Direction = ParameterDirection.Output;

            await command.ExecuteScalarAsync();

            textBox5.Text = Convert.ToString(command.Parameters["@sum_kol_vo"].Value);
            textBox6.Text = Convert.ToString(command.Parameters["@sum_summa"].Value);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
