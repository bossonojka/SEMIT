﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dlvr
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void физическиеЛицаBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.физическиеЛицаBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.deliveryDataSet);

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'deliveryDataSet.Поставщики' table. You can move, or remove it, as needed.
            this.поставщикиTableAdapter.Fill(this.deliveryDataSet.Поставщики);
            // TODO: This line of code loads data into the 'deliveryDataSet.ФизическиеЛица' table. You can move, or remove it, as needed.
            this.физическиеЛицаTableAdapter.Fill(this.deliveryDataSet.ФизическиеЛица);
        }

        private void физическиеЛицаDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
