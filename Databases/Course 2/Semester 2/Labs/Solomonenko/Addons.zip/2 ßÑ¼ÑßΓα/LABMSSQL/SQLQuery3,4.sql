use delivery
exec sp_dgvr_mdf 'U',8,'2008/12/31',2,'88888888'