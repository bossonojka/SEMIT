﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form_Rep2 : Form
    {
        public Form_Rep2()
        {
            InitializeComponent();
        }
        deliveryDataSet dsDelivery = new deliveryDataSet();
        deliveryDataSetTableAdapters.sp_dgvr_sum1TableAdapter daДоговоры = new WindowsFormsApplication1.deliveryDataSetTableAdapters.sp_dgvr_sum1TableAdapter();

        private void Form_Rep2_Load(object sender, EventArgs e)
        {
            Form_Rep2_ДоговорыFill();
            this.crystalReport_sp21.SetDataSource(dsDelivery);
            this.crystalReportViewer1.Refresh();
            this.crystalReportViewer1.ReportSource = this.crystalReport_sp21;
        }

        public void Form_Rep2_ДоговорыFill()
        {
            daДоговоры.Fill(dsDelivery.sp_dgvr_sum1,2);
        }
    }
}
