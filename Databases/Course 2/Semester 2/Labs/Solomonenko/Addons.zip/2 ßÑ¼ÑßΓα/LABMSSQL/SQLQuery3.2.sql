use dlvr
exec sp_dgvr_agr '19990101' , '19991031'