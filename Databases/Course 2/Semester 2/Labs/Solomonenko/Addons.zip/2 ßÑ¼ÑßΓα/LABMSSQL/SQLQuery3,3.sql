use delivery
exec sp_dgvr_mdf 'I',0,'2008/12/16',2,''