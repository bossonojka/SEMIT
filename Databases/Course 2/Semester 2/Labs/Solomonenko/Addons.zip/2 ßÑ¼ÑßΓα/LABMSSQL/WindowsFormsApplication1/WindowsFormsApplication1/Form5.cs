﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Collections;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form5 : Form
    {
        SqlConnection conn = null;
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "deliveryDataSet.Поставлено". При необходимости она может быть перемещена или удалена.
            this.поставленоTableAdapter.Fill(this.deliveryDataSet.Поставлено);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "deliveryDataSet.View_3". При необходимости она может быть перемещена или удалена.
            this.view_3TableAdapter.Fill(this.deliveryDataSet.View_3);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "deliveryDataSet.Договоры". При необходимости она может быть перемещена или удалена.
            this.договорыTableAdapter.Fill(this.deliveryDataSet.Договоры);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2; 
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int codeSupplier = int.Parse(this.comboBox1.SelectedValue.ToString());
                DateTime datedgvr = Convert.ToDateTime(this.dateTimePicker1.Text);
                string dgvrComment = Convert.ToString(this.textBox1.Text);

                conn = new SqlConnection();
                conn.ConnectionString = "integrated security=SSPI; data source=\".\"; persist security info=False; initial catalog=delivery";
                conn.Open();
                SqlCommand myCommand = conn.CreateCommand();
                myCommand.CommandText = "INSERT INTO Договоры (КодПоставщика,ДатаДоговора,Комментарий) VALUES (@codeSupplier,@datedgvr,@dgvrComment)";
                myCommand.Parameters.Add("@codeSupplier", SqlDbType.Int, 4);
                myCommand.Parameters["@codeSupplier"].Value = codeSupplier;
                myCommand.Parameters.Add("@datedgvr", SqlDbType.DateTime, 8);
                myCommand.Parameters["@datedgvr"].Value = datedgvr;
                myCommand.Parameters.Add("@dgvrComment", SqlDbType.NVarChar, 50);
                myCommand.Parameters["@dgvrComment"].Value = dgvrComment;

                int UspeshoeIzmenenie = myCommand.ExecuteNonQuery();
                if (UspeshoeIzmenenie != 0)
                {
                    MessageBox.Show("Изменения внесены", "Изменение записи");
                }
                else
                {
                    MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            this.договорыTableAdapter.Fill(this.deliveryDataSet.Договоры);
            this.tabControl1.SelectedTab = tabPage1;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int dgvrNumber = int.Parse(dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells["номерДоговораDataGridViewTextBoxColumn"].Value.ToString());

            DialogResult result = MessageBox.Show(" Удалить договор № " + Convert.ToString(dgvrNumber) + "? ", "Предупреждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            switch (result)
            {
                case DialogResult.Yes:
                    {
                        try
                        {
                            conn = new SqlConnection();
                            conn.ConnectionString = "integrated security=SSPI; data source=\".\"; persist security info=False; initial catalog=delivery";
                            conn.Open();
                            SqlCommand myCommand = conn.CreateCommand();
                            myCommand.CommandText = "DELETE FROM Договоры WHERE НомерДоговора = @dgvrNumber";
                            myCommand.Parameters.Add("@dgvrNumber", SqlDbType.Int, 4);
                            myCommand.Parameters["@dgvrNumber"].Value = dgvrNumber;
                            int UspeshonoeIzmenenie = myCommand.ExecuteNonQuery();
                            if (UspeshonoeIzmenenie != 0)
                            {
                                MessageBox.Show("Изменения внесены", "Изменение записи");
                            }
                            else
                            {
                                MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                        finally
                        {
                            conn.Close();
                        }
                        this.договорыTableAdapter.Fill(this.deliveryDataSet.Договоры);
                        break;
                    }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                int dgvrNumber = int.Parse(dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells["номерДоговораDataGridViewTextBoxColumn"].Value.ToString());
                string tovar = Convert.ToString(this.textBox2.Text);
                int tovar_kol = int.Parse(this.textBox3.Text.ToString());
                Decimal tovar_cena = Convert.ToDecimal(this.textBox4.Text);

                conn = new SqlConnection();
                conn.ConnectionString = "integrated security=SSPI;data source=\".\"; " + "persist security info=False; initial catalog=delivery";
                conn.Open();
                SqlCommand myCommand = conn.CreateCommand();
                myCommand.CommandText = "INSERT INTO Поставлено (НомерДоговора,Товар,Количество,Цена)" +
                    "VALUES (@dgvrNumber,@tovar,@tovar_kol,@tovar_cena)";
                myCommand.Parameters.Add("@dgvrNumber", SqlDbType.Int, 4);
                myCommand.Parameters["@dgvrNumber"].Value = dgvrNumber;
                myCommand.Parameters.Add("@tovar", SqlDbType.NVarChar, 20);
                myCommand.Parameters["@tovar"].Value = tovar;
                myCommand.Parameters.Add("@tovar_kol", SqlDbType.Int, 8);
                myCommand.Parameters["@tovar_kol"].Value = tovar_kol;
                myCommand.Parameters.Add("@tovar_cena", SqlDbType.Decimal, 8);
                myCommand.Parameters["@tovar_cena"].Value = tovar_cena;
                int UspeshnoeIzmenenie = myCommand.ExecuteNonQuery();
                if (UspeshnoeIzmenenie != 0)
                {
                    MessageBox.Show("Изменения внесены", "Изменение записи");
                }
                else
                {
                    MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            this.поставленоTableAdapter.Fill(this.deliveryDataSet.Поставлено);
            this.tabControl2.SelectedTab = tabPage3;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.tabControl2.SelectedTab = tabPage3;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int dgvrNumber = int.Parse(dataGridView2.Rows[dataGridView2.CurrentCell.RowIndex].Cells["номерДоговораDataGridViewTextBoxColumn1"].Value.ToString());
            String dgvrTovar = Convert.ToString(dataGridView2.Rows[dataGridView2.CurrentCell.RowIndex].Cells["товарDataGridViewTextBoxColumn"].Value.ToString());

            DialogResult result = MessageBox.Show(" Удалить договор № " + Convert.ToString(dgvrNumber) + " товар " + dgvrTovar + "? ",
                "Предупрежедение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            switch (result)
            {
                case DialogResult.Yes:
                    {
                        try
                        {
                            conn = new SqlConnection();
                            conn.ConnectionString = "integrated security=SSPI;data source=\".\"; " +
                                "persist security info=False; initial catalog=delivery";
                            conn.Open();
                            SqlCommand myComment = conn.CreateCommand();
                            myComment.CommandText = "DELETE FROM Поставлено WHERE " +
                                "НомерДоговора = @dgvrNumber AND Товар = @dgvrTovar";
                            myComment.Parameters.Add("@dgvrNumber", SqlDbType.Int, 4);
                            myComment.Parameters["@dgvrNumber"].Value = dgvrNumber;
                            myComment.Parameters.Add("@dgvrTovar", SqlDbType.NVarChar, 20);
                            myComment.Parameters["@dgvrTovar"].Value = dgvrTovar;

                            int UspeshnoeIzmenenie = myComment.ExecuteNonQuery();
                            if (UspeshnoeIzmenenie != 0)
                            {
                                MessageBox.Show("Изменения внесены", "Изменение записи");
                            }
                            else
                            {
                                MessageBox.Show("Не удалось внести изменения", "Изменение записи");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                        finally
                        {
                            conn.Close();
                        }
                        this.поставленоTableAdapter.Fill(this.deliveryDataSet.Поставлено);
                        break;
                    }
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int dgvrNumber = int.Parse(dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells["номерДоговораDataGridViewTextBoxColumn"].Value.ToString());
                conn = new SqlConnection();
                conn.ConnectionString = "integrated security=SSPI;data source=\".\"; " +
                    "persist security info=False; initial catalog=delivery";
                SqlCommand myCommand = conn.CreateCommand();
                myCommand.CommandType = CommandType.StoredProcedure;
                myCommand.CommandText = "[sp_sum_dgvr]";
                myCommand.Parameters.Add("@dgvrNumber", SqlDbType.Int, 4);
                myCommand.Parameters["@dgvrNumber"].Value = dgvrNumber;
                myCommand.Parameters["@dgvrNumber"].Direction = ParameterDirection.Input;

                myCommand.Parameters.Add("@sum_kol_vo", SqlDbType.Int, 4);
                myCommand.Parameters["@sum_kol_vo"].Direction = ParameterDirection.Output;
                myCommand.Parameters.Add("@sum_summa", SqlDbType.Money);
                myCommand.Parameters["@sum_summa"].Direction = ParameterDirection.Output;

                conn.Open();
                myCommand.ExecuteScalar();
                textBox5.Text = Convert.ToString(myCommand.Parameters["@sum_kol_vo"].Value);
                textBox6.Text = Convert.ToString(myCommand.Parameters["@sum_summa"].Value);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
