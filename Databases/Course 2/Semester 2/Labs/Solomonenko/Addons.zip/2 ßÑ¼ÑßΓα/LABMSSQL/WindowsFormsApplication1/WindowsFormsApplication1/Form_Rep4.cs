﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form_Rep4 : Form
    {
        public Form_Rep4()
        {
            InitializeComponent();
        }
        deliveryDataSet dsDelivery = new deliveryDataSet();
        deliveryDataSetTableAdapters.sp_dgvr_agrTableAdapter daДоговоры = new WindowsFormsApplication1.deliveryDataSetTableAdapters.sp_dgvr_agrTableAdapter();


        private void Form_Rep4_Load(object sender, EventArgs e)
        {
            Form_Rep4_ДоговорыFill();
            this.crystalReport_sp31.SetDataSource(dsDelivery);
            this.crystalReportViewer1.Refresh();
            this.crystalReportViewer1.ReportSource = this.crystalReport_sp31;
        }

        public void setContent(string txt1, string txt2)
        {
            this.textBox1.Text = txt1;
            this.textBox2.Text = txt2;
        }

        public void Form_Rep4_ДоговорыFill()
        {
            DateTime datedgvr1 = Convert.ToDateTime(this.textBox1.Text);
            DateTime datedgvr2 = Convert.ToDateTime(this.textBox2.Text);
            daДоговоры.Fill(dsDelivery.sp_dgvr_agr, datedgvr1, datedgvr2);
        }
    }
}
