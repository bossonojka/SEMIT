﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form_Reports : Form
    {
        public Form_Reports()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.Parse(this.textBox1.Text.ToString()) <= 0)
            {
                MessageBox.Show("Введите номер договора");
            }
            else
            {
                Form_Rep3 frm = new Form_Rep3();
                frm.setContent(this.textBox1.Text);
                frm.Show();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form_Rep4 frm = new Form_Rep4();
            frm.setContent(this.dateTimePicker1.Text, this.dateTimePicker2.Text);
            frm.Show();
        }
    }
}
