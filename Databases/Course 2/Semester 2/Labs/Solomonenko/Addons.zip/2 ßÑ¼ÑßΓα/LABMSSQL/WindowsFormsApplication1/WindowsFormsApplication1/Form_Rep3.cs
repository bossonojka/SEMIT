﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form_Rep3 : Form
    {
        public Form_Rep3()
        {
            InitializeComponent();
        }
        deliveryDataSet dsDelivery = new deliveryDataSet();
        deliveryDataSetTableAdapters.sp_dgvr_sum1TableAdapter daДоговоры = new WindowsFormsApplication1.deliveryDataSetTableAdapters.sp_dgvr_sum1TableAdapter();

        private void Form_Rep3_Load(object sender, EventArgs e)
        {
            Form_Rep3_ДоговорыFill();
            this.crystalReport_sp21.SetDataSource(dsDelivery);
            this.crystalReportViewer1.Refresh();
            this.crystalReportViewer1.ReportSource = this.crystalReport_sp21;
        }

        public void setContent(string txt)
        {
            this.textBox1.Text = txt;
        }

        public void Form_Rep3_ДоговорыFill()
        {
            int nom_dgvr = int.Parse(this.textBox1.Text.ToString());
            daДоговоры.Fill(dsDelivery.sp_dgvr_sum1, nom_dgvr);
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
