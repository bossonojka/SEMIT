use dlvr
exec sp_dgvr_mdf 'D', 8, '2008/12/31', 0, ''