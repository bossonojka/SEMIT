var DELETE_MESSAGE = 1;
var CREATE_MESSAGE = 2;
var EDIT_MESSAGE = 3;

var handler;
shop.initialize(handler);

var deletor = document.querySelectorAll(".deletor");
var creator = document.querySelector("#creator");
var editor = document.querySelector("#editor");

deletor.forEach(function(form){
    form.onsubmit = function(e){
        e.preventDefault();
        var request = new XMLHttpRequest()
            
        request.open("POST", "ProductDelete", true);
        request.onreadystatechange = function(){
            if (this.readyState == 4){
                if (this.status == 200){
                    if (this.response != null){
                        shop.sendMessage({type:DELETE_MESSAGE});
                        location.reload();
                    }
                }
            }
        }

        request.send(new FormData(form));
    }
})

creator.onsubmit = function(e){
    e.preventDefault();
    if (creator.name.value != "" && creator.price.value != ""){
        var request = new XMLHttpRequest()
        
        request.open("POST", "ProductCreate", true);
        request.onreadystatechange = function(){
            if (this.readyState == 4){
                if (this.status == 200){
                    if (this.response != null){
                        shop.sendMessage({type:CREATE_MESSAGE});
                        location.reload();
                    }
                }
            }
        }

        request.send(new FormData(creator));
    }
}

editor.onsubmit = function(e){
    e.preventDefault();
    if (editor.name.value != "" && editor.price.value != ""){
        var request = new XMLHttpRequest()
        
        request.open("POST", "ProductEdit", true);
        request.onreadystatechange = function(){
            if (this.readyState == 4){
                if (this.status == 200){
                    if (this.response != null){
                        shop.sendMessage({type:EDIT_MESSAGE});
                        
                        editor.name.value = "";
                        editor.price.value = "";
                        
                        location.reload();
                    }
                }
            }
        }

        request.send(new FormData(editor));
    }
}