package socket_admin.servlets;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import socket_admin.models.Product;
import socket_admin.models.User;
import socket_admin.util.Validation;

@MultipartConfig
public class ProductEdit extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ProductEdit() {
        super();
    }

	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("product") != "") {
			int productId = Integer.parseInt(request.getParameter("product"));
			
			HttpSession session = request.getSession();
			
			if (!session.isNew()) {
				User user = (User) session.getAttribute("user");
				if (user != null) {
					if (user.isAdmin()) {
						List<Product> products = (CopyOnWriteArrayList<Product>) getServletContext().getAttribute("products");
						
						for (Product p : products) {
							if (p.getId() == productId) {
								request.setAttribute("product", p);
							}
						}
						request.setAttribute("products", products);
						request.getRequestDispatcher("index.jsp").forward(request, response);
					} else {
						request.getRequestDispatcher("index.jsp").forward(request, response);
					}
				} else {
					response.sendRedirect("Login");
				}
			} else {
				response.sendRedirect("Login");
			}
		}
	}

	@SuppressWarnings("unchecked")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("name") != "" && request.getParameter("manufacturer") != "" && Validation.isDouble(request.getParameter("price")) && (request.getParameter("product") != "")) {
			int productId = Integer.parseInt(request.getParameter("product"));
			String manufacturer = request.getParameter("manufacturer");
			String name = request.getParameter("name");
			double price = Double.parseDouble(request.getParameter("price"));
			
			List<Product> products = (CopyOnWriteArrayList<Product>) getServletContext().getAttribute("products");
			
			for (Product p : products) {
				if (p.getId() == productId) {
					p.setName(name);
					p.setPrice(price);
					p.setManufacturer(manufacturer);
					p.edit();
				}
			}
		}
		response.sendRedirect("index.jsp");
	}
}
