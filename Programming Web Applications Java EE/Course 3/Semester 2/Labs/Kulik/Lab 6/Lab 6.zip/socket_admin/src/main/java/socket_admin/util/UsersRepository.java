package socket_admin.util;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import socket_admin.models.Product;
import socket_admin.models.User;

public class UsersRepository {
	private SessionFactory factory;
	private List<User> users = new CopyOnWriteArrayList<User>();
	
	public UsersRepository(SessionFactory factory) {
		this.factory = factory;
	}
	
	public List<User> getUsers() {
		Session session = factory.openSession();
        session.beginTransaction();
        
        List<User> users = session.createQuery("from User", User.class).list();
         
        for (User u : users) {
			this.users.add(u);
		}
         
        session.getTransaction().commit();
        session.close(); 
		
		return this.users;
	}
}
