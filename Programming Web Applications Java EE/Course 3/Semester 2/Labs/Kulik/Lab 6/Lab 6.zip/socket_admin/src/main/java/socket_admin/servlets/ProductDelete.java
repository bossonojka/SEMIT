package socket_admin.servlets;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import socket_admin.models.Product;
import socket_admin.models.User;

@MultipartConfig
public class ProductDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ProductDelete() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	@SuppressWarnings("unchecked")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("product") != "") {
			int productId = Integer.parseInt(request.getParameter("product"));
			
			HttpSession session = request.getSession();
			
			if (!session.isNew()) {
				User user = (User) session.getAttribute("user");
				if (user != null) {
					if (user.isAdmin()) {
						List<Product> products = (CopyOnWriteArrayList<Product>) getServletContext().getAttribute("products");
						
						for (Product p : products) {
							if (p.getId() == productId) {
								p.delete();
								products.remove(p);
							}
						}
					} else {
						request.getRequestDispatcher("index.jsp").forward(request, response);
					}
				} else {
					response.sendRedirect("Login");
				}
			} else {
				response.sendRedirect("Login");
			}
		}
		response.sendRedirect("");
	}

}
