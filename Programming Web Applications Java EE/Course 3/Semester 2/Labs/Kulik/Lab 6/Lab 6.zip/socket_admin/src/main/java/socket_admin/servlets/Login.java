package socket_admin.servlets;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import javassist.expr.NewArray;
import socket_admin.models.Product;
import socket_admin.models.User;
import socket_admin.util.Repository;
import socket_admin.util.UsersRepository;

/**
 * Servlet implementation class Login
 */
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private List<User> users;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		if (!session.isNew()) {
			User user = (User) session.getAttribute("user");
			if (user != null) {
				String username = user.getUsername();
				String password = user.getPassword();
				boolean isAdmin = user.isAdmin();
				
				if (isAdmin) {
					response.sendRedirect("/socket_admin");
				}
			} else {
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}
		} else {
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		if (!request.getParameter("username").equals("") && !request.getParameter("password").equals("")) {
			HttpSession session = request.getSession();
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			
			UsersRepository usersRepo = (UsersRepository) getServletContext().getAttribute("usersRepo");
			this.users = usersRepo.getUsers();
			
			User user = null;
			for(User u : this.users) {
				if (username.equals(u.getUsername()) && password.equals(u.getPassword())) {
					user = u;
				}
			}
			
			if (user != null) {
				session.setAttribute("user", user);
				session.setMaxInactiveInterval(900);
				response.sendRedirect("/socket_admin");
			} else {
				request.setAttribute("error", "No user found");
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}
		}
	}

}
