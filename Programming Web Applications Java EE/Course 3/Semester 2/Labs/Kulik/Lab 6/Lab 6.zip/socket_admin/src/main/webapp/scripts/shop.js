'use strict'

var shop = (function(){

    var socket = null;
    var handler;
    
    function connect(host){
        if ('WebSocket' in window) {
            socket = new WebSocket(host);
        } else if ('MozWebSocket' in window) {
            socket = new MozWebSocket(host);
        } else {
            console.error('WebSocket is not supported by this browser.');
            return;
        }

        socket.onopen = function(){
            console.info('WebSocket connection opened.');
        }

        socket.onclose = function(){
            console.info('WebSocket closed.');
        }

        socket.onmessage = function(message){
            console.log(JSON.parse(message.data));
            if (handler){
                handler.onmessage(message);
            }
        }
    }

    function initialize(callback){
        handler = callback;
        var ep = "/socket/websocket/shop";
        if (window.location.protocol == "http:"){
            connect('ws://' + window.location.host +  ep);
        } else {
            connect('wss://' + window.location.host + ep);
        }
    }

    function sendMessage(message){
        if (socket) {
            socket.send(JSON.stringify(message));
        }
    }
    
    return {
        initialize: initialize,
        sendMessage: sendMessage
    }
})();