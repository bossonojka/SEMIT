package socket_admin.servlets;

import java.io.*;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import socket_admin.models.Product;
import socket_admin.models.User;

public class Products extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private List<Product> products;
       
    public Products() {
        super();
    }

    @SuppressWarnings("unchecked")
	public void init(){
    	final Object products = getServletContext().getAttribute("products");
    	
    	if (products == null || !(products instanceof CopyOnWriteArrayList)) {
    		throw new IllegalStateException();
    	} else {
    		this.products = (CopyOnWriteArrayList<Product>) products;
    	}
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		if (!session.isNew()) {
			User user = (User) session.getAttribute("user");
			if (user != null) {
				if (user.isAdmin()) {
					request.setAttribute("products", products);
					request.getRequestDispatcher("index.jsp").forward(request, response);
				} else {
					request.getRequestDispatcher("index.jsp").forward(request, response);
				}
			} else {
				response.sendRedirect("Login");
			}
		} else {
			response.sendRedirect("Login");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		HttpSession session = request.getSession(false);
//		User user = (User) session.getAttribute("user");
//		if (!session.isNew() && user != null) {
//			
//			String username = ((User) session.getAttribute("user")).getUsername();
//			String password = ((User) session.getAttribute("user")).getPassword();
//			boolean isAdmin = ((User) session.getAttribute("user")).isAdmin();
//			
//			if (username != "" && password != "" && isAdmin != false) {
//				
//			}
//		} else {
//			
//		}
		
		if (request.getParameter("manufacturer") != "") {
			String manufacturer = request.getParameter("manufacturer");
			List<Product> products = new CopyOnWriteArrayList<Product>();

			for (Product p : this.products) {
				if(p.getManufacturer().equals(manufacturer)) {
					products.add(p);
				}
			}
			request.setAttribute("products", products);
			request.getRequestDispatcher("/index.jsp").forward(request, response);
		}
	}
}
