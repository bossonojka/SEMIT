package socket_user.servlets;

import java.io.*;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import socket_user.models.Product;
import socket_user.util.Repository;

public class Products extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private List<Product> products;
       
    public Products() {
        super();
    }

    @SuppressWarnings("unchecked")
	public void init(){
    	final Object products = getServletContext().getAttribute("products");
    	
    	if (products == null || !(products instanceof CopyOnWriteArrayList)) {
    		throw new IllegalStateException();
    	} else {
    		this.products = (CopyOnWriteArrayList<Product>) products;
    	}
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		request.setAttribute("products", products);
		request.getRequestDispatcher("/index.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("manufacturer") != null) {
			String manufacturer = request.getParameter("manufacturer");
			List<Product> products = new CopyOnWriteArrayList<Product>();
			
			Repository repo = (Repository) getServletContext().getAttribute("repo");
			
			for (Product p : repo.getProducts()) {
				if(p.getManufacturer().equals(manufacturer)) {
					products.add(p);
				}
			}
			request.setAttribute("products", products);
			request.getRequestDispatcher("/index.jsp").forward(request, response);
		}
	}
}
