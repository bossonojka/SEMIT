package socket.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PersistenceException;
import javax.persistence.Table;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

@Entity
@Table
public class Product {
	private int id;
	private String name;
	private double price;
	private String manufacturer;
	
	public Product(String name, double price, String manufacturer) {
		super();
		this.name = name;
		this.price = price;
		this.manufacturer = manufacturer;
	}
	
	public Product() {
		
	}

	public static SessionFactory factory;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Column(nullable = false)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Column(nullable = false)
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	@Column(nullable = false)
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	
	public boolean create() throws PersistenceException{
		Session session = factory.openSession();
		session.beginTransaction();
		
		session.save(this);
		
		session.getTransaction().commit();
		session.close();
		
		return true;
	}
	
	public boolean delete(){
		Session session = factory.openSession();
		session.beginTransaction();
		
		session.delete(this);
		
		session.getTransaction().commit();
		session.close();
		
		return true;
	}
	
	public boolean edit(){
		Session session = factory.openSession();
		session.beginTransaction();
		
		session.update(this);
		
		session.getTransaction().commit();
		session.close();
		
		return true;
	}
	
	public String toString() {
		return this.id + " : " + this.manufacturer + " : " + this.name + " : " + this.price;
	}
}
