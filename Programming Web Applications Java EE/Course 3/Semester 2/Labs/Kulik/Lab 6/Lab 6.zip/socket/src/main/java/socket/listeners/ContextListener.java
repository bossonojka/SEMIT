package socket.listeners;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import socket.endpoints.ShopEndpoint;
import socket.models.Product;
import socket.util.Repository;

public class ContextListener implements ServletContextListener {
	
	private SessionFactory factory;

	public void contextInitialized(ServletContextEvent sce) {
		final ServletContext ctx = sce.getServletContext();

		StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure().build(); 
		factory = new MetadataSources(registry).buildMetadata().buildSessionFactory(); 
		
		Product.factory = factory;
		Repository repo = ShopEndpoint.repository =  new Repository(factory);
		
		List<Product> products = repo.getProducts();
		
		ShopEndpoint.products = products;
		
		ctx.setAttribute("products", products);
	}

	public void contextDestroyed(ServletContextEvent sce) {
		
	}
}
