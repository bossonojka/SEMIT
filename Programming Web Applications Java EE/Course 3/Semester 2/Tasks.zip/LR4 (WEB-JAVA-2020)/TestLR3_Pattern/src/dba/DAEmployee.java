package dba;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import model.MyObject;

/**
 * @author Dvukhglavov D.E.
 */
public class DAEmployee {
	// Data Access to objects of class of YOUR Object

	public static void showAll(Connection con, String promptText) {
		Statement st = null;
		ResultSet rs = null;

		System.out.println("\n\n" + promptText);
		try {

			// Обращение к базе данных путем отправки SQL-запроса
			st = con.createStatement();
			String SQLText = "SELECT * FROM *имя таблицы*"; //
			rs = st.executeQuery(SQLText); // ResultSet - класс для хранения результатов выполнения SELECT

			// Обработка результата выполнения запроса (SELECT)
			while (rs.next()) {
				// Обработка данных из текущей строки запроса
				// ...
			}

		} catch (SQLException ex) {
			System.out.println("Ошибка получения данных!");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
			} catch (SQLException ex) {

			}

		}

	}

	// Метод поиска конкретного, формирует Select c параметрами
	public static long seek(Connection con, MyObject seekObject) {
		long id;// = -1;
		if (seekObject == null) {
			System.out.println("Нет объекта для поиска");
			id = -1;
		} else {
			PreparedStatement prst = null;
			ResultSet rs = null;
			String SQLTextSEEK = "SELECT * FROM *имя таблицы*" +
			" WHERE (*параметр*=?) AND (*параметр* =?)"; // ПРОБЕЛ В НАЧАЛЕ!!!! Иначе склейка
			try {
				prst = con.prepareStatement(SQLTextSEEK);
				//

				rs = prst.executeQuery();
				// Если есть, то будет считывание в ID
				// Если нет, то будет SQLException
				id = rs.getLong(1);// @param columnIndex the first column is 1, the second is 2, ...
				// Обработка результата выполнения запроса (SELECT)" + dr + ")");
				// ...
				
			} catch (SQLException ex) {
				System.out.println("Объект с таким данными не найден");
				id = -1;
			} finally {
				try {
					if (rs != null) {
						rs.close();
					}
					if (prst != null) {
						prst.close();
					}
				} catch (SQLException ex) {

				}
			}
		}

		return id;

	}

	// Метод добавления, формирует Insert
	public static void insert(Connection con, MyObject newObject) {
		PreparedStatement prst = null;
		String SQLTextIns = "INSERT INTO *имя таблицы*(*поля*) " + "VALUES (?,?,?,?)";
		
		try {
			prst = con.prepareStatement(SQLTextIns);
			// @param parameterIndex the first parameter is 1, the second is 2, ...
			//Подготовка параметров
			//...
			
			prst.execute();
		} catch (SQLException ex) {
			System.out.println("Ошибка добавления. Возможно есть объект с такими данными");
		} finally {
			try {

				if (prst != null) {
					prst.close();
				}
			} catch (SQLException ex) {

			}
		}
	}
	
	// Метод добавления, формирует Update
	public static void update(Connection con, long id, MyObject newObject) {
		if (id == -1) {
			return;
		}
		PreparedStatement prst = null;
		String SQLTextUp = "UPDATE *имя таблицы*" + " SET  *параметр*=?,*параметр*=?, ..." + " WHERE ID=" + id;
		try {

			prst = con.prepareStatement(SQLTextUp);
			// @param parameterIndex the first parameter is 1, the second is 2, ...
			//Подготовка параметров
			//...
			
			prst.execute();

		} catch (SQLException ex) {
			System.out.println("Ошибка обновления. Возможно есть объект с такими данными");
		} finally {
			try {

				if (prst != null) {
					prst.close();
				}
			} catch (SQLException ex) {

			}
		}
	}

	
	public static void delete(Connection con, long id) {
		if (id == -1) {
			return;
		}
		Statement st = null;
		String SQLTextDel = "DELETE FROM *имя таблицы*" + " WHERE ID=" + id; // ПРОБЕЛ В НАЧАЛЕ!!!! Иначе склейка
		try {
			st = con.createStatement();
			st.executeUpdate(SQLTextDel);
		} catch (SQLException ex) {

		} finally {
			try {
				if (st != null) {
					st.close();
				}
			} catch (SQLException ex) {

			}
		}
	}

}
