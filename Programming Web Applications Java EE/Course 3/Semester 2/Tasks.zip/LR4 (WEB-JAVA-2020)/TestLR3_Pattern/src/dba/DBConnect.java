package dba;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author Dvukhglavov D.E.
 */
public class DBConnect {

	private static Connection con;

	public static Connection getConnection() {
		return con;
	}

	public static void DBConection(String dbFileName) {
		// Регистрация драйвера JDBC для в данной сессии программы
		// Если драйвера нет в проекте, то должно генерироваться исключение
		try {
			Class.forName("СТРОКА С НАЗВАНИЕМ КЛАССА ДРАЙВЕРА"); // ClassNotFoundException ex
			System.out.println("Начало работы");

			// Подключение к базе данных.
			// Если подключение "неудачное", то дальнейшая работа невозможна
			// ВОЗМОЖНА ДРУГАЯ ТЕХНОЛОГИЯ ОБРАБОТКИ ОШИБОК ПОДКЛЮЧЕНИЯ
			System.out.println("\nПодключаемся к БД....");

			con = DriverManager.getConnection("СТРОКА ПОДКЛЮЧЕНИЯ К MySQL DB");
			System.out.println("БД для работы успешно подключена!");
			

		} catch (ClassNotFoundException ex) {
			System.out.println("Отсутствует драйвер СУБД, работа невозможна");
			System.exit(111);
		} catch (SQLException ex) {
			System.out.println("Подключение к БД не выполнено!\nПроверьте наличие и исправность БД!");
			System.exit(222);
		}
	}

	public static void DBClose() {
		try {
			if (con != null) {
				con.close();
			}
		} catch (SQLException sQLException) {
		}

	}

}
