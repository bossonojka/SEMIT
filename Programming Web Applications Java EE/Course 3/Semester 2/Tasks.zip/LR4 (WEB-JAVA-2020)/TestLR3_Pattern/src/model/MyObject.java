package model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

/**
 * @author Dvukhglavov D.E.
 */
public class MyObject implements Serializable {

	//**********************************************************************************
	//Это Ваш объект в соответствии с выбранной моделью
	//Интерес представляю методы ввода данных с консоли, которые могуть быть адаптированы
	//**********************************************************************************
	
    private String sname;
    //private String pname;
    private String fname;
    private boolean sex; //true - male, false - female
    //private String tabN; //4 цифры
    //private String position;
    private String dr;
    //private double salary;

    public MyObject() {
	sname = "unknown";
	//pname="unknown";
	fname = "unknown";
	sex = true;
	//tabN="1111";
	//position="manager";
	dr = "01.01.2019";  // 
	//LocalDate today = LocalDate.now();
	//DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd.MM.yyyy");
	//dr=String.valueOf(today.format(dtf));
	//salary=5000.00;
    }

    @Override
    public String toString() {
	String sexText;
	/*if (sex) sexText="male";
	else sexText="female";*/
	sexText = sex ? "male" : "female";
	return "" + sname + " "
		//+  pname + " " 
		+ fname + "(" + (sex ? "male" : "female")/*sexText*/ + ")"
		//+ "\ntabN=" + tabN + " " + position 
		+ "\ndataS=" + dr
		//+ ", salary=" + salary +
		+ '\n';
    }

    public String toStringForFile() {
	String sexText;
	/*if (sex) sexText="male";
	else sexText="female";*/
	sexText = sex ? "male" : "female";
	return "" + sname
		//+ ","+  pname
		+ "," + fname
		+ "," + (sex ? "male" : "female")/*sexText*/
		//"," + tabN 
		//+ "," + position 
		+ "," + dr
		//+ "," + salary
		+ '\n';
    }

    public MyObject(String sname // , String pname
	    ,
	     String fname, boolean sex //, String tabN, String position
	    ,
	     String dr
    //, double salary
    ) {
	this.sname = sname;
	//this.pname = pname;
	this.fname = fname;
	this.sex = sex;
	//this.tabN = tabN;
	//this.position = position;
	this.dr = dr;
	//this.salary = salary;
    }

    public MyObject(Scanner scan, String promptText) {
	System.out.println("\n\n"+promptText);
	System.out.print("Введите фамилию ===>");
	this.sname = scan.nextLine();
	//this.pname = "";
	System.out.print("Введите имя ===>");
	this.fname = scan.nextLine();
	System.out.print("Введите пол (1- муж (по умолчанию), 0 - жен )===> ");
	String sex = scan.nextLine();
	/*if (sex.equals("0")) {
	    this.sex = false;
	} else {
	    this.sex = true;
	}*/
	this.sex= !sex.equals("0");

	/*System.out.print("Введите табельный номер ===>");
	try {
	    String myTab = scan.nextLine();
	    int tab = Integer.parseInt(myTab);
	    if (myTab.length()!=4) this.tabN = "0000";
	    this.tabN = myTab;
	} catch (NumberFormatException numberFormatException) {
	    this.tabN = "0000";
	}*/
	//this.position = "manager";
	//this.dr = "01.01.2019";
	boolean isOK = true;
	do {

	    System.out.print("Введите дату рождения (dd.MM.yyyy)===>");
	    try {
		String myDR = scan.nextLine();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd.MM.yyyy");
		LocalDate myDRdate = LocalDate.parse(myDR, dtf);
		dr = myDR;
		isOK = true;
	    } catch (Exception ex) {
		System.out.println("Дата рождения не допустимая, повторите ввод");
		isOK = false;
	    }
	} while (!isOK);
	//this.salary = 4300.00;
    }

     public MyObject(Scanner scan) {
	System.out.println("\n\nВведите ключевые данные сотрудника");
	System.out.print("Введите фамилию ===>");
	this.sname = scan.nextLine();
	//this.pname = "";
	System.out.print("Введите имя ===>");
	this.fname = scan.nextLine();
	/*System.out.print("Введите пол (1- муж (по умолчанию), 0 - жен )===> ");
	String sex = scan.nextLine();
	if (sex.equals("0")) {
	    this.sex = false;
	} else {
	    this.sex = true;
	}*/
	// this.sex= !sex.equals("0");

	/*System.out.print("Введите табельный номер ===>");
	try {
	    String myTab = scan.nextLine();
	    int tab = Integer.parseInt(myTab);
	    if (myTab.length()!=4) this.tabN = "0000";
	    this.tabN = myTab;
	} catch (NumberFormatExcetion numberFormatException) {
	    this.tabN = "0000";
	}*/
	//this.position = "manager";
	this.dr = "01.01.2019";
	//*boolean isOK = true;
	/*do {

	    System.out.print("Введите дату рождения (dd.MM.yyyy)===>");
	    try {
		String myDR = scan.nextLine();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd.MM.yyyy");
		LocalDate myDRdate = LocalDate.parse(myDR, dtf);
		dr = myDR;
		isOK = true;
	    } catch (Exception ex) {
		System.out.println("Дата рождения не допустимая, повторите ввод");
		isOK = false;
	    }
	} while (!isOK);*/
	//this.salary = 4300.00;
    }
    
    /*public double getSalary() {
	return salary;
    }

    public void setSalary(double salary) {
	this.salary = salary;
    }
     */
    public String getDr() {
	return dr;
    }

    public void setDataS(String dr) {
	this.dr = dr;
    }

    /*
    public String getPosition() {
	return position;
    }

    public void setPosition(String position) {
	this.position = position;
    }

     */
    public boolean isSex() {
	return sex;
    }

    public void setSex(boolean sex) {
	this.sex = sex;
    }

    /*
    public String getTabN() {
	return tabN;
    }

    public void setTabN(String tabN) {
	this.tabN = tabN;
    }
     */
    public String getFname() {
	return fname;
    }

    public void setFname(String fname) {
	this.fname = fname;
    }

    /*
    public String getPname() {
	return pname;
    }

    public void setPname(String pname) {
	this.pname = pname;
    }
     */
    public String getSname() {
	return sname;
    }

    public void setSname(String sname) {
	this.sname = sname;
    }

}


