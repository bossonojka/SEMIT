package main;

import dba.DAEmployee;
import dba.DBConnect;
import java.util.Scanner;
import model.MyObject;

/**
 *
 * @author Dvukhglavov D.E.
 */
public class RunLR3_JDBC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	// PROGRAMM CODE WRITING HERE!!!

	System.out.println("**** Programm JDBC Struct ****");
	Scanner scan = new Scanner(System.in);

	String dbFileName = "departament.db"; //А можно ввести с консоли...
	DBConnect.DBConection(dbFileName);
	MyObject myEmployee;
	long id;
	//Действия с БД
	//Меню!!!
	int choice = 0;
	do {
	    choice = menu(scan); //показ меню и получение выбора пользователя
	    switch (choice) {
		case 1:
		    //SELECT
		    DAEmployee.showAll(DBConnect.getConnection(), "Список сотрудников");
		    break;
		case 2:
		    //SEEK - поиск нужного 
		    System.out.println("Поиск сотрудника");
		    DAEmployee.seek(DBConnect.getConnection(), createEmployeeToSeek(scan));
		    break;
		case 3:
		    //INSERT
		    System.out.println("Добавление сотрудника");
		    myEmployee = new MyObject(scan, "Введите данные нового сотрудника");
		    //System.out.println(myEmployee);
		    DAEmployee.insert(DBConnect.getConnection(), myEmployee);
		    DAEmployee.showAll(DBConnect.getConnection(), "Данные после добавления");
		    break;
		case 4:
		    //UPDATE
		    System.out.println("Обновление данных сотрудника");
		    id = DAEmployee.seek(DBConnect.getConnection(), createEmployeeToSeek(scan));
		    if (id != -1) {
			myEmployee=new MyObject(scan, "Введите данные для обновления");
			DAEmployee.update(DBConnect.getConnection(), id, myEmployee);
			DAEmployee.showAll(DBConnect.getConnection(), "Данные после изменения");
		    } else {
			System.out.println("Такой сотрудник не найден!");
		    }
		    break;
		case 5:
		    //DELETE
		    System.out.println("Удаление данных сотрудника");
		    //Вариант 1
		    id = DAEmployee.seek(DBConnect.getConnection(), createEmployeeToSeek(scan));
		    if (id != -1) {
			DAEmployee.delete(DBConnect.getConnection(), id);
			DAEmployee.showAll(DBConnect.getConnection(), "Список после удаления");
		    } else {
			System.out.println("Такой сотрудник не найден!");
		    }
		    //Вариант 2
		    // DAEmployee.delete(DBConnect.getConnection(), createEmployeeToSeek(scan));
		    break;

		case 0:
		    System.out.println("\n");
		    break;
		default:
		    System.out.println("Неправильный выбор");
	    }

	} while (choice != 0); //
	//Завершение работы
	DBConnect.DBClose();
	scan.close();
	System.out.println("**** THE END ****");
    }

    public static int menu(Scanner scan) {
	//Метод, который реализует вывод меню и считываение выбора
	int choice = 0; //0 - выход
	//Вывод пунктов меню
	System.out.println("\n\n***** MENU *****");
	System.out.println("1. Вывод всех записей");
	System.out.println("2. Поиск");
	System.out.println("3. Вставка");
	System.out.println("4. Обновление");
	System.out.println("5. Удаление");
	System.out.println("0. Выход");
	System.out.print("***** Сделайте выбор ====>>>");
	choice = Integer.parseInt(scan.nextLine());
	System.out.println();
	//Считывание выбора с контролем ввода

	return choice;
    }

    static private MyObject createEmployeeToSeek(Scanner scan) {
	return new MyObject(scan);

    }

}
