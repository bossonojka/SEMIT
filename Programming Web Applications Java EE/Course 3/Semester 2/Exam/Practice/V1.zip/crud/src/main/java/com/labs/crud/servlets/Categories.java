package com.labs.crud.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.labs.crud.classes.Category;

/**
 * Servlet implementation class Categories
 */
public class Categories extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private List<Category> categories;
	private Connection con = null;
	private PreparedStatement stmt = null;
       
    public Categories() {
        super();
        
    }
    
    public void init(){
    	final Object categories = getServletContext().getAttribute("categories");
    	
    	if (categories == null || !(categories instanceof CopyOnWriteArrayList)) {
    		throw new IllegalStateException();
    	} else {
    		this.categories = (CopyOnWriteArrayList<Category>) categories;
    	}
    	con = (Connection) getServletContext().getAttribute("con");
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		request.setAttribute("categories", categories);
		request.getRequestDispatcher("categories.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("product") != null) {
//			String category = request.getParameter("category");
//			List<Product> categories = new CopyOnWriteArrayList<Category>();
//			
//			for (Category c : this.categories) {
//				if(c.get.equals(category)) {
//					categories.add(c);
//				}
//			}
//			request.setAttribute("products", products);
//			request.getRequestDispatcher("/products.jsp").forward(request, response);
		}
	}
}
