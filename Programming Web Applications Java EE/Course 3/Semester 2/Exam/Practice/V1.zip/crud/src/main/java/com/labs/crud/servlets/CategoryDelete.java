package com.labs.crud.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.labs.crud.classes.Category;

/**
 * Servlet implementation class CategoryDelete
 */
public class CategoryDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public CategoryDelete() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("category") != "") {
			int categoryId = Integer.parseInt(request.getParameter("category"));
			
			List<Category> categories = (CopyOnWriteArrayList<Category>) getServletContext().getAttribute("categories");
			
			for (Category c : categories) {
				if (c.getId() == categoryId) {
					c.delete();
					categories.remove(c);			
				}
			}
		}
		response.sendRedirect("Categories");
	}
}
