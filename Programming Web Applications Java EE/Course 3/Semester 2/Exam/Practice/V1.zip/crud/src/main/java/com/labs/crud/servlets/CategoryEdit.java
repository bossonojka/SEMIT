package com.labs.crud.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.labs.crud.classes.Category;

/**
 * Servlet implementation class CategoryEdit
 */
public class CategoryEdit extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection con = null;
	private Statement stmt = null;

    public CategoryEdit() {
        super();
    }
    
    public void init() {
    	con = (Connection) getServletContext().getAttribute("con");
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("category") != "") {
			int categoryId = Integer.parseInt(request.getParameter("category"));
			
			List<Category> categories = (CopyOnWriteArrayList<Category>) getServletContext().getAttribute("categories");
			
			for (Category c : categories) {
				if (c.getId() == categoryId) {
					request.setAttribute("category", c);
				}
			}
			request.setAttribute("categories", categories);
			request.getRequestDispatcher("categories.jsp").forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("catName") != "" && request.getParameter("catCode") != "") {
			int categoryId = Integer.parseInt(request.getParameter("category"));
			String catName = request.getParameter("catName");
			int catCode = Integer.parseInt(request.getParameter("catCode"));
			
			List<Category> categories = (CopyOnWriteArrayList<Category>) getServletContext().getAttribute("categories");
			
			for (Category c : categories) {
				if (c.getId() == categoryId) {
					c.setCatName(catName);
					c.setCatCode(catCode);
					c.edit();
				}
			}
		}
		response.sendRedirect("./Categories");
	}

}
