package com.labs.crud.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.labs.crud.classes.Category;

/**
 * Servlet implementation class CategoryCreate
 */
public class CategoryCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private List<Category> categories;
	private AtomicInteger id;
	private Connection con = null;
       
    public CategoryCreate() {
        super();
    }
    
    public void init() {
    	final Object categories = getServletContext().getAttribute("categories");
    	
    	if (categories == null || !(categories instanceof CopyOnWriteArrayList)) {
    		throw new IllegalStateException();
    	} else {
    		this.categories = (CopyOnWriteArrayList<Category>) categories;
    	}
    	if (!this.categories.isEmpty()) {
    		this.id = new AtomicInteger(this.categories.get(this.categories.size() - 1).getId() + 1);
    	} else {
    		this.id = new AtomicInteger(1);
    	}
    	
    	con = (Connection) getServletContext().getAttribute("con");
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("Categories");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("catName") != "" && request.getParameter("catCode") != "") {
			int id = this.id.getAndIncrement();
			String catName = request.getParameter("catName");
			int catCode = Integer.parseInt(request.getParameter("catCode"));
			
			Category category = new Category(id, catName, catCode);
			boolean result = category.create() ? categories.add(category) : false;
		}
		response.sendRedirect("Categories");
	}
}
