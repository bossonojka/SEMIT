package com.labs.crud.classes;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Set;

public class Category {
	private int id;
	private String catName;
	private int catCode;

	public static Connection con;
	
	public Category() {
		
	}
	
	public Category(int id, String catName, int catCode) {
		this.catCode = catCode;
		this.id = id;
		this.catName = catName;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getCatName() {
		return catName;
	}
	public void setCatName(String catName) {
		this.catName = catName;
	}
	
	public int getCatCode() {
		return catCode;
	}
	public void setCatCode(int catCode) {
		this.catCode = catCode;
	}
	
	public boolean create(){
		String sql = "insert into CATEGORY values('"+this.getId()+"', '"+this.getCatName()+"', '"+this.getCatCode()+"')";
		
		Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean delete(){
		String sql = "delete from CATEGORY where \"ID_CATAGORY\"='"+this.getId()+"';";
		
		Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean edit(){
		String sql = "update CATEGORY set \"CAT_NAME\"='"+this.getCatName()+"', \"CAT_CODE\"='"+this.getCatCode()+"' where \"ID_CATAGORY\"='"+this.getId()+"';";

		Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}
