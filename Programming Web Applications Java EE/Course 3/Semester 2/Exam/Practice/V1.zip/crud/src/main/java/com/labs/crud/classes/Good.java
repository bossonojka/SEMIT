package com.labs.crud.classes;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class Good implements Comparable<Good>{
	private int id;
	private String goodName;
	private String producer;
	private double price;
	
	private Category category;
	
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	
	public Good(int id, String goodName, String producer, double price, Category category) {
		super();
		this.id = id;
		this.goodName = goodName;
		this.producer = producer;
		this.price = price;
		this.category = category;
	}
	
	public static Connection con;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public String getGoodName() {
		return goodName;
	}
	public void setGoodName(String goodName) {
		this.goodName = goodName;
	}

	public String getProducer() {
		return producer;
	}
	public void setProducer(String producer) {
		this.producer = producer;
	}

	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	public boolean create(){
		String sql = "insert into GOODS values('"+this.getId()+"', '"+this.getGoodName()+"', '"+this.getProducer()+"', '"+this.getPrice()+"', '"+this.getCategory().getId()+"')";
		
		Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean delete(){
		String sql = "delete from GOODS where \"ID_GOOD\"='"+this.getId()+"';";
		
		Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean edit(){
		String sql = "update GOODS set \"GOOD_NAIM\"='"+this.getGoodName()+"', \"PRODUCER\"='"+this.getProducer()+"', \"PRICE\"='"+this.getPrice()+"', \"ID_CATEGORY\"='"+this.getCategory().getId()+"' where \"ID_GOOD\"='"+this.getId()+"';";

		Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	@Override
	public int compareTo(Good arg0) {
		int res = this.producer.compareTo(arg0.producer);
		if (res != 0) {
			return res;
		} else {
			return this.goodName.compareTo(arg0.goodName);
		}
	}
}
