package com.labs.crud.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.labs.crud.classes.Category;
import com.labs.crud.classes.Good;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Servlet implementation class GoodEdit
 */
public class GoodEdit extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private List<Good> goods;
    /**
     * @see HttpServlet#HttpServlet()
     */
	public GoodEdit() {
        super();
    }
	
	public void init() {
    	final Object goods = getServletContext().getAttribute("goods");
    	
    	if (goods == null || !(goods instanceof CopyOnWriteArrayList)) {
    		throw new IllegalStateException();
    	} else {
    		this.goods = (CopyOnWriteArrayList<Good>) goods;
    	}
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("good") != "") {
			int goodId = Integer.parseInt(request.getParameter("good"));
			
			List<Good> goods = (CopyOnWriteArrayList<Good>) getServletContext().getAttribute("goods");
			
			for (Good g : goods) {
				if (g.getId() == goodId) {
					request.setAttribute("good", g);
				}
			}
			request.setAttribute("goods", goods);
			request.getRequestDispatcher("goods.jsp").forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("goodName") != "" && request.getParameter("producer") != "" && request.getParameter("price") != "" && request.getParameter("category") != "") {
			int goodId = Integer.parseInt(request.getParameter("good"));
			String goodName = request.getParameter("goodName");
			String producer = request.getParameter("producer");
			double price = Double.parseDouble(request.getParameter("price"));
			int categoryId = Integer.parseInt(request.getParameter("category"));
			
			List<Category> categories = (CopyOnWriteArrayList<Category>) getServletContext().getAttribute("categories");
			
			Category category = null;
			for (Category c : categories) {
				if (c.getId() == categoryId) {
					category = c;
				}
			}
			
			for (Good g : goods) {
				if (g.getId() == goodId) {
					g.setCategory(category);
					g.setGoodName(goodName);
					g.setPrice(price);
					g.setProducer(producer);
					g.edit();
				}
			}
		}
		response.sendRedirect("Goods");
	}

}
