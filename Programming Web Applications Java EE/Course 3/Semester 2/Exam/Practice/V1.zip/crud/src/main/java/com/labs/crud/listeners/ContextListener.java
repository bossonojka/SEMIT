package com.labs.crud.listeners;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.labs.crud.classes.Category;
import com.labs.crud.classes.Good;
import com.labs.crud.util.SqlRepository;

public class ContextListener implements ServletContextListener {

	public void contextInitialized(ServletContextEvent sce) {
		final ServletContext ctx = sce.getServletContext();
		
		try {
			Class.forName("org.sqlite.JDBC");
			Connection con = DriverManager.getConnection("jdbc:sqlite:C:\\Users\\arsen\\Desktop\\Exam_JAVA_v1.db");
			
			Good.con = Category.con = con;
			//Product.con = Provider.con = Order.con = con;
			SqlRepository repo = new SqlRepository(con);
			
			ctx.setAttribute("categories", repo.getCategories());
			ctx.setAttribute("goods", repo.getGoods());
			
			ctx.setAttribute("con", con);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void contextDestroyed(ServletContextEvent sce) {
		
	}
}
