package com.labs.crud.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.labs.crud.classes.Good;

/**
 * Servlet implementation class Goods
 */
public class Goods extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private List<Good> goods;
	private Connection con = null;
	private PreparedStatement stmt = null;
       
    public Goods() {
        super();
        
    }
    
    public void init(){
    	final Object goods = getServletContext().getAttribute("goods");
    	
    	if (goods == null || !(goods instanceof CopyOnWriteArrayList)) {
    		throw new IllegalStateException();
    	} else {
    		this.goods = (CopyOnWriteArrayList<Good>) goods;
    	}
    	con = (Connection) getServletContext().getAttribute("con");
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		Collections.sort(goods);
		request.setAttribute("goods", goods);
		request.getRequestDispatcher("goods.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("category") != "") {
			String category = request.getParameter("category");
			List<Good> goods = new CopyOnWriteArrayList<Good>();
			
			for (Good g : this.goods) {
				if(g.getCategory().getCatName().equals(category)) {
					goods.add(g);
				}
			}
			request.setAttribute("goods", goods);
			request.getRequestDispatcher("goods.jsp").forward(request, response);
		}	
	}
}
