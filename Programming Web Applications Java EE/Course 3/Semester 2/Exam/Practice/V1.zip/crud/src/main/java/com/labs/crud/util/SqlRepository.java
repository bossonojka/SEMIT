package com.labs.crud.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletContext;

import com.labs.crud.classes.Category;
import com.labs.crud.classes.Good;

public class SqlRepository {
	private Connection con;
	
	private List<Category> categories = new CopyOnWriteArrayList<Category>();
	private List<Good> goods = new CopyOnWriteArrayList<Good>();
	
	public SqlRepository(Connection con) {
		this.con = con;
	}
	
	public List<Category> getCategories() throws SQLException {
		PreparedStatement stmt = null;
		
		String sql = "select * from CATEGORY";
		stmt = this.con.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();
		
		while(rs.next()) {
			this.categories.add(new Category(Integer.parseInt(rs.getString("ID_CATAGORY")), rs.getString("CAT_NAME"), Integer.parseInt(rs.getString("CAT_CODE"))));
		}
		
		rs.close();
		stmt.close();
		
		return this.categories;
	}

	public List<Good> getGoods() throws SQLException {
		PreparedStatement stmt = null;
		
		String sql = "select * from GOODS";
		stmt = con.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();
		
		while(rs.next()) {
			Category category = null;
			
			for (Category cat : this.categories) {
				if (Integer.parseInt(rs.getString("ID_CATEGORY")) == (cat.getId())) {
					category = cat;
				}
			}
			
			if (category != null) {
				this.goods.add(new Good(Integer.parseInt(rs.getString("ID_GOOD")), rs.getString("GOOD_NAIM"),rs.getString("PRODUCER"),Double.parseDouble(rs.getString("PRICE")), category));
			}
		}
		
		rs.close();
		stmt.close();
		
		return this.goods;
	}
	
//	public List<Order> getOrders() throws SQLException {
//		PreparedStatement stmt = null;
//		
//		String sql = "select * from orders";
//		stmt = con.prepareStatement(sql);
//		ResultSet rs = stmt.executeQuery();
//		
//		while(rs.next()) {
//			Product product = null;
//			Provider provider = null;
//			
//			for (Product prod : this.products) {
//				if (Integer.parseInt(rs.getString("productId")) == (prod.getId())) {
//					product = prod;
//				}
//			}
//			
//			for (Provider prov : this.providers) {
//				if (Integer.parseInt(rs.getString("providerId")) == (prov.getId())) {
//					provider = prov;
//				}
//			}
//			
//			if (product != null && provider != null) {
//				this.orders.add(new Order(Integer.parseInt(rs.getString("id")), product, provider, Integer.parseInt(rs.getString("quantity"))));
//			}
//		}
//		
//		rs.close();
//		stmt.close();
//		
//		return this.orders;
//	}
}
