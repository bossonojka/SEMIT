package com.labs.crud.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.labs.crud.classes.Category;
import com.labs.crud.classes.Good;

/**
 * Servlet implementation class GoodDelete
 */
public class GoodDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	public GoodDelete() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("Goods");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("good") != "") {
			int goodId = Integer.parseInt(request.getParameter("good"));
			
			List<Good> goods = (CopyOnWriteArrayList<Good>) getServletContext().getAttribute("goods");
			
			for (Good g : goods) {
				if (g.getId() == goodId) {
					g.delete();
					goods.remove(g);		
				}
			}
		}
		response.sendRedirect("Goods");
	}

}
