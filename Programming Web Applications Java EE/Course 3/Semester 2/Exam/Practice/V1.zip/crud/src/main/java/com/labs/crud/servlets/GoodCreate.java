package com.labs.crud.servlets;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.labs.crud.classes.Category;
import com.labs.crud.classes.Good;
import com.labs.crud.util.Validation;

/**
 * Servlet implementation class GoodCreate
 */
public class GoodCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private List<Good> goods;
	private AtomicInteger id;
       
    public GoodCreate() {
        super();
    }
    
    public void init() {
    	final Object goods = getServletContext().getAttribute("goods");
    	
    	if (goods == null || !(goods instanceof CopyOnWriteArrayList)) {
    		throw new IllegalStateException();
    	} else {
    		this.goods = (CopyOnWriteArrayList<Good>) goods;
    	}
    	if (!this.goods.isEmpty()) {
    		this.id = new AtomicInteger(this.goods.get(this.goods.size() - 1).getId() + 1);
    	} else {
    		this.id = new AtomicInteger(1);
    	}
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("./");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("goodName") != "" && request.getParameter("producer") != "" && request.getParameter("price") != "" && request.getParameter("category") != "") {
			int id = this.id.getAndIncrement();
			String goodName = request.getParameter("goodName");
			String producer = request.getParameter("producer");
			double price = Double.parseDouble(request.getParameter("price"));
			int categoryId = Integer.parseInt(request.getParameter("category"));
			
			List<Category> categories = (CopyOnWriteArrayList<Category>) getServletContext().getAttribute("categories");
			
			Category category = null;
			for (Category c : categories) {
				if (c.getId() == categoryId) {
					category = c;
				}
			}
			
			Good good = new Good(id, goodName, producer, price, category);
			boolean result = good.create() ? goods.add(good) : false;
		}
		response.sendRedirect("./Goods");
	}

}
