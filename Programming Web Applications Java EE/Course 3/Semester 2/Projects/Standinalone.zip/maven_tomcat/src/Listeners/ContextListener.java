package Listeners;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import models.DbOperations;
import models.HibernateHelper;
import Servlets.*;

@WebListener
public class ContextListener implements ServletContextListener{
	
	@Override
	public void contextInitialized(ServletContextEvent event) {
		DbOperations hibernateHelper = new HibernateHelper();
		
		System.out.println("Injecting hibernateHelper to servlets");
		DeleteElementServlet.setDbHelper(hibernateHelper);
		ElementCreateUpdate.setDbHelper(hibernateHelper);
		ListElementsServlet.setDbHelper(hibernateHelper);
		LoginServlet.setDbHelper(hibernateHelper);
		RegisterServlet.setDbHelper(hibernateHelper);
		DeleteProductServlet.setDbHelper(hibernateHelper);
		ListProductsServlet.setDbHelper(hibernateHelper);
		ProductCreateEditServlet.setDbHelper(hibernateHelper);
		ListGroupsServlet.setDbHelper(hibernateHelper);
		GroupCreateUpdate.setDbHelper(hibernateHelper);
		DeleteGroupServlet.setDbHelper(hibernateHelper);
		SearchGroupsServlet.setDbHelper(hibernateHelper);
		SearchProductsServlet.setDbHelper(hibernateHelper);
		SendMailServlet.setDbHelper(hibernateHelper);
		
		event.getServletContext().setAttribute("allgroups", hibernateHelper.getGroups());
	}

}
