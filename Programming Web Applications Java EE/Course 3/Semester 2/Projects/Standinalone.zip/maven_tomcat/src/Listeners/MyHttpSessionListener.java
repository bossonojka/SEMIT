package Listeners;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

@WebListener
public class MyHttpSessionListener implements HttpSessionListener {
	  public void sessionCreated(HttpSessionEvent event){
	      event.getSession().setMaxInactiveInterval(2*60); // in seconds
	  }
}
