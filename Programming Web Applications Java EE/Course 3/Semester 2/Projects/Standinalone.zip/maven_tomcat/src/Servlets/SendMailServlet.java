package Servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.mail.Address;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.persistence.EntityNotFoundException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import models.*;

@WebServlet("/SendMail")
public class SendMailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static DbOperations dbHelper = null;
	private Product product = null;
	private Element element = null;
	private Group group = null;
	
	private List<Product> products = null;
	private List<Element> elements = null;
	private List<Group> groups = null;
	private List<byte[]> xmls = new ArrayList<>();
    
	public static void setDbHelper(DbOperations DbHelper) {
		dbHelper = DbHelper;
	}
	
    public SendMailServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		
		List<Object> objects = new ArrayList<>(Arrays.asList(
				dbHelper.getElements().stream().map(el -> el.toString() + " - Микронутриент").collect(Collectors.toList()),
				dbHelper.getProducts().stream().map(el -> el.toString() + " - Продукт").collect(Collectors.toList()),
				dbHelper.getGroups().stream().map(el -> el.toString() + " - Категория").collect(Collectors.toList())));
		request.setAttribute("objects", objects);
		
		
		
		request.getRequestDispatcher("WEB-INF/Views/Mail/SendMail.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		xmls.clear();
		
		String subject = request.getParameter("subject");
		String[] objects = request.getParameterValues("objects");
		String text = request.getParameter("text");
		String[] usernames = request.getParameterValues("username");
		
		if (usernames != null && objects != null) {
					for (int j = 0; j < objects.length; j++) { // Loop through each object selected by user
						String object = objects[j].split(" - ")[0];
						String type = objects[j].split(" - ")[1];
						try {
							switch(type) {
								case "Продукт":
										product = dbHelper.getProducts().stream().filter(el -> el.getName().equals(object)).findFirst().get();
										xmls.add(XMLHelper.writeObject(product));
										break;
								case "Микронутриент":
										element = dbHelper.getElements().stream().filter(el -> el.getName().equals(object)).findFirst().get();
										xmls.add(XMLHelper.writeObject(element));
										break;
								case "Категория":
										group = dbHelper.getGroups().stream().filter(el -> el.getName().equals(object)).findFirst().get();
										xmls.add(XMLHelper.writeObject(group));
										break;
								case "Продукты":
										products = dbHelper.getProducts();
										xmls.add(XMLHelper.writeObject(products));
										break;
								case "Микронутриенты":
										elements = dbHelper.getElements();
										xmls.add(XMLHelper.writeObject(elements));
										break;
								case "Категории":
										groups = dbHelper.getGroups();
										xmls.add(XMLHelper.writeObject(groups));
										break;
								default:
									break;
							}
							
						}
						catch(EntityNotFoundException ex) {
							ex.printStackTrace();
						}; 
					}
					try {
						String username = "";
						Address[] addresses = new Address[usernames.length];
						for (int i = 0; i < usernames.length; i++) {
							addresses[i] = new InternetAddress(usernames[i]);
						}
						if (request.getSession().getAttribute("CURRENT_USER") != null) {
							username = ((User) request.getSession().getAttribute("CURRENT_USER")).getEmail();
						}
						Mailer.sendMail(addresses, text, subject, xmls, objects, username);
					} catch (MessagingException e) {
						e.printStackTrace();
					}
		}
		response.sendRedirect(request.getContextPath() + "/SendMail");
	}

}
