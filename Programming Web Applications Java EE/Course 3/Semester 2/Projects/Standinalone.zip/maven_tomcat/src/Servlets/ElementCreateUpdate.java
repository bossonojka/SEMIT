package Servlets;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

import models.DbOperations;
import models.Element;
import models.Product;

/**
 * Servlet implementation class ElementCreateUpdate
 */
@WebServlet("/CreateUpdateElement")
public class ElementCreateUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static DbOperations dbHelper = null;
       
	public static void setDbHelper(DbOperations DbHelper) {
		dbHelper = DbHelper;
	}
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ElementCreateUpdate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		if (request.getParameter("id") == null) {
			request.setAttribute("products", dbHelper.getProducts());
			request.getRequestDispatcher("WEB-INF/Views/Element/CreateEditElement.jsp").forward(request, response);
		}
		else {
			try {
				// Edit logic
				int id = Integer.parseInt(request.getParameter("id"));
				Element element = dbHelper.getElements().stream().filter(el -> el.getId() == id).findFirst().get();
				if (element != null) {
					request.setAttribute("element", element);
					request.setAttribute("products", dbHelper.getProducts());
					request.setAttribute("elementProducts", element.getProducts());
					request.getRequestDispatcher("WEB-INF/Views/Element/CreateEditElement.jsp").forward(request, response);
				}
			}
			catch (NoSuchElementException | NumberFormatException  ex){
				request.setAttribute("ErrorMessage", "Неверный формат id");
				request.getRequestDispatcher("WEB-INF/Views/Shared/Error.jsp").forward(request, response);
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		request.setAttribute("Errors", new ArrayList<String>());
		try {
			Element element = new Element();
			element.setName(request.getParameter("name"));
			
			if (request.getParameter("id") == null) {
				if (dbHelper.getElements().stream().filter(el -> el.getName().equals(element.getName())).count() > 0 ){
					List<String> errors = (List<String>) request.getAttribute("Errors");
					errors.add("Элемент уже существует");
					request.setAttribute("Errors", errors);
					throw new IOException();
				}
			}
			else {
				element.setId(Integer.parseInt(request.getParameter("id")));
			}
			if (request.getParameter("id") == null || request.getParameter("id").isEmpty() )
				dbHelper.addElement(element);
			else
				dbHelper.updateElement(element);
			
//			List<ElementProduct> list = dbHelper.getElementProducts().stream().filter(el -> !el.getElement().getId().equals(element.getId())).collect(Collectors.toList());
//			dbHelper.updateElementProducts(list);
			
			String[] checkedIds = request.getParameterValues("products");
			if (checkedIds != null) {
				for (int i = 0; i < checkedIds.length; i++) {
						String id = checkedIds[i];
						Product product = dbHelper.getProducts().stream().filter(el -> el.getId() == Integer.parseInt(id)).findFirst().get();
						if (product != null) {
							element.getProducts().add(product);
							product.getElements().add(element);
							dbHelper.updateProduct(product);
//							dbHelper.addElementProduct(new ElementProduct(product, element));
						}
				}
				dbHelper.updateElement(element);
			}
			
			response.sendRedirect("Elements");
		}
		catch(IOException | NumberFormatException ex) {
			ex.printStackTrace();
			request.setAttribute("ErrorMessage", "Заполните поля");
			request.setAttribute("products", dbHelper.getProducts());
			request.getRequestDispatcher("WEB-INF/Views/Element/CreateEditElement.jsp").forward(request, response);
			
		}
	}

}
