package Servlets;

import java.io.IOException;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import models.DbOperations;

/**
 * Servlet implementation class SearchServlet
 */
@WebServlet("/SearchProducts")
public class SearchProductsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static DbOperations dbHelper = null;
    
	public static void setDbHelper(DbOperations DbHelper) {
		dbHelper = DbHelper;
	}
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchProductsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String text_to_find = request.getParameter("text_to_find");
		
		request.setAttribute("products", dbHelper.findProductsByText(text_to_find));
		request.getRequestDispatcher("WEB-INF/Views/Product/ListProducts.jsp").forward(request, response);
		doGet(request, response);
	}

}
