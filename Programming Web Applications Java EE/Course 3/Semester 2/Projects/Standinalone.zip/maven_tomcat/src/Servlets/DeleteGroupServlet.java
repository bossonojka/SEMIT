package Servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import models.DbOperations;

@WebServlet("/DeleteGroup")
public class DeleteGroupServlet extends HttpServlet{
	private static DbOperations dbHelper = null;
    
	public static void setDbHelper(DbOperations DbHelper) {
		dbHelper = DbHelper;
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		dbHelper.deleteGroup(id);
		getServletContext().setAttribute("allgroups", dbHelper.getGroups());
	}
}
