package Servlets;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

import models.DbOperations;
import models.Element;
import models.Product;

/**
 * Servlet implementation class ProductCreateServlet
 */
@WebServlet("/CreateUpdateProduct")
@MultipartConfig(fileSizeThreshold = 1024 * 1024,
maxFileSize = 1024 * 1024 * 5, 
maxRequestSize = 1024 * 1024 * 5 * 5)
public class ProductCreateEditServlet extends HttpServlet {
	private static DbOperations dbHelper = null;
    
	public static void setDbHelper(DbOperations DbHelper) {
		dbHelper = DbHelper;
	}
	private ServletFileUpload uploader = null;

	@Override
	public void init() throws ServletException{
		DiskFileItemFactory fileFactory = new DiskFileItemFactory();
		File filesDir = new File("images");
		fileFactory.setRepository(filesDir);
		this.uploader = new ServletFileUpload(fileFactory);
	}
	
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductCreateEditServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html; charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		if (request.getParameter("id") == null) {
			//Product product = new Product();
			request.setAttribute("elements", dbHelper.getElements());
			request.getRequestDispatcher("WEB-INF/Views/Product/CreateEditProduct.jsp").forward(request, response);
		}
		else {
			try {
				// Edit logic
				int id = Integer.parseInt(request.getParameter("id"));
				Product product = dbHelper.getProducts().stream().filter(el -> el.getId() == id).findFirst().get();
//				Product product = dbHelper.getProduct(id);
				if (product != null) {
					request.setAttribute("product", product);
					request.setAttribute("elements", dbHelper.getElements());
					
					
					List<Element> elements = dbHelper.getElements();
//					List<Element> elementProducts = dbHelper.getElementsByProductId(product.getId());
					
					request.setAttribute("elementProducts", product.getElements());
					request.getRequestDispatcher("WEB-INF/Views/Product/CreateEditProduct.jsp").forward(request, response);
				}
			}
			catch (NoSuchElementException | NumberFormatException  ex){
				request.setAttribute("ErrorMessage", "Неверный формат id");
				request.getRequestDispatcher("WEB-INF/Views/Shared/Error.jsp").forward(request, response);
			}
		}
		
	}
	private static String transliterate(String message){
	    char[] abcCyr =   {' ','а','б','в','г','д','е','ё', 'ж','з','и','й','к','л','м','н','о','п','р','с','т','у','ф','х', 'ц','ч', 'ш','щ','ъ','ы','ь','э', 'ю','я','А','Б','В','Г','Д','Е','Ё', 'Ж','З','И','Й','К','Л','М','Н','О','П','Р','С','Т','У','Ф','Х', 'Ц', 'Ч','Ш', 'Щ','Ъ','Ы','Ь','Э','Ю','Я','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
	    String[] abcLat = {"_","a","b","v","g","d","e","e","zh","z","i","y","k","l","m","n","o","p","r","s","t","u","f","h","ts","ch","sh","sch", "","i", "","e","ju","ja","A","B","V","G","D","E","E","Zh","Z","I","Y","K","L","M","N","O","P","R","S","T","U","F","H","Ts","Ch","Sh","Sch", "","I", "","E","Ju","Ja","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
	    StringBuilder builder = new StringBuilder();
	    for (int i = 0; i < message.length(); i++) {
	    	int x = 0;
	        for (; x < abcCyr.length; x++ ) {
	            if (message.charAt(i) == abcCyr[x]) {
	                builder.append(abcLat[x]);
	            }
	            if (x == abcCyr.length) {
	            	builder.append(message.charAt(i));
	            }
	        }
	    }
	    return builder.toString();
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");		
		try {
			Product product = new Product();
			product.setName(request.getParameter("name"));
			product.setProteins(Double.parseDouble(request.getParameter("proteins")));
			product.setFats(Double.parseDouble(request.getParameter("fats")));
			product.setCarbohydrates(Double.parseDouble(request.getParameter("carbohydrates")));

			if (request.getParameter("id") != null) {
				product.setId(Integer.parseInt(request.getParameter("id")));
				Product updating_product = dbHelper.getProducts().stream().filter(el -> el.getId() == Integer.parseInt(request.getParameter("id"))).findFirst().get();
				
				
				List<Element> elements = dbHelper.getElements();
				for (Element element : elements) {
					element.getProducts().removeIf(el -> el.getId() == product.getId());
					updating_product.getElements().removeIf(el -> el.getId() == element.getId());
					dbHelper.updateElement(element);
					dbHelper.updateProduct(updating_product);
				}
				
				product.getElements().clear();
				product.setEng_name(updating_product.getEng_name());
			}

			Part filePart = request.getPart("picture");
			
			if (request.getParameter("id") == null || !filePart.getSubmittedFileName().isEmpty()) {
				String extension = filePart.getSubmittedFileName().split("\\.")[1];
				product.setEng_name(transliterate(request.getParameter("name")) + "." + extension);
				if(!ServletFileUpload.isMultipartContent(request)){
					throw new ServletException("Content type is not multipart/form-data");
				}
				ServletContext application = getServletContext();
				
				String uploadPath = application.getRealPath("images/");
				System.out.println(uploadPath);
				
				File uploadDir = new File(uploadPath);
				if (!uploadDir.exists()) {
					System.out.println(uploadDir.mkdir());
				}
				
				InputStream fileInputStream = filePart.getInputStream();
				File fileToSave = new File(uploadPath + product.getEng_name());
				Files.copy(fileInputStream, fileToSave.toPath(), StandardCopyOption.REPLACE_EXISTING);

			}
			
			
			
			
			if (request.getParameter("id") == null || request.getParameter("id").isEmpty() )
				dbHelper.addProduct(product);
			else
				dbHelper.updateProduct(product);
			
			String[] checkedIds = request.getParameterValues("elements");
			product.getElements().clear();
			
			if (checkedIds != null) {
				for (int i = 0; i < checkedIds.length; i++) {
						String checked_id = checkedIds[i];
						Element element = dbHelper.getElements().stream().filter(el -> el.getId() == Integer.parseInt(checked_id)).findFirst().get();
						if (element != null) {
							product.getElements().add(element);
							element.getProducts().add(product);
							dbHelper.updateElement(element);
						}
				}
				dbHelper.updateProduct(product);
			}
			
			response.sendRedirect("Products");
		}
		catch(ServletException | IOException | NumberFormatException ex) {
			ex.printStackTrace();
			request.setAttribute("ErrorMessage", "Заполните поля");
			request.setAttribute("elements", dbHelper.getElements());
			request.getRequestDispatcher("WEB-INF/Views/Product/CreateEditProduct.jsp").forward(request, response);
			
		}
		
		

	}

}
