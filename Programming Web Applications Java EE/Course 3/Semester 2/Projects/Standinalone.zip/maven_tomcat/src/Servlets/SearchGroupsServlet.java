package Servlets;

import java.io.IOException;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import models.DbOperations;

@WebServlet("/SearchGroups")
public class SearchGroupsServlet extends HttpServlet{
	private static DbOperations dbHelper = null;
    
	public static void setDbHelper(DbOperations DbHelper) {
		dbHelper = DbHelper;
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String text_to_find = request.getParameter("text_to_find");
		
		request.setAttribute("groups", dbHelper.findGroupsByText(text_to_find));
		request.getRequestDispatcher("WEB-INF/Views/Group/ListGroups.jsp").forward(request, response);
		doGet(request, response);
	}
}
