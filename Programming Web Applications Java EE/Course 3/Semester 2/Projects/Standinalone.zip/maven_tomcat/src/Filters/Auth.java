package Filters;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import models.User;

/**
 * Servlet Filter implementation class Auth
 */
//@WebFilter(servletNames = {"ListElementsServlet"})
@WebFilter(urlPatterns = {"/Elements", "/Products", "/CreateUpdateElement", 
		"/CreateUpdateProduct", "/DeleteElement", "/DeleteProduct", "/SendMail",
		"/CreateUpdateGroup", "/Groups", "/DeleteGroup"} )
//@WebFilter()
public class Auth implements Filter {

    /**
     * Default constructor. 
     */
    public Auth() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
		resp.setContentType("text/html; charset=UTF-8");
	    PrintWriter out=resp.getWriter();  

    	HttpServletRequest httpReq = (HttpServletRequest) req;
    	User user = (User) httpReq.getSession().getAttribute("CURRENT_USER");  
	    if(user != null){  
	    	chain.doFilter(req, resp);//sends request to next resource  
	    }  
	    else{  
	    	HttpServletResponse httpResp = (HttpServletResponse) resp;
	    	httpResp.sendRedirect("Login");
			//req.getRequestDispatcher("WEB-INF/Views/Account/Login.jsp").forward(req, resp); 
	    }  
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
