package models;

import java.util.List;

public interface DbOperations {
	
	public Element updateElement(Element element);
	
	public Element deleteElement(int id);
	
	public List<Element> getElements();
	
	public Element addElement(Element element);
	
	public Product updateProduct(Product product);
	
	public Product deleteProduct(int id);
	
	public List<Product> getProducts();
	
	public Product addProduct(Product product);
	
	public List<User> getUsers();
	
	public User addUser(User user);

	public List<Group> getGroups();

	public void addGroup(Group group);

	public void updateGroup(Group group);

	public void deleteGroup(int id);

	public List<Product> getProductsByGroupId(String parameter);

	public List<Product> getProductsByGroupName(String parameter);

	public List<Group> findGroupsByText(String text);

	public List<Product> findProductsByText(String text_to_find);	
}
