package models;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;
import java.util.stream.Collectors;

public class XMLHelper{

	public static ByteArrayOutputStream bos = null;
	
	public static FileOutputStream fos;
	public static FileInputStream fis;
	public static XMLEncoder encoder;
	public static XMLDecoder decoder;
	
	public static byte[] writeObject(Object object) {
		bos = new ByteArrayOutputStream();
		try {
			//fos = new FileOutputStream(new File(path));
			//encoder = new XMLEncoder(fos);			
			encoder = new XMLEncoder(new BufferedOutputStream(bos));			
			encoder.writeObject(object);
			encoder.close();
			//fos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bos.toByteArray();
	}
	
	public static Object readObject(String path) {
		try {
			fis = new FileInputStream(new File(path));
			decoder = new XMLDecoder(fis);
			
			Object obj = decoder.readObject();
			decoder.close();
			fis.close();
			return obj;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
