package models;



import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity (name = "Elements")
public class Element {

	public String Name;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO )
	public int id;
	@ManyToMany
	private Collection<Product> products = new ArrayList<>();
	public Collection<Product> getProducts() {
		return products;
	}
	public void setProducts(Collection<Product> products) {
		this.products = products;
	}
	public Element() {}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Element(int id, String Name) {
		this.id = id;
		this.Name = Name;
	}
	
	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	@Override
	public String toString() {
		return this.getName();
	}
	
}
