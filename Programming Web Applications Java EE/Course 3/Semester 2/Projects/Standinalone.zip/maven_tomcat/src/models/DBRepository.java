package models;

import java.util.List;

public interface DBRepository {

	public List<Product> getProducts();
	public void setProducts(List<Product> products);
	public Product addProduct(Product product);
}
