package models;

import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;


public class HibernateHelper implements DbOperations{
	private Session session = null;
	private CriteriaBuilder cb = null;
	//private final SessionFactory sf1 = new Configuration().configure().buildSessionFactory();
	private SessionFactory sf1 = null;
	private SessionFactory sf2 = null;
	
	public HibernateHelper() {
		SessionFactory sessionFactory = EntityManagerFactory.unwrap(SessionFactory.class);
		Configuration cfg1 = new Configuration();
		cfg1.configure("mysql.cfg.xml");
		
		this.sf1 = cfg1.buildSessionFactory();

		Configuration cfg2 = new Configuration();
		cfg2.configure("sqllite.cfg.xml");
		this.sf2 = cfg2.buildSessionFactory();
	}
	
	public void addGroup(Group group) {
		session = sf1.openSession();
		session.beginTransaction();
		
		session.save(group);
		
		session.getTransaction().commit();
		session.close();
	}
 
	public List<Element> getElements() {
		session = sf1.openSession();
		session.beginTransaction();
		
		cb = session.getCriteriaBuilder();
		CriteriaQuery<Element> cr = cb.createQuery(Element.class);
		Root<Element> root = cr.from(Element.class);
		cr.select(root);
		 
		Query<Element> query = session.createQuery(cr);
		List<Element> elements = query.getResultList();
		
		for (Element e : elements) {
			Hibernate.initialize(e.getProducts());
		}
		
		session.getTransaction().commit();
		session.close();
		return elements;
	}
 
	public Element addElement(Element element) {
		session = sf1.openSession();
		session.beginTransaction();
		
		session.save(element);
		
		session.getTransaction().commit();
		session.close();
		return element;
	}
 
	public Product updateProduct(Product product) {
		session = sf1.openSession();
		session.beginTransaction();

		session.update(product);
		
		session.getTransaction().commit();
		session.close();
		return product;
	}
 

 
	public List<Product> getProducts() {
		session = sf1.openSession();
		session.beginTransaction();
		
		cb = session.getCriteriaBuilder();
		CriteriaQuery<Product> cr = cb.createQuery(Product.class);
		Root<Product> root = cr.from(Product.class);
		cr.select(root);
		 
		Query<Product> query = session.createQuery(cr);
		List<Product> products = query.getResultList();
		
		for (Product p : products) {
			Hibernate.initialize(p.getElements());
			Hibernate.initialize(p.getGroup());
		}
		session.getTransaction().commit();
		session.close();
		return products;
	}
 
	public Product addProduct(Product product) {
		session = sf1.openSession();
		session.beginTransaction();
		
		session.save(product);
		
		session.getTransaction().commit();
		session.close();
		return product;
	}
 
	public List<User> getUsers() {
		session = sf2.openSession();
		session.beginTransaction();
		
		cb = session.getCriteriaBuilder();
		CriteriaQuery<User> cr = cb.createQuery(User.class);
		Root<User> root = cr.from(User.class);
		cr.select(root);
		 
		Query<User> query = session.createQuery(cr);
		List<User> users = query.getResultList();
		
		session.getTransaction().commit();
		session.close();
		return users;
	}
 
	public User addUser(User user) {
		session = sf2.openSession();
		session.beginTransaction();
		
		session.save(user);
		
		session.getTransaction().commit();
		session.close();
		return user;
	}

	@Override
	public Element deleteElement(int id) {
		session = sf1.openSession();
		session.beginTransaction();
		Element element = (Element) session.load(Element.class, id);
		
		session.delete(element);
		
		session.getTransaction().commit();
		session.close();
		return element;
	}

	@Override
	public Product deleteProduct(int id) {
		session = sf1.openSession();
		session.beginTransaction();

		Product product = (Product) session.load(Product.class, id);
		session.delete(product);
		
		session.getTransaction().commit();
		session.close();
		return product;
	}

	@Override
	public Element updateElement(Element element) {
		session = sf1.openSession();
		session.beginTransaction();
		
		session.update(element);
		
		session.getTransaction().commit();
		session.close();
		return element;
	}

	@Override
	public List<Group> getGroups() {
		session = sf1.openSession();
		session.beginTransaction();
		
		cb = session.getCriteriaBuilder();
		CriteriaQuery<Group> cr = cb.createQuery(Group.class);
		Root<Group> root = cr.from(Group.class);
		cr.select(root);
		 
		Query<Group> query = session.createQuery(cr);
		List<Group> groups = query.getResultList();
		
		for (Group g : groups) {
			Hibernate.initialize(g.getProducts());
		}
		session.getTransaction().commit();
		session.close();
		return groups;
	}

	@Override
	public void updateGroup(Group group) {
		session = sf1.openSession();
		session.beginTransaction();
		
		session.update(group);
		
		session.getTransaction().commit();
		session.close();
		
	}

	@Override
	public void deleteGroup(int id) {
		session = sf1.openSession();
		session.beginTransaction();

		Group group = (Group) session.load(Group.class, id);
		session.delete(group);
		
		session.getTransaction().commit();
		session.close();
	}

	@Override
	public List<Product> getProductsByGroupId(String groupId) {

		session = sf1.openSession();
		session.beginTransaction();
		
		cb = session.getCriteriaBuilder();
		CriteriaQuery<Product> cr = cb.createQuery(Product.class);
		Root<Product> root = cr.from(Product.class);
		cr.select(root).where(cb.equal(root.join("group").get("group_id"), Integer.parseInt(groupId)));
		 
		Query<Product> query = session.createQuery(cr);
		List<Product> results = query.getResultList();

		session.getTransaction().commit();
		session.close();
		return results;
	}
	
	public List<Product> getProductsByGroupName(String groupName) {

		session = sf1.openSession();
		session.beginTransaction();
		
		cb = session.getCriteriaBuilder();
		CriteriaQuery<Product> cr = cb.createQuery(Product.class);
		Root<Product> root = cr.from(Product.class);
		cr.select(root).where(cb.equal(root.join("group").get("name"), groupName));
		 
		Query<Product> query = session.createQuery(cr);
		List<Product> results = query.getResultList();

		session.getTransaction().commit();
		session.close();
		return results;
	}

	@Override
	public List<Group> findGroupsByText(String text) {
		session = sf1.openSession();
		session.beginTransaction();
		
		cb = session.getCriteriaBuilder();
		CriteriaQuery<Group> cr = cb.createQuery(Group.class);
		Root<Group> root = cr.from(Group.class);
		cr.select(root).where(cb.like(cb.upper(root.get("name")),  "%" + text.toUpperCase() + "%"));
		 
		Query<Group> query = session.createQuery(cr);
		List<Group> results = query.getResultList();

		session.getTransaction().commit();
		session.close();
		return results;
	}
	
	@Override
	public List<Product> findProductsByText(String text) {
		session = sf1.openSession();
		session.beginTransaction();
		
		cb = session.getCriteriaBuilder();
		CriteriaQuery<Product> cr = cb.createQuery(Product.class);
		Root<Product> root = cr.from(Product.class);
		cr.select(root).where(cb.like(cb.upper(root.get("Name")), "%" + text.toUpperCase() + "%"));
		 
		Query<Product> query = session.createQuery(cr);
		List<Product> results = query.getResultList();

		session.getTransaction().commit();
		session.close();
		return results;
	}
	

}
